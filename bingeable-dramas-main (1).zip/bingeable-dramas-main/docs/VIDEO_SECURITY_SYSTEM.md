# 🎥 Sistema de Hospedagem e Reprodução Segura de Vídeos - DramaFlix

## 📋 Índice
1. [Visão Geral](#visão-geral)
2. [Arquitetura](#arquitetura)
3. [Estrutura do Banco de Dados](#estrutura-do-banco-de-dados)
4. [Edge Functions](#edge-functions)
5. [Sistema Anti-Share](#sistema-anti-share)
6. [Prévia de 10 Minutos](#prévia-de-10-minutos)
7. [Player Seguro](#player-seguro)
8. [Como Usar](#como-usar)

---

## 🎯 Visão Geral

Sistema completo de hospedagem e reprodução segura de vídeos usando Lovable Cloud (Supabase), com:

- ✅ **Prévia de 10 minutos** para não assinantes
- ✅ **Acesso completo** para assinantes premium
- ✅ **URLs assinadas** com expiração automática
- ✅ **Proteção Anti-Share** contra compartilhamento de contas
- ✅ **Renovação automática** de URLs durante reprodução
- ✅ **Rastreamento de progresso** de visualização
- ✅ **Proteção contra download** e inspeção

---

## 🏗️ Arquitetura

### Componentes Principais

```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (React)                        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         SecureVideoPlayer Component                   │  │
│  │  • Fingerprinting de dispositivo                     │  │
│  │  • Renovação automática de URLs (60s)               │  │
│  │  • Rastreamento de progresso (5s)                   │  │
│  │  • Proteção contra download                         │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              Edge Functions (Supabase)                      │
│  ┌─────────────────────┐    ┌───────────────────────────┐  │
│  │ generate-video-url  │    │ track-video-progress      │  │
│  │ • Validação Auth    │    │ • Salvar posição         │  │
│  │ • Check assinatura  │    │ • Detectar limite 10min  │  │
│  │ • Anti-Share        │    │ • Atualizar histórico    │  │
│  │ • URL assinada      │    │                          │  │
│  └─────────────────────┘    └───────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   Supabase Storage                          │
│  • Bucket: videos (privado)                                │
│  • URLs assinadas com expiração                            │
│  • Proteção via RLS policies                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🗄️ Estrutura do Banco de Dados

### Tabela: `dramas` (atualizada)
```sql
- id: uuid (PK)
- title: text
- slug: text
- storage_path: text          -- Novo: caminho no bucket
- video_url: text             -- Existente: URL externa
- duration_seconds: integer   -- Novo: duração em segundos
- is_premium: boolean         -- Novo: requer assinatura
- cover_url, thumbnail_url, synopsis, genre, tags, etc.
```

### Tabela: `movie_views` (nova)
```sql
- id: uuid (PK)
- user_id: uuid (FK → auth.users)
- drama_id: uuid (FK → dramas)
- last_position_seconds: integer
- is_preview_finished: boolean
- preview_started_at: timestamptz
- created_at, updated_at: timestamptz

UNIQUE(user_id, drama_id)
```

### Tabela: `user_sessions` (nova)
```sql
- id: uuid (PK)
- user_id: uuid (FK → auth.users)
- session_token: text
- user_agent: text
- ip_hash: text               -- Hash SHA-256 do IP
- fingerprint: text           -- Fingerprint do dispositivo
- is_active: boolean
- last_activity_at: timestamptz
- created_at: timestamptz

UNIQUE(session_token)
```

### Storage Bucket: `videos`
```sql
- Não público (public: false)
- Tamanho máximo: 10GB por arquivo
- Tipos permitidos: video/mp4, video/webm, video/ogg
- Acesso apenas via URLs assinadas
```

---

## ⚡ Edge Functions

### 1. `generate-video-url`

**Propósito**: Gerar URLs assinadas com validação completa de segurança

**Fluxo**:
```
1. Verificar autenticação (JWT)
2. Buscar informações do filme
3. Verificar status de assinatura do usuário
4. Checar progresso de visualização (para preview)
5. Validar/Criar sessão (Anti-Share)
6. Gerar URL assinada (60s de validade)
7. Retornar URL + metadados
```

**Request**:
```json
{
  "dramaId": "uuid",
  "userAgent": "string",
  "fingerprint": "string"
}
```

**Response (Sucesso)**:
```json
{
  "videoUrl": "https://...signed-url",
  "expiresIn": 60,
  "isPreviewMode": true,
  "maxAllowedSeconds": 600,
  "currentPosition": 0,
  "requiresSubscription": true,
  "drama": {
    "id": "uuid",
    "title": "string",
    "durationSeconds": 3600
  }
}
```

**Response (Erro)**:
```json
{
  "error": "PREVIEW_FINISHED" | "ANTI_SHARE_TRIGGERED",
  "message": "string",
  "requiresSubscription": true,
  "requiresReLogin": false
}
```

---

### 2. `track-video-progress`

**Propósito**: Rastrear progresso de visualização e detectar limite de prévia

**Fluxo**:
```
1. Verificar autenticação
2. Salvar posição atual no banco
3. Detectar se atingiu 10 minutos (preview)
4. Marcar is_preview_finished se necessário
5. Atualizar user_dramas (Minha Lista)
```

**Request**:
```json
{
  "dramaId": "uuid",
  "currentPosition": 150,
  "totalDuration": 3600
}
```

**Response**:
```json
{
  "success": true,
  "currentPosition": 150,
  "isPreviewFinished": false,
  "remainingPreviewSeconds": 450
}
```

---

## 🛡️ Sistema Anti-Share

### Conceito
Previne compartilhamento de contas detectando múltiplos dispositivos/IPs diferentes.

### Funcionamento

1. **Fingerprinting de Dispositivo**
   ```typescript
   const fingerprint = SHA-256(
     userAgent +
     language +
     timezone +
     screenResolution +
     colorDepth
   )
   ```

2. **Controle de Sessões**
   - Máximo de **2 sessões ativas** por usuário
   - Sessão mais antiga é desativada automaticamente
   - Validação a cada chamada

3. **Detecção de Mudanças**
   ```typescript
   if (ipHash !== session.ip_hash || 
       userAgent !== session.user_agent) {
     // ANTI_SHARE_TRIGGERED
     invalidateSession();
     return 403;
   }
   ```

4. **Ações ao Detectar Compartilhamento**
   - Invalidar sessão suspeita
   - Bloquear geração de novas URLs
   - Forçar re-login do usuário

---

## ⏱️ Prévia de 10 Minutos

### Para Não Assinantes

1. **Primeiro Acesso**
   - Criar registro em `movie_views`
   - Definir `preview_started_at`
   - Permitir reprodução

2. **Durante Reprodução**
   - Rastrear progresso a cada 5 segundos
   - Calcular tempo restante
   - Exibir contador na tela

3. **Ao Atingir 10 Minutos (600s)**
   - Marcar `is_preview_finished = true`
   - Pausar vídeo automaticamente
   - Exibir paywall no player
   - Bloquear novas URLs assinadas

4. **Após Limite**
   - Todas as chamadas para `generate-video-url` retornam erro `PREVIEW_FINISHED`
   - Usuário deve assinar para continuar

### Para Assinantes

- Sem limites de tempo
- Acesso completo ao catálogo
- URLs renovadas normalmente

---

## 🎬 Player Seguro

### Componente: `SecureVideoPlayer`

**Características**:

1. **URLs Assinadas**
   - Renovação automática a cada 50 segundos
   - Expiração de 60 segundos
   - Sem exposição de URLs reais

2. **Rastreamento Automático**
   - Progresso salvo a cada 5 segundos
   - Restauração de posição ao voltar
   - Sincronização com servidor

3. **Proteção Anti-Download**
   ```typescript
   - Desabilitar botão direito
   - Bloquear F12, CTRL+S, CTRL+U
   - controlsList="nodownload"
   - Sem drag-and-drop
   ```

4. **Interface de Prévia**
   - Contador regressivo visível
   - Paywall automático ao encerrar
   - Botão "Assinar Premium" integrado

---

## 📖 Como Usar

### 1. Upload de Vídeos (Admin)

```typescript
// Via Supabase Storage API
const { data, error } = await supabase.storage
  .from('videos')
  .upload(`movies/${movieId}/source.mp4`, file);

// Cadastrar no banco
await supabase.from('dramas').insert({
  title: "Nome do Filme",
  slug: "nome-do-filme",
  storage_path: `movies/${movieId}/source.mp4`,
  duration_seconds: 3600,
  is_premium: true
});
```

### 2. Reprodução no Frontend

```tsx
import SecureVideoPlayer from "@/components/SecureVideoPlayer";

<SecureVideoPlayer
  dramaId={movie.id}
  dramaTitle={movie.title}
  coverUrl={movie.cover_url}
  onPreviewFinished={() => {
    // Callback quando prévia acabar
  }}
/>
```

### 3. Verificar Progresso

```typescript
const { data } = await supabase
  .from('movie_views')
  .select('*')
  .eq('user_id', userId)
  .eq('drama_id', dramaId)
  .single();

console.log(`Posição: ${data.last_position_seconds}s`);
console.log(`Prévia acabou: ${data.is_preview_finished}`);
```

### 4. Gerenciar Sessões (Admin)

```typescript
// Ver sessões ativas
const { data } = await supabase
  .from('user_sessions')
  .select('*')
  .eq('user_id', userId)
  .eq('is_active', true);

// Invalidar sessão
await supabase
  .from('user_sessions')
  .update({ is_active: false })
  .eq('id', sessionId);

// Limpar sessões antigas (executar periodicamente)
await supabase.rpc('cleanup_inactive_sessions');
```

---

## 🔒 Políticas de Segurança (RLS)

### Storage: `videos`
```sql
-- Acesso via URLs assinadas apenas
SELECT: authenticated users
INSERT: apenas admins
UPDATE: apenas admins
DELETE: apenas admins
```

### Tabela: `movie_views`
```sql
SELECT: próprio usuário ou admins
INSERT: próprio usuário
UPDATE: próprio usuário
```

### Tabela: `user_sessions`
```sql
SELECT: próprio usuário ou admins
INSERT: próprio usuário
UPDATE: próprio usuário
DELETE: apenas admins
```

---

## 🚀 Próximos Passos

1. **Upload em Lote**
   - Interface admin para múltiplos uploads
   - Processamento em background
   - Geração automática de thumbnails

2. **Análise de Vídeo**
   - Detecção automática de duração
   - Extração de thumbnails
   - Geração de previews

3. **Métricas e Analytics**
   - Dashboard de visualizações
   - Relatórios de uso
   - Detecção de padrões suspeitos

4. **CDN e Performance**
   - Integração com CDN
   - Compressão adaptativa
   - Múltiplas qualidades

---

## 📞 Suporte

Para dúvidas ou problemas:
- Verifique os logs das Edge Functions no Lovable Cloud
- Consulte a documentação do Supabase Storage
- Entre em contato com o time de desenvolvimento

---

**Desenvolvido com ❤️ para DramaFlix**
