import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, cache-control, pragma, expires',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const checkoutSessionId = url.searchParams.get('checkout_session_id');

    console.log('🔍 === CHECK CHECKOUT SESSION STATUS ===');
    console.log('📍 Checkout Session ID:', checkoutSessionId);

    if (!checkoutSessionId) {
      console.error('❌ Checkout session ID missing!');
      return new Response(
        JSON.stringify({ error: 'Missing checkout_session_id parameter' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Buscar checkout_session por ID
    console.log('🔎 Searching checkout_session...');
    const { data: checkoutSession, error: sessionError } = await supabase
      .from('checkout_sessions')
      .select('status, items')
      .eq('id', checkoutSessionId)
      .maybeSingle();

    if (sessionError) {
      console.error('❌ Error querying checkout_session:', sessionError);
    }

    if (!checkoutSession) {
      console.log('❌ Checkout session not found');
      return new Response(
        JSON.stringify({ status: 'pending', purchasedDramaId: null }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Extract drama_id from items
    const items = checkoutSession.items as Array<{ drama_id: string }>;
    const purchasedDramaId = items?.[0]?.drama_id || null;

    console.log('✅ === RESULT ===');
    console.log('Status:', checkoutSession.status);
    console.log('Drama ID:', purchasedDramaId);
    console.log('=================');

    return new Response(
      JSON.stringify({ 
        status: checkoutSession.status,
        purchasedDramaId 
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('💥 CRITICAL ERROR:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

/*
POSTMAN TEST for /functions/v1/check-transaction-status:
GET /functions/v1/check-transaction-status?checkout_session_id=<uuid-da-sessao>

Nota: Substitua <uuid-da-sessao> por um ID válido de checkout_sessions
*/