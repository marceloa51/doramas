import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Gera CPF matematicamente válido
function generateValidCPF(): string {
  const randomDigits: number[] = [];
  for (let i = 0; i < 9; i++) {
    randomDigits.push(Math.floor(Math.random() * 9) + 1);
  }
  
  // Calcula primeiro dígito verificador
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += randomDigits[i] * (10 - i);
  }
  let firstVerifier = 11 - (sum % 11);
  if (firstVerifier >= 10) firstVerifier = 0;
  
  // Calcula segundo dígito verificador
  sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += randomDigits[i] * (11 - i);
  }
  sum += firstVerifier * 2;
  let secondVerifier = 11 - (sum % 11);
  if (secondVerifier >= 10) secondVerifier = 0;
  
  return [...randomDigits, firstVerifier, secondVerifier].join('');
}

// Bestfy API client
class BestfyClient {
  private secretKey: string;
  private baseURL: string;

  constructor(secretKey: string) {
    this.secretKey = secretKey;
    this.baseURL = 'https://api.bestfybr.com.br/v1';
  }

  private getAuthHeader(): string {
    const credentials = btoa(`${this.secretKey}:x`);
    return `Basic ${credentials}`;
  }

  async createTransaction(payload: any) {
    console.log('📤 Sending request to Bestfy:', JSON.stringify(payload, null, 2));
    
    const response = await fetch(`${this.baseURL}/transactions`, {
      method: 'POST',
      headers: {
        'Authorization': this.getAuthHeader(),
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const responseText = await response.text();
    console.log('📥 Bestfy raw response:', responseText);

    if (!response.ok) {
      throw new Error(`Bestfy API error: ${response.status} - ${responseText}`);
    }

    return JSON.parse(responseText);
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== CREATE FULL ACCESS PAYMENT ===');
    
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const BESTFY_SECRET_KEY = Deno.env.get('BESTFY_SECRET_KEY')!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const bestfyClient = new BestfyClient(BESTFY_SECRET_KEY);

    const { customerName, customerCpf, userId, visitor_id, paymentMethod, cardToken, cardData } = await req.json();
    console.log('Request data:', { customerName, customerCpf: customerCpf ? 'provided' : 'missing', userId: userId ? 'logged' : 'anonymous', visitor_id, paymentMethod, hasToken: !!cardToken, hasCardData: !!cardData });

    if (!customerName) {
      return new Response(JSON.stringify({ error: 'Customer name is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fixed price for 30-day full access
    const FULL_ACCESS_PRICE = 24.90;
    const priceInCents = Math.round(FULL_ACCESS_PRICE * 100);

    // Generate unique reference ID
    const referenceId = `FULLACCESS_${crypto.randomUUID()}`;
    console.log('Generated reference ID:', referenceId);

    // Create checkout session
    const checkoutItems = [{
      type: 'full_access_30_days',
      title: 'Acesso Completo 30 Dias',
      price: FULL_ACCESS_PRICE,
      quantity: 1
    }];

    const { data: checkoutSession, error: checkoutError } = await supabase
      .from('checkout_sessions')
      .insert({
        reference_id: referenceId,
        amount: FULL_ACCESS_PRICE,
        items: checkoutItems,
        customer_name: customerName,
        visitor_id: visitor_id || null,
        status: 'pending',
        currency: 'BRL',
        payment_method: paymentMethod === 'credit_card' ? 'credit_card' : 'pix'
      })
      .select()
      .single();

    if (checkoutError || !checkoutSession) {
      console.error('Error creating checkout session:', checkoutError);
      return new Response(JSON.stringify({ error: 'Failed to create checkout session' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Created checkout session:', checkoutSession.id);

    // Create transaction record
    const { data: transaction, error: transactionError } = await supabase
      .from('transactions')
      .insert({
        user_id: userId || null,
        amount: FULL_ACCESS_PRICE,
        payment_method: paymentMethod === 'credit_card' ? 'card' : 'pix',
        status: 'pending',
        checkout_session_id: checkoutSession.id,
        external_id: referenceId,
        currency: 'BRL',
        metadata: {
          purchase_type: 'full_access_30_days',
          customer_name: customerName,
          visitor_id: visitor_id
        }
      })
      .select()
      .single();

    if (transactionError || !transaction) {
      console.error('Error creating transaction:', transactionError);
      return new Response(JSON.stringify({ error: 'Failed to create transaction' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Created transaction:', transaction.id);

    // Create payment with Bestfy
    // Gerar CPF válido automaticamente
    const cpfToUse = generateValidCPF();
    console.log('🆔 Generated valid CPF for Bestfy');
    
    let paymentPayload: any = {
      amount: priceInCents,
      externalRef: referenceId,
      customer: {
        name: customerName,
        email: `${referenceId}@checkout.doramassuper.site`,
        phone: customerName.replace(/\D/g, '') || '11999999999',
        document: {
          type: 'cpf',
          number: cpfToUse,
        },
      },
      items: [{
        title: 'Acesso Completo 30 Dias - Doramas Super',
        description: 'Acesso ilimitado a todos os doramas por 30 dias',
        quantity: 1,
        tangible: false,
        unitPrice: priceInCents,
      }],
      postbackUrl: `${SUPABASE_URL}/functions/v1/webhook-bestfy`,
    };

    if (paymentMethod === 'credit_card') {
      paymentPayload.paymentMethod = 'credit_card';
      paymentPayload.installments = 1;
      
      // Validar se cardToken é uma string real (não objeto vazio, não undefined)
      const isValidToken = cardToken && typeof cardToken === 'string' && cardToken.length > 10;
      
      if (isValidToken) {
        paymentPayload.card = { token: cardToken };
        console.log('Using valid card token for payment, length:', cardToken.length);
      } else if (cardData) {
        // Fallback: usar dados brutos sanitizados
        console.log('cardToken invalid/empty, using raw cardData. Token was:', typeof cardToken, cardToken);
        paymentPayload.card = {
          number: String(cardData.number).replace(/\D/g, ''),
          holderName: String(cardData.holderName).trim().toUpperCase().slice(0, 100),
          expirationMonth: parseInt(String(cardData.expirationMonth), 10),
          expirationYear: parseInt(String(cardData.expirationYear), 10),
          cvv: String(cardData.cvv).replace(/\D/g, '').slice(0, 4),
        };
        console.log('Using raw card data for payment (sanitized)');
      } else {
        throw new Error('Credit card payment requires valid cardToken or cardData');
      }
    } else {
      paymentPayload.paymentMethod = 'pix';
      paymentPayload.pix = { expiresInDays: 1 };
    }

    console.log('Sending payment request to Bestfy...');
    const bestfyResponse = await bestfyClient.createTransaction(paymentPayload);
    console.log('Bestfy response received:', JSON.stringify(bestfyResponse, null, 2));

    // Extract PIX data
    const pixData = bestfyResponse.pix || bestfyResponse.data?.pix || {};
    const pixCode = pixData.qrcode || pixData.qrCode || bestfyResponse.qrCode || bestfyResponse.qrcode;
    const secureUrl = bestfyResponse.secureUrl || bestfyResponse.secure_url || bestfyResponse.data?.secureUrl;

    // Update checkout session with payment details
    await supabase
      .from('checkout_sessions')
      .update({
        pix_code: pixCode,
        checkout_url: secureUrl,
      })
      .eq('id', checkoutSession.id);

    // Verificar status para cartão de crédito
    if (paymentMethod === 'credit_card') {
      const cardStatus = bestfyResponse.status || bestfyResponse.data?.status;
      console.log('💳 Card payment status from Bestfy:', cardStatus);
      
      // Se RECUSADO/FALHOU - retornar erro
      if (cardStatus === 'refused' || cardStatus === 'failed' || cardStatus === 'canceled') {
        console.log('❌ Payment REFUSED by Bestfy');
        
        // Atualizar status para cancelado/falha
        await supabase
          .from('checkout_sessions')
          .update({ status: 'canceled' })
          .eq('id', checkoutSession.id);

        await supabase
          .from('transactions')
          .update({ status: 'failed', updated_at: new Date().toISOString() })
          .eq('external_id', referenceId);

        const refusedReason = bestfyResponse.refusedReason?.description || 
                              bestfyResponse.statusReason || 
                              bestfyResponse.data?.refusedReason?.description ||
                              'Pagamento não autorizado pela operadora';
        
        return new Response(JSON.stringify({
          success: false,
          error: refusedReason,
          status: 'refused',
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        });
      }
      
      // Se APROVADO - ativar acesso
      if (cardStatus === 'paid' || cardStatus === 'authorized') {
        console.log('✅ Payment APPROVED by Bestfy');
        
        await supabase
          .from('checkout_sessions')
          .update({ status: 'paid', paid_at: new Date().toISOString() })
          .eq('id', checkoutSession.id);

        await supabase
          .from('transactions')
          .update({ status: 'paid', updated_at: new Date().toISOString() })
          .eq('external_id', referenceId);

        // Activate full access for logged user
        if (userId) {
          const planExpiresAt = new Date();
          planExpiresAt.setDate(planExpiresAt.getDate() + 30);

          await supabase
            .from('profiles')
            .update({
              plan_status: 'active',
              plan_renews_at: planExpiresAt.toISOString(),
            })
            .eq('id', userId);
        }

        return new Response(JSON.stringify({
          success: true,
          status: 'paid',
          checkoutSessionId: checkoutSession.id,
          transactionId: transaction.id,
          referenceId: referenceId,
          amount: FULL_ACCESS_PRICE,
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        });
      }
      
      // Se PENDENTE - informar que está processando
      console.log('⏳ Payment PENDING, waiting for webhook');
      return new Response(JSON.stringify({
        success: true,
        status: 'pending',
        message: 'Pagamento em processamento',
        checkoutSessionId: checkoutSession.id,
        transactionId: transaction.id,
        referenceId: referenceId,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Para PIX, retornar dados do código
    console.log('📱 PIX payment created successfully');
    return new Response(JSON.stringify({
      success: true,
      status: 'pending',
      checkoutSessionId: checkoutSession.id,
      transactionId: transaction.id,
      referenceId: referenceId,
      amount: FULL_ACCESS_PRICE,
      pixCode: pixCode,
      checkoutUrl: secureUrl,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (error: unknown) {
    console.error('Error in create-fullaccess-payment:', error);
    const errorMessage = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: errorMessage 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
