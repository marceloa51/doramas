import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Normalizar telefone para formato 55XXXXXXXXXXX
function normalizePhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('55')) return digits;
  return `55${digits}`;
}

// Validar telefone (deve ter 12-13 dígitos após normalização)
function isValidPhone(phone: string): boolean {
  const normalized = normalizePhone(phone);
  return normalized.length >= 12 && normalized.length <= 13;
}

// Gerar OTP de 4 dígitos (1000-9999)
function generateOTP(): string {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  const otp = 1000 + (array[0] % 9000);
  return otp.toString();
}

// Hash simples do OTP (em produção usar bcrypt)
async function hashOTP(otp: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp + Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'));
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Enviar WhatsApp via Z-API
async function sendWhatsApp(phone: string, message: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
  const instanceId = Deno.env.get('ZAPI_INSTANCE_ID');
  const instanceToken = Deno.env.get('ZAPI_INSTANCE_TOKEN');
  const clientToken = Deno.env.get('ZAPI_CLIENT_TOKEN');

  if (!instanceId || !instanceToken) {
    console.error('[password-reset-request] Z-API credentials not configured');
    return { success: false, error: 'WhatsApp service not configured' };
  }

  const url = `https://api.z-api.io/instances/${instanceId}/token/${instanceToken}/send-text`;
  
  try {
    console.log(`[password-reset-request] Sending WhatsApp to ${phone}`);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': clientToken || '',
      },
      body: JSON.stringify({
        phone: phone,
        message: message,
      }),
    });

    const data = await response.json();
    console.log('[password-reset-request] Z-API response:', JSON.stringify(data));

    if (response.ok && data.zapiMessageId) {
      return { success: true, messageId: data.zapiMessageId };
    }

    return { success: false, error: data.message || 'Failed to send message' };
  } catch (error: any) {
    console.error('[password-reset-request] Error sending WhatsApp:', error);
    return { success: false, error: error?.message || 'Unknown error' };
  }
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { phone } = await req.json();
    
    if (!phone) {
      return new Response(
        JSON.stringify({ ok: false, code: 'MISSING_PHONE', message: 'Telefone é obrigatório' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const normalizedPhone = normalizePhone(phone);
    console.log(`[password-reset-request] Phone: ${phone} -> Normalized: ${normalizedPhone}`);

    if (!isValidPhone(phone)) {
      return new Response(
        JSON.stringify({ ok: false, code: 'INVALID_PHONE', message: 'Telefone inválido' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Criar cliente Supabase com service_role
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Rate limit: máximo 3 pedidos em 15 minutos
    const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { count: recentRequests } = await supabase
      .from('password_reset_requests')
      .select('*', { count: 'exact', head: true })
      .eq('phone', normalizedPhone)
      .gte('created_at', fifteenMinutesAgo);

    console.log(`[password-reset-request] Recent requests for ${normalizedPhone}: ${recentRequests}`);

    if (recentRequests && recentRequests >= 3) {
      return new Response(
        JSON.stringify({ ok: false, code: 'RATE_LIMITED', message: 'Muitas tentativas. Aguarde alguns minutos.' }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar se existe usuário com esse telefone
    // Email no banco está no formato: telefone@doramassuper.internal (sem o 55)
    const phoneDigits = phone.replace(/\D/g, ''); // Remove formatação, mantém sem 55
    const emailPattern = `${phoneDigits}@doramassuper.internal`;
    
    console.log(`[password-reset-request] Email pattern: ${emailPattern}`);
    
    const { data: existingUser, error: userError } = await supabase
      .from('profiles')
      .select('id, email')
      .eq('email', emailPattern)
      .maybeSingle();

    console.log(`[password-reset-request] User lookup:`, existingUser ? 'Found' : 'Not found');

    // SEGURANÇA: Não revelar se usuário existe
    // Sempre retornar sucesso mesmo se não existir (mas não enviar código)
    
    // Gerar OTP
    const otp = generateOTP();
    const otpHash = await hashOTP(otp);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutos

    console.log(`[password-reset-request] Generated OTP for ${normalizedPhone}`);

    // Salvar no banco
    const { data: resetRequest, error: insertError } = await supabase
      .from('password_reset_requests')
      .insert({
        phone: normalizedPhone,
        otp_hash: otpHash,
        expires_at: expiresAt.toISOString(),
        ip_address: req.headers.get('x-forwarded-for') || req.headers.get('cf-connecting-ip') || 'unknown',
      })
      .select('id')
      .single();

    if (insertError) {
      console.error('[password-reset-request] Insert error:', insertError);
      return new Response(
        JSON.stringify({ ok: false, code: 'SERVER_ERROR', message: 'Erro interno' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Se usuário existe, enviar código via WhatsApp
    if (existingUser) {
      const message = `🔐 Código de verificação (Doramas Super)

Seu código para redefinir a senha é: ${otp}

Ele expira em 10 minutos.

Se você não solicitou isso, ignore esta mensagem.`;

      const whatsappResult = await sendWhatsApp(normalizedPhone, message);
      
      if (!whatsappResult.success) {
        console.error('[password-reset-request] WhatsApp send failed:', whatsappResult.error);
        // Mesmo se falhar, retornar sucesso para não revelar se número existe
      } else {
        console.log(`[password-reset-request] WhatsApp sent successfully: ${whatsappResult.messageId}`);
      }
    }

    // Sempre retornar sucesso (não revelar se usuário existe)
    return new Response(
      JSON.stringify({
        ok: true,
        requestId: resetRequest.id,
        expiresAt: expiresAt.getTime(),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[password-reset-request] Error:', error);
    return new Response(
      JSON.stringify({ ok: false, code: 'SERVER_ERROR', message: 'Erro interno' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
