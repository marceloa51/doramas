import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Não autenticado' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { sessionId } = await req.json();

    console.log(`[invalidate-session] Invalidating session for user ${user.id.slice(0, 8)}...`);

    // Hash the session ID to match stored format
    const hashedSessionId = sessionId ? await hashString(sessionId) : null;

    // 1. Mark session as inactive using hashed token
    if (hashedSessionId) {
      await supabaseClient
        .from('user_sessions')
        .update({ is_active: false })
        .eq('user_id', user.id)
        .eq('session_token', hashedSessionId);
    }

    // 2. Clear current_session_id from profiles
    await supabaseClient
      .from('profiles')
      .update({ current_session_id: null })
      .eq('id', user.id);

    console.log(`[invalidate-session] Session invalidated successfully`);

    return new Response(
      JSON.stringify({ success: true }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('[invalidate-session] Error:', error.message);
    return new Response(
      JSON.stringify({ error: 'Erro interno' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function hashString(str: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}
