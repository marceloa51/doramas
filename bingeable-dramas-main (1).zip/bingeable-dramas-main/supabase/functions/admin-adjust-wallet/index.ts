import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.81.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verificar autenticação
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Unauthorized');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    // Verificar se é admin
    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    const isAdmin = roles?.some((r) => r.role === 'admin');
    if (!isAdmin) {
      throw new Error('Forbidden: Admin access required');
    }

    const { 
      userId, 
      adjustments, 
      reason 
    } = await req.json();

    console.log('Admin adjustment request:', { userId, adjustments, adminId: user.id });

    if (!userId || !reason || !adjustments) {
      throw new Error('Missing required fields');
    }

    // Buscar wallet e profile atuais
    const { data: wallet, error: walletError } = await supabase
      .from('wallets')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (walletError) {
      throw new Error(`Wallet not found: ${walletError.message}`);
    }

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('referral_count')
      .eq('id', userId)
      .single();

    if (profileError) {
      throw new Error(`Profile not found: ${profileError.message}`);
    }

    // Aplicar ajustes
    const updates: any = {};
    const transactions: any[] = [];

    // Ajuste de saldo disponível
    if (adjustments.available_balance !== undefined && adjustments.available_balance !== 0) {
      const newBalance = Number(wallet.available_balance) + Number(adjustments.available_balance);
      if (newBalance < 0) {
        throw new Error('Saldo disponível não pode ser negativo');
      }
      updates.available_balance = newBalance;

      // Registrar transação
      transactions.push({
        user_id: userId,
        type: 'ADMIN_ADJUSTMENT',
        amount: adjustments.available_balance,
        description: `Ajuste manual pelo admin: ${reason}`
      });
    }

    // Ajuste de total ganho
    if (adjustments.total_earned !== undefined && adjustments.total_earned !== 0) {
      const newEarned = Number(wallet.total_earned) + Number(adjustments.total_earned);
      if (newEarned < 0) {
        throw new Error('Total ganho não pode ser negativo');
      }
      updates.total_earned = newEarned;
    }

    // Ajuste de total sacado
    if (adjustments.total_withdrawn !== undefined && adjustments.total_withdrawn !== 0) {
      const newTotal = Number(wallet.total_withdrawn) + Number(adjustments.total_withdrawn);
      if (newTotal < 0) {
        throw new Error('Total sacado não pode ser negativo');
      }
      updates.total_withdrawn = newTotal;
    }

    // Atualizar wallet
    if (Object.keys(updates).length > 0) {
      updates.updated_at = new Date().toISOString();
      
      const { error: updateError } = await supabase
        .from('wallets')
        .update(updates)
        .eq('user_id', userId);

      if (updateError) {
        throw new Error(`Failed to update wallet: ${updateError.message}`);
      }
    }

    // Inserir transações
    if (transactions.length > 0) {
      const { error: transactionError } = await supabase
        .from('wallet_transactions')
        .insert(transactions);

      if (transactionError) {
        console.error('Failed to create transaction:', transactionError);
      }
    }

    // Ajuste de contagem de referrals no profile
    if (adjustments.referral_count !== undefined && adjustments.referral_count !== 0) {
      const newReferralCount = Number(profile.referral_count || 0) + Number(adjustments.referral_count);
      if (newReferralCount < 0) {
        throw new Error('Contagem de referrals não pode ser negativa');
      }

      const { error: profileUpdateError } = await supabase
        .from('profiles')
        .update({ referral_count: newReferralCount })
        .eq('id', userId);

      if (profileUpdateError) {
        throw new Error(`Failed to update referral count: ${profileUpdateError.message}`);
      }
    }

    console.log('Wallet adjusted successfully for user:', userId);

    return new Response(
      JSON.stringify({ 
        success: true,
        message: 'Carteira ajustada com sucesso'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error in admin-adjust-wallet:', error);
    const errorMessage = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ 
        error: errorMessage
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: errorMessage === 'Unauthorized' ? 401 : (errorMessage.includes('Forbidden') ? 403 : 500)
      }
    );
  }
});
