import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface UserPlan {
  id: string;
  email: string;
  plan_status: string;
  plan_renews_at: string;
}

function normalizePhone(phone: string): string {
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = cleaned.substring(1);
  }
  if (!cleaned.startsWith('55')) {
    cleaned = '55' + cleaned;
  }
  return cleaned;
}

function extractPhoneFromEmail(email: string): string | null {
  // Format: {phone}@doramassuper.internal
  if (email.includes('@doramassuper.internal')) {
    const phone = email.split('@')[0];
    if (/^\d+$/.test(phone)) {
      return normalizePhone(phone);
    }
  }
  return null;
}

async function sendWhatsApp(phone: string, message: string): Promise<boolean> {
  const instanceId = Deno.env.get('ZAPI_INSTANCE_ID');
  const instanceToken = Deno.env.get('ZAPI_INSTANCE_TOKEN');
  const clientToken = Deno.env.get('ZAPI_CLIENT_TOKEN');

  if (!instanceId || !instanceToken) {
    console.error('Z-API credentials not configured');
    return false;
  }

  try {
    const response = await fetch(
      `https://api.z-api.io/instances/${instanceId}/token/${instanceToken}/send-text`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Client-Token': clientToken || '',
        },
        body: JSON.stringify({
          phone: phone,
          message: message,
        }),
      }
    );

    const result = await response.json();
    console.log(`WhatsApp sent to ${phone}:`, result);
    return response.ok;
  } catch (error) {
    console.error(`Failed to send WhatsApp to ${phone}:`, error);
    return false;
  }
}

function getExpiryMessage(daysUntilExpiry: number): { message: string; eventType: string } | null {
  // 2-3 days before expiry
  if (daysUntilExpiry >= 2 && daysUntilExpiry <= 3) {
    return {
      eventType: 'plan_expiring_3d',
      message: `Oii! 👋

Passando pra te lembrar que seu acesso ao *Doramas Super+* vence em *${daysUntilExpiry} dias* 📅

Pra continuar assistindo todos os doramas sem interrupção, renove agora:
👉 https://doramassuper.site/vip

Qualquer dúvida, estamos aqui! 💜`
    };
  }

  // 1 day before or same day
  if (daysUntilExpiry === 1 || daysUntilExpiry === 0) {
    return {
      eventType: 'plan_expiring_1d',
      message: daysUntilExpiry === 1 
        ? `Ei! 😊

Seu acesso ao *Doramas Super+* vence *amanhã*! ⏰

Não deixe pra última hora - renove agora:
👉 https://doramassuper.site/vip

Te esperamos lá! 💜`
        : `Ei! 😊

Seu acesso ao *Doramas Super+* vence *hoje*! ⏰

Renove agora pra não perder seus doramas:
👉 https://doramassuper.site/vip

Te esperamos lá! 💜`
    };
  }

  if (daysUntilExpiry <= 0) {
    return {
      eventType: 'plan_expired',
      message: `Oii! 💔

Sentimos sua falta! Seu acesso ao *Doramas Super+* venceu.

Reative agora e volte a assistir todos os doramas:
👉 https://doramassuper.site/vip

Esperamos você de volta! 💜`
    };
  }

  return null;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const now = new Date();
    console.log(`[${now.toISOString()}] Starting plan expiry check...`);

    // First, update expired plans to 'canceled' status (expired not in enum)
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ plan_status: 'canceled' })
      .eq('plan_status', 'active')
      .lt('plan_renews_at', now.toISOString());

    if (updateError) {
      console.error('Error updating expired plans:', updateError);
    } else {
      console.log('Updated expired plans to expired status');
    }

    // Fetch users with active plans or recently canceled (within last 14 days for catch-up)
    const fourteenDaysAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
    
    const { data: users, error: fetchError } = await supabase
      .from('profiles')
      .select('id, email, plan_status, plan_renews_at')
      .not('plan_renews_at', 'is', null)
      .or(`plan_status.eq.active,and(plan_status.eq.canceled,plan_renews_at.gte.${fourteenDaysAgo.toISOString()})`);

    if (fetchError) {
      console.error('Error fetching users:', fetchError);
      return new Response(JSON.stringify({ error: fetchError.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Found ${users?.length || 0} users to check`);

    let sent = 0;
    let skipped = 0;
    let errors = 0;

    for (const user of users || []) {
      const phone = extractPhoneFromEmail(user.email);
      if (!phone) {
        console.log(`No phone for user ${user.id} (email: ${user.email})`);
        skipped++;
        continue;
      }

      const expiryDate = new Date(user.plan_renews_at);
      const diffTime = expiryDate.getTime() - now.getTime();
      const daysUntilExpiry = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      console.log(`User ${user.id}: ${daysUntilExpiry} days until expiry`);

      const messageData = getExpiryMessage(daysUntilExpiry);
      if (!messageData) {
        console.log(`No message needed for ${daysUntilExpiry} days`);
        continue;
      }

      // Check if we already sent this type of message
      const { data: existingEvent } = await supabase
        .from('whatsapp_events')
        .select('id')
        .eq('phone', phone)
        .eq('event_type', messageData.eventType)
        .gte('created_at', new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString())
        .maybeSingle();

      if (existingEvent) {
        console.log(`Already sent ${messageData.eventType} to ${phone}`);
        skipped++;
        continue;
      }

      // Send the message
      const success = await sendWhatsApp(phone, messageData.message);

      // Log the event
      await supabase.from('whatsapp_events').insert({
        phone,
        event_type: messageData.eventType,
        message: messageData.message,
        status: success ? 'sent' : 'failed',
        metadata: { user_id: user.id, days_until_expiry: daysUntilExpiry }
      });

      if (success) {
        sent++;
        console.log(`✓ Sent ${messageData.eventType} to ${phone}`);
      } else {
        errors++;
        console.log(`✗ Failed to send ${messageData.eventType} to ${phone}`);
      }
    }

    const summary = { checked: users?.length || 0, sent, skipped, errors };
    console.log('Plan expiry check complete:', summary);

    return new Response(JSON.stringify({ success: true, ...summary }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    console.error('Error in check-plan-expiry:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
