import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const url = new URL(req.url);
    const visitorId = url.searchParams.get('visitor_id');

    if (!visitorId) {
      return new Response(JSON.stringify({ error: 'visitor_id is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('🔍 Fetching orders for visitor:', visitorId);

    // Buscar todas as checkout_sessions deste visitor
    const { data: sessions, error: sessionsError } = await supabase
      .from('checkout_sessions')
      .select('*')
      .eq('visitor_id', visitorId)
      .order('created_at', { ascending: false });

    if (sessionsError) {
      console.error('Error fetching sessions:', sessionsError);
      throw sessionsError;
    }

    const paidOrdersWithoutUser: any[] = [];
    const pendingOrders: any[] = [];
    const expiredOrders: any[] = [];

    // Processar cada sessão
    for (const session of sessions || []) {
      // Caso 1: Ordens PAGAS sem conta criada (sem user_purchases)
      if (session.status === 'paid') {
        const items = session.items as Array<{ drama_id: string; title: string; price: number }>;
        
        // Verificar se existe user_purchase para algum item
        let hasUserPurchase = false;
        for (const item of items) {
          const { data: purchase } = await supabase
            .from('user_purchases')
            .select('id')
            .eq('drama_id', item.drama_id)
            .limit(1)
            .maybeSingle();
          
          if (purchase) {
            hasUserPurchase = true;
            break;
          }
        }

        if (!hasUserPurchase) {
          paidOrdersWithoutUser.push(session);
        }
      }

      // Caso 2: Ordens PENDENTES recentes (< 24h)
      if (session.status === 'pending') {
        const createdAt = new Date(session.created_at);
        const now = new Date();
        const hoursDiff = (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60);

        if (hoursDiff < 24) {
          pendingOrders.push(session);
        }
      }

      // Caso 3: Ordens EXPIRADAS recentes (< 2h) - para notificar usuário
      if (session.status === 'expired') {
        const createdAt = new Date(session.created_at);
        const now = new Date();
        const hoursDiff = (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60);

        if (hoursDiff < 2) {
          expiredOrders.push(session);
        }
      }
    }

    console.log('✅ Orders found:', {
      paidWithoutUser: paidOrdersWithoutUser.length,
      pending: pendingOrders.length,
      expired: expiredOrders.length,
    });

    return new Response(
      JSON.stringify({
        paidOrdersWithoutUser,
        pendingOrders,
        expiredOrders,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Unexpected error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
