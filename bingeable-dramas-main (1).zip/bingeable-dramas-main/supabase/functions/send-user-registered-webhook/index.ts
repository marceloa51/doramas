import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Função para normalizar telefone
const normalizePhone = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('5555')) {
    return digits.slice(2);
  }
  return digits.startsWith('55') ? digits : `55${digits}`;
};

// Função central para enviar WhatsApp via Z-API
const sendWhatsApp = async (phone: string, message: string): Promise<{ success: boolean; messageId?: string; error?: string }> => {
  const instanceId = Deno.env.get('ZAPI_INSTANCE_ID');
  const instanceToken = Deno.env.get('ZAPI_INSTANCE_TOKEN');
  const clientToken = Deno.env.get('ZAPI_CLIENT_TOKEN');

  if (!instanceId || !instanceToken || !clientToken) {
    console.error('[Z-API] ❌ Secrets não configurados');
    return { success: false, error: 'Z-API secrets não configurados' };
  }

  const formattedPhone = normalizePhone(phone);
  const url = `https://api.z-api.io/instances/${instanceId}/token/${instanceToken}/send-text`;

  console.log('[Z-API] 📤 Enviando mensagem para:', formattedPhone);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': clientToken
      },
      body: JSON.stringify({ phone: formattedPhone, message })
    });

    const data = await response.json();
    console.log('[Z-API] Resposta:', response.status, JSON.stringify(data));

    if (response.ok) {
      return { success: true, messageId: data.messageId || data.id };
    } else {
      return { success: false, error: data.message || data.error || 'Erro desconhecido' };
    }
  } catch (error) {
    console.error('[Z-API] ❌ Erro na requisição:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Erro de conexão' };
  }
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { user_id, phone, name } = await req.json();

    console.log('[send-user-registered-webhook] Recebido:', { user_id, phone, name });

    if (!phone) {
      console.log('[send-user-registered-webhook] Telefone não fornecido, ignorando');
      return new Response(JSON.stringify({ success: false, reason: 'no_phone' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const normalizedPhone = normalizePhone(phone);
    const referenceId = user_id || `phone_${normalizedPhone}`;

    // Verificar idempotência
    const { data: existing } = await supabase
      .from('whatsapp_events')
      .select('id')
      .eq('phone', normalizedPhone)
      .eq('event_type', 'user_registered')
      .eq('reference_id', referenceId)
      .maybeSingle();

    if (existing) {
      console.log('[send-user-registered-webhook] ⚠️ Mensagem já enviada, ignorando duplicata');
      return new Response(JSON.stringify({ 
        success: false, 
        reason: 'already_sent' 
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Se user_id foi fornecido, verificar se o usuário tem VIP
    if (user_id) {
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('plan_status')
        .eq('id', user_id)
        .single();

      if (profileError) {
        console.error('[send-user-registered-webhook] Erro ao buscar profile:', profileError);
      }

      // Se usuário tem VIP, não enviar webhook
      if (profile?.plan_status === 'active') {
        console.log('[send-user-registered-webhook] Usuário já é VIP, não enviando webhook');
        return new Response(JSON.stringify({ 
          success: false, 
          reason: 'user_is_vip',
          plan_status: profile.plan_status 
        }), {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // Mensagem de cadastro concluído
    const message = `✨ Cadastro confirmado!

Seu acesso foi liberado e você já pode continuar assistindo com 10 minutos de brinde em todos os doramas. 

Se precisar de ajuda, é só responder esta mensagem.`;

    console.log('[send-user-registered-webhook] 📤 Enviando via Z-API para:', normalizedPhone);

    const result = await sendWhatsApp(normalizedPhone, message);

    // Registrar evento
    const { error: insertError } = await supabase.from('whatsapp_events').insert({
      phone: normalizedPhone,
      event_type: 'user_registered',
      reference_id: referenceId,
      message_id: result.messageId,
      status: result.success ? 'sent' : 'failed',
      error_message: result.error
    });

    if (insertError) {
      console.error('[send-user-registered-webhook] Erro ao registrar evento:', insertError);
    }

    console.log(`[send-user-registered-webhook] ${result.success ? '✅' : '❌'} Resultado:`, result);

    return new Response(JSON.stringify({ 
      success: result.success,
      messageId: result.messageId 
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[send-user-registered-webhook] Erro inesperado:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
