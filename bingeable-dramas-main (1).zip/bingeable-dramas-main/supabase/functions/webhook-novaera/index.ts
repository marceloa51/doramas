import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';
import { crypto } from 'https://deno.land/std@0.177.0/crypto/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-novaera-signature',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const NOVAERA_WEBHOOK_SECRET = Deno.env.get('NOVAERA_WEBHOOK_SECRET')!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Verify webhook signature
    const signature = req.headers.get('X-NovaEra-Signature') || req.headers.get('x-novaera-signature');
    const payload = await req.text();

    console.log('Received webhook, signature:', signature ? 'present' : 'missing');

    if (signature && NOVAERA_WEBHOOK_SECRET) {
      const encoder = new TextEncoder();
      const key = await crypto.subtle.importKey(
        'raw',
        encoder.encode(NOVAERA_WEBHOOK_SECRET),
        { name: 'HMAC', hash: 'SHA-256' },
        false,
        ['sign']
      );

      const signatureBuffer = await crypto.subtle.sign(
        'HMAC',
        key,
        encoder.encode(payload)
      );

      const expectedSignature = Array.from(new Uint8Array(signatureBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');

      if (signature !== expectedSignature) {
        console.error('Invalid webhook signature');
        return new Response('Unauthorized', { status: 401, headers: corsHeaders });
      }
    }

    const webhookData = JSON.parse(payload);
    console.log('📨 Webhook received:', JSON.stringify(webhookData, null, 2));

    const event = webhookData.event || webhookData.type || 'unknown';
    const transactionData = webhookData.data || webhookData;
    
    // Extract reference_id (externalRef) sent during payment creation
    const referenceId = transactionData.externalRef || transactionData.external_ref || transactionData.id;
    const status = transactionData.status;

    console.log('🔍 Processing webhook:', { event, referenceId, status });

    // ⚠️ VALIDATION: First check if this reference_id belongs to Doramas Super
    const { data: checkoutSession, error: checkoutError } = await supabase
      .from('checkout_sessions')
      .select('*')
      .eq('reference_id', referenceId)
      .maybeSingle();

    if (checkoutError) {
      console.error('Error querying checkout_session:', checkoutError);
    }

    if (!checkoutSession) {
      console.log('❌ REJECTED: Checkout session not found for reference_id:', referenceId);
      console.log('This webhook does not belong to Doramas Super - ignoring');
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Invalid reference_id - not from this system' 
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Checkout session found:', checkoutSession.id);

    // Only save webhook event if checkout_session exists (belongs to Doramas Super)
    const { error: webhookError } = await supabase.from('webhook_events').upsert({
      external_id: referenceId,
      event_type: event,
      payload: webhookData,
      provider: 'novaera',
      status_processed: 'pending',
      processed_at: new Date().toISOString(),
    }, {
      onConflict: 'external_id,event_type',
      ignoreDuplicates: false,
    });

    if (webhookError) {
      console.error('Error saving webhook event:', webhookError);
    } else {
      console.log('✅ Webhook event saved');
    }

    // Check if payment is confirmed
    const isPaid = status === 'paid' || 
                   status === 'approved' || 
                   status === 'completed' ||
                   event === 'payment.approved' ||
                   event === 'payment.paid' ||
                   event === 'transaction.paid';

    if (isPaid) {
      console.log('💰 PAYMENT CONFIRMED! Updating checkout_session...');

      // Update checkout_session to paid
      const { error: updateError } = await supabase
        .from('checkout_sessions')
        .update({ 
          status: 'paid',
          paid_at: new Date().toISOString(),
        })
        .eq('id', checkoutSession.id);

      if (updateError) {
        console.error('Error updating checkout_session:', updateError);
      } else {
        console.log('✅ Checkout session marked as paid');
      }

      // Verificar se a transação tem user_id (usuário logado)
      const { data: txData } = await supabase
        .from('transactions')
        .select('user_id, metadata')
        .eq('checkout_session_id', checkoutSession.id)
        .maybeSingle();

      // Verificar se é compra de Acesso Completo 30 Dias
      const items = checkoutSession.items as Array<{ type?: string; drama_id?: string; price: number }>;
      const isFullAccess = items.some(item => item.type === 'full_access_30_days');

      if (isFullAccess && txData?.user_id) {
        console.log('🎁 ACESSO COMPLETO 30 DIAS - Ativando plano para usuário:', txData.user_id);
        
        const planExpiresAt = new Date();
        planExpiresAt.setDate(planExpiresAt.getDate() + 30);

        const { error: planError } = await supabase
          .from('profiles')
          .update({
            plan_status: 'active',
            plan_renews_at: planExpiresAt.toISOString(),
          })
          .eq('id', txData.user_id);

        if (planError) {
          console.error('Error activating full access plan:', planError);
        } else {
          console.log('✅ Full access plan activated until:', planExpiresAt.toISOString());
        }
      } else if (txData?.user_id) {
        console.log('👤 Usuário logado detectado - Criando user_purchases automaticamente');
        
        for (const item of items) {
          if (item.drama_id) {
            const { error: purchaseError } = await supabase
              .from('user_purchases')
              .upsert({
                user_id: txData.user_id,
                drama_id: item.drama_id,
                amount: item.price,
                transaction_id: checkoutSession.id,
              }, { 
                onConflict: 'user_id,drama_id',
                ignoreDuplicates: true 
              });

            if (purchaseError) {
              console.error('Error creating user_purchase:', purchaseError);
            } else {
              console.log('✅ User purchase created:', item.drama_id);
            }
          }
        }
      } else {
        console.log('👻 Compra anônima - processamento será feito após criação de conta');
      }

      // Update existing transaction to 'paid' status
      const { error: txError } = await supabase
        .from('transactions')
        .update({
          status: 'paid',
          updated_at: new Date().toISOString(),
          metadata: {
            items: checkoutSession.items,
            customer_name: checkoutSession.customer_name,
            webhook_data: webhookData,
            paid_at: new Date().toISOString(),
          },
        })
        .eq('external_id', referenceId);

      if (txError) {
        console.error('Error updating transaction to paid:', txError);
      } else {
        console.log('✅ Transaction updated to paid');
      }

      // Mark webhook as processed
      await supabase
        .from('webhook_events')
        .update({ status_processed: 'processed' })
        .eq('external_id', referenceId)
        .eq('event_type', event);

      console.log('🎉 PAYMENT FLOW COMPLETE - Ready for account creation');
    } else if (status === 'failed' || status === 'canceled' || status === 'expired') {
      console.log('❌ Payment failed/canceled/expired');
      
      await supabase
        .from('checkout_sessions')
        .update({ 
          status: status === 'expired' ? 'expired' : 'canceled',
          expired_at: status === 'expired' ? new Date().toISOString() : null,
        })
        .eq('id', checkoutSession.id);

      await supabase
        .from('webhook_events')
        .update({ status_processed: 'processed' })
        .eq('external_id', referenceId)
        .eq('event_type', event);
    } else {
      console.log('⏳ Payment still pending');
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Webhook error:', error);
    return new Response(JSON.stringify({ error: 'Internal error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

/*
POSTMAN TEST PAYLOAD for /functions/v1/webhook-novaera:

Simular pagamento aprovado:
{
  "event": "payment.paid",
  "data": {
    "id": "12345",
    "externalRef": "CHK_xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
    "status": "paid",
    "amount": 700,
    "paidAmount": 700,
    "paidAt": "2025-01-15T12:00:00Z",
    "paymentMethod": "pix",
    "customer": {
      "name": "Teste",
      "email": "teste@teste.com"
    }
  }
}

Nota: Substitua o externalRef por um reference_id válido de checkout_sessions
*/