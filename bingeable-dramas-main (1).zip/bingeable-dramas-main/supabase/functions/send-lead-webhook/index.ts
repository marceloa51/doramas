import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Função para normalizar telefone
const normalizePhone = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('5555')) {
    return digits.slice(2);
  }
  return digits.startsWith('55') ? digits : `55${digits}`;
};

// Função para enviar texto via Z-API
const sendWhatsApp = async (phone: string, message: string): Promise<{ success: boolean; messageId?: string; error?: string }> => {
  const instanceId = Deno.env.get('ZAPI_INSTANCE_ID');
  const instanceToken = Deno.env.get('ZAPI_INSTANCE_TOKEN');
  const clientToken = Deno.env.get('ZAPI_CLIENT_TOKEN');

  if (!instanceId || !instanceToken || !clientToken) {
    console.error('[Z-API] ❌ Secrets não configurados');
    return { success: false, error: 'Z-API secrets não configurados' };
  }

  const formattedPhone = normalizePhone(phone);
  const url = `https://api.z-api.io/instances/${instanceId}/token/${instanceToken}/send-text`;

  console.log('[Z-API] 📤 Enviando texto para:', formattedPhone);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': clientToken
      },
      body: JSON.stringify({ phone: formattedPhone, message })
    });

    const data = await response.json();
    console.log('[Z-API] Resposta:', response.status, JSON.stringify(data));

    if (response.ok) {
      return { success: true, messageId: data.messageId || data.zaapId };
    } else {
      return { success: false, error: data.message || data.error || 'Erro desconhecido' };
    }
  } catch (error) {
    console.error('[Z-API] ❌ Erro na requisição:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Erro de conexão' };
  }
};

serve(async (req) => {
  console.log("[send-lead-webhook] ========== NOVA REQUISIÇÃO ==========");
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const payload = await req.json();
    console.log("[send-lead-webhook] Payload recebido:", JSON.stringify(payload));

    const lead = payload.record;
    
    if (!lead || !lead.phone) {
      console.log("[send-lead-webhook] Lead inválido - sem phone");
      return new Response(JSON.stringify({ error: "Lead inválido" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const phone = normalizePhone(lead.phone);
    const referenceId = lead.id;

    // Verificar idempotência
    const { data: existing } = await supabase
      .from('whatsapp_events')
      .select('id')
      .eq('phone', phone)
      .eq('event_type', 'lead_captured')
      .eq('reference_id', referenceId)
      .maybeSingle();

    if (existing) {
      console.log('[send-lead-webhook] ⚠️ Mensagem já enviada, ignorando duplicata');
      return new Response(JSON.stringify({ 
        success: false, 
        reason: 'already_sent',
        whatsapp_event_id: existing.id
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Mensagem para lead capturado (apenas texto com nome do dorama)
    const doramaName = lead.drama_title || 'esse dorama';
    const message = `Oi! 😊 Aqui é a Malu do Doramas Super.

Vi que você está assistindo *${doramaName}* 😊e colocou seu numero pra liberar +15 minutos no site.

Já está liberado pra você continuar assistindo 💛

Se quiser assistir completo e sem travar, é só me responder aqui.`;

    console.log("[send-lead-webhook] 📤 Enviando mensagem para:", phone);
    const result = await sendWhatsApp(phone, message);

    // Registrar evento
    const { error: insertError } = await supabase.from('whatsapp_events').insert({
      phone,
      event_type: 'lead_captured',
      reference_id: referenceId,
      message_id: result.messageId,
      status: result.success ? 'sent' : 'failed',
      error_message: result.error
    });

    if (insertError) {
      console.error('[send-lead-webhook] Erro ao registrar evento:', insertError);
    }

    console.log(`[send-lead-webhook] ${result.success ? '✅' : '❌'} Resultado:`, result);

    return new Response(JSON.stringify({ 
      success: result.success, 
      phone,
      messageId: result.messageId,
      error: result.error
    }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error("[send-lead-webhook] ❌ ERRO:", errorMessage);
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
