import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Hash do OTP (mesmo algoritmo do request)
async function hashOTP(otp: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp + Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'));
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { requestId, otp } = await req.json();
    
    if (!requestId || !otp) {
      return new Response(
        JSON.stringify({ ok: false, code: 'MISSING_PARAMS', message: 'Parâmetros obrigatórios' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validar formato do OTP (4 dígitos)
    if (!/^\d{4}$/.test(otp)) {
      return new Response(
        JSON.stringify({ ok: false, code: 'INVALID_OTP', message: 'Código deve ter 4 dígitos' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Criar cliente Supabase com service_role
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Buscar request
    const { data: resetRequest, error: fetchError } = await supabase
      .from('password_reset_requests')
      .select('*')
      .eq('id', requestId)
      .maybeSingle();

    if (fetchError || !resetRequest) {
      console.log(`[password-reset-verify] Request not found: ${requestId}`);
      return new Response(
        JSON.stringify({ ok: false, code: 'INVALID_REQUEST', message: 'Solicitação inválida' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar se já foi usado
    if (resetRequest.used) {
      return new Response(
        JSON.stringify({ ok: false, code: 'ALREADY_USED', message: 'Esta solicitação já foi utilizada' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar expiração
    if (new Date(resetRequest.expires_at) < new Date()) {
      return new Response(
        JSON.stringify({ ok: false, code: 'EXPIRED', message: 'Esse código expirou. Solicite um novo código para continuar.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar tentativas
    if (resetRequest.attempts >= resetRequest.max_attempts) {
      return new Response(
        JSON.stringify({ ok: false, code: 'MAX_ATTEMPTS', message: 'Muitas tentativas incorretas. Solicite um novo código.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar OTP
    const otpHash = await hashOTP(otp);
    
    if (otpHash !== resetRequest.otp_hash) {
      // Incrementar tentativas
      await supabase
        .from('password_reset_requests')
        .update({ attempts: resetRequest.attempts + 1 })
        .eq('id', requestId);

      const remainingAttempts = resetRequest.max_attempts - resetRequest.attempts - 1;
      console.log(`[password-reset-verify] Invalid OTP. Remaining attempts: ${remainingAttempts}`);

      return new Response(
        JSON.stringify({ 
          ok: false, 
          code: 'INVALID_OTP', 
          message: 'Código incorreto. Confira os 4 dígitos e tente novamente.',
          remainingAttempts 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // OTP válido - marcar como verificado
    const { error: updateError } = await supabase
      .from('password_reset_requests')
      .update({ verified: true })
      .eq('id', requestId);

    if (updateError) {
      console.error('[password-reset-verify] Update error:', updateError);
      return new Response(
        JSON.stringify({ ok: false, code: 'SERVER_ERROR', message: 'Erro interno' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`[password-reset-verify] OTP verified for request: ${requestId}`);

    return new Response(
      JSON.stringify({ ok: true, verified: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[password-reset-verify] Error:', error);
    return new Response(
      JSON.stringify({ ok: false, code: 'SERVER_ERROR', message: 'Erro interno' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
