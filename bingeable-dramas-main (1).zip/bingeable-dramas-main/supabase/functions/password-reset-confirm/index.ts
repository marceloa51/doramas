import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { requestId, newPassword } = await req.json();
    
    if (!requestId || !newPassword) {
      return new Response(
        JSON.stringify({ ok: false, code: 'MISSING_PARAMS', message: 'Parâmetros obrigatórios' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validar senha (mínimo 6 caracteres)
    if (newPassword.length < 6) {
      return new Response(
        JSON.stringify({ ok: false, code: 'WEAK_PASSWORD', message: 'A senha deve ter pelo menos 6 caracteres' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Criar cliente Supabase com service_role
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Buscar request
    const { data: resetRequest, error: fetchError } = await supabase
      .from('password_reset_requests')
      .select('*')
      .eq('id', requestId)
      .maybeSingle();

    if (fetchError || !resetRequest) {
      console.log(`[password-reset-confirm] Request not found: ${requestId}`);
      return new Response(
        JSON.stringify({ ok: false, code: 'INVALID_REQUEST', message: 'Solicitação inválida' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar se foi verificado
    if (!resetRequest.verified) {
      return new Response(
        JSON.stringify({ ok: false, code: 'NOT_VERIFIED', message: 'Código não verificado' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar se já foi usado
    if (resetRequest.used) {
      return new Response(
        JSON.stringify({ ok: false, code: 'ALREADY_USED', message: 'Esta solicitação já foi utilizada' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar expiração (dar mais 5 minutos após verificação)
    const extendedExpiry = new Date(new Date(resetRequest.expires_at).getTime() + 5 * 60 * 1000);
    if (extendedExpiry < new Date()) {
      return new Response(
        JSON.stringify({ ok: false, code: 'EXPIRED', message: 'Sessão expirada. Solicite um novo código.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Buscar usuário pelo telefone - email é no formato [telefone_sem_55]@doramassuper.internal
    const phoneDigits = resetRequest.phone.replace(/^55/, '');
    const emailPattern = `${phoneDigits}@doramassuper.internal`;
    
    console.log(`[password-reset-confirm] Looking for email: ${emailPattern}`);
    
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('id')
      .eq('email', emailPattern)
      .maybeSingle();

    if (profileError || !profile) {
      console.error('[password-reset-confirm] Profile not found for email:', emailPattern);
      return new Response(
        JSON.stringify({ ok: false, code: 'USER_NOT_FOUND', message: 'Usuário não encontrado' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Atualizar senha via Admin API
    const { error: updateError } = await supabase.auth.admin.updateUserById(
      profile.id,
      { password: newPassword }
    );

    if (updateError) {
      console.error('[password-reset-confirm] Password update error:', updateError);
      return new Response(
        JSON.stringify({ ok: false, code: 'UPDATE_FAILED', message: 'Erro ao atualizar senha' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Marcar request como usado
    await supabase
      .from('password_reset_requests')
      .update({ used: true })
      .eq('id', requestId);

    console.log(`[password-reset-confirm] Password updated for user: ${profile.id}`);

    return new Response(
      JSON.stringify({ ok: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[password-reset-confirm] Error:', error);
    return new Response(
      JSON.stringify({ ok: false, code: 'SERVER_ERROR', message: 'Erro interno' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
