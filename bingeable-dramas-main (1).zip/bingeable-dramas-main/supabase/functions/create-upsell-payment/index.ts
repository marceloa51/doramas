import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Gera CPF matematicamente válido
function generateValidCPF(): string {
  const randomDigits: number[] = [];
  for (let i = 0; i < 9; i++) {
    randomDigits.push(Math.floor(Math.random() * 9) + 1);
  }
  
  // Calcula primeiro dígito verificador
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += randomDigits[i] * (10 - i);
  }
  let firstVerifier = 11 - (sum % 11);
  if (firstVerifier >= 10) firstVerifier = 0;
  
  // Calcula segundo dígito verificador
  sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += randomDigits[i] * (11 - i);
  }
  sum += firstVerifier * 2;
  let secondVerifier = 11 - (sum % 11);
  if (secondVerifier >= 10) secondVerifier = 0;
  
  return [...randomDigits, firstVerifier, secondVerifier].join('');
}

// Bestfy API client
class BestfyClient {
  private secretKey: string;
  private baseURL: string;

  constructor(secretKey: string) {
    this.secretKey = secretKey;
    this.baseURL = 'https://api.bestfybr.com.br/v1';
  }

  private getAuthHeader(): string {
    const credentials = btoa(`${this.secretKey}:x`);
    return `Basic ${credentials}`;
  }

  async createTransaction(payload: any) {
    console.log('📤 Sending request to Bestfy:', JSON.stringify(payload, null, 2));
    
    const response = await fetch(`${this.baseURL}/transactions`, {
      method: 'POST',
      headers: {
        'Authorization': this.getAuthHeader(),
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const responseText = await response.text();
    console.log('📥 Bestfy raw response:', responseText);

    if (!response.ok) {
      throw new Error(`Bestfy API error: ${response.status} - ${responseText}`);
    }

    return JSON.parse(responseText);
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const BESTFY_SECRET_KEY = Deno.env.get('BESTFY_SECRET_KEY')!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const bestfyClient = new BestfyClient(BESTFY_SECRET_KEY);

    const { customerName, customerCpf, dramaIds, userId, visitor_id, paymentMethod, cardToken, cardData } = await req.json();

    console.log('💰 Creating upsell payment:', { customerName, customerCpf: customerCpf ? 'provided' : 'missing', dramaIds, userId: userId ? 'logged' : 'anonymous', visitor_id, paymentMethod, hasToken: !!cardToken, hasCardData: !!cardData });

    // CORRIGIDO: Aceitar 3 IDs (1 original + 2 extras do upsell)
    if (!customerName || !dramaIds || dramaIds.length !== 3) {
      return new Response(JSON.stringify({ error: 'Invalid request. Need customerName and exactly 3 dramaIds' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Buscar informações dos doramas
    const { data: dramas, error: dramasError } = await supabase
      .from('dramas')
      .select('id, title, slug, price, thumbnail_url')
      .in('id', dramaIds);

    if (dramasError || !dramas || dramas.length !== 3) {
      console.error('Dramas not found:', dramasError);
      return new Response(JSON.stringify({ error: 'One or more dramas not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const upsellPrice = 16.00; // Preço fixo do upsell
    const priceInCents = Math.round(upsellPrice * 100);

    // Gerar reference_id único para rastreamento
    const referenceId = `CHK_${crypto.randomUUID()}`;

    console.log('📦 Creating upsell checkout_session:', { referenceId, amount: upsellPrice, paymentMethod: paymentMethod || 'pix' });

    // Criar checkout_session
    const { data: checkoutSession, error: checkoutError } = await supabase
      .from('checkout_sessions')
      .insert({
        reference_id: referenceId,
        visitor_id: visitor_id || null,
        amount: upsellPrice,
        currency: 'BRL',
        items: dramas.map(d => ({
          drama_id: d.id,
          title: d.title,
          price: d.price || 12.90,
        })),
        customer_name: customerName,
        status: 'pending',
        payment_method: paymentMethod === 'credit_card' ? 'credit_card' : 'pix'
      })
      .select()
      .single();

    if (checkoutError || !checkoutSession) {
      console.error('Error creating checkout session:', checkoutError);
      return new Response(JSON.stringify({ error: 'Failed to create checkout session' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Checkout session created:', checkoutSession.id);

    // Criar transação pendente
    const { data: transaction, error: transactionError } = await supabase
      .from('transactions')
      .insert({
        external_id: referenceId,
        amount: upsellPrice,
        currency: 'BRL',
        payment_method: paymentMethod === 'credit_card' ? 'card' : 'pix',
        status: 'pending',
        user_id: userId || null,
        checkout_session_id: checkoutSession.id,
        metadata: {
          customer_name: customerName,
          items: dramas.map(d => ({
            drama_id: d.id,
            title: d.title,
            price: d.price || 12.90,
          })),
          purchase_type: 'upsell',
          drama_ids: dramaIds,
        }
      })
      .select()
      .single();

    if (transactionError || !transaction) {
      console.error('Error creating transaction:', transactionError);
      return new Response(JSON.stringify({ error: 'Failed to create transaction' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Transaction created:', transaction.id);

    // Gerar CPF válido automaticamente
    const cpfToUse = generateValidCPF();
    console.log('🆔 Generated valid CPF for Bestfy');

    // Preparar payload para Bestfy
    let paymentPayload: any = {
      amount: priceInCents,
      externalRef: referenceId,
      customer: {
        name: customerName,
        email: `${referenceId}@checkout.doramassuper.site`,
        phone: customerName.replace(/\D/g, '') || '11999999999',
        document: {
          type: 'cpf',
          number: cpfToUse,
        },
      },
      items: dramas.map((drama, index) => ({
        title: drama.title,
        description: `Dorama ${index + 1}: ${drama.title}`,
        quantity: 1,
        tangible: false,
        unitPrice: Math.round((drama.price || 12.90) * 100),
      })),
      postbackUrl: `${SUPABASE_URL}/functions/v1/webhook-bestfy`,
    };

    if (paymentMethod === 'credit_card') {
      paymentPayload.paymentMethod = 'credit_card';
      paymentPayload.installments = 1;
      
      // Validar se cardToken é uma string real (não objeto vazio, não undefined)
      const isValidToken = cardToken && typeof cardToken === 'string' && cardToken.length > 10;
      
      if (isValidToken) {
        paymentPayload.card = { token: cardToken };
        console.log('Using valid card token for payment, length:', cardToken.length);
      } else if (cardData) {
        // Fallback: usar dados brutos sanitizados
        console.log('cardToken invalid/empty, using raw cardData. Token was:', typeof cardToken, cardToken);
        paymentPayload.card = {
          number: String(cardData.number).replace(/\D/g, ''),
          holderName: String(cardData.holderName).trim().toUpperCase().slice(0, 100),
          expirationMonth: parseInt(String(cardData.expirationMonth), 10),
          expirationYear: parseInt(String(cardData.expirationYear), 10),
          cvv: String(cardData.cvv).replace(/\D/g, '').slice(0, 4),
        };
        console.log('Using raw card data for payment (sanitized)');
      } else {
        throw new Error('Credit card payment requires valid cardToken or cardData');
      }
    } else {
      paymentPayload.paymentMethod = 'pix';
      paymentPayload.pix = { expiresInDays: 1 };
    }

    console.log('🔄 Calling Bestfy API...');
    const bestfyResponse = await bestfyClient.createTransaction(paymentPayload);

    console.log('✅ Bestfy response received:', JSON.stringify(bestfyResponse, null, 2));

    // Extract PIX data
    const pixData = bestfyResponse.pix || bestfyResponse.data?.pix || {};
    const pixCode = pixData.qrcode || pixData.qrCode || bestfyResponse.qrCode || bestfyResponse.qrcode;
    const secureUrl = bestfyResponse.secureUrl || bestfyResponse.secure_url || bestfyResponse.data?.secureUrl;

    // Atualizar checkout_session com dados do PIX
    await supabase
      .from('checkout_sessions')
      .update({
        pix_code: pixCode,
        checkout_url: secureUrl,
      })
      .eq('id', checkoutSession.id);

    // Verificar status para cartão de crédito
    if (paymentMethod === 'credit_card') {
      const cardStatus = bestfyResponse.status || bestfyResponse.data?.status;
      console.log('💳 Card payment status from Bestfy:', cardStatus);
      
      // Se RECUSADO/FALHOU - retornar erro
      if (cardStatus === 'refused' || cardStatus === 'failed' || cardStatus === 'canceled') {
        console.log('❌ Payment REFUSED by Bestfy');
        
        // Atualizar status para cancelado/falha
        await supabase
          .from('checkout_sessions')
          .update({ status: 'canceled' })
          .eq('id', checkoutSession.id);

        await supabase
          .from('transactions')
          .update({ status: 'failed', updated_at: new Date().toISOString() })
          .eq('external_id', referenceId);

        const refusedReason = bestfyResponse.refusedReason?.description || 
                              bestfyResponse.statusReason || 
                              bestfyResponse.data?.refusedReason?.description ||
                              'Pagamento não autorizado pela operadora';
        
        return new Response(
          JSON.stringify({
            success: false,
            error: refusedReason,
            status: 'refused',
          }),
          {
            status: 200,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }
      
      // Se APROVADO - criar compras
      if (cardStatus === 'paid' || cardStatus === 'authorized') {
        console.log('✅ Payment APPROVED by Bestfy');
        
        await supabase
          .from('checkout_sessions')
          .update({ status: 'paid', paid_at: new Date().toISOString() })
          .eq('id', checkoutSession.id);

        await supabase
          .from('transactions')
          .update({ status: 'paid', updated_at: new Date().toISOString() })
          .eq('external_id', referenceId);

        // Create user purchases if logged
        if (userId) {
          for (const drama of dramas) {
            await supabase
              .from('user_purchases')
              .upsert({
                user_id: userId,
                drama_id: drama.id,
                amount: drama.price || 12.90,
                transaction_id: checkoutSession.id,
              }, { onConflict: 'user_id,drama_id', ignoreDuplicates: true });
          }
        }

        return new Response(
          JSON.stringify({
            success: true,
            status: 'paid',
            transactionId: bestfyResponse.id || bestfyResponse.data?.id,
            checkout_session_id: checkoutSession.id,
            reference_id: referenceId,
          }),
          {
            status: 200,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }
      
      // Se PENDENTE - informar que está processando
      console.log('⏳ Payment PENDING, waiting for webhook');
      return new Response(
        JSON.stringify({
          success: true,
          status: 'pending',
          message: 'Pagamento em processamento',
          checkout_session_id: checkoutSession.id,
          reference_id: referenceId,
        }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Para PIX, retornar dados do código
    console.log('📱 PIX payment created successfully');
    return new Response(
      JSON.stringify({
        success: true,
        status: 'pending',
        checkoutUrl: secureUrl,
        pixCode: pixCode,
        transactionId: bestfyResponse.id || bestfyResponse.data?.id,
        checkout_session_id: checkoutSession.id,
        reference_id: referenceId,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Unexpected error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
