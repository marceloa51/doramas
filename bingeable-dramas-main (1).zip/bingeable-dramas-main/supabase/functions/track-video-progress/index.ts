import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const RequestBodySchema = z.object({
  dramaId: z.string().uuid({ message: 'Invalid drama ID format' }),
  currentPosition: z.number().min(0, { message: 'Current position must be non-negative' }).max(86400, { message: 'Position exceeds maximum duration' }),
  totalDuration: z.number().min(0).max(86400).optional()
});

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Verificar autenticação
    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Não autenticado' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse and validate request body
    const body = await req.json();
    const validationResult = RequestBodySchema.safeParse(body);
    
    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid request data',
          details: validationResult.error.issues 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
    
    const { dramaId, currentPosition, totalDuration } = validationResult.data;

    const sessionId = req.headers.get('x-session-id');
    
    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('current_session_id')
      .eq('id', user.id)
      .single();

    if (!sessionId || !profile || profile.current_session_id !== sessionId) {
      console.warn('[track-video-progress] Invalid or missing session ID');
      
      return new Response(
        JSON.stringify({ 
          error: 'INVALID_SESSION',
          message: 'Sua conta foi acessada em outro dispositivo. Faça login novamente.'
        }),
        { 
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Log without exposing user IDs (hash for debugging)
    const userHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(user.id));
    const hashStr = Array.from(new Uint8Array(userHash)).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 8);
    console.log(`[track-video-progress] Progress update at ${currentPosition}s (user: ${hashStr})`);

    // Verificar se o usuário COMPROU este dorama específico
    const { data: purchase } = await supabaseClient
      .from('user_purchases')
      .select('id')
      .eq('user_id', user.id)
      .eq('drama_id', dramaId)
      .single();

    const hasPurchased = !!purchase;
    const PREVIEW_LIMIT = 600; // 10 minutos

    // Buscar ou criar movie_view
    const { data: existingView } = await supabaseClient
      .from('movie_views')
      .select('*')
      .eq('user_id', user.id)
      .eq('drama_id', dramaId)
      .single();

    let isPreviewFinished = false;

    if (!hasPurchased && currentPosition >= PREVIEW_LIMIT) {
      isPreviewFinished = true;
      console.log(`[track-video-progress] Preview limit reached`);
    }

    if (existingView) {
      // Atualizar progresso existente
      const { error: updateError } = await supabaseClient
        .from('movie_views')
        .update({
          last_position_seconds: currentPosition,
          is_preview_finished: isPreviewFinished,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingView.id);

      if (updateError) {
        console.error('[track-video-progress] Error updating progress:', updateError.message);
      }
    } else {
      // Criar novo registro
      const { error: insertError } = await supabaseClient
        .from('movie_views')
        .insert({
          user_id: user.id,
          drama_id: dramaId,
          last_position_seconds: currentPosition,
          is_preview_finished: isPreviewFinished,
          preview_started_at: new Date().toISOString()
        });

      if (insertError) {
        console.error('[track-video-progress] Error creating progress:', insertError.message);
      }
    }

    // Atualizar registro de watch history (para "Minha Lista")
    const isWatching = totalDuration ? (currentPosition > 30 && currentPosition < (totalDuration - 60)) : false;
    const isWatched = totalDuration ? (totalDuration > 0 && currentPosition >= (totalDuration - 60)) : false;

    if (isWatching || isWatched) {
      const status = isWatched ? 'watched' : 'watching';
      
      const { data: existingUserDrama } = await supabaseClient
        .from('user_dramas')
        .select('*')
        .eq('user_id', user.id)
        .eq('drama_id', dramaId)
        .single();

      if (existingUserDrama) {
        await supabaseClient
          .from('user_dramas')
          .update({
            status,
            last_watched_at: new Date().toISOString()
          })
          .eq('id', existingUserDrama.id);
      } else {
        await supabaseClient
          .from('user_dramas')
          .insert({
            user_id: user.id,
            drama_id: dramaId,
            status,
            last_watched_at: new Date().toISOString()
          });
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        currentPosition,
        isPreviewFinished,
        remainingPreviewSeconds: hasPurchased ? null : Math.max(0, PREVIEW_LIMIT - currentPosition)
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('[track-video-progress] Unexpected error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Erro interno do servidor' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
