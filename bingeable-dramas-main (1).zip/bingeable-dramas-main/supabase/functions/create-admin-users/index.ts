import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.81.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

    // Verify admin authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authorization required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Create client with user's token to verify identity
    const supabaseAuth = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } }
    });

    const { data: { user: authUser }, error: authError } = await supabaseAuth.auth.getUser();
    if (authError || !authUser) {
      console.error('Auth error:', authError);
      return new Response(JSON.stringify({ error: 'Invalid authentication' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Verify user is admin
    const { data: isAdmin } = await supabaseAdmin.rpc('has_role', {
      _user_id: authUser.id,
      _role: 'admin'
    });

    if (!isAdmin) {
      console.error('Non-admin user attempted to create admin users:', authUser.id);
      return new Response(JSON.stringify({ error: 'Admin access required' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get admin users from request body (no more hardcoded credentials)
    const { adminUsers } = await req.json();
    
    if (!adminUsers || !Array.isArray(adminUsers) || adminUsers.length === 0) {
      return new Response(JSON.stringify({ error: 'adminUsers array required in request body' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const results = [];

    for (const adminUser of adminUsers) {
      if (!adminUser.email || !adminUser.password || !adminUser.full_name) {
        results.push({ email: adminUser.email || 'unknown', status: 'error', error: 'Missing required fields' });
        continue;
      }

      try {
        let userId: string | null = null;
        let status: string = "created";

        const { data: authUserData, error: createError } = await supabaseAdmin.auth.admin.createUser({
          email: adminUser.email,
          password: adminUser.password,
          email_confirm: true,
          user_metadata: {
            full_name: adminUser.full_name,
          },
        });

        if (createError) {
          const message = createError.message || "";
          const isAlreadyRegistered =
            message.toLowerCase().includes("already registered") ||
            message.toLowerCase().includes("user already exists");

          if (!isAlreadyRegistered) {
            console.error(`Error creating user ${adminUser.email}:`, createError);
            results.push({ email: adminUser.email, status: "error", error: createError.message });
            continue;
          }

          status = "updated";

          const { data: { users }, error: listError } = await supabaseAdmin.auth.admin.listUsers({
            page: 1,
            perPage: 1000,
          });

          if (listError) {
            console.error(`Error listing users while updating ${adminUser.email}:`, listError);
            results.push({ email: adminUser.email, status: "error", error: listError.message });
            continue;
          }

          const existingUser = users?.find((user: any) =>
            user.email?.toLowerCase() === adminUser.email.toLowerCase()
          );

          if (!existingUser) {
            console.error(`User ${adminUser.email} already exists in Auth but was not found via listUsers`);
            results.push({ email: adminUser.email, status: "error", error: "User exists but could not be fetched" });
            continue;
          }

          const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(existingUser.id, {
            password: adminUser.password,
            user_metadata: {
              full_name: adminUser.full_name,
            },
          });

          if (updateError) {
            console.error(`Error updating admin user ${adminUser.email}:`, updateError);
            results.push({ email: adminUser.email, status: "error", error: updateError.message });
            continue;
          }

          userId = existingUser.id;
        } else {
          if (!authUserData.user) {
            results.push({ email: adminUser.email, status: "error", error: "No user returned" });
            continue;
          }

          userId = authUserData.user.id;
        }

        if (!userId) {
          results.push({ email: adminUser.email, status: "error", error: "User ID not found" });
          continue;
        }

        const { error: roleError } = await supabaseAdmin
          .from("user_roles")
          .upsert(
            {
              user_id: userId,
              role: "admin",
            },
            { onConflict: "user_id,role" }
          );

        if (roleError) {
          console.error(`Error assigning admin role to ${adminUser.email}:`, roleError);
          results.push({ email: adminUser.email, status: "error", error: roleError.message });
          continue;
        }

        const { error: profileUpdateError } = await supabaseAdmin
          .from("profiles")
          .update({
            email: adminUser.email,
            full_name: adminUser.full_name,
          })
          .eq("id", userId);

        if (profileUpdateError) {
          console.error(`Error updating profile for ${adminUser.email}:`, profileUpdateError);
        }

        // Log audit
        await supabaseAdmin.from('audit_logs').insert({
          user_id: authUser.id,
          action: status === 'created' ? 'ADMIN_USER_CREATED' : 'ADMIN_USER_UPDATED',
          table_name: 'user_roles',
          record_id: userId,
          new_data: { email: adminUser.email, role: 'admin' }
        });

        results.push({ email: adminUser.email, status });
      } catch (error: any) {
        const message = error?.message || "Unknown error";
        console.error(`Unexpected error processing admin ${adminUser.email}:`, error);
        results.push({ email: adminUser.email, status: "error", error: message });
      }
    }

    console.log('Admin', authUser.id, 'managed admin users:', results);

    return new Response(JSON.stringify({ success: true, results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
