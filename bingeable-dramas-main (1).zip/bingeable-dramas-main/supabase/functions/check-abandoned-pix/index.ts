import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const ABANDONMENT_MINUTES = 6;
const PIX_EXPIRY_MINUTES = 30;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const normalizePhone = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('5555')) return digits.slice(2);
  return digits.startsWith('55') ? digits : `55${digits}`;
};

const sendWhatsApp = async (phone: string, message: string) => {
  const instanceId = Deno.env.get('ZAPI_INSTANCE_ID');
  const instanceToken = Deno.env.get('ZAPI_INSTANCE_TOKEN');
  const clientToken = Deno.env.get('ZAPI_CLIENT_TOKEN');

  if (!instanceId || !instanceToken || !clientToken) {
    return { success: false, error: 'Z-API secrets não configurados' };
  }

  const formattedPhone = normalizePhone(phone);
  const url = `https://api.z-api.io/instances/${instanceId}/token/${instanceToken}/send-text`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Client-Token': clientToken },
      body: JSON.stringify({ phone: formattedPhone, message })
    });
    const data = await response.json();
    return response.ok ? { success: true, messageId: data.messageId || data.id } : { success: false, error: data.message || 'Erro' };
  } catch (error) {
    return { success: false, error: error instanceof Error ? error.message : 'Erro' };
  }
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    console.log("[check-abandoned-pix] Iniciando...");
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

    const now = new Date();
    const abandonmentCutoff = new Date(now.getTime() - ABANDONMENT_MINUTES * 60 * 1000);
    const expiryCutoff = new Date(now.getTime() - PIX_EXPIRY_MINUTES * 60 * 1000);

    await supabase.from('checkout_sessions').update({ status: 'expired' }).eq('status', 'pending').lt('created_at', expiryCutoff.toISOString());

    const { data: sessions } = await supabase
      .from('checkout_sessions')
      .select('id, customer_name, created_at, reference_id, items')
      .eq('status', 'pending')
      .eq('abandoned_notified', false)
      .lt('created_at', abandonmentCutoff.toISOString())
      .gt('created_at', expiryCutoff.toISOString());

    console.log(`[check-abandoned-pix] ${sessions?.length || 0} sessões`);
    const results: any[] = [];

    // Agrupar sessões por telefone para enviar apenas 1 mensagem por cliente
    const phonesSent = new Set<string>();
    
    for (const session of sessions || []) {
      if (!session.customer_name) continue;
      const phone = normalizePhone(session.customer_name);
      const eventType = 'pix_pending';

      // Se já enviamos para esse telefone neste ciclo, apenas marcar como notificado
      if (phonesSent.has(phone)) {
        console.log(`[check-abandoned-pix] Já enviamos para ${phone} neste ciclo, apenas marcando sessão ${session.id}`);
        await supabase.from('checkout_sessions').update({ abandoned_notified: true }).eq('id', session.id);
        continue;
      }

      // Verificar se já enviou para esse telefone nas últimas 24h (qualquer sessão)
      const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const { data: recentMessage } = await supabase
        .from('whatsapp_events')
        .select('id')
        .eq('phone', phone)
        .eq('event_type', eventType)
        .gte('created_at', last24h)
        .limit(1)
        .maybeSingle();
      
      if (recentMessage) {
        console.log(`[check-abandoned-pix] Já enviamos para ${phone} nas últimas 24h, ignorando`);
        await supabase.from('checkout_sessions').update({ abandoned_notified: true }).eq('id', session.id);
        continue;
      }

      // Extrair drama_id dos items para montar link correto
      const items = session.items as Array<{ drama_id?: string; type?: string }>;
      const dramaItem = items?.find((item: any) => item.drama_id);
      const fullAccessItem = items?.find((item: any) => item.type === 'full_access_30_days');
      
      console.log(`[check-abandoned-pix] Sessão: ${session.id}`);
      console.log(`[check-abandoned-pix] Items:`, JSON.stringify(items));
      console.log(`[check-abandoned-pix] Drama ID:`, dramaItem?.drama_id);
      console.log(`[check-abandoned-pix] Full Access:`, !!fullAccessItem);
      
      let checkoutLink: string;
      
      // Se for full access, mandar para /paywall
      if (fullAccessItem) {
        checkoutLink = `https://doramassuper.site/paywall`;
        console.log(`[check-abandoned-pix] Tipo: Full Access -> /paywall`);
      }
      // Se tiver drama_id, buscar o slug e montar link direto para o dorama
      else if (dramaItem?.drama_id) {
        const { data: drama } = await supabase
          .from('dramas')
          .select('slug')
          .eq('id', dramaItem.drama_id)
          .maybeSingle();
        
        console.log(`[check-abandoned-pix] Drama slug:`, drama?.slug);
        
        if (drama?.slug) {
          checkoutLink = `https://doramassuper.site/checkout/${drama.slug}`;
        } else {
          checkoutLink = `https://doramassuper.site`;
        }
      } else {
        // Fallback para página inicial
        checkoutLink = `https://doramassuper.site`;
      }
      
      console.log(`[check-abandoned-pix] Link final:`, checkoutLink);

      const message = `✨ Olá! Aqui é do Doramas Super.

Percebi que você iniciou o acesso a um dos nossos doramas e gerou um Pix, mas o pagamento ainda não foi concluído.

O acesso completo continua reservado para você, para assistir sem interrupções e acompanhar a história até o final. 🎬

Quer continuar assistindo?

${checkoutLink}`;

      const result = await sendWhatsApp(phone, message);
      phonesSent.add(phone); // Marcar telefone como enviado neste ciclo
      await supabase.from('whatsapp_events').insert({ phone, event_type: eventType, reference_id: session.id, message_id: result.messageId, status: result.success ? 'sent' : 'failed', error_message: result.error });
      await supabase.from('checkout_sessions').update({ abandoned_notified: true }).eq('id', session.id);
      results.push({ session_id: session.id, phone, success: result.success, event_type: eventType });
    }

    return new Response(JSON.stringify({ success: true, processed: results.length, results }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error: any) {
    console.error("[check-abandoned-pix] Erro:", error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
