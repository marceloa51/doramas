import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Função para normalizar telefone
const normalizePhone = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('5555')) {
    return digits.slice(2);
  }
  return digits.startsWith('55') ? digits : `55${digits}`;
};

// Função central para enviar WhatsApp via Z-API
const sendWhatsApp = async (phone: string, message: string): Promise<{ success: boolean; messageId?: string; error?: string }> => {
  const instanceId = Deno.env.get('ZAPI_INSTANCE_ID');
  const instanceToken = Deno.env.get('ZAPI_INSTANCE_TOKEN');
  const clientToken = Deno.env.get('ZAPI_CLIENT_TOKEN');

  if (!instanceId || !instanceToken || !clientToken) {
    console.error('[Z-API] ❌ Secrets não configurados');
    return { success: false, error: 'Z-API secrets não configurados' };
  }

  const formattedPhone = normalizePhone(phone);
  const url = `https://api.z-api.io/instances/${instanceId}/token/${instanceToken}/send-text`;

  console.log('[Z-API] 📤 Enviando mensagem para:', formattedPhone);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': clientToken
      },
      body: JSON.stringify({ phone: formattedPhone, message })
    });

    const data = await response.json();
    console.log('[Z-API] Resposta:', response.status, JSON.stringify(data));

    if (response.ok) {
      return { success: true, messageId: data.messageId || data.id };
    } else {
      return { success: false, error: data.message || data.error || 'Erro desconhecido' };
    }
  } catch (error) {
    console.error('[Z-API] ❌ Erro na requisição:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Erro de conexão' };
  }
};

// Função para enviar mensagem de cartão recusado
const sendCardDeclinedMessage = async (supabaseClient: any, phone: string, referenceId: string, checkoutSession: any) => {
  const normalizedPhone = normalizePhone(phone);

  // Verificar idempotência
  const { data: existing } = await supabaseClient
    .from('whatsapp_events')
    .select('id')
    .eq('phone', normalizedPhone)
    .eq('event_type', 'card_declined')
    .eq('reference_id', referenceId)
    .maybeSingle();

  if (existing) {
    console.log('[webhook-bestfy] ⚠️ Mensagem card_declined já enviada');
    return { skipped: true };
  }

  // Extrair drama_id dos items para montar link correto
  const items = checkoutSession.items as Array<{ drama_id?: string; type?: string }>;
  const dramaItem = items?.find(item => item.drama_id);
  
  let retryLink = `https://doramassuperplus.com.br/drama-checkout?session=${referenceId}`;
  
  // Se tiver drama_id, buscar o slug e montar link direto
  if (dramaItem?.drama_id) {
    const { data: drama } = await supabaseClient
      .from('dramas')
      .select('slug')
      .eq('id', dramaItem.drama_id)
      .maybeSingle();
    
    if (drama?.slug) {
      retryLink = `https://doramassuperplus.com.br/drama/${drama.slug}`;
    }
  }

  const message = `❌ Pagamento não aprovado.

A operadora do cartão não autorizou a transação.

Isso pode acontecer por limite disponível ou validação de segurança.

Você pode tentar novamente pelo link abaixo:

${retryLink}

Se precisar de ajuda, é só responder esta mensagem.`;

  const result = await sendWhatsApp(normalizedPhone, message);

  // Registrar evento
  await supabaseClient.from('whatsapp_events').insert({
    phone: normalizedPhone,
    event_type: 'card_declined',
    reference_id: referenceId,
    message_id: result.messageId,
    status: result.success ? 'sent' : 'failed',
    error_message: result.error
  });

  return result;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const payload = await req.text();
    console.log('📨 Bestfy Webhook received:', payload);

    const webhookData = JSON.parse(payload);
    console.log('📨 Parsed webhook data:', JSON.stringify(webhookData, null, 2));

    // Extract data from Bestfy webhook
    const event = webhookData.type || webhookData.event || 'unknown';
    const transactionData = webhookData.data || webhookData;
    
    // Extract reference_id (externalRef) sent during payment creation
    const referenceId = transactionData.externalRef || transactionData.external_ref || transactionData.externalReference || transactionData.id;
    const status = transactionData.status;

    console.log('🔍 Processing Bestfy webhook:', { event, referenceId, status });

    // Validate: First check if this reference_id belongs to Doramas Super
    const { data: checkoutSession, error: checkoutError } = await supabase
      .from('checkout_sessions')
      .select('*')
      .eq('reference_id', referenceId)
      .maybeSingle();

    if (checkoutError) {
      console.error('Error querying checkout_session:', checkoutError);
    }

    if (!checkoutSession) {
      console.log('❌ REJECTED: Checkout session not found for reference_id:', referenceId);
      console.log('This webhook does not belong to Doramas Super - ignoring');
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Invalid reference_id - not from this system' 
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Checkout session found:', checkoutSession.id);

    // Idempotency check - only process if checkout_session status is different
    const processedKey = `${referenceId}_${status}`;
    
    // Check webhook_events for duplicate
    const { data: existingEvent } = await supabase
      .from('webhook_events')
      .select('id')
      .eq('external_id', processedKey)
      .eq('provider', 'bestfy')
      .maybeSingle();

    if (existingEvent) {
      console.log('⚠️ Duplicate webhook detected, already processed:', processedKey);
      return new Response(JSON.stringify({ success: true, message: 'Already processed' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Save webhook event
    const { error: webhookError } = await supabase.from('webhook_events').insert({
      external_id: processedKey,
      event_type: event,
      payload: webhookData,
      provider: 'bestfy',
      status_processed: 'pending',
      processed_at: new Date().toISOString(),
    });

    if (webhookError) {
      console.error('Error saving webhook event:', webhookError);
    } else {
      console.log('✅ Webhook event saved');
    }

    // Check if payment is confirmed
    // Bestfy status: paid, refused, waiting_payment, processing, authorized
    const isPaid = status === 'paid' || status === 'authorized';
    const isFailed = status === 'refused' || status === 'canceled' || status === 'failed';
    const isPending = status === 'waiting_payment' || status === 'processing';

    if (isPaid) {
      console.log('💰 PAYMENT CONFIRMED! Updating checkout_session...');

      // Get transaction data FIRST before any other checks
      const { data: txData } = await supabase
        .from('transactions')
        .select('user_id, metadata')
        .eq('checkout_session_id', checkoutSession.id)
        .maybeSingle();

      // Check if user_purchases already exist for this transaction (idempotency)
      const items = checkoutSession.items as Array<{ type?: string; drama_id?: string; price: number }>;
      const isFullAccess = items.some(item => item.type === 'full_access_30_days');
      
      let purchasesAlreadyCreated = false;
      if (!isFullAccess && txData?.user_id) {
        const dramaIds = items.filter(i => i.drama_id).map(i => i.drama_id);
        if (dramaIds.length > 0) {
          const { data: existingPurchases } = await supabase
            .from('user_purchases')
            .select('drama_id')
            .eq('user_id', txData.user_id)
            .in('drama_id', dramaIds);
          
          purchasesAlreadyCreated = existingPurchases?.length === dramaIds.length;
        }
      }

      // Skip if already paid AND purchases already created
      if (checkoutSession.status === 'paid' && purchasesAlreadyCreated) {
        console.log('⚠️ Checkout session already paid and purchases exist, skipping');
        return new Response(JSON.stringify({ success: true, message: 'Already paid' }), {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Update checkout_session to paid (if not already)
      if (checkoutSession.status !== 'paid') {
        const { error: updateError } = await supabase
          .from('checkout_sessions')
          .update({ 
            status: 'paid',
            paid_at: new Date().toISOString(),
          })
          .eq('id', checkoutSession.id);

        if (updateError) {
          console.error('Error updating checkout_session:', updateError);
        } else {
          console.log('✅ Checkout session marked as paid');
        }
      }

      // Use items and isFullAccess already declared above

      if (isFullAccess && txData?.user_id) {
        console.log('🎁 FULL ACCESS 30 DAYS - Activating plan for user:', txData.user_id);
        
        const planExpiresAt = new Date();
        planExpiresAt.setDate(planExpiresAt.getDate() + 30);

        const { error: planError } = await supabase
          .from('profiles')
          .update({
            plan_status: 'active',
            plan_renews_at: planExpiresAt.toISOString(),
          })
          .eq('id', txData.user_id);

        if (planError) {
          console.error('Error activating full access plan:', planError);
        } else {
          console.log('✅ Full access plan activated until:', planExpiresAt.toISOString());
        }
      } else if (txData?.user_id) {
        console.log('👤 Logged user detected - Creating user_purchases');
        
        for (const item of items) {
          if (item.drama_id) {
            const { error: purchaseError } = await supabase
              .from('user_purchases')
              .upsert({
                user_id: txData.user_id,
                drama_id: item.drama_id,
                amount: item.price,
                transaction_id: checkoutSession.id,
              }, { 
                onConflict: 'user_id,drama_id',
                ignoreDuplicates: true 
              });

            if (purchaseError) {
              console.error('Error creating user_purchase:', purchaseError);
            } else {
              console.log('✅ User purchase created:', item.drama_id);
            }
          }
        }
      } else {
        console.log('👻 Anonymous purchase - will be processed after account creation');
      }

      // Update transaction to 'paid' status
      const { error: txError } = await supabase
        .from('transactions')
        .update({
          status: 'paid',
          updated_at: new Date().toISOString(),
          metadata: {
            items: checkoutSession.items,
            customer_name: checkoutSession.customer_name,
            webhook_data: webhookData,
            paid_at: new Date().toISOString(),
          },
        })
        .eq('external_id', referenceId);

      if (txError) {
        console.error('Error updating transaction to paid:', txError);
      } else {
        console.log('✅ Transaction updated to paid');
      }

      // Mark webhook as processed
      await supabase
        .from('webhook_events')
        .update({ status_processed: 'processed' })
        .eq('external_id', processedKey)
        .eq('provider', 'bestfy');

      console.log('🎉 PAYMENT FLOW COMPLETE');
    } else if (isFailed) {
      console.log('❌ Payment failed/refused');
      
      await supabase
        .from('checkout_sessions')
        .update({ 
          status: 'canceled',
        })
        .eq('id', checkoutSession.id);

      await supabase
        .from('transactions')
        .update({ status: 'failed', updated_at: new Date().toISOString() })
        .eq('external_id', referenceId);

      await supabase
        .from('webhook_events')
        .update({ status_processed: 'processed' })
        .eq('external_id', processedKey)
        .eq('provider', 'bestfy');

      // 🆕 Enviar mensagem de cartão recusado via Z-API
      if (checkoutSession.customer_name) {
        console.log('📤 Enviando mensagem de cartão recusado via Z-API...');
        const whatsappResult = await sendCardDeclinedMessage(
          supabase,
          checkoutSession.customer_name,
          referenceId,
          checkoutSession
        );
        console.log('📤 Resultado Z-API card_declined:', whatsappResult);
      }
    } else if (isPending) {
      console.log('⏳ Payment still pending/processing');
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Webhook error:', error);
    return new Response(JSON.stringify({ error: 'Internal error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
