import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const RequestBodySchema = z.object({
  dramaId: z.string().uuid({ message: 'Invalid drama ID format' }),
  userAgent: z.string().max(500).optional(),
  fingerprint: z.string().max(200).optional()
});

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Verificar autenticação
    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      console.error('[generate-video-url] Auth error:', authError);
      return new Response(
        JSON.stringify({ error: 'Não autenticado' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate session with hashed token
    const sessionId = req.headers.get('x-session-id');
    if (sessionId) {
      const hashedSessionId = await hashString(sessionId);
      const sessionValidation = await validateSession(supabaseClient, user.id, hashedSessionId);
      
      if (!sessionValidation.valid) {
        console.warn('[generate-video-url] Invalid session');
        return new Response(
          JSON.stringify({ 
            error: sessionValidation.error,
            message: sessionValidation.message || 'Sua conta foi acessada em outro dispositivo. Faça login novamente.'
          }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Parse and validate request body
    const body = await req.json();
    const validationResult = RequestBodySchema.safeParse(body);
    
    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid request data',
          details: validationResult.error.issues 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
    
    const { dramaId, userAgent, fingerprint } = validationResult.data;

    // Log without exposing user IDs (hash for debugging)
    const userHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(user.id));
    const hashStr = Array.from(new Uint8Array(userHash)).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 8);
    console.log(`[generate-video-url] Request for drama content (user: ${hashStr})`);

    // 1. Buscar informações do filme
    const { data: drama, error: dramaError } = await supabaseClient
      .from('dramas')
      .select('id, title, storage_path, video_url, duration_seconds, is_premium')
      .eq('id', dramaId)
      .single();

    if (dramaError || !drama) {
      console.error('[generate-video-url] Drama not found:', dramaError);
      return new Response(
        JSON.stringify({ error: 'Filme não encontrado' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 2. PRIMEIRO: Verificar se usuário tem PLANO VIP ATIVO (30 dias)
    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('plan_status, plan_renews_at')
      .eq('id', user.id)
      .single();

    const hasActivePlan = profile?.plan_status === 'active' && 
      profile?.plan_renews_at && 
      new Date(profile.plan_renews_at) > new Date();

    console.log(`[generate-video-url] Plan status: ${profile?.plan_status}, renews_at: ${profile?.plan_renews_at}, active: ${hasActivePlan}`);

    // 3. Se não tem plano VIP, verificar compra individual do dorama
    let hasPurchased = hasActivePlan; // VIP = acesso a TODOS os doramas

    if (!hasActivePlan) {
      const { data: purchase } = await supabaseClient
        .from('user_purchases')
        .select('id')
        .eq('user_id', user.id)
        .eq('drama_id', dramaId)
        .single();

      hasPurchased = !!purchase;
    }

    const isPreviewMode = !hasPurchased;

    console.log(`[generate-video-url] Has access: ${hasPurchased} (VIP: ${hasActivePlan}, individual purchase: ${!hasActivePlan && hasPurchased})`);

    // 3. Verificar progresso de visualização (para modo preview)
    let movieView = null;
    if (isPreviewMode) {
      const { data: existingView } = await supabaseClient
        .from('movie_views')
        .select('*')
        .eq('user_id', user.id)
        .eq('drama_id', dramaId)
        .single();

      movieView = existingView;

      // Se já terminou a prévia, bloquear
      if (movieView?.is_preview_finished) {
        console.log(`[generate-video-url] Preview time limit reached`);
        return new Response(
          JSON.stringify({
            error: 'PREVIEW_FINISHED',
            message: 'Tempo de prévia encerrado. Assine para continuar assistindo.',
            requiresSubscription: true
          }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Criar registro de visualização se não existir
      if (!movieView) {
        const { data: newView, error: viewError } = await supabaseClient
          .from('movie_views')
          .insert({
            user_id: user.id,
            drama_id: dramaId,
            last_position_seconds: 0,
            is_preview_finished: false,
            preview_started_at: new Date().toISOString()
          })
          .select()
          .single();

        if (viewError) {
          console.error('[generate-video-url] Error creating movie view:', viewError);
        } else {
          movieView = newView;
          console.log(`[generate-video-url] Created new movie view record`);
        }
      }
    }

    // 4. Session management removed - handled in validateSession
    // All old session logic removed, now using single session validation

    // 5. Gerar URL assinada
    let videoUrl: string;
    
    if (drama.storage_path) {
      // Vídeo no Storage (URL assinada com expiração de 60 segundos)
      const { data: signedUrlData, error: signedError } = await supabaseClient
        .storage
        .from('videos')
        .createSignedUrl(drama.storage_path, 60); // 60 segundos

      if (signedError || !signedUrlData) {
        console.error('[generate-video-url] Error creating signed URL:', signedError);
        return new Response(
          JSON.stringify({ error: 'Erro ao gerar URL do vídeo' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      videoUrl = signedUrlData.signedUrl;
    } else if (drama.video_url) {
      // Vídeo externo (usar URL direta)
      videoUrl = drama.video_url;
    } else {
      return new Response(
        JSON.stringify({ error: 'Vídeo não disponível' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 6. Calcular tempo máximo permitido
    const maxAllowedSeconds = isPreviewMode ? 600 : drama.duration_seconds || 999999; // 10 min para preview

    console.log(`[generate-video-url] Generated video URL for user ${user.id}, max time: ${maxAllowedSeconds}s`);

    return new Response(
      JSON.stringify({
        videoUrl,
        expiresIn: 60, // segundos
        isPreviewMode,
        maxAllowedSeconds,
        currentPosition: movieView?.last_position_seconds || 0,
        requiresSubscription: isPreviewMode,
        drama: {
          id: drama.id,
          title: drama.title,
          durationSeconds: drama.duration_seconds
        }
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('[generate-video-url] Unexpected error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Erro interno do servidor' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

// Helper para hash de string
async function hashString(str: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Validate session helper
async function validateSession(
  supabaseClient: any,
  userId: string,
  sessionId: string | null
): Promise<{ valid: boolean; error?: string; message?: string }> {
  if (!sessionId) {
    return { 
      valid: false, 
      error: 'MISSING_SESSION_ID',
      message: 'Sessão não encontrada. Faça login novamente.'
    };
  }

  // Fetch user profile
  const { data: profile } = await supabaseClient
    .from('profiles')
    .select('current_session_id')
    .eq('id', userId)
    .single();

  if (!profile || profile.current_session_id !== sessionId) {
    return { 
      valid: false, 
      error: 'INVALID_SESSION',
      message: 'Sua conta foi acessada em outro dispositivo. Faça login novamente.'
    };
  }

  // Update last_activity_at on session
  await supabaseClient
    .from('user_sessions')
    .update({ last_activity_at: new Date().toISOString() })
    .eq('user_id', userId)
    .eq('session_token', sessionId)
    .eq('is_active', true);

  return { valid: true };
}
