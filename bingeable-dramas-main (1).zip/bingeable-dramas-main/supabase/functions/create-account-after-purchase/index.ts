import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const DISPARA_WEBHOOK_URL = "https://link.dispara.ai/w/014923ac-53e2-444d-a946-1521abc7e8ef";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { checkout_session_id, phone, password, fullName, visitor_id } = await req.json();

    console.log('📱 Creating account after purchase:', { checkout_session_id, phone, fullName, visitor_id });

    if (!checkout_session_id || !phone || !password) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Verificar se checkout_session existe e está paga
    const { data: checkoutSession, error: sessionError } = await supabase
      .from('checkout_sessions')
      .select('*')
      .eq('id', checkout_session_id)
      .single();

    if (sessionError || !checkoutSession) {
      console.error('Checkout session not found:', sessionError);
      return new Response(JSON.stringify({ error: 'Checkout session not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (checkoutSession.status !== 'paid') {
      console.error('Checkout session not paid:', checkoutSession.status);
      return new Response(JSON.stringify({ 
        error: 'Payment not confirmed yet',
        status: checkoutSession.status 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Checkout session verified as paid');

    // Criar usuário com telefone como email
    const userEmail = `${phone}@doramassuper.internal`;
    
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: userEmail,
      password,
      email_confirm: true,
      user_metadata: {
        phone,
        full_name: fullName || '',
      },
    });

    if (authError || !authData.user) {
      console.error('Error creating user:', authError);
      return new Response(JSON.stringify({ error: authError?.message || 'Failed to create account' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ User created:', authData.user.id);

    // Atualizar profile com telefone
    await supabase
      .from('profiles')
      .update({ 
        full_name: fullName || '',
      })
      .eq('id', authData.user.id);

    // Buscar TODAS as checkout_sessions pagas deste visitor (se fornecido)
    let allPaidSessions = [checkoutSession];
    
    if (visitor_id) {
      console.log('🔍 Buscando todas as ordens pagas do visitor:', visitor_id);
      const { data: visitorSessions } = await supabase
        .from('checkout_sessions')
        .select('*')
        .eq('visitor_id', visitor_id)
        .eq('status', 'paid');
      
      if (visitorSessions && visitorSessions.length > 0) {
        allPaidSessions = visitorSessions;
        console.log(`✅ Encontradas ${visitorSessions.length} ordens pagas para vincular`);
      }
    }

    // Criar registros de compra para cada dorama em TODAS as sessões
    let hasFullAccess = false;
    
    for (const session of allPaidSessions) {
      const items = session.items as Array<{ type?: string; drama_id?: string; title: string; price: number }>;
      
      for (const item of items) {
        // Verificar se é Acesso Completo 30 Dias
        if (item.type === 'full_access_30_days') {
          console.log('🎁 Detectado: Acesso Completo 30 Dias');
          hasFullAccess = true;
          continue; // Não criar user_purchase para este item
        }
        
        // Para itens de dorama individual
        if (item.drama_id) {
          // Verificar se já existe para evitar duplicatas
          const { data: existing } = await supabase
            .from('user_purchases')
            .select('id')
            .eq('user_id', authData.user.id)
            .eq('drama_id', item.drama_id)
            .maybeSingle();

          if (!existing) {
            const { error: purchaseError } = await supabase
              .from('user_purchases')
              .insert({
                user_id: authData.user.id,
                drama_id: item.drama_id,
                amount: item.price,
              });

            if (purchaseError) {
              console.error('Error creating user_purchase:', purchaseError);
            } else {
              console.log('✅ User purchase created for drama:', item.drama_id);
            }
          } else {
            console.log('⏭️ Purchase already exists for drama:', item.drama_id);
          }
        }
      }
    }

    // Se comprou Acesso Completo 30 Dias, ativar plano
    if (hasFullAccess) {
      const planExpiresAt = new Date();
      planExpiresAt.setDate(planExpiresAt.getDate() + 30);

      const { error: planError } = await supabase
        .from('profiles')
        .update({
          plan_status: 'active',
          plan_renews_at: planExpiresAt.toISOString(),
        })
        .eq('id', authData.user.id);

      if (planError) {
        console.error('Error activating full access plan:', planError);
      } else {
        console.log('✅ Full access 30-day plan activated until:', planExpiresAt.toISOString());
      }
    }

    // ENVIAR WEBHOOK SE NÃO FOR VIP
    // Se comprou dorama unitário (não é VIP), enviar pro webhook
    if (!hasFullAccess) {
      console.log('📤 Usuário NÃO é VIP, enviando webhook para Dispara Aí');
      try {
        const formattedPhone = phone.startsWith('55') ? phone : `55${phone}`;
        const webhookResponse = await fetch(DISPARA_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            telefone: formattedPhone,
            origem: 'site'
          }),
        });

        if (webhookResponse.ok) {
          console.log('✅ Webhook de usuário cadastrado enviado com sucesso');
        } else {
          console.error('❌ Erro no webhook:', webhookResponse.status);
        }
      } catch (webhookError) {
        console.error('❌ Erro ao enviar webhook:', webhookError);
      }
    } else {
      console.log('⏭️ Usuário é VIP, NÃO enviando webhook');
    }

    // Atualizar TODAS as transactions deste visitor com user_id
    if (visitor_id) {
      const { error: txUpdateError } = await supabase
        .from('transactions')
        .update({ user_id: authData.user.id })
        .eq('checkout_session_id', checkout_session_id)
        .is('user_id', null);

      if (txUpdateError) {
        console.error('Error updating transactions:', txUpdateError);
      } else {
        console.log('✅ Transactions linked to user');
      }
    } else {
      // Fallback: atualizar apenas a transaction desta sessão
      const { error: txUpdateError } = await supabase
        .from('transactions')
        .update({ user_id: authData.user.id })
        .eq('checkout_session_id', checkout_session_id);

      if (txUpdateError) {
        console.error('Error updating transaction:', txUpdateError);
      } else {
        console.log('✅ Transaction linked to user');
      }
    }

    // Pegar slug do primeiro dorama para redirecionamento (se houver)
    let dramaSlug: string | null = null;
    const firstSession = allPaidSessions[0];
    const firstItems = firstSession.items as Array<{ type?: string; drama_id?: string; title: string; price: number }>;
    const firstDramaItem = firstItems.find(item => item.drama_id && item.type !== 'full_access_30_days');
    
    if (firstDramaItem?.drama_id) {
      const { data: drama } = await supabase
        .from('dramas')
        .select('slug')
        .eq('id', firstDramaItem.drama_id)
        .single();
      dramaSlug = drama?.slug || null;
    }

    // Criar session token para auto-login
    const { data: sessionData, error: sessionLinkError } = await supabase.auth.admin.generateLink({
      type: 'magiclink',
      email: userEmail,
    });

    // Contar total de doramas vinculados
    const { count: totalPurchases } = await supabase
      .from('user_purchases')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', authData.user.id);

    console.log('🎉 ACCOUNT CREATION COMPLETE - Total purchases:', totalPurchases);

    return new Response(
      JSON.stringify({
        success: true,
        userId: authData.user.id,
        dramaSlug: dramaSlug,
        hasFullAccess: hasFullAccess,
        sessionToken: sessionData?.properties?.action_link,
        purchasedCount: totalPurchases || 0,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Unexpected error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

/*
POSTMAN TEST PAYLOAD for /functions/v1/create-account-after-purchase:
{
  "checkout_session_id": "uuid-da-sessao-paga",
  "phone": "11999999999",
  "password": "senha123",
  "fullName": "João Silva"
}

Nota: Substitua checkout_session_id por um ID válido de checkout_sessions com status='paid'
*/