import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    // Verify admin authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authorization required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Create client with user's token to verify identity
    const supabaseAuth = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } }
    });

    const { data: { user: authUser }, error: authError } = await supabaseAuth.auth.getUser();
    if (authError || !authUser) {
      console.error('Auth error:', authError);
      return new Response(JSON.stringify({ error: 'Invalid authentication' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Use service role to check admin status
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Verify user is admin
    const { data: isAdmin } = await supabase.rpc('has_role', {
      _user_id: authUser.id,
      _role: 'admin'
    });

    if (!isAdmin) {
      console.error('Non-admin user attempted to activate premium:', authUser.id);
      return new Response(JSON.stringify({ error: 'Admin access required' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { email, userId } = await req.json();

    if (!email && !userId) {
      return new Response(JSON.stringify({ error: 'Email or userId required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Find user
    let query = supabase.from('profiles').select('id, email, plan_status');
    if (email) query = query.eq('email', email);
    if (userId) query = query.eq('id', userId);

    const { data: user, error: userError } = await query.single();

    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'User not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Activate premium
    const renewsAt = new Date();
    renewsAt.setDate(renewsAt.getDate() + 30);

    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        plan_status: 'active',
        plan_renews_at: renewsAt.toISOString(),
      })
      .eq('id', user.id);

    if (updateError) {
      console.error('Error activating user:', updateError);
      return new Response(JSON.stringify({ error: updateError.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Log audit
    await supabase.from('audit_logs').insert({
      user_id: authUser.id,
      action: 'MANUAL_PREMIUM_ACTIVATION',
      table_name: 'profiles',
      record_id: user.id,
      new_data: { plan_status: 'active', plan_renews_at: renewsAt.toISOString() }
    });

    console.log('Admin', authUser.id, 'manually activated premium for:', user.email);

    return new Response(
      JSON.stringify({ 
        success: true, 
        user: { id: user.id, email: user.email },
        message: 'Premium activated successfully'
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
