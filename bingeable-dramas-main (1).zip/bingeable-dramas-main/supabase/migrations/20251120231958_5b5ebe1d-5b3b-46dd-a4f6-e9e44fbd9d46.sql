-- Criar tabela para doramas em destaque gerenciados por admins
CREATE TABLE IF NOT EXISTS public.featured_dramas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  drama_id UUID NOT NULL REFERENCES public.dramas(id) ON DELETE CASCADE,
  section TEXT NOT NULL CHECK (section IN ('top_all_time', 'hero')),
  position INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(drama_id, section)
);

-- Habilitar RLS
ALTER TABLE public.featured_dramas ENABLE ROW LEVEL SECURITY;

-- Política: Todos podem visualizar destaques
CREATE POLICY "Anyone can view featured dramas"
  ON public.featured_dramas
  FOR SELECT
  USING (true);

-- Política: Apenas admins podem gerenciar destaques
CREATE POLICY "Admins can manage featured dramas"
  ON public.featured_dramas
  FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_featured_dramas_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER featured_dramas_updated_at
  BEFORE UPDATE ON public.featured_dramas
  FOR EACH ROW
  EXECUTE FUNCTION update_featured_dramas_updated_at();

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_featured_dramas_section ON public.featured_dramas(section);
CREATE INDEX IF NOT EXISTS idx_featured_dramas_position ON public.featured_dramas(position);