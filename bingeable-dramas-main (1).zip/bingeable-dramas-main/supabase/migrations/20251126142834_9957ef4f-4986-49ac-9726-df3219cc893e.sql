-- Criar tabela checkout_sessions para rastrear pagamentos anônimos
CREATE TABLE IF NOT EXISTS public.checkout_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_id TEXT UNIQUE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'BRL',
  items JSONB NOT NULL,
  customer_name TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'expired', 'canceled')),
  pix_code TEXT,
  checkout_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  paid_at TIMESTAMPTZ,
  expired_at TIMESTAMPTZ
);

-- RLS para checkout_sessions
ALTER TABLE public.checkout_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create checkout sessions"
ON public.checkout_sessions
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can view checkout sessions"
ON public.checkout_sessions
FOR SELECT
USING (true);

-- Adicionar colunas em webhook_events
ALTER TABLE public.webhook_events 
ADD COLUMN IF NOT EXISTS provider TEXT DEFAULT 'novaera',
ADD COLUMN IF NOT EXISTS status_processed TEXT DEFAULT 'pending';

-- Adicionar checkout_session_id em transactions e tornar user_id nullable
ALTER TABLE public.transactions 
ADD COLUMN IF NOT EXISTS checkout_session_id UUID REFERENCES public.checkout_sessions(id);

ALTER TABLE public.transactions 
ALTER COLUMN user_id DROP NOT NULL;

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_reference_id ON public.checkout_sessions(reference_id);
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_status ON public.checkout_sessions(status);
CREATE INDEX IF NOT EXISTS idx_webhook_events_status ON public.webhook_events(status_processed);
CREATE INDEX IF NOT EXISTS idx_transactions_checkout_session ON public.transactions(checkout_session_id);