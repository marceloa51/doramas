-- Atualizar função handle_new_user para aplicar TRIM no full_name
-- Isso garante que espaços extras sejam removidos mesmo se passarem pela validação do front-end

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    TRIM(COALESCE(NEW.raw_user_meta_data->>'full_name', ''))
  );
  RETURN NEW;
END;
$function$;