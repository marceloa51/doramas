-- Add youtube_id field to dramas table
ALTER TABLE public.dramas 
ADD COLUMN youtube_id TEXT;

COMMENT ON COLUMN public.dramas.youtube_id IS 'YouTube video ID for embedded playback';
