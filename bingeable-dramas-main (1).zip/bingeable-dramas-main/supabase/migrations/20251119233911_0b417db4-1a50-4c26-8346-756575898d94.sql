-- Add video_url to dramas table to support full movies
ALTER TABLE public.dramas ADD COLUMN video_url text;

-- Remove episodes reference since we're moving to full movies only
-- Keep the episodes table for now but we'll deprecate it in favor of video_url on dramas

COMMENT ON COLUMN public.dramas.video_url IS 'Direct URL to the hosted video file for streaming';