-- Update dorama default price from 9.90 to 12.90
ALTER TABLE public.dramas 
ALTER COLUMN price SET DEFAULT 12.90;

-- Update user_purchases default amount from 9.90 to 12.90
ALTER TABLE public.user_purchases 
ALTER COLUMN amount SET DEFAULT 12.90;

-- Update upsell_purchases default amount from 16.00 to keep proportional (or you can adjust)
-- Keeping this same since it's for multiple dramas