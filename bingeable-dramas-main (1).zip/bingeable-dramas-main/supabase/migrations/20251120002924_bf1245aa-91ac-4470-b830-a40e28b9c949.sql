-- Create user_dramas table for "Minha Lista"
CREATE TABLE IF NOT EXISTS public.user_dramas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  drama_id UUID NOT NULL REFERENCES public.dramas(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('watching','watched')),
  last_watched_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, drama_id)
);

ALTER TABLE public.user_dramas ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Users can manage own user_dramas" ON public.user_dramas;
DROP POLICY IF EXISTS "Admins can view all user_dramas" ON public.user_dramas;

-- Users can manage their own records
CREATE POLICY "Users can manage own user_dramas"
  ON public.user_dramas
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Admins can view all records
CREATE POLICY "Admins can view all user_dramas"
  ON public.user_dramas
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Trigger to keep updated_at in sync
DROP TRIGGER IF EXISTS user_dramas_set_updated_at ON public.user_dramas;
CREATE TRIGGER user_dramas_set_updated_at
  BEFORE UPDATE ON public.user_dramas
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Ensure profiles are automatically created when new auth users are created
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_trigger
    WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW
      EXECUTE FUNCTION public.handle_new_user();
  END IF;
END $$;