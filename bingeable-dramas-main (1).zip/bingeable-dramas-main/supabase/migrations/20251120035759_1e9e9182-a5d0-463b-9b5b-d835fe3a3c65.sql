-- =============================================
-- SISTEMA DE HOSPEDAGEM E REPRODUÇÃO DE VÍDEOS
-- =============================================

-- 1. Criar bucket de storage para vídeos
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'videos',
  'videos',
  false, -- não público, apenas URLs assinadas
  10737418240, -- 10GB por arquivo
  ARRAY['video/mp4', 'video/webm', 'video/ogg']
)
ON CONFLICT (id) DO NOTHING;

-- 2. Adicionar campo storage_path à tabela dramas existente
ALTER TABLE public.dramas 
ADD COLUMN IF NOT EXISTS storage_path text,
ADD COLUMN IF NOT EXISTS duration_seconds integer,
ADD COLUMN IF NOT EXISTS is_premium boolean DEFAULT true;

-- 3. Criar tabela para rastreamento de visualizações
CREATE TABLE IF NOT EXISTS public.movie_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  drama_id uuid REFERENCES public.dramas(id) ON DELETE CASCADE NOT NULL,
  last_position_seconds integer DEFAULT 0,
  is_preview_finished boolean DEFAULT false,
  preview_started_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, drama_id)
);

-- 4. Criar tabela para controle de sessões (Anti-Share)
CREATE TABLE IF NOT EXISTS public.user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  session_token text NOT NULL,
  user_agent text,
  ip_hash text,
  fingerprint text,
  is_active boolean DEFAULT true,
  last_activity_at timestamp with time zone DEFAULT now(),
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(session_token)
);

-- 5. Habilitar RLS nas novas tabelas
ALTER TABLE public.movie_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;

-- 6. Políticas RLS para movie_views
CREATE POLICY "Users can view own movie progress"
ON public.movie_views FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own movie progress"
ON public.movie_views FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own movie progress"
ON public.movie_views FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all movie views"
ON public.movie_views FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- 7. Políticas RLS para user_sessions
CREATE POLICY "Users can view own sessions"
ON public.user_sessions FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own sessions"
ON public.user_sessions FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sessions"
ON public.user_sessions FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all sessions"
ON public.user_sessions FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete sessions"
ON public.user_sessions FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- 8. Políticas de Storage para bucket de vídeos
CREATE POLICY "Authenticated users can view videos via signed URLs"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'videos' 
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Admins can upload videos"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'videos' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can update videos"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'videos' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can delete videos"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'videos' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- 9. Função para limpar sessões inativas (executar periodicamente)
CREATE OR REPLACE FUNCTION public.cleanup_inactive_sessions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Marcar como inativas sessões sem atividade há mais de 24 horas
  UPDATE public.user_sessions
  SET is_active = false
  WHERE last_activity_at < NOW() - INTERVAL '24 hours'
    AND is_active = true;
    
  -- Deletar sessões muito antigas (mais de 30 dias)
  DELETE FROM public.user_sessions
  WHERE created_at < NOW() - INTERVAL '30 days';
END;
$$;

-- 10. Trigger para atualizar updated_at em movie_views
CREATE OR REPLACE FUNCTION public.update_movie_views_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_movie_views_timestamp
BEFORE UPDATE ON public.movie_views
FOR EACH ROW
EXECUTE FUNCTION public.update_movie_views_updated_at();

-- 11. Índices para performance
CREATE INDEX IF NOT EXISTS idx_movie_views_user_drama 
ON public.movie_views(user_id, drama_id);

CREATE INDEX IF NOT EXISTS idx_user_sessions_user_active 
ON public.user_sessions(user_id, is_active);

CREATE INDEX IF NOT EXISTS idx_user_sessions_token 
ON public.user_sessions(session_token);

-- 12. Comentários de documentação
COMMENT ON TABLE public.movie_views IS 'Rastreia o progresso de visualização de filmes por usuário';
COMMENT ON TABLE public.user_sessions IS 'Controla sessões ativas para prevenção de compartilhamento de contas';
COMMENT ON COLUMN public.dramas.storage_path IS 'Caminho do arquivo de vídeo no bucket de storage';
COMMENT ON COLUMN public.dramas.duration_seconds IS 'Duração total do filme em segundos';
COMMENT ON COLUMN public.dramas.is_premium IS 'Define se o filme é premium (requer assinatura completa)';