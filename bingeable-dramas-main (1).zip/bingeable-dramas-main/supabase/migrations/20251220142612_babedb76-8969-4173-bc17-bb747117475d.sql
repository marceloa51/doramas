-- Habilitar extensão pg_net para chamadas HTTP
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Criar função que dispara o webhook para novos leads
CREATE OR REPLACE FUNCTION public.notify_new_lead()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Chamar edge function send-lead-webhook
  PERFORM extensions.http_post(
    url := 'https://mobdsjupoklbkfluctmk.supabase.co/functions/v1/send-lead-webhook',
    headers := jsonb_build_object(
      'Content-Type', 'application/json'
    ),
    body := jsonb_build_object(
      'record', row_to_json(NEW)
    )
  );
  
  RETURN NEW;
END;
$$;

-- Criar trigger que dispara em cada INSERT na tabela leads
DROP TRIGGER IF EXISTS on_new_lead_inserted ON public.leads;
CREATE TRIGGER on_new_lead_inserted
  AFTER INSERT ON public.leads
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_new_lead();