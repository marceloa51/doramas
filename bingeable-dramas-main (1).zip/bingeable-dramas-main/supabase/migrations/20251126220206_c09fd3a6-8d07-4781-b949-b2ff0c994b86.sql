-- Adicionar constraint unique para evitar duplicatas em user_purchases
ALTER TABLE user_purchases 
ADD CONSTRAINT user_purchases_user_drama_unique 
UNIQUE (user_id, drama_id);