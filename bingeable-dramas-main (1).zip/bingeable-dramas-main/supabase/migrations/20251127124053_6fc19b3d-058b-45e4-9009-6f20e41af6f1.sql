-- Update dorama default price from 7.00 to 9.90
ALTER TABLE public.dramas 
ALTER COLUMN price SET DEFAULT 9.90;

-- Update user_purchases default amount from 7.00 to 9.90
ALTER TABLE public.user_purchases 
ALTER COLUMN amount SET DEFAULT 9.90;