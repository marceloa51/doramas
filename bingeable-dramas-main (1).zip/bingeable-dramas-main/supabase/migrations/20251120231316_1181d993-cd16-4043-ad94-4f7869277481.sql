-- Criar tabela para rastrear progresso de visualização
CREATE TABLE IF NOT EXISTS public.watch_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  drama_id UUID NOT NULL REFERENCES public.dramas(id) ON DELETE CASCADE,
  position_seconds INTEGER NOT NULL DEFAULT 0,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  progress_percent NUMERIC GENERATED ALWAYS AS (
    CASE 
      WHEN duration_seconds > 0 THEN (position_seconds::NUMERIC / duration_seconds::NUMERIC * 100)
      ELSE 0
    END
  ) STORED,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, drama_id)
);

-- Habilitar RLS
ALTER TABLE public.watch_progress ENABLE ROW LEVEL SECURITY;

-- Política: Usuários podem ver seu próprio progresso
CREATE POLICY "Users can view own progress"
  ON public.watch_progress
  FOR SELECT
  USING (auth.uid() = user_id);

-- Política: Usuários podem inserir seu próprio progresso
CREATE POLICY "Users can insert own progress"
  ON public.watch_progress
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Política: Usuários podem atualizar seu próprio progresso
CREATE POLICY "Users can update own progress"
  ON public.watch_progress
  FOR UPDATE
  USING (auth.uid() = user_id);

-- Política: Usuários podem deletar seu próprio progresso
CREATE POLICY "Users can delete own progress"
  ON public.watch_progress
  FOR DELETE
  USING (auth.uid() = user_id);

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_watch_progress_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER watch_progress_updated_at
  BEFORE UPDATE ON public.watch_progress
  FOR EACH ROW
  EXECUTE FUNCTION update_watch_progress_updated_at();

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_watch_progress_user_id ON public.watch_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_watch_progress_drama_id ON public.watch_progress(drama_id);
CREATE INDEX IF NOT EXISTS idx_watch_progress_updated_at ON public.watch_progress(updated_at DESC);