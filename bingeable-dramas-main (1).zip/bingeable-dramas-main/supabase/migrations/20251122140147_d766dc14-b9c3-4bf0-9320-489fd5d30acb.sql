-- ============================================
-- PROGRAMA DE AFILIADOS DORAMAS SUPER
-- ============================================

-- 1. CRIAR TABELA WALLETS (CARTEIRA)
CREATE TABLE IF NOT EXISTS public.wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  available_balance NUMERIC(10, 2) DEFAULT 0 NOT NULL CHECK (available_balance >= 0),
  total_earned NUMERIC(10, 2) DEFAULT 0 NOT NULL,
  total_withdrawn NUMERIC(10, 2) DEFAULT 0 NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX idx_wallets_user_id ON public.wallets(user_id);

ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own wallet" ON public.wallets
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins view all wallets" ON public.wallets
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 2. CRIAR ENUM E TABELA WALLET_TRANSACTIONS
CREATE TYPE public.wallet_transaction_type AS ENUM (
  'REFERRAL_BONUS',
  'WITHDRAWAL_REQUEST',
  'WITHDRAWAL_APPROVED',
  'WITHDRAWAL_REJECTED',
  'FREE_MONTH_BONUS',
  'ADMIN_ADJUSTMENT'
);

CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type public.wallet_transaction_type NOT NULL,
  amount NUMERIC(10, 2) NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX idx_wallet_transactions_user_id ON public.wallet_transactions(user_id);
CREATE INDEX idx_wallet_transactions_type ON public.wallet_transactions(type);
CREATE INDEX idx_wallet_transactions_created_at ON public.wallet_transactions(created_at DESC);

ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own transactions" ON public.wallet_transactions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins view all transactions" ON public.wallet_transactions
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 3. CRIAR ENUM E TABELA WITHDRAWAL_REQUESTS
CREATE TYPE public.withdrawal_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

CREATE TABLE IF NOT EXISTS public.withdrawal_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount NUMERIC(10, 2) NOT NULL CHECK (amount >= 30),
  pix_key TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  status public.withdrawal_status DEFAULT 'PENDING' NOT NULL,
  admin_id UUID REFERENCES public.profiles(id),
  admin_note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  processed_at TIMESTAMPTZ
);

CREATE INDEX idx_withdrawal_requests_user_id ON public.withdrawal_requests(user_id);
CREATE INDEX idx_withdrawal_requests_status ON public.withdrawal_requests(status);
CREATE INDEX idx_withdrawal_requests_created_at ON public.withdrawal_requests(created_at DESC);

ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own requests" ON public.withdrawal_requests
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users create own requests" ON public.withdrawal_requests
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins view all requests" ON public.withdrawal_requests
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 4. ATUALIZAR TABELA PROFILES
ALTER TABLE public.profiles 
  ADD COLUMN IF NOT EXISTS free_months_granted INTEGER DEFAULT 0 NOT NULL,
  ADD COLUMN IF NOT EXISTS first_payment_processed BOOLEAN DEFAULT FALSE NOT NULL;

-- 5. CRIAR TRIGGER PARA CRIAR CARTEIRA AUTOMATICAMENTE
CREATE OR REPLACE FUNCTION public.create_wallet_for_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.wallets (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER create_wallet_on_profile
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.create_wallet_for_user();

-- 6. CRIAR CARTEIRAS PARA USUÁRIOS EXISTENTES
INSERT INTO public.wallets (user_id)
SELECT id FROM public.profiles
WHERE id NOT IN (SELECT user_id FROM public.wallets)
ON CONFLICT (user_id) DO NOTHING;