-- ============================================
-- SECURITY FIXES: RLS Policies & Audit Logging
-- ============================================

-- 1. CREATE AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id UUID,
  old_data JSONB,
  new_data JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS on audit_logs
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can view audit logs
CREATE POLICY "Admins can view all audit logs"
ON public.audit_logs
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Create index for performance
CREATE INDEX idx_audit_logs_user_id ON public.audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON public.audit_logs(created_at DESC);

-- 2. IMPROVE WALLET_TRANSACTIONS SECURITY
-- Add explicit denial policy for direct modifications
CREATE POLICY "Deny direct wallet transaction modifications"
ON public.wallet_transactions
FOR INSERT
TO authenticated
WITH CHECK (false);

CREATE POLICY "Deny direct wallet transaction updates"
ON public.wallet_transactions
FOR UPDATE
TO authenticated
USING (false);

CREATE POLICY "Deny direct wallet transaction deletions"
ON public.wallet_transactions
FOR DELETE
TO authenticated
USING (false);

-- 3. IMPROVE PROFILES SECURITY
-- Drop existing policies and recreate with stricter rules
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;

-- Users can only view their own active profile
CREATE POLICY "Users can view own active profile"
ON public.profiles
FOR SELECT
TO authenticated
USING (auth.uid() = id AND is_active = true);

-- Users can only update their own profile
CREATE POLICY "Users can update own profile safely"
ON public.profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id AND is_active = true)
WITH CHECK (auth.uid() = id AND is_active = true);

-- 4. ADD RLS TO SEARCH_QUERIES
-- Drop existing policy if any
DROP POLICY IF EXISTS "Anyone can insert search queries" ON public.search_queries;

-- Users can only view their own searches
CREATE POLICY "Users can view own searches"
ON public.search_queries
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Users can insert their own searches
CREATE POLICY "Users can insert own searches"
ON public.search_queries
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- 5. IMPROVE VIDEO_VIEWS SECURITY
-- Add policy to prevent viewing other users' history
DROP POLICY IF EXISTS "Users can view own video views" ON public.video_views;

CREATE POLICY "Users can view only own video views"
ON public.video_views
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- 6. IMPROVE USER_SESSIONS SECURITY
-- Prevent users from viewing other users' sessions
DROP POLICY IF EXISTS "Users can view own sessions" ON public.user_sessions;

CREATE POLICY "Users can view only own sessions"
ON public.user_sessions
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- 7. ADD DATA RETENTION HELPER FUNCTION
-- Function to clean old data (to be called by cron)
CREATE OR REPLACE FUNCTION public.cleanup_old_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete old search queries (>90 days)
  DELETE FROM public.search_queries 
  WHERE created_at < NOW() - INTERVAL '90 days';
  
  -- Delete old video views (>180 days)
  DELETE FROM public.video_views 
  WHERE created_at < NOW() - INTERVAL '180 days';
  
  -- Delete old inactive sessions (>30 days)
  DELETE FROM public.user_sessions 
  WHERE last_activity_at < NOW() - INTERVAL '30 days'
    AND is_active = false;
    
  -- Delete old audit logs (>1 year)
  DELETE FROM public.audit_logs
  WHERE created_at < NOW() - INTERVAL '1 year';
END;
$$;

-- 8. ADD FUNCTION TO LOG SECURITY EVENTS
CREATE OR REPLACE FUNCTION public.log_security_event(
  p_action TEXT,
  p_table_name TEXT,
  p_record_id UUID DEFAULT NULL,
  p_old_data JSONB DEFAULT NULL,
  p_new_data JSONB DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_log_id UUID;
BEGIN
  INSERT INTO public.audit_logs (
    user_id,
    action,
    table_name,
    record_id,
    old_data,
    new_data
  ) VALUES (
    auth.uid(),
    p_action,
    p_table_name,
    p_record_id,
    p_old_data,
    p_new_data
  )
  RETURNING id INTO v_log_id;
  
  RETURN v_log_id;
END;
$$;