-- 1. Adicionar campos de convite na tabela profiles
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS ref_code TEXT UNIQUE,
ADD COLUMN IF NOT EXISTS referred_by UUID REFERENCES public.profiles(id),
ADD COLUMN IF NOT EXISTS referral_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- Gerar ref_code único para usuários existentes
UPDATE public.profiles
SET ref_code = LOWER(SUBSTRING(MD5(RANDOM()::TEXT), 1, 8))
WHERE ref_code IS NULL;

-- 2. Criar tabela de visualizações de vídeos
CREATE TABLE IF NOT EXISTS public.video_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  drama_id UUID REFERENCES public.dramas(id) ON DELETE CASCADE NOT NULL,
  watched_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  watch_duration INTEGER DEFAULT 0,
  device TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.video_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own video views"
ON public.video_views FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all video views"
ON public.video_views FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can view own video views"
ON public.video_views FOR SELECT
USING (auth.uid() = user_id);

-- Índice para melhorar performance de queries
CREATE INDEX IF NOT EXISTS idx_video_views_drama_watched 
ON public.video_views(drama_id, watched_at DESC);

CREATE INDEX IF NOT EXISTS idx_video_views_user 
ON public.video_views(user_id);

-- 3. Criar tabela de pesquisas
CREATE TABLE IF NOT EXISTS public.search_queries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  query TEXT NOT NULL,
  results_count INTEGER DEFAULT 0,
  clicked_drama_id UUID REFERENCES public.dramas(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.search_queries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert search queries"
ON public.search_queries FOR INSERT
WITH CHECK (true);

CREATE POLICY "Admins can view all search queries"
ON public.search_queries FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Índices para relatórios
CREATE INDEX IF NOT EXISTS idx_search_queries_created 
ON public.search_queries(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_search_queries_query 
ON public.search_queries(query);

-- 4. Criar função para gerar ref_code único
CREATE OR REPLACE FUNCTION public.generate_ref_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.ref_code IS NULL THEN
    NEW.ref_code := LOWER(SUBSTRING(MD5(RANDOM()::TEXT || NEW.id::TEXT), 1, 8));
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para gerar ref_code automaticamente
DROP TRIGGER IF EXISTS generate_ref_code_trigger ON public.profiles;
CREATE TRIGGER generate_ref_code_trigger
BEFORE INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.generate_ref_code();

-- 5. Criar função para incrementar contador de indicações
CREATE OR REPLACE FUNCTION public.increment_referral_count()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.referred_by IS NOT NULL AND OLD.referred_by IS NULL THEN
    UPDATE public.profiles
    SET referral_count = referral_count + 1
    WHERE id = NEW.referred_by;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para incrementar contador
DROP TRIGGER IF EXISTS increment_referral_trigger ON public.profiles;
CREATE TRIGGER increment_referral_trigger
AFTER UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.increment_referral_count();