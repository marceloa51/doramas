-- Criar constraint unique para user_id + drama_id na tabela movie_views
-- Isso permite fazer upsert corretamente

-- Primeiro, remover duplicatas se existirem
DELETE FROM movie_views a
USING movie_views b
WHERE a.id < b.id
  AND a.user_id = b.user_id
  AND a.drama_id = b.drama_id;

-- Criar índice unique
CREATE UNIQUE INDEX IF NOT EXISTS movie_views_user_drama_unique 
ON movie_views(user_id, drama_id);