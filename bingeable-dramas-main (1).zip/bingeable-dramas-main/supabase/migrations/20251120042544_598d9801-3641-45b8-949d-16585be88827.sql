-- Fix: Add SET search_path to can_watch_episode function

CREATE OR REPLACE FUNCTION public.can_watch_episode(episode_id uuid, user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  episode_number INTEGER;
  user_plan plan_status;
BEGIN
  -- Get episode number
  SELECT e.episode_number INTO episode_number
  FROM public.episodes e
  WHERE e.id = episode_id;

  -- Check if episode is free (episodes 1-5)
  IF episode_number <= 5 THEN
    RETURN true;
  END IF;

  -- Check if user has active plan
  SELECT p.plan_status INTO user_plan
  FROM public.profiles p
  WHERE p.id = user_id;

  RETURN user_plan = 'active';
END;
$function$;