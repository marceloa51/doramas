-- Add session control fields to profiles table
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS current_session_id TEXT,
ADD COLUMN IF NOT EXISTS last_device JSONB,
ADD COLUMN IF NOT EXISTS last_ip TEXT;

-- Index for fast session lookup
CREATE INDEX IF NOT EXISTS idx_profiles_current_session_id 
ON public.profiles(current_session_id);

-- Ensure only 1 active session per user
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_sessions_active_unique 
ON public.user_sessions(user_id) 
WHERE is_active = true;