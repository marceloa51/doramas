-- Add start_position_seconds column to dramas table
ALTER TABLE public.dramas 
ADD COLUMN IF NOT EXISTS start_position_seconds INTEGER DEFAULT 0;

COMMENT ON COLUMN public.dramas.start_position_seconds IS 'Position in seconds where the video should start when user clicks "Continue from where I stopped"';