-- Remove the permissive policy that exposes payment data to everyone
DROP POLICY IF EXISTS "Anyone can view checkout sessions" ON checkout_sessions;

-- Create restrictive policy: only admins can view all checkout sessions
CREATE POLICY "Admins can view all checkout sessions" 
ON checkout_sessions
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));