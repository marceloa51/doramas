-- Criar tabela whatsapp_events para controle de mensagens enviadas
CREATE TABLE public.whatsapp_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone TEXT NOT NULL,
  event_type TEXT NOT NULL,
  reference_id TEXT,
  message_id TEXT,
  status TEXT DEFAULT 'sent',
  error_message TEXT,
  sent_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Índice único para idempotência (evitar duplicatas)
CREATE UNIQUE INDEX idx_whatsapp_unique_event 
ON public.whatsapp_events(phone, event_type, reference_id);

-- Índices para consultas
CREATE INDEX idx_whatsapp_events_phone ON public.whatsapp_events(phone);
CREATE INDEX idx_whatsapp_events_type ON public.whatsapp_events(event_type);
CREATE INDEX idx_whatsapp_events_sent_at ON public.whatsapp_events(sent_at);

-- Enable RLS
ALTER TABLE public.whatsapp_events ENABLE ROW LEVEL SECURITY;

-- Apenas admins podem visualizar
CREATE POLICY "Admins can view all whatsapp events" 
ON public.whatsapp_events 
FOR SELECT 
USING (has_role(auth.uid(), 'admin'::app_role));