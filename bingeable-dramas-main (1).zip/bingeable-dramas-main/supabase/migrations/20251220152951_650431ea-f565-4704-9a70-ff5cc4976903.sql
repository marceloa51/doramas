-- Adicionar coluna para controle de notificação de abandono
ALTER TABLE public.checkout_sessions 
ADD COLUMN IF NOT EXISTS abandoned_notified boolean DEFAULT false;

-- Criar índice para otimizar a busca de sessões abandonadas
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_abandoned 
ON public.checkout_sessions (status, abandoned_notified, created_at) 
WHERE status = 'pending' AND abandoned_notified = false;