-- Add file_url field to dramas table for custom video server integration
ALTER TABLE public.dramas 
ADD COLUMN IF NOT EXISTS file_url TEXT;

COMMENT ON COLUMN public.dramas.file_url IS 'Direct URL to video file on custom server (e.g., http://5.189.155.6/videos/movie.mp4)';
