-- Função que notifica quando pagamento é confirmado
CREATE OR REPLACE FUNCTION public.notify_payment_confirmed()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Só dispara quando status MUDA para 'paid' (evita duplicatas)
  IF NEW.status = 'paid' AND (OLD.status IS NULL OR OLD.status != 'paid') THEN
    PERFORM net.http_post(
      url := 'https://mobdsjupoklbkfluctmk.supabase.co/functions/v1/send-payment-webhook',
      headers := '{"Content-Type": "application/json"}'::jsonb,
      body := jsonb_build_object('record', row_to_json(NEW))
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger que dispara APÓS update na tabela checkout_sessions
DROP TRIGGER IF EXISTS on_payment_confirmed ON public.checkout_sessions;

CREATE TRIGGER on_payment_confirmed
  AFTER UPDATE ON public.checkout_sessions
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_payment_confirmed();