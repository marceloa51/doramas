-- Fase 1: Adicionar novo campo genres (array de text)
ALTER TABLE public.dramas ADD COLUMN IF NOT EXISTS genres text[];

-- Fase 2: Migrar dados existentes de genre (string) para genres (array)
-- Dividir o campo genre por " • " e criar array
UPDATE public.dramas
SET genres = 
  CASE 
    WHEN genre IS NOT NULL AND genre != '' THEN 
      string_to_array(
        regexp_replace(genre, '\s*•\s*', '•', 'g'), 
        '•'
      )
    ELSE ARRAY[]::text[]
  END
WHERE genres IS NULL;

-- Fase 3: Remover o campo genre antigo
ALTER TABLE public.dramas DROP COLUMN IF EXISTS genre;