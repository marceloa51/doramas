-- Add payment_method column to checkout_sessions
ALTER TABLE public.checkout_sessions 
ADD COLUMN payment_method TEXT DEFAULT 'pix';

-- Add index for faster queries
CREATE INDEX idx_checkout_sessions_payment_method ON public.checkout_sessions(payment_method);