-- Fase 1: Adicionar constraints e coluna username_locked
ALTER TABLE public.profiles 
ADD CONSTRAINT profiles_username_unique UNIQUE (username);

CREATE INDEX IF NOT EXISTS idx_profiles_username 
ON public.profiles(username) 
WHERE username IS NOT NULL;

ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS username_locked BOOLEAN DEFAULT FALSE;

-- Fase 2: Atualizar trigger para gerar ref_code baseado no username
CREATE OR REPLACE FUNCTION public.generate_ref_code()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Se username foi definido pela primeira vez, usar como ref_code
  IF NEW.username IS NOT NULL AND (OLD.username IS NULL OR OLD.username = '') THEN
    NEW.ref_code := LOWER(NEW.username);
    NEW.username_locked := TRUE;
  -- Se não há username ainda, gerar código aleatório (fallback)
  ELSIF NEW.ref_code IS NULL THEN
    NEW.ref_code := LOWER(SUBSTRING(MD5(RANDOM()::TEXT || NEW.id::TEXT), 1, 8));
  END IF;
  RETURN NEW;
END;
$$;

-- Aplicar trigger também no UPDATE
DROP TRIGGER IF EXISTS generate_ref_code_trigger ON public.profiles;
CREATE TRIGGER generate_ref_code_trigger
BEFORE INSERT OR UPDATE OF username ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.generate_ref_code();