-- Adicionar coluna visitor_id na tabela checkout_sessions
ALTER TABLE public.checkout_sessions ADD COLUMN IF NOT EXISTS visitor_id TEXT;

-- Criar índice para melhorar performance de busca
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_visitor_id ON public.checkout_sessions(visitor_id);

-- Comentário explicativo
COMMENT ON COLUMN public.checkout_sessions.visitor_id IS 'Identificador único do visitante (navegador/dispositivo) para rastrear compras anônimas antes da criação de conta';