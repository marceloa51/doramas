-- Marcar como expired todas as sessões pendentes antigas (mais de 30 minutos)
-- Isso limpa o histórico antigo para não ser processado novamente
UPDATE checkout_sessions 
SET status = 'expired' 
WHERE status = 'pending' 
  AND created_at < NOW() - INTERVAL '30 minutes';