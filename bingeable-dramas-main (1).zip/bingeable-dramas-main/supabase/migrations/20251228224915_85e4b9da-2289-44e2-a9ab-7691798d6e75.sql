-- Tabela para armazenar pedidos de reset de senha
CREATE TABLE public.password_reset_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone TEXT NOT NULL,
  otp_hash TEXT NOT NULL,
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 5,
  verified BOOLEAN DEFAULT false,
  used BOOLEAN DEFAULT false,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  ip_address TEXT
);

-- Index para rate-limit por telefone
CREATE INDEX idx_password_reset_phone_created ON password_reset_requests(phone, created_at);

-- Index para busca por id
CREATE INDEX idx_password_reset_id ON password_reset_requests(id);

-- RLS: Apenas service_role pode acessar (sem policies públicas)
ALTER TABLE password_reset_requests ENABLE ROW LEVEL SECURITY;

-- Comentário na tabela
COMMENT ON TABLE password_reset_requests IS 'Armazena pedidos de reset de senha via OTP WhatsApp';