-- Corrigir função para usar net.http_post (nome correto do pg_net)
CREATE OR REPLACE FUNCTION public.notify_new_lead()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Chamar edge function send-lead-webhook usando net.http_post
  PERFORM net.http_post(
    url := 'https://mobdsjupoklbkfluctmk.supabase.co/functions/v1/send-lead-webhook',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object('record', row_to_json(NEW))
  );
  
  RETURN NEW;
END;
$$;