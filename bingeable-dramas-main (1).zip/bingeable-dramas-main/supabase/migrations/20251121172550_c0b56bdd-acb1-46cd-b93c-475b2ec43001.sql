-- Adicionar campo para controlar se usuário já usou cupom de convite
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS referral_coupon_used BOOLEAN NOT NULL DEFAULT false;

-- Índice para busca rápida
CREATE INDEX IF NOT EXISTS idx_profiles_referral_coupon_used 
ON public.profiles(referral_coupon_used);

-- Comentário explicativo
COMMENT ON COLUMN public.profiles.referral_coupon_used IS 
'Indica se o usuário já usou um código de convite como cupom de desconto (R$ 12,50 no primeiro pagamento)';