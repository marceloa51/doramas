-- Corrigir função de atualização de progresso com search_path
DROP TRIGGER IF EXISTS watch_progress_updated_at ON public.watch_progress;
DROP FUNCTION IF EXISTS update_watch_progress_updated_at() CASCADE;

CREATE OR REPLACE FUNCTION update_watch_progress_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER watch_progress_updated_at
  BEFORE UPDATE ON public.watch_progress
  FOR EACH ROW
  EXECUTE FUNCTION update_watch_progress_updated_at();