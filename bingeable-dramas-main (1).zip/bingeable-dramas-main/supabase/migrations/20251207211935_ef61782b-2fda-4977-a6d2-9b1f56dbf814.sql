-- Criar tabela para rastrear visitas ao site
CREATE TABLE public.page_visits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL,
  page_path TEXT NOT NULL DEFAULT '/',
  user_agent TEXT,
  ip_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Índice para consultas por data
CREATE INDEX idx_page_visits_created_at ON public.page_visits(created_at);

-- RLS: Admins podem visualizar, sistema pode inserir
ALTER TABLE public.page_visits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all visits" ON public.page_visits
  FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can insert visits" ON public.page_visits
  FOR INSERT WITH CHECK (true);