-- Criar tabela de compras individuais de doramas
CREATE TABLE IF NOT EXISTS public.user_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  drama_id UUID NOT NULL REFERENCES public.dramas(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL DEFAULT 7.00,
  transaction_id UUID REFERENCES public.transactions(id),
  purchased_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, drama_id)
);

-- Habilitar RLS na tabela user_purchases
ALTER TABLE public.user_purchases ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para user_purchases
CREATE POLICY "Users can view own purchases" 
ON public.user_purchases
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "System can insert purchases" 
ON public.user_purchases
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Criar tabela de compras de upsell (2 doramas por R$16)
CREATE TABLE IF NOT EXISTS public.upsell_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  original_purchase_id UUID REFERENCES public.user_purchases(id),
  drama_ids UUID[] NOT NULL,
  amount NUMERIC NOT NULL DEFAULT 16.00,
  transaction_id UUID REFERENCES public.transactions(id),
  purchased_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Habilitar RLS na tabela upsell_purchases
ALTER TABLE public.upsell_purchases ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para upsell_purchases
CREATE POLICY "Users can view own upsell purchases" 
ON public.upsell_purchases
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "System can insert upsell purchases" 
ON public.upsell_purchases
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Adicionar coluna de preço na tabela dramas
ALTER TABLE public.dramas 
ADD COLUMN IF NOT EXISTS price NUMERIC NOT NULL DEFAULT 7.00;

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_user_purchases_user_id ON public.user_purchases(user_id);
CREATE INDEX IF NOT EXISTS idx_user_purchases_drama_id ON public.user_purchases(drama_id);
CREATE INDEX IF NOT EXISTS idx_upsell_purchases_user_id ON public.upsell_purchases(user_id);