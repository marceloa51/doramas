import { supabase } from "@/integrations/supabase/client";
import { getOrCreateVisitorId } from "./visitorManager";

const LAST_VISIT_KEY = 'doramassuper_last_visit_date';

export const trackPageVisit = async () => {
  try {
    // 1. Verificar se usuário está logado - não contar visita
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      return; // Usuário logado, não registrar visita
    }

    // 2. Verificar se já visitou hoje
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const lastVisitDate = localStorage.getItem(LAST_VISIT_KEY);
    
    if (lastVisitDate === today) {
      return; // Já visitou hoje, não registrar duplicata
    }

    // 3. Registrar visita e salvar data
    const visitorId = getOrCreateVisitorId();
    
    await (supabase as any).from("page_visits").insert({
      visitor_id: visitorId,
      page_path: window.location.pathname,
      user_agent: navigator.userAgent
    });

    // Marcar que já visitou hoje
    localStorage.setItem(LAST_VISIT_KEY, today);
    
  } catch (error) {
    console.error("Error tracking visit:", error);
  }
};
