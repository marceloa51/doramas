interface Drama {
  id: string;
  title: string;
  slug: string;
  synopsis: string | null;
  genres: string[] | null;
  thumbnail_url: string | null;
  cover_url: string | null;
  created_at?: string | null;
}

interface SEOData {
  title: string;
  description: string;
  keywords: string[];
  canonical: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  schema: object;
}

const SITE_URL = "https://doramassuper.site";

function generateTitleVariation(title: string, genres: string[] | null): string {
  const firstGenre = genres && genres.length > 0 ? genres[0].toLowerCase() : "";
  
  const variations: { [key: string]: string } = {
    romance: `Assistir ${title} Dublado Online - Romance Completo | Doramas Super`,
    ação: `Assistir ${title} Dublado em HD - Ação e Aventura | Doramas Super`,
    drama: `${title} Completo Dublado Online em Alta Qualidade | Doramas Super`,
    fantasia: `${title} - Fantasia Dublada Completa em HD | Doramas Super`,
    mistério: `Ver ${title} Dublado Online - Mistério Completo | Doramas Super`,
    suspense: `Assistir ${title} Dublado - Suspense Completo em HD | Doramas Super`,
    comédia: `${title} Dublado Online - Comédia Completa | Doramas Super`,
  };
  
  return variations[firstGenre] || `Assistir ${title} Dublado Online em HD | Doramas Super`;
}

function generateUniqueDescription(
  synopsis: string | null,
  genres: string[] | null
): string {
  if (!synopsis) {
    const genreText = genres && genres.length > 0 
      ? genres.slice(0, 2).join(" e ") 
      : "Dorama";
    return `Assista online em HD com qualidade superior. ${genreText} dublado completo disponível agora.`;
  }
  
  // Remove quebras de linha e espaços extras
  const cleanSynopsis = synopsis.replace(/\s+/g, " ").trim();
  
  // Pega os primeiros 130 caracteres da sinopse
  let desc = cleanSynopsis.slice(0, 130);
  
  // Encontra o último espaço para não cortar palavras
  const lastSpace = desc.lastIndexOf(" ");
  if (lastSpace > 100) {
    desc = desc.slice(0, lastSpace);
  }
  
  // Adiciona sufixo único baseado nos gêneros
  const genreText = genres && genres.length > 0
    ? genres.slice(0, 2).join(" e ")
    : "Dorama";
  desc += `... ${genreText} dublado em HD.`;
  
  return desc;
}

function generateKeywords(title: string, genres: string[] | null): string[] {
  const baseKeywords = [
    `assistir ${title.toLowerCase()}`,
    `${title.toLowerCase()} dublado`,
    `${title.toLowerCase()} online`,
    `${title.toLowerCase()} completo`,
    "doramas dublados",
    "doramas online",
    "doramas super",
  ];
  
  // Adiciona keywords por gênero
  if (genres && genres.length > 0) {
    genres.forEach((genre) => {
      baseKeywords.push(`dorama ${genre.toLowerCase()}`);
      baseKeywords.push(`${genre.toLowerCase()} dublado`);
    });
  }
  
  return baseKeywords;
}

export function generateDramaSEO(
  drama: Drama,
  pageType: "movie" | "drama"
): SEOData {
  const title = generateTitleVariation(drama.title, drama.genres);
  const description = generateUniqueDescription(drama.synopsis, drama.genres);
  const keywords = generateKeywords(drama.title, drama.genres);
  const canonical = `${SITE_URL}/${pageType === "movie" ? "movie" : "drama"}/${drama.slug}`;
  const ogImage = drama.thumbnail_url || drama.cover_url || `${SITE_URL}/og-image.jpg`;
  
  const schema = {
    "@context": "https://schema.org",
    "@type": pageType === "movie" ? "Movie" : "TVSeries",
    name: drama.title,
    description: drama.synopsis || description,
    genre: drama.genres || [],
    contentUrl: canonical,
    thumbnailUrl: ogImage,
    image: ogImage,
    inLanguage: "pt-BR",
    datePublished: drama.created_at || new Date().toISOString(),
    publisher: {
      "@type": "Organization",
      name: "Doramas Super",
      logo: {
        "@type": "ImageObject",
        url: `${SITE_URL}/og-image.jpg`,
      },
    },
    potentialAction: {
      "@type": "WatchAction",
      target: canonical,
    },
  };
  
  return {
    title,
    description,
    keywords,
    canonical,
    ogTitle: title,
    ogDescription: description,
    ogImage,
    schema,
  };
}
