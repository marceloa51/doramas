// Gerenciador de visitor_id persistente para rastreamento de compras anônimas
const VISITOR_ID_KEY = 'doramassuper_visitor_id';
const LAST_ORDER_KEY = 'doramassuper_last_order';

/**
 * Obtém ou cria um visitor_id único para este navegador/dispositivo
 */
export const getOrCreateVisitorId = (): string => {
  let visitorId = localStorage.getItem(VISITOR_ID_KEY);
  if (!visitorId) {
    visitorId = crypto.randomUUID();
    localStorage.setItem(VISITOR_ID_KEY, visitorId);
  }
  return visitorId;
};

/**
 * Obtém o visitor_id existente (pode ser null)
 */
export const getVisitorId = (): string | null => {
  return localStorage.getItem(VISITOR_ID_KEY);
};

/**
 * Salva informações da última ordem gerada
 */
export const saveLastOrder = (order: {
  order_id: string;
  checkout_session_id: string;
  product_id: string;
  created_at: string;
}) => {
  localStorage.setItem(LAST_ORDER_KEY, JSON.stringify(order));
};

/**
 * Obtém informações da última ordem
 */
export const getLastOrder = () => {
  const data = localStorage.getItem(LAST_ORDER_KEY);
  return data ? JSON.parse(data) : null;
};

/**
 * Limpa informações da última ordem
 */
export const clearLastOrder = () => {
  localStorage.removeItem(LAST_ORDER_KEY);
};

const PENDING_PIX_MODAL_KEY = 'pending_pix_modal';

/**
 * Salvar dados do modal PIX (com timestamp para expiração)
 */
export const savePendingPixModal = (data: {
  pixCode: string;
  checkoutUrl: string;
  transactionId: string;
  checkout_session_id: string;
  amount: number;
  dramaTitle: string;
  dramaId: string;
  isUpsell?: boolean;
  isFullAccess?: boolean;
}) => {
  localStorage.setItem(PENDING_PIX_MODAL_KEY, JSON.stringify({
    ...data,
    createdAt: new Date().toISOString()
  }));
};

/**
 * Recuperar dados do modal PIX (retorna null se expirou após 30 min)
 */
export const getPendingPixModal = () => {
  const data = localStorage.getItem(PENDING_PIX_MODAL_KEY);
  if (!data) return null;
  
  try {
    const parsed = JSON.parse(data);
    const minutesElapsed = (Date.now() - new Date(parsed.createdAt).getTime()) / (1000 * 60);
    
    // Se passou mais de 30 minutos, PIX expirou
    if (minutesElapsed >= 30) {
      console.log('⏰ PIX expirado (>30 min), limpando localStorage');
      localStorage.removeItem(PENDING_PIX_MODAL_KEY);
      return null;
    }
    
    console.log(`✅ PIX válido (${minutesElapsed.toFixed(1)} min)`);
    return parsed;
  } catch (e) {
    console.error('Erro ao parsear pending_pix_modal:', e);
    localStorage.removeItem(PENDING_PIX_MODAL_KEY);
    return null;
  }
};

/**
 * Limpar dados do modal PIX
 */
export const clearPendingPixModal = () => {
  localStorage.removeItem(PENDING_PIX_MODAL_KEY);
};
