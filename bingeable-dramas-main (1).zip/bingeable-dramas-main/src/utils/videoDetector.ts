/**
 * Detecta o tipo de vídeo baseado na URL
 */

export interface VideoInfo {
  type: 'bunny' | 'hls' | 'standard';
  url: string;
  videoId?: string;
}

/**
 * Base URL da CDN Bunny para streams HLS
 */
const BUNNY_HLS_BASE = "https://vz-67627d7f-a4e.b-cdn.net";

/**
 * Detecta se a URL é de um vídeo do Bunny.net
 * Suporta: iframe.mediadelivery.net, player.mediadelivery.net, e outros subdomínios
 */
export const detectBunnyVideo = (url: string): boolean => {
  if (!url) return false;
  return url.includes('mediadelivery.net') || url.includes('bunny.net');
};

/**
 * Extrai o ID do vídeo Bunny da URL iframe ou embed
 * Exemplos: 
 * - https://iframe.mediadelivery.net/play/547891/ae445ac2-1978-4a04-8618-254fe2cd0c58
 * - https://player.mediadelivery.net/embed/547891/ae445ac2-1978-4a04-8618-254fe2cd0c58
 * Retorna: ae445ac2-1978-4a04-8618-254fe2cd0c58
 */
export const extractBunnyVideoId = (url: string): string | null => {
  try {
    const match = url.match(/\/(?:play|embed)\/\d+\/([a-f0-9-]+)/i);
    return match ? match[1] : null;
  } catch {
    return null;
  }
};

/**
 * Detecta se a URL é de um HLS playlist (.m3u8)
 */
export const detectHlsVideo = (url: string): boolean => {
  if (!url) return false;
  return url.includes('.m3u8') || url.includes('playlist.m3u8');
};

/**
 * Extrai o ID do vídeo de uma URL HLS do Bunny
 * Exemplo: https://vz-67627d7f-a4e.b-cdn.net/ae445ac2-1978-4a04-8618-254fe2cd0c58/playlist.m3u8
 * Retorna: ae445ac2-1978-4a04-8618-254fe2cd0c58
 */
export const extractHlsVideoId = (url: string): string | null => {
  try {
    const match = url.match(/\/([a-f0-9-]+)\/playlist\.m3u8/i);
    return match ? match[1] : null;
  } catch {
    return null;
  }
};

/**
 * Converte uma URL de iframe Bunny para URL HLS
 * Exemplo: https://iframe.mediadelivery.net/play/547891/ae445ac2-1978-4a04-8618-254fe2cd0c58
 * Retorna: https://vz-67627d7f-a4e.b-cdn.net/ae445ac2-1978-4a04-8618-254fe2cd0c58/playlist.m3u8
 */
export const bunnyEmbedToHls = (embedUrl: string): string | null => {
  const videoId = extractBunnyVideoId(embedUrl);
  if (!videoId) return null;
  return `${BUNNY_HLS_BASE}/${videoId}/playlist.m3u8`;
};

/**
 * Analisa a URL do vídeo e retorna informações sobre o tipo
 */
export const analyzeVideoUrl = (url: string): VideoInfo => {
  if (detectHlsVideo(url)) {
    return {
      type: 'hls',
      url,
      videoId: extractHlsVideoId(url) || undefined,
    };
  }

  if (detectBunnyVideo(url)) {
    return {
      type: 'bunny',
      url,
      videoId: extractBunnyVideoId(url) || undefined,
    };
  }

  return {
    type: 'standard',
    url,
  };
};
