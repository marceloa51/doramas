export const generateSessionId = (): string => {
  return crypto.randomUUID();
};

export const saveSessionId = (sessionId: string): void => {
  localStorage.setItem('ds_session_id', sessionId);
};

export const getSessionId = (): string | null => {
  return localStorage.getItem('ds_session_id');
};

export const clearSessionId = (): void => {
  localStorage.removeItem('ds_session_id');
};

export const getDeviceFingerprint = () => {
  return {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    screen: `${window.screen.width}x${window.screen.height}`,
    colorDepth: window.screen.colorDepth,
  };
};

export const getClientIp = async (): Promise<string> => {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch {
    return 'unknown';
  }
};

export const clearSupabaseAuthStorage = () => {
  try {
    // Remove qualquer chave de sessão criada pelo Supabase
    Object.keys(localStorage)
      .filter((key) => key.startsWith('sb-') || key.includes('supabase.auth'))
      .forEach((key) => localStorage.removeItem(key));
  } catch (e) {
    console.error('[Logout] Error clearing Supabase auth storage', e);
  }
};
