import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function FortunaPoderCompleto() {
  const drama = seoContent[1];
  const page = drama.pages.completo;

  return (
    <SEODramaPage
      title="Fortuna e Poder em Minutos Completo e Dublado"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/${drama.slug}-completo-e-dublado`}
    />
  );
}
