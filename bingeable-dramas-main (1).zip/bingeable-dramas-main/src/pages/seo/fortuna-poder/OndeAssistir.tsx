import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function OndeAssistirFortunaPoder() {
  const drama = seoContent[1];
  const page = drama.pages.ondeAssistir;

  return (
    <SEODramaPage
      title="Onde Assistir Fortuna e Poder em Minutos Dublado e Completo"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/onde-assistir-${drama.slug}-dublado-e-completo`}
    />
  );
}
