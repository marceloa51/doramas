import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function OndeAssistirCasamentoBlindado() {
  const drama = seoContent[5];
  const page = drama.pages.ondeAssistir;

  return (
    <SEODramaPage
      title="Onde Assistir Casamento Blindado: Um Contrato de Natal Dublado e Completo"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/onde-assistir-${drama.slug}-dublado-e-completo`}
    />
  );
}
