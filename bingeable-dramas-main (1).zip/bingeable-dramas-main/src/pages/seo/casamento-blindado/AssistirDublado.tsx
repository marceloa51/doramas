import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function AssistirCasamentoBlindadoDublado() {
  const drama = seoContent[5];
  const page = drama.pages.assistirDublado;

  return (
    <SEODramaPage
      title="Assistir Casamento Blindado: Um Contrato de Natal Dublado"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/assistir-${drama.slug}-dublado`}
    />
  );
}
