import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function AssistirNovatoMaisForteDublado() {
  const drama = seoContent[2];
  const page = drama.pages.assistirDublado;

  return (
    <SEODramaPage
      title="Assistir O Novato Mais Forte do Mundo Dublado"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/assistir-${drama.slug}-dublado`}
    />
  );
}
