import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function NovatoMaisForteCompleto() {
  const drama = seoContent[2];
  const page = drama.pages.completo;

  return (
    <SEODramaPage
      title="O Novato Mais Forte do Mundo Completo e Dublado"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/${drama.slug}-completo-e-dublado`}
    />
  );
}
