import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function OndeAssistirOEncantoDaVirgem() {
  const drama = seoContent[8];
  const page = drama.pages.ondeAssistir;

  return (
    <SEODramaPage
      title="Onde Assistir O Encanto da Virgem Dublado e Completo"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/onde-assistir-${drama.slug}-dublado-e-completo`}
    />
  );
}
