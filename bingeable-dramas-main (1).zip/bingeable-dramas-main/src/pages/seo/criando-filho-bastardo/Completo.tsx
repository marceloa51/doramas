import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function CriandoFilhoBastardoCompleto() {
  const drama = seoContent[6];
  const page = drama.pages.completo;

  return (
    <SEODramaPage
      title="Criando o Filho Bastardo do Meu Marido Completo e Dublado"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/${drama.slug}-completo-e-dublado`}
    />
  );
}
