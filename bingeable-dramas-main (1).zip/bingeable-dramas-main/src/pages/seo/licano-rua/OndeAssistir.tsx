import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function OndeAssistirLicanoRua() {
  const drama = seoContent[3];
  const page = drama.pages.ondeAssistir;

  return (
    <SEODramaPage
      title="Onde Assistir Meu Companheiro é um Licano de Rua Dublado e Completo"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/onde-assistir-${drama.slug}-dublado-e-completo`}
    />
  );
}
