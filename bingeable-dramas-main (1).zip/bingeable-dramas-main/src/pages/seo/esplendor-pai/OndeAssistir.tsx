import { SEODramaPage } from "@/components/SEODramaPage";
import { seoContent } from "@/data/seoContent";

export default function OndeAssistirEsplendorPai() {
  const drama = seoContent[0];
  const page = drama.pages.ondeAssistir;

  return (
    <SEODramaPage
      title="Onde Assistir O Esplendor de um Pai Dublado e Completo"
      metaTitle={page.metaTitle}
      metaDescription={page.metaDescription}
      h1={page.h1}
      dramaName={drama.name}
      genre={drama.genre}
      content={page.content}
      slug={drama.slug}
      currentPath={`/onde-assistir-${drama.slug}-dublado-e-completo`}
    />
  );
}
