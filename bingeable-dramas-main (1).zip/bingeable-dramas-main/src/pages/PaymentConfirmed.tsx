import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle, Crown, Zap, Shield, Infinity } from "lucide-react";

export default function PaymentConfirmed() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4 py-12">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
        <title>Pagamento Confirmado | Doramas Super</title>
      </Helmet>

      <Card className="max-w-2xl w-full bg-charcoal-black border-fire-orange/40 p-8 md:p-12 text-center shadow-[0_0_80px_rgba(255,140,0,0.4)]">
        
        {/* Ícone de Sucesso */}
        <div className="w-28 h-28 mx-auto rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center mb-8 animate-pulse shadow-[0_0_60px_rgba(255,170,0,0.7)]">
          <CheckCircle className="w-16 h-16 text-white" />
        </div>
        
        {/* Título Premium */}
        <h1 className="text-4xl md:text-5xl font-black mb-4 bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-bright bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(255,184,0,0.6)]">
          Pagamento Confirmado!
        </h1>
        
        {/* Subtítulo */}
        <p className="text-xl md:text-2xl text-fire-yellow-bright mb-3 font-bold">
          Sua assinatura Premium foi ativada.
        </p>
        
        <p className="text-lg text-white/80 mb-10">
          Agora você pode assistir todos os doramas completos, sem limite e sem interrupções.
        </p>
        
        {/* Benefícios */}
        <div className="bg-background/30 rounded-xl p-6 mb-10 space-y-4 border border-fire-orange/20">
          <div className="flex items-center gap-4">
            <Infinity className="w-6 h-6 text-fire-orange flex-shrink-0" />
            <span className="text-left text-white/90">Acesso ilimitado a todos os doramas</span>
          </div>
          <div className="flex items-center gap-4">
            <Zap className="w-6 h-6 text-fire-yellow-intense flex-shrink-0" />
            <span className="text-left text-white/90">Lançamentos antecipados exclusivos</span>
          </div>
          <div className="flex items-center gap-4">
            <Shield className="w-6 h-6 text-fire-orange flex-shrink-0" />
            <span className="text-left text-white/90">Assista sem anúncios ou interrupções</span>
          </div>
          <div className="flex items-center gap-4">
            <Crown className="w-6 h-6 text-fire-yellow-bright flex-shrink-0" />
            <span className="text-left text-white/90">Conteúdo exclusivo e especiais</span>
          </div>
        </div>
        
        {/* CTA Button */}
        <Button
          size="lg"
          onClick={() => navigate('/')}
          className="w-full bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_15px_50px_rgba(255,140,0,0.6)] text-white font-black text-lg py-7 transition-all duration-300 hover:scale-[1.02]"
        >
          <Crown className="w-6 h-6 mr-2" />
          Ir para os Doramas
        </Button>
      </Card>
    </div>
  );
}
