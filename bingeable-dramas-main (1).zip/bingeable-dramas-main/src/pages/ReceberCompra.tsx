import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/ui/password-input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle2 } from "lucide-react";
import { generateSessionId, saveSessionId, getDeviceFingerprint, getClientIp } from "@/utils/sessionManager";
import { getVisitorId, clearPendingPixModal } from "@/utils/visitorManager";

const ReceberCompra = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [purchaseInfo, setPurchaseInfo] = useState<any>(null);

  const formatPhoneNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  useEffect(() => {
    const loadPurchaseInfo = async () => {
      // Primeiro, tentar localStorage
      const pendingPurchase = localStorage.getItem('pending_purchase');
      if (pendingPurchase) {
        const data = JSON.parse(pendingPurchase);
        if (data.checkout_session_id) {
          setPurchaseInfo(data);
          return;
        }
      }

      // Fallback: buscar via visitor_id
      const visitorId = getVisitorId();
      if (visitorId) {
        try {
          const response = await fetch(
            `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-visitor-orders?visitor_id=${visitorId}`,
            {
              headers: {
                'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
              },
            }
          );

          if (response.ok) {
            const { paidOrdersWithoutUser } = await response.json();
            
            if (paidOrdersWithoutUser && paidOrdersWithoutUser.length > 0) {
              const order = paidOrdersWithoutUser[0];
              setPurchaseInfo({
                checkout_session_id: order.id,
                dramaTitle: order.items[0]?.title || 'Dorama',
                amount: order.amount,
                customerName: order.customer_name,
              });
              return;
            }
          }
        } catch (error) {
          console.error('Error fetching visitor orders:', error);
        }
      }

      // Nenhuma compra encontrada
      toast({
        title: "Erro",
        description: "Informações de compra não encontradas",
        variant: "destructive",
      });
      navigate("/");
    };

    loadPurchaseInfo();
  }, [navigate, toast]);

  // Validação de telefone em tempo real
  const isValidPhone = (phoneValue: string) => {
    const cleaned = phoneValue.replace(/\D/g, '');
    return cleaned.length === 11;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!purchaseInfo) {
      toast({
        title: "Erro",
        description: "Informações de compra não encontradas",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Validate phone format (exige exatamente 11 dígitos)
      const cleanPhone = phone.replace(/\D/g, '');
      if (cleanPhone.length !== 11) {
        throw new Error("Número de telefone inválido. Use formato: (DD) 9XXXX-XXXX");
      }

      if (password.length < 6) {
        throw new Error("A senha deve ter pelo menos 6 caracteres");
      }

      // NOVO: Obter visitor_id
      const visitorId = getVisitorId();

      // Call edge function to create account and link purchase
      const { data, error } = await supabase.functions.invoke('create-account-after-purchase', {
        body: {
          phone: cleanPhone,
          password,
          fullName: purchaseInfo.customerName,
          checkout_session_id: purchaseInfo.checkout_session_id,
          visitor_id: visitorId, // NOVO: enviar visitor_id
        },
      });

      if (error) throw error;

      if (data?.success) {
        // Fazer login automático com as credenciais recém-criadas
        const userEmail = `${cleanPhone}@doramassuper.internal`;
        const { error: loginError } = await supabase.auth.signInWithPassword({
          email: userEmail,
          password,
        });

        if (loginError) {
          console.error("Login error:", loginError);
          throw new Error("Conta criada, mas erro ao fazer login automático");
        }

        // Criar sessão do sistema
        const sessionId = generateSessionId();
        saveSessionId(sessionId);
        const deviceFingerprint = getDeviceFingerprint();
        const userIp = await getClientIp();

        await supabase.functions.invoke('create-session', {
          body: { sessionId, deviceFingerprint, userIp },
        });

        // Clear pending purchase and PIX modal from localStorage
        localStorage.removeItem('pending_purchase');
        clearPendingPixModal();

        toast({
          title: "✅ Conta criada com sucesso!",
          description: `Você já está logado! Redirecionando...`,
        });

        // Redirect to Meus Doramas (usuário já logado!)
        setTimeout(() => {
          navigate('/meus-doramas');
        }, 1500);
      } else {
        throw new Error(data?.error || "Erro ao criar conta");
      }
    } catch (error: any) {
      console.error("Account creation error:", error);
      toast({
        title: "Erro ao criar conta",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (!purchaseInfo) {
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Helmet>
        <title>Receber Sua Compra | Doramas Super</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-fire-orange/5 to-transparent" />

      <Card className="w-full max-w-md p-8 bg-drama-card border-drama-border relative z-10">
        {/* Success Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center shadow-[0_0_50px_rgba(255,140,0,0.6)]">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-display font-black mb-3">
            <span className="text-fire-yellow-bright">RECEBER SUA COMPRA AGORA</span>
          </h1>
          <p className="text-sm text-muted-foreground mb-4">
            Informe seu telefone e crie uma senha<br />
            para acessar o aplicativo
          </p>
          <div className="bg-fire-orange/10 border border-fire-orange/30 rounded-lg p-3 mb-2">
            <p className="text-sm font-semibold text-fire-yellow-bright">
              {purchaseInfo.dramaTitle}
            </p>
            <p className="text-xs text-muted-foreground">
              R$ {purchaseInfo.amount.toFixed(2)}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="phone">Número de Telefone</Label>
            <Input
              id="phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
              required
              className="bg-background border-drama-border"
              placeholder="(11) 99999-9999"
              maxLength={15}
            />
            <p className="text-xs text-muted-foreground">
              Use este número para fazer login futuramente
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Crie uma Senha</Label>
            <PasswordInput
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="bg-background border-drama-border"
              placeholder="••••••••"
              minLength={6}
              autoComplete="new-password"
            />
            <p className="text-xs text-muted-foreground">
              Mínimo de 6 caracteres
            </p>
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold py-6 text-lg"
            disabled={loading || !isValidPhone(phone) || password.length < 6}
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Criando conta...
              </>
            ) : (
              "RESGATAR AGORA"
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-xs text-muted-foreground">
            Ao criar sua conta, você concorda com nossos Termos de Uso
          </p>
        </div>
      </Card>
    </div>
  );
};

export default ReceberCompra;
