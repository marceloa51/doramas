import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Wallet as WalletIcon, ArrowUpRight, ArrowDownLeft, Gift, CheckCircle, XCircle, Clock, TrendingUp, Copy, AlertCircle, Link as LinkIcon } from "lucide-react";
import { toast } from "sonner";
import WithdrawalRequestModal from "@/components/WithdrawalRequestModal";
import { SITE_URL } from "@/config/site";

interface WalletData {
  available_balance: number;
  total_earned: number;
  total_withdrawn: number;
}

interface Transaction {
  id: string;
  type: string;
  amount: number;
  description: string;
  created_at: string;
}

interface ProfileData {
  referral_count: number;
  free_months_granted: number;
  username: string | null;
  username_locked: boolean;
  invites_confirmed: number;
}

export default function Wallet() {
  const navigate = useNavigate();
  const [wallet, setWallet] = useState<WalletData | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showWithdrawalModal, setShowWithdrawalModal] = useState(false);
  const [username, setUsername] = useState("");

  useEffect(() => {
    fetchWalletData();
  }, []);

  const fetchWalletData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/auth");
        return;
      }

      // Fetch wallet
      const { data: walletData, error: walletError } = await supabase
        .from("wallets")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (walletError) throw walletError;
      setWallet(walletData);

      // Fetch transactions
      const { data: txData, error: txError } = await supabase
        .from("wallet_transactions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(50);

      if (txError) throw txError;
      setTransactions(txData || []);

      // Fetch profile stats
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("referral_count, free_months_granted, username, username_locked, invites_confirmed")
        .eq("id", user.id)
        .single();

      if (profileError) throw profileError;
      setProfile(profileData);

    } catch (error) {
      console.error("Error fetching wallet data:", error);
      toast.error("Erro ao carregar dados da carteira");
    } finally {
      setLoading(false);
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "REFERRAL_BONUS":
        return <ArrowDownLeft className="h-4 w-4 text-green-500" />;
      case "WITHDRAWAL_REQUEST":
        return <ArrowUpRight className="h-4 w-4 text-yellow-500" />;
      case "WITHDRAWAL_APPROVED":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "WITHDRAWAL_REJECTED":
        return <XCircle className="h-4 w-4 text-red-500" />;
      case "FREE_MONTH_BONUS":
        return <Gift className="h-4 w-4 text-purple-500" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getTransactionLabel = (type: string) => {
    const labels: Record<string, string> = {
      REFERRAL_BONUS: "Bônus de Indicação",
      WITHDRAWAL_REQUEST: "Saque Solicitado",
      WITHDRAWAL_APPROVED: "Saque Aprovado",
      WITHDRAWAL_REJECTED: "Saque Recusado",
      FREE_MONTH_BONUS: "Mês Grátis",
      ADMIN_ADJUSTMENT: "Ajuste Manual"
    };
    return labels[type] || type;
  };

  const nextFreeMonthAt = profile ? Math.ceil((profile.referral_count || 0) / 5) * 5 : 5;
  const progressToNextMonth = profile ? (profile.referral_count || 0) % 5 : 0;
  const canWithdraw = (wallet?.available_balance || 0) >= 30;

  const handleUsernameUpdate = async () => {
    if (!profile || !username.trim()) return;

    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!usernameRegex.test(username.trim())) {
      toast.error("Use 3-20 caracteres (apenas letras, números e _)");
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('update-username', {
        body: { username: username.trim() }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success("Username definido! Seu link de convite está pronto.");
      fetchWalletData();
    } catch (error: any) {
      toast.error(error.message || "Erro ao definir username");
    }
  };

  const copyInviteLink = () => {
    const link = `${SITE_URL}/ref/${profile?.username}`;
    navigator.clipboard.writeText(link);
    toast.success("Link copiado para a área de transferência!");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Helmet>
          <meta name="robots" content="noindex, nofollow" />
          <title>Carteira | Doramas Super</title>
        </Helmet>
        <p className="text-muted-foreground">Carregando carteira...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
        <title>Carteira | Doramas Super</title>
      </Helmet>

      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <WalletIcon className="h-8 w-8 text-[#FF6A00]" />
            <h1 className="text-3xl font-bold">Minha Carteira</h1>
          </div>
          <Button variant="outline" onClick={() => navigate("/perfil")}>
            Voltar ao Perfil
          </Button>
        </div>

        {/* Balance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-[#FF6A00]/20">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Saldo Disponível</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-[#FFC93C]">
                R$ {(wallet?.available_balance || 0).toFixed(2)}
              </p>
              {canWithdraw && (
                <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/30">
                  Saque disponível
                </Badge>
              )}
            </CardContent>
          </Card>

          <Card className="border-[#FF6A00]/20">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Ganho</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">R$ {(wallet?.total_earned || 0).toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card className="border-[#FF6A00]/20">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Sacado</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">R$ {(wallet?.total_withdrawn || 0).toFixed(2)}</p>
            </CardContent>
          </Card>
        </div>

        {/* Programa de Afiliados - Integrated Section */}
        <Card className="border-[#FF6A00]/20 bg-gradient-to-br from-drama-card to-[#FF6A00]/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Gift className="h-6 w-6 text-[#FF6A00]" />
              Programa de Afiliados
            </CardTitle>
            <CardDescription className="text-base">
              Ganhe comissões indicando o Doramas Super. Cada indicação paga gera saldo na sua carteira. A cada 5 indicações pagas, você ganha 1 mês grátis.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Username e Convites */}
            <div className="space-y-4 p-4 rounded-lg bg-background/50 border border-[#FF6A00]/10">
              <div className="flex items-center gap-2">
                <LinkIcon className="h-5 w-5 text-[#FF6A00]" />
                <h3 className="text-lg font-semibold">Username e Convites</h3>
              </div>
              
              <p className="text-sm text-muted-foreground leading-relaxed">
                Defina seu username para gerar um link único. Esse é o link que você vai enviar para amigos/clientes. 
                Quando eles assinarem usando seu link, as compras serão atribuídas a você e suas comissões aparecerão aqui na carteira.
              </p>

              {!profile?.username_locked ? (
                <div className="space-y-3">
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                    <AlertCircle className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-muted-foreground">
                      Defina seu username para compartilhar seu link de convite e ganhar comissões
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="username">Escolha seu Username</Label>
                    <div className="flex flex-col md:flex-row gap-2">
                      <Input
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="seuusername"
                        className="flex-1 bg-background border-[#FF6A00]/20"
                      />
                      <Button
                        onClick={handleUsernameUpdate}
                        className="bg-gradient-to-r from-[#FF6A00] to-[#FFC93C] hover:brightness-110 text-white font-bold"
                      >
                        Definir
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      3-20 caracteres, apenas letras, números e _. <strong className="text-[#FFC93C]">Atenção: não poderá ser alterado depois!</strong>
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Seu Username</Label>
                    <Input
                      value={profile.username || ""}
                      disabled
                      className="bg-background/50 border-[#FF6A00]/20 opacity-70 cursor-not-allowed select-text"
                    />
                    <p className="text-xs text-muted-foreground">
                      Username definido permanentemente
                    </p>
                  </div>

                  <div className="space-y-2 p-4 rounded-lg bg-[#FF6A00]/5 border border-[#FF6A00]/20">
                    <Label className="flex items-center gap-2">
                      <LinkIcon className="h-4 w-4 text-[#FF6A00]" />
                      Seu Link de Convite
                    </Label>
                    <div className="flex flex-col md:flex-row gap-2">
                      <Input
                        value={`${SITE_URL}/ref/${profile.username}`}
                        readOnly
                        className="flex-1 bg-background border-[#FF6A00]/20 font-mono text-xs md:text-sm select-text"
                      />
                      <Button
                        onClick={copyInviteLink}
                        variant="outline"
                        className="border-[#FF6A00]/30 hover:bg-[#FF6A00]/10 hover:border-[#FF6A00]/50"
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copiar
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Compartilhe este link para ganhar comissões e benefícios
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Estatísticas */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-background/50 border border-[#FF6A00]/10 hover:border-[#FF6A00]/30 transition-colors">
                <p className="text-sm text-muted-foreground mb-1">Indicações Pagas</p>
                <p className="text-3xl font-bold text-[#FFC93C]">{profile?.referral_count || 0}</p>
              </div>
              <div className="p-4 rounded-lg bg-background/50 border border-[#FF6A00]/10 hover:border-[#FF6A00]/30 transition-colors">
                <p className="text-sm text-muted-foreground mb-1">Próximo Mês Grátis</p>
                <p className="text-3xl font-bold text-[#FFC93C]">{progressToNextMonth}/5</p>
                <div className="mt-2 w-full bg-background rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-[#FF6A00] to-[#FFC93C] h-2 rounded-full transition-all"
                    style={{ width: `${(progressToNextMonth / 5) * 100}%` }}
                  />
                </div>
              </div>
              <div className="p-4 rounded-lg bg-background/50 border border-[#FF6A00]/10 hover:border-[#FF6A00]/30 transition-colors">
                <p className="text-sm text-muted-foreground mb-1">Meses Grátis Ganhos</p>
                <p className="text-3xl font-bold text-[#FFC93C]">{profile?.free_months_granted || 0}</p>
              </div>
            </div>

            {/* Como Funciona */}
            <div className="space-y-2 p-4 rounded-lg bg-[#FF6A00]/5 border border-[#FF6A00]/10">
              <h4 className="font-semibold text-[#FFC93C] flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Como Funciona
              </h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-[#FF6A00] mt-0.5">•</span>
                  <span>A cada amigo que assina com seu link, você ganha <strong className="text-[#FFC93C]">R$ 5,00</strong> de comissão</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#FF6A00] mt-0.5">•</span>
                  <span>A cada <strong className="text-[#FFC93C]">5 indicações pagas</strong>, você ganha <strong className="text-[#FFC93C]">1 mês grátis</strong> na plataforma</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#FF6A00] mt-0.5">•</span>
                  <span>Você pode solicitar saque a partir de <strong className="text-[#FFC93C]">R$ 30,00</strong> via Pix</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#FF6A00] mt-0.5">•</span>
                  <span>Os saques são processados em até 48 horas úteis</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Withdrawal Button */}
        <div className="flex justify-center">
          <Button
            size="lg"
            disabled={!canWithdraw}
            onClick={() => setShowWithdrawalModal(true)}
            className="bg-gradient-to-r from-[#FF6A00] via-[#FFC93C] to-[#FFE066] text-white hover:brightness-110"
          >
            <ArrowUpRight className="mr-2 h-5 w-5" />
            Solicitar Saque
            {!canWithdraw && " (Mínimo R$ 30,00)"}
          </Button>
        </div>

        {/* Transactions History */}
        <Card className="border-[#FF6A00]/20">
          <CardHeader>
            <CardTitle>Histórico de Transações</CardTitle>
            <CardDescription>Todas as suas movimentações na carteira</CardDescription>
          </CardHeader>
          <CardContent>
            {transactions.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Nenhuma transação ainda</p>
            ) : (
              <div className="space-y-3">
                {transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:border-[#FF6A00]/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {getTransactionIcon(tx.type)}
                      <div>
                        <p className="font-medium">{getTransactionLabel(tx.type)}</p>
                        <p className="text-sm text-muted-foreground">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(tx.created_at).toLocaleDateString("pt-BR", {
                            day: "2-digit",
                            month: "2-digit",
                            year: "numeric",
                            hour: "2-digit",
                            minute: "2-digit"
                          })}
                        </p>
                      </div>
                    </div>
                    <p className={`font-bold ${tx.amount >= 0 ? "text-green-500" : "text-red-500"}`}>
                      {tx.amount >= 0 ? "+" : ""}R$ {Math.abs(tx.amount).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <WithdrawalRequestModal
        open={showWithdrawalModal}
        onClose={() => setShowWithdrawalModal(false)}
        onSuccess={fetchWalletData}
        availableBalance={wallet?.available_balance || 0}
      />
    </div>
  );
}
