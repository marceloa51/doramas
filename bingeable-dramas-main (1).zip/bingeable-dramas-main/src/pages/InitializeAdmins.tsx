import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, XCircle } from "lucide-react";

const InitializeAdmins = () => {
  const navigate = useNavigate();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [results, setResults] = useState<any[]>([]);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    initializeAdmins();
  }, []);

  const initializeAdmins = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("create-admin-users");

      if (error) throw error;

      setResults(data.results || []);
      setStatus("success");
    } catch (err: any) {
      setError(err.message || "Erro ao criar usuários admin");
      setStatus("error");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md p-8 bg-drama-card border-drama-border">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold mb-2">Inicialização de Admins</h1>
          <p className="text-muted-foreground">Criando usuários administrativos</p>
        </div>

        {status === "loading" && (
          <div className="flex flex-col items-center justify-center py-8">
            <Loader2 className="w-12 h-12 animate-spin text-drama-red mb-4" />
            <p className="text-muted-foreground">Criando usuários...</p>
          </div>
        )}

        {status === "success" && (
          <div className="space-y-4">
            <div className="flex items-center justify-center text-green-500 mb-4">
              <CheckCircle className="w-12 h-12" />
            </div>
            <div className="space-y-2">
              {results.map((result, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-background rounded-lg"
                >
                  <span className="text-sm">{result.email}</span>
                  <span
                    className={`text-xs px-2 py-1 rounded ${
                      result.status === "created"
                        ? "bg-green-500/20 text-green-500"
                        : result.status === "already_exists"
                        ? "bg-yellow-500/20 text-yellow-500"
                        : "bg-red-500/20 text-red-500"
                    }`}
                  >
                    {result.status === "created"
                      ? "Criado"
                      : result.status === "already_exists"
                      ? "Já existe"
                      : "Erro"}
                  </span>
                </div>
              ))}
            </div>
            <Button
              onClick={() => navigate("/auth")}
              className="w-full bg-drama-red hover:bg-drama-red-hover"
            >
              Ir para Login
            </Button>
          </div>
        )}

        {status === "error" && (
          <div className="space-y-4">
            <div className="flex items-center justify-center text-red-500 mb-4">
              <XCircle className="w-12 h-12" />
            </div>
            <p className="text-center text-red-500">{error}</p>
            <Button
              onClick={initializeAdmins}
              className="w-full bg-drama-red hover:bg-drama-red-hover"
            >
              Tentar Novamente
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
};

export default InitializeAdmins;
