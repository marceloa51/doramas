import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ArrowLeft, Phone } from "lucide-react";

const ForgotPassword = () => {
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [resetInitiated, setResetInitiated] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const formatPhoneNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handleResetRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phone) {
      toast({
        title: "Campo obrigatório",
        description: "Por favor, insira seu número de telefone.",
        variant: "destructive",
      });
      return;
    }

    const phoneClean = phone.replace(/\D/g, '');
    if (phoneClean.length !== 11) {
      toast({
        title: "Telefone inválido",
        description: "Por favor, insira um número de telefone válido com DDD.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('reset-password-phone', {
        body: { phone: phoneClean }
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      // Redirecionar automaticamente para a página de reset com o token
      if (data.redirectUrl) {
        toast({
          title: "Validação concluída!",
          description: "Redirecionando para redefinição de senha...",
        });
        
        setTimeout(() => {
          window.location.href = data.redirectUrl;
        }, 1000);
        
        setResetInitiated(true);
      }
    } catch (error: any) {
      console.error("Error sending reset request:", error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível processar a solicitação.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-fire-orange/5 to-transparent" />

      <Card className="w-full max-w-md p-8 bg-drama-card border-drama-border relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-display font-black mb-2">
            <span className="text-fire-primary">DORAMAS</span>
            <span className="text-fire-yellow-intense"> SUPER</span>
          </h1>
          <p className="text-muted-foreground">
            {resetInitiated ? "Validação concluída" : "Recuperar senha"}
          </p>
        </div>

        {!resetInitiated ? (
          <form onSubmit={handleResetRequest} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Número de Telefone</Label>
              <Input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
                required
                className="bg-background border-drama-border"
                placeholder="(11) 99999-9999"
                maxLength={15}
              />
              <p className="text-xs text-muted-foreground">
                Digite seu telefone para redefinir sua senha
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Validando...
                </>
              ) : (
                <>
                  <Phone className="w-4 h-4 mr-2" />
                  Redefinir senha
                </>
              )}
            </Button>
          </form>
        ) : (
          <div className="space-y-6 text-center">
            <div className="w-16 h-16 mx-auto rounded-full bg-fire-orange/20 flex items-center justify-center">
              <Phone className="w-8 h-8 text-fire-orange" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-bold text-foreground">Redirecionando...</h3>
              <p className="text-sm text-muted-foreground">
                Aguarde enquanto validamos seu telefone.
              </p>
            </div>
          </div>
        )}

        {!resetInitiated && (
          <div className="mt-6 text-center">
            <button
              onClick={() => navigate('/auth')}
              type="button"
              className="text-sm text-muted-foreground hover:text-fire-orange transition-smooth underline inline-flex items-center gap-1"
            >
              <ArrowLeft className="w-3 h-3" />
              Voltar para o login
            </button>
          </div>
        )}
      </Card>
    </div>
  );
};

export default ForgotPassword;
