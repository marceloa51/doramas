import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/ui/password-input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Lock, CheckCircle } from "lucide-react";

const ResetPassword = () => {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [passwordReset, setPasswordReset] = useState(false);
  const [validSession, setValidSession] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Verificar se há uma sessão válida (usuário veio do link de reset)
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setValidSession(true);
      } else {
        toast({
          title: "Sessão inválida",
          description: "O link de redefinição expirou ou é inválido.",
          variant: "destructive",
        });
        setTimeout(() => navigate('/auth/forgot-password'), 2000);
      }
    });
  }, [navigate, toast]);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (newPassword !== confirmPassword) {
      toast({
        title: "Erro",
        description: "As senhas não coincidem.",
        variant: "destructive",
      });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: "Erro",
        description: "A senha deve ter no mínimo 6 caracteres.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (error) throw error;

      toast({
        title: "Senha atualizada!",
        description: "Sua senha foi alterada com sucesso.",
      });

      setPasswordReset(true);

      // Redirecionar para login após 2 segundos
      setTimeout(() => {
        navigate('/auth');
      }, 2000);
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (!validSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="absolute inset-0 bg-gradient-to-br from-fire-orange/5 to-transparent" />
        <Card className="w-full max-w-md p-8 bg-drama-card border-drama-border relative z-10">
          <div className="text-center">
            <Loader2 className="w-8 h-8 mx-auto animate-spin text-fire-orange mb-4" />
            <p className="text-muted-foreground">Verificando link...</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-fire-orange/5 to-transparent" />

      <Card className="w-full max-w-md p-8 bg-drama-card border-drama-border relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-display font-black mb-2">
            <span className="text-fire-primary">DORAMAS</span>
            <span className="text-fire-yellow-intense"> SUPER</span>
          </h1>
          <p className="text-muted-foreground">
            {passwordReset ? "Senha redefinida com sucesso" : "Redefinir senha"}
          </p>
        </div>

        {!passwordReset ? (
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="newPassword">Nova senha</Label>
              <PasswordInput
                id="newPassword"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={6}
                className="bg-background border-drama-border"
                placeholder="••••••••"
                autoComplete="new-password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar nova senha</Label>
              <PasswordInput
                id="confirmPassword"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                minLength={6}
                className="bg-background border-drama-border"
                placeholder="••••••••"
                autoComplete="new-password"
              />
              {confirmPassword && newPassword !== confirmPassword && (
                <p className="text-xs text-destructive">
                  As senhas não coincidem
                </p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold"
              disabled={loading || newPassword !== confirmPassword}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Redefinindo...
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Redefinir senha
                </>
              )}
            </Button>
          </form>
        ) : (
          <div className="space-y-6 text-center">
            <div className="w-16 h-16 mx-auto rounded-full bg-fire-orange/20 flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-fire-orange" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-bold text-foreground">Senha atualizada!</h3>
              <p className="text-sm text-muted-foreground">
                Redirecionando para o login...
              </p>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default ResetPassword;
