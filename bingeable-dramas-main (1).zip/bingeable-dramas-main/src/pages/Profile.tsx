import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { User, LogOut, Gift, Clock, Film, Settings, AlertCircle, Users, BarChart3, Wallet as WalletIcon, ArrowRight, TrendingUp, Crown, Loader2, Check, CheckCircle2 } from "lucide-react";
import { Session } from "@supabase/supabase-js";
import { SITE_URL } from "@/config/site";
import { PixPaymentModal } from "@/components/PixPaymentModal";
import { PaymentMethodSelector } from "@/components/PaymentMethodSelector";
import { CreditCardForm } from "@/components/CreditCardPaymentForm";
import { getOrCreateVisitorId, savePendingPixModal } from "@/utils/visitorManager";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { getSessionId, clearSessionId, clearSupabaseAuthStorage } from "@/utils/sessionManager";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Profile {
  id: string;
  email: string;
  full_name: string;
  username: string | null;
  username_locked: boolean;
  ref_code: string;
  plan_status: string;
  plan_renews_at: string | null;
  invites_confirmed: number;
  free_months: number;
  free_months_granted: number;
  episodes_watched: number;
  total_watch_time: number;
  referral_count: number;
  created_at: string | null;
}

const Profile = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Premium subscription modal states
  const [showBenefitsModal, setShowBenefitsModal] = useState(false);
  const [customerWhatsApp, setCustomerWhatsApp] = useState("");
  const [showPixModal, setShowPixModal] = useState(false);
  const [pixCode, setPixCode] = useState("");
  const [checkoutUrl, setCheckoutUrl] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [checkoutSessionId, setCheckoutSessionId] = useState("");
  const [processingPayment, setProcessingPayment] = useState(false);
  
  // Payment method states
  const [showPaymentSelector, setShowPaymentSelector] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit_card'>('pix');
  const [showCreditCardForm, setShowCreditCardForm] = useState(false);
  const [cardPaymentSuccess, setCardPaymentSuccess] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  useEffect(() => {
    if (!session?.user) return;
    
    const channel = supabase
      .channel('profile-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${session.user.id}`
        },
        (payload) => {
          console.log('Profile updated:', payload);
          setProfile(payload.new as Profile);
          
          if (payload.new.plan_status === 'active' && 
              (payload.old as any).plan_status !== 'active') {
            toast({
              title: "🔥 Premium Ativado!",
              description: "Sua assinatura foi confirmada. Aproveite!",
            });
          }
        }
      )
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, [session, toast]);

  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      navigate("/auth");
      return;
    }

    setSession(session);
    await fetchProfile(session.user.id);
    await checkAdminRole(session.user.id);
  };

  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId)
        .single();

      if (error) throw error;

      setProfile(data);
    } catch (error) {
      console.error("Error fetching profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const checkAdminRole = async (userId: string) => {
    try {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .single();
      
      setIsAdmin(!!data);
    } catch (error) {
      setIsAdmin(false);
    }
  };

  const handleLogout = async () => {
    try {
      const sessionId = getSessionId();

      if (sessionId) {
        try {
          await supabase.functions.invoke('invalidate-session', {
            body: { sessionId },
          });
        } catch (err) {
          console.error('Error invalidating session:', err);
        }
      }

      clearSessionId();
      clearSupabaseAuthStorage();
      await supabase.auth.signOut();

      toast({
        title: "Logout realizado",
        description: "Você foi desconectado com sucesso.",
      });

      navigate("/auth", { replace: true });
    } catch (error) {
      console.error('Error logging out:', error);
      clearSessionId();
      clearSupabaseAuthStorage();
      await supabase.auth.signOut().catch(() => {});
      navigate("/auth", { replace: true });
    }
  };

  const handleCancelSubscription = async () => {
    if (!profile) return;

    try {
      const { error } = await supabase
        .from("profiles")
        .update({ 
          plan_status: "none",
          plan_renews_at: null
        })
        .eq("id", profile.id);

      if (error) throw error;

      toast({
        title: "Assinatura cancelada",
        description: "Sua assinatura foi cancelada com sucesso.",
      });

      fetchProfile(profile.id);
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Opens benefits modal for subscription
  const handleActivatePlan = () => {
    setShowBenefitsModal(true);
  };

  // After WhatsApp is validated, show payment selector
  const handleContinueToPayment = () => {
    const phoneDigits = customerWhatsApp.replace(/\D/g, '');
    if (phoneDigits.length < 7) {
      toast({
        title: "WhatsApp inválido",
        description: "Por favor, informe pelo menos 7 dígitos",
        variant: "destructive"
      });
      return;
    }
    setShowBenefitsModal(false);
    setShowPaymentSelector(true);
  };

  // Generates PIX after confirmation
  const handleConfirmSubscription = async () => {
    setProcessingPayment(true);
    setShowPaymentSelector(false);
    
    try {
      const visitorId = getOrCreateVisitorId();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-fullaccess-payment`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            customerName: customerWhatsApp.trim(),
            visitor_id: visitorId,
            paymentMethod: 'pix',
            ...(session?.user && { userId: session.user.id }),
          }),
        }
      ).then(res => res.json());

      if (response.error) throw new Error(response.error);

      if (response.success || response.checkoutUrl) {
        const purchaseData = {
          checkout_session_id: response.checkoutSessionId,
          amount: 24.90,
          isFullAccess: true,
        };
        localStorage.setItem('pending_purchase', JSON.stringify(purchaseData));

        savePendingPixModal({
          pixCode: response.pixCode || "",
          checkoutUrl: response.checkoutUrl || "",
          transactionId: response.transactionId || "",
          checkout_session_id: response.checkoutSessionId,
          amount: 24.90,
          dramaTitle: "Acesso Completo 30 Dias",
          dramaId: 'full_access_30_days',
          isFullAccess: true
        });

        setPixCode(response.pixCode || "");
        setCheckoutUrl(response.checkoutUrl || "");
        setTransactionId(response.transactionId || "");
        setCheckoutSessionId(response.checkoutSessionId);
        setShowPixModal(true);
      }
    } catch (error) {
      console.error("Erro ao gerar pagamento:", error);
      toast({
        title: "Erro",
        description: "Não foi possível gerar o pagamento. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setProcessingPayment(false);
    }
  };

  // Handle payment method selection
  const handlePaymentMethodSelect = (method: 'pix' | 'credit_card') => {
    setPaymentMethod(method);
    if (method === 'pix') {
      handleConfirmSubscription();
    } else {
      setShowPaymentSelector(false);
      setShowCreditCardForm(true);
    }
  };

  // Handle credit card payment success
  const handleCardPaymentSuccess = () => {
    setShowCreditCardForm(false);
    setCardPaymentSuccess(true);
    fetchProfile(profile?.id || '');
  };

  const getPlanBadge = () => {
    switch (profile?.plan_status) {
      case "active":
        return <Badge className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white border-none">PLANO ATIVO</Badge>;
      case "pending":
        return <Badge className="bg-status-pending text-white">PENDENTE</Badge>;
      default:
        return <Badge className="bg-status-inactive text-white">SEM PLANO</Badge>;
    }
  };

  if (loading || !profile) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet>
          <meta name="robots" content="noindex, nofollow" />
          <title>Perfil | Doramas Super</title>
        </Helmet>

        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-32 bg-drama-card rounded-lg" />
            <div className="h-64 bg-drama-card rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
        <title>Perfil | Doramas Super</title>
      </Helmet>

      <Navbar />
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8 pb-12">
        <div className="max-w-4xl mx-auto space-y-6">
        <Card className="bg-drama-card border-drama-border p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center flex-shrink-0">
                <User className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="text-lg sm:text-2xl font-bold truncate">
                  {profile.full_name || "Usuário"}
                </h1>
                <p className="text-sm text-muted-foreground truncate">
                  {profile.email}
                </p>
              </div>
            </div>
            <Button
              variant="destructive"
              onClick={handleLogout}
              className="bg-destructive hover:bg-destructive/90 flex items-center gap-2 rounded-full px-3 py-2 sm:px-4 text-xs sm:text-sm font-semibold whitespace-nowrap shadow-md hover:shadow-lg active:scale-95 transition-all"
            >
              <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">Sair</span>
              <span className="inline xs:hidden">⮕</span>
            </Button>
          </div>
        </Card>

          {/* Programa de Afiliados - OCULTO TEMPORARIAMENTE
          <Card className="bg-gradient-to-br from-drama-card via-drama-card to-fire-orange/5 border-2 border-fire-orange/30 shadow-[0_8px_32px_rgba(255,106,0,0.15)] hover:shadow-[0_12px_48px_rgba(255,106,0,0.25)] transition-all duration-300 p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense">
                  <Gift className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light bg-clip-text text-transparent">
                    🎁 Programa de Afiliados
                  </h2>
                  <p className="text-xs text-fire-yellow-intense">Ganhe dinheiro divulgando!</p>
                </div>
              </div>
              
              <Button
                size="lg"
                onClick={() => navigate("/wallet")}
                className="w-full md:w-auto bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light text-white font-bold text-base hover:shadow-[0_10px_40px_rgba(255,140,0,0.5)] hover:scale-105 transition-all duration-300 active:scale-95"
              >
                <WalletIcon className="w-5 h-5 mr-2" />
                Ver Minha Carteira
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            <div className="bg-background/50 rounded-lg p-4 border border-fire-orange/20 mb-4">
              <p className="text-sm leading-relaxed flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-fire-yellow-intense flex-shrink-0" />
                💰 Ganhe <strong className="text-fire-yellow-intense text-lg">R$ 5,00</strong> por cada indicação paga
              </p>
              <p className="text-sm leading-relaxed mt-2 flex items-center gap-2">
                <Gift className="w-4 h-4 text-fire-yellow-intense flex-shrink-0" />
                🎁 Ganhe <strong className="text-fire-yellow-intense text-lg">1 mês grátis</strong> a cada 5 indicações
              </p>
              <p className="text-xs text-muted-foreground mt-3">
                💸 Você pode ganhar até <strong className="text-fire-yellow-intense">R$ 200 por dia</strong> divulgando!
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-gradient-to-br from-background to-fire-orange/5 rounded-lg p-4 border border-fire-orange/10 hover:border-fire-orange/30 transition-colors">
                <p className="text-sm text-muted-foreground mb-1">Indicações Pagas</p>
                <p className="text-2xl font-bold text-fire-yellow-intense">
                  {profile.referral_count || 0}
                </p>
              </div>

              <div className="bg-gradient-to-br from-background to-fire-orange/5 rounded-lg p-4 border border-fire-orange/10 hover:border-fire-orange/30 transition-colors">
                <p className="text-sm text-muted-foreground mb-1">Próximo Mês Grátis</p>
                <p className="text-2xl font-bold text-fire-yellow-intense">
                  {profile.invites_confirmed || 0}/5
                </p>
              </div>

              <div className="bg-gradient-to-br from-background to-fire-orange/5 rounded-lg p-4 border border-fire-orange/10 hover:border-fire-orange/30 transition-colors col-span-2 md:col-span-1">
                <p className="text-sm text-muted-foreground mb-1">Meses Grátis Ganhos</p>
                <p className="text-2xl font-bold text-fire-yellow-intense">
                  {profile.free_months_granted || 0}
                </p>
              </div>
            </div>

            <div className="mt-4 p-3 rounded-lg bg-fire-orange/5 border border-fire-orange/10">
              <p className="text-xs text-muted-foreground text-center">
                Acesse sua <strong className="text-fire-yellow-intense">Carteira</strong> para gerenciar seu username, link de convite e solicitar saques
              </p>
            </div>
          </Card>
          */}

          <Card className="bg-drama-card border-drama-border p-6">
            <h2 className="text-xl font-bold mb-4">Meu Plano</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-semibold">Plano Premium</span>
                    {getPlanBadge()}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    R$ 24,90 • Acesso por 30 dias
                  </p>
                  {profile.plan_renews_at && profile.plan_status === "active" && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Válido até {new Date(profile.plan_renews_at).toLocaleDateString("pt-BR")}
                    </p>
                  )}
                </div>
              </div>

              {profile.plan_status !== "active" && (
                <Button
                  className="bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold"
                  onClick={handleActivatePlan}
                  disabled={processingPayment}
                >
                  {processingPayment ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Crown className="w-4 h-4 mr-2" />
                      Ativar Plano Premium
                    </>
                  )}
                </Button>
              )}
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-drama-card border-drama-border p-6 text-center">
              <Gift className="w-8 h-8 text-fire-orange mx-auto mb-2" />
              <div className="text-2xl font-bold">{profile.referral_count}</div>
              <div className="text-sm text-muted-foreground">Indicações</div>
            </Card>

            <Card className="bg-drama-card border-drama-border p-6 text-center">
              <Film className="w-8 h-8 text-fire-yellow-intense mx-auto mb-2" />
              <div className="text-2xl font-bold">{profile.episodes_watched}</div>
              <div className="text-sm text-muted-foreground">Episódios</div>
            </Card>

            <Card className="bg-drama-card border-drama-border p-6 text-center">
              <Clock className="w-8 h-8 text-fire-orange mx-auto mb-2" />
              <div className="text-2xl font-bold">{profile.total_watch_time}</div>
              <div className="text-sm text-muted-foreground">Minutos</div>
            </Card>
          </div>

          {isAdmin && (
            <Card className="bg-drama-card border-drama-border p-6">
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <Settings className="w-5 h-5 mr-2 text-fire-orange" />
                Painel Administrativo
              </h2>
              
              <div className="grid grid-cols-1 gap-4">
                <Button
                  onClick={() => navigate("/admin")}
                  className="bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold h-auto py-6"
                >
                  <Settings className="w-6 h-6 mr-3" />
                  <div className="text-left flex-1">
                    <div className="text-lg font-bold">Dashboard Admin</div>
                    <div className="text-xs opacity-90">Painel completo de gerenciamento e controle</div>
                  </div>
                </Button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Button
                    onClick={() => navigate("/admin/users")}
                    variant="outline"
                    className="border-drama-border hover:bg-drama-card h-auto py-4"
                  >
                    <Users className="w-5 h-5 mr-2" />
                    <div className="text-left">
                      <div className="font-bold">Gerenciar Usuários</div>
                      <div className="text-xs opacity-70">Ativar, desativar e visualizar indicações</div>
                    </div>
                  </Button>

                  <Button
                    onClick={() => navigate("/admin/reports")}
                    variant="outline"
                    className="border-drama-border hover:bg-drama-card h-auto py-4"
                  >
                    <BarChart3 className="w-5 h-5 mr-2" />
                    <div className="text-left">
                      <div className="font-bold">Relatórios</div>
                      <div className="text-xs opacity-70">Filmes assistidos e títulos pesquisados</div>
                    </div>
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {profile.plan_status === "active" && (
            <Card className="bg-drama-card border-drama-border p-6">
              <h2 className="text-xl font-bold mb-4">Gerenciamento de Assinatura</h2>
              
              <Sheet>
                <SheetTrigger asChild>
                  <Button 
                    variant="outline"
                    className="w-full sm:w-auto border-drama-border hover:bg-drama-card"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    Gerenciar assinatura
                  </Button>
                </SheetTrigger>
                <SheetContent className="bg-drama-card border-drama-border">
                  <SheetHeader>
                    <SheetTitle>Gerenciar Assinatura</SheetTitle>
                    <SheetDescription>
                      Detalhes do seu plano e opções de gerenciamento
                    </SheetDescription>
                  </SheetHeader>
                  
                  <div className="mt-6 space-y-6">
                    <div className="space-y-4">
                      <div className="bg-background rounded-lg p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Status</span>
                          <Badge className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white border-none">PLANO ATIVO</Badge>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Plano</span>
                          <span className="font-semibold">Plano Premium</span>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Valor</span>
                          <span className="font-semibold">R$ 2,00/mês</span>
                        </div>
                        
                        {profile.plan_renews_at && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Renovação</span>
                            <span className="font-semibold">
                              {new Date(profile.plan_renews_at).toLocaleDateString("pt-BR")}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-drama-border">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            variant="destructive" 
                            className="w-full bg-destructive hover:bg-destructive/90"
                          >
                            <AlertCircle className="w-4 h-4 mr-2" />
                            Cancelar assinatura
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-drama-card border-drama-border">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Cancelar assinatura?</AlertDialogTitle>
                            <AlertDialogDescription className="text-muted-foreground">
                              Tem certeza que deseja cancelar sua assinatura Premium? 
                              Você perderá o acesso ilimitado aos filmes e voltará ao plano gratuito.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="border-drama-border hover:bg-drama-card">
                              Manter assinatura
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={handleCancelSubscription}
                              className="bg-destructive hover:bg-destructive/90"
                            >
                              Sim, cancelar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </Card>
          )}
        </div>
      </div>

      {/* Modal de Benefícios do Premium */}
      <Dialog open={showBenefitsModal} onOpenChange={setShowBenefitsModal}>
        <DialogContent className="max-w-[95vw] sm:max-w-[450px] bg-charcoal-black border-fire-orange/20">
          <DialogHeader>
            <DialogTitle className="text-xl font-black text-fire-yellow-bright text-center">
              🔥 Oferta Especial
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="text-center">
              <p className="text-4xl font-black text-white">R$ 24,90</p>
              <p className="text-sm text-muted-foreground">Acesso completo por 30 dias</p>
            </div>
            
            <div className="space-y-3 bg-fire-orange/10 border border-fire-orange/30 rounded-lg p-4">
              <p className="text-sm font-bold text-fire-yellow-bright">✨ Benefícios Premium:</p>
              <ul className="space-y-2 text-sm text-foreground">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Acesso a TODOS os doramas
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Sem limite de tempo de assistir
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Novos lançamentos liberados
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Assista quantas vezes quiser
                </li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="customerWhatsAppProfile" className="text-sm font-medium text-foreground">
                WhatsApp *
              </Label>
              <Input
                id="customerWhatsAppProfile"
                type="tel"
                inputMode="numeric"
                value={customerWhatsApp}
                onChange={(e) => {
                  const numbersOnly = e.target.value.replace(/\D/g, '').slice(0, 11);
                  let formatted = '';
                  if (numbersOnly.length > 0) formatted = '(' + numbersOnly.slice(0, 2);
                  if (numbersOnly.length > 2) formatted += ') ' + numbersOnly.slice(2, 7);
                  if (numbersOnly.length > 7) formatted += '-' + numbersOnly.slice(7, 11);
                  setCustomerWhatsApp(formatted);
                }}
                placeholder="(99) 99999-9999"
                className="bg-background border-border text-foreground"
              />
            </div>
            
            <Button
              onClick={handleContinueToPayment}
              disabled={customerWhatsApp.replace(/\D/g, '').length < 7}
              className="w-full min-h-[52px] bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white font-bold text-lg hover:brightness-125 shadow-lg hover:shadow-[0_10px_40px_rgba(255,140,0,0.5)] transition-all disabled:opacity-50"
            >
              <Crown className="w-5 h-5 mr-2" />
              Continuar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Seleção de Pagamento */}
      <Dialog open={showPaymentSelector} onOpenChange={setShowPaymentSelector}>
        <DialogContent className="max-w-[95vw] sm:max-w-[450px] bg-charcoal-black border-fire-orange/20">
          <DialogHeader>
            <DialogTitle className="text-xl font-black text-fire-yellow-bright text-center">
              Acesso Completo 30 Dias
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <div className="text-center mb-6">
              <p className="text-3xl font-black text-white">R$ 24,90</p>
            </div>
            
            <PaymentMethodSelector
              selectedMethod={paymentMethod}
              onSelect={handlePaymentMethodSelect}
              disabled={processingPayment}
            />
            
            {processingPayment && (
              <div className="flex items-center justify-center mt-4 text-muted-foreground">
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Gerando pagamento...
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Cartão de Crédito */}
      <Dialog open={showCreditCardForm} onOpenChange={setShowCreditCardForm}>
        <DialogContent className="max-w-[95vw] sm:max-w-[450px] bg-charcoal-black border-fire-orange/20">
          <DialogHeader>
            <DialogTitle className="text-xl font-black text-fire-yellow-bright text-center">
              💳 Pagamento com Cartão
            </DialogTitle>
          </DialogHeader>
          
          <CreditCardForm
            amount={24.90}
            customerName={customerWhatsApp}
            onSuccess={handleCardPaymentSuccess}
            onCancel={() => {
              setShowCreditCardForm(false);
              setShowPaymentSelector(true);
            }}
            createPaymentEndpoint="create-fullaccess-payment"
            paymentData={{
              visitor_id: getOrCreateVisitorId(),
              ...(session?.user && { userId: session.user.id }),
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Modal de Sucesso Cartão */}
      <Dialog open={cardPaymentSuccess} onOpenChange={setCardPaymentSuccess}>
        <DialogContent className="max-w-[95vw] sm:max-w-[400px] bg-charcoal-black border-fire-orange/20">
          <div className="text-center py-8">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center mx-auto mb-6 animate-pulse">
              <CheckCircle2 className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-2xl font-black text-fire-yellow-bright mb-2">
              Pagamento Aprovado!
            </h2>
            <p className="text-muted-foreground mb-6">
              Seu acesso Premium foi ativado com sucesso.
            </p>
            <Button
              onClick={() => setCardPaymentSuccess(false)}
              className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white font-bold"
            >
              Continuar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Pagamento PIX */}
      <PixPaymentModal
        isOpen={showPixModal}
        onClose={() => setShowPixModal(false)}
        checkoutUrl={checkoutUrl}
        pixCode={pixCode}
        transactionId={transactionId}
        checkoutSessionId={checkoutSessionId}
        amount={24.90}
        dramaTitle="Acesso Completo 30 Dias"
        isUpsell={true}
      />
    </div>
  );
};

export default Profile;
