import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play, Lock, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import VideoPlayer from "@/components/VideoPlayer";
import BunnyPlayer from "@/components/BunnyPlayer";
import DoramasHlsPlayer from "@/components/DoramasHlsPlayer";
import { analyzeVideoUrl, bunnyEmbedToHls } from "@/utils/videoDetector";
import { LegalDisclaimer } from "@/components/LegalDisclaimer";
import { generateDramaSEO } from "@/utils/seoGenerator";

interface Drama {
  id: string;
  title: string;
  slug: string;
  synopsis: string;
  cover_url: string;
  thumbnail_url: string;
  genres: string[];
  tags: string[];
  total_episodes: number;
  file_url: string | null;
  video_url?: string | null;
  created_at?: string | null;
}

interface Episode {
  id: string;
  episode_number: number;
  title: string;
  description: string;
  duration: number;
  is_free: boolean;
}

const Drama = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [drama, setDrama] = useState<Drama | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [userPlan, setUserPlan] = useState<string>("none");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDramaData();
    checkUserPlan();
  }, [slug]);

  // Re-check plan when page becomes visible (after payment)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        checkUserPlan();
      }
    };
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  const fetchDramaData = async () => {
    try {
      // Fetch drama
      const { data: dramaData, error: dramaError } = await supabase
        .from("dramas")
        .select("*")
        .eq("slug", slug)
        .single();

      if (dramaError) throw dramaError;
      setDrama(dramaData);

      // Fetch episodes
      const { data: episodesData, error: episodesError } = await supabase
        .from("episodes")
        .select("*")
        .eq("drama_id", dramaData.id)
        .order("episode_number", { ascending: true });

      if (episodesError) throw episodesError;
      setEpisodes(episodesData || []);
    } catch (error) {
      console.error("Error fetching drama:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar o drama.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const checkUserPlan = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      console.log("Drama: Usuário não logado");
      setUserPlan("none");
      return;
    }

    const { data: profile, error } = await supabase
      .from("profiles")
      .select("plan_status")
      .eq("id", session.user.id)
      .single();

    console.log("Drama: Verificação de plano", {
      userId: session.user.id,
      plan_status: profile?.plan_status,
      error
    });

    if (profile) {
      setUserPlan(profile.plan_status);
    } else {
      setUserPlan("none");
    }
  };

  const canWatchEpisode = (episodeNumber: number) => {
    // Episodes 1-5 are free
    if (episodeNumber <= 5) return true;
    // Episodes 6+ require active plan
    return userPlan === "active";
  };

  const handleEpisodeClick = async (episode: Episode) => {
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      toast({
        title: "Login necessário",
        description: "Faça login para assistir aos episódios.",
      });
      navigate("/auth");
      return;
    }

    if (!canWatchEpisode(episode.episode_number)) {
      navigate("/paywall");
      return;
    }

    navigate(`/player/${episode.id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 pt-24">
          <div className="animate-pulse space-y-8">
            <div className="h-96 bg-drama-card rounded-lg" />
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-24 bg-drama-card rounded-lg" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!drama) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 pt-24 text-center">
          <h1 className="text-2xl font-bold mb-4">Drama não encontrado</h1>
          <Button onClick={() => navigate("/")}>Voltar ao Início</Button>
        </div>
      </div>
    );
  }

  const seoData = generateDramaSEO(drama, "drama");

  const effectiveVideoUrl = drama.file_url || drama.video_url || null;
  const analyzed = effectiveVideoUrl ? analyzeVideoUrl(effectiveVideoUrl) : null;

  // Auto-convert Bunny to HLS
  let playerType = analyzed?.type ?? null;
  let finalVideoUrl = effectiveVideoUrl;

  if (analyzed?.type === "bunny") {
    const hlsFromBunny = bunnyEmbedToHls(analyzed.url);
    if (hlsFromBunny) {
      playerType = "hls";
      finalVideoUrl = hlsFromBunny;
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{seoData.title}</title>
        <meta name="description" content={seoData.description} />
        <meta name="keywords" content={seoData.keywords.join(", ")} />
        <link rel="canonical" href={seoData.canonical} />
        
        {/* Open Graph */}
        <meta property="og:title" content={seoData.ogTitle} />
        <meta property="og:description" content={seoData.ogDescription} />
        <meta property="og:url" content={seoData.canonical} />
        <meta property="og:type" content="video.tv_show" />
        <meta property="og:image" content={seoData.ogImage} />
        <meta property="og:site_name" content="Doramas Super" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={seoData.ogTitle} />
        <meta name="twitter:description" content={seoData.ogDescription} />
        <meta name="twitter:image" content={seoData.ogImage} />
        
        {/* Schema.org */}
        <script type="application/ld+json">
          {JSON.stringify(seoData.schema)}
        </script>
      </Helmet>
      
      <Navbar />

      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-end">
        <div className="absolute inset-0">
          <img
            src={drama.cover_url || drama.thumbnail_url || "/placeholder.svg"}
            alt={drama.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 gradient-hero" />
        </div>

        <div className="relative container mx-auto px-4 pb-12 z-10">
          <div className="max-w-3xl space-y-3 sm:space-y-4">
            <h1 className="text-2xl sm:text-3xl md:text-6xl font-bold text-white leading-tight break-words">
              {drama.title}
            </h1>
            
            <div className="flex flex-wrap items-center gap-2">
              {drama.genres && drama.genres.map((genre) => (
                <Badge key={genre} className="bg-drama-red text-white text-xs sm:text-sm">
                  {genre}
                </Badge>
              ))}
              <span className="text-sm sm:text-base text-gray-300">{drama.total_episodes} episódios</span>
            </div>

            <p className="text-sm sm:text-base md:text-lg text-gray-200 leading-relaxed break-words">
              {drama.synopsis}
            </p>
          </div>
        </div>
      </section>

        {/* Video Player Section */}
        <section className="container mx-auto px-4 py-8">
          {finalVideoUrl && playerType ? (
            playerType === 'hls' ? (
              <DoramasHlsPlayer
                key={drama.id}
                hlsUrl={finalVideoUrl}
                dramaTitle={drama.title}
                dramaId={drama.id}
                isPremium={userPlan === "active"}
                thumbnailUrl={drama.thumbnail_url}
                previewSeconds={1500}
              />
            ) : playerType === 'bunny' ? (
              <BunnyPlayer
                key={drama.id}
                videoUrl={finalVideoUrl}
                thumbnailUrl={drama.thumbnail_url}
                dramaTitle={drama.title}
                dramaId={drama.id}
                isPremium={userPlan === "active"}
              />
            ) : (
              <VideoPlayer
                key={drama.id}
                videoUrl={finalVideoUrl}
                thumbnailUrl={drama.thumbnail_url}
                dramaTitle={drama.title}
                dramaId={drama.id}
                isPremium={userPlan === "active"}
              />
            )
          ) : (
            <Card className="w-full aspect-video bg-drama-card border-drama-border flex items-center justify-center">
              <p className="text-muted-foreground">Vídeo ainda não disponível</p>
            </Card>
          )}
        </section>

      {/* Episodes List */}
      <section className="container mx-auto px-4 py-12">
        <h2 className="text-xl sm:text-2xl font-bold mb-6">Episódios</h2>

        {episodes.length === 0 ? (
          <p className="text-sm sm:text-base text-muted-foreground">Nenhum episódio disponível ainda.</p>
        ) : (
          <div className="space-y-3">
            {episodes.map((episode) => {
              const isLocked = !canWatchEpisode(episode.episode_number);

              return (
                <Card
                  key={episode.id}
                  className={`p-3 sm:p-4 bg-drama-card border-drama-border hover:border-drama-red transition-smooth cursor-pointer ${
                    isLocked ? "opacity-60" : ""
                  }`}
                  onClick={() => handleEpisodeClick(episode)}
                >
                  <div className="flex items-center space-x-3 sm:space-x-4">
                    <div className="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 bg-drama-red/20 rounded-full flex items-center justify-center">
                      {isLocked ? (
                        <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-drama-red" />
                      ) : (
                        <Play className="w-4 h-4 sm:w-5 sm:h-5 text-drama-red" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-xs sm:text-sm text-muted-foreground">
                          Episódio {episode.episode_number}
                        </span>
                        {episode.episode_number <= 5 && (
                          <Badge variant="outline" className="text-xs">
                            Grátis
                          </Badge>
                        )}
                      </div>
                      <h3 className="text-sm sm:text-base font-semibold text-foreground truncate">
                        {episode.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-muted-foreground line-clamp-1">
                        {episode.description}
                      </p>
                    </div>

                    {episode.duration && (
                      <div className="flex items-center text-xs sm:text-sm text-muted-foreground flex-shrink-0">
                        <Clock className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                        {episode.duration}min
                      </div>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </section>

      {/* Legal Disclaimer */}
      <section className="container mx-auto px-4 pb-12">
        <LegalDisclaimer />
      </section>
    </div>
  );
};

export default Drama;
