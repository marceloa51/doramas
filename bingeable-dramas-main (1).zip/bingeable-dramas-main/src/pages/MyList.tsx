import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import DramaCard from "@/components/DramaCard";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Film } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UserDrama {
  drama_id: string;
  status: "watching" | "watched";
  last_watched_at: string;
  drama: {
    id: string;
    title: string;
    slug: string;
    synopsis: string;
    thumbnail_url: string;
    cover_url: string;
    genres: string[];
  };
}

const MyList = () => {
  const [userDramas, setUserDramas] = useState<UserDrama[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    checkAuthAndFetch();
  }, []);

  const checkAuthAndFetch = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      toast({
        title: "Login necessário",
        description: "Faça login para ver sua lista.",
      });
      navigate("/auth");
      return;
    }

    fetchUserDramas(session.user.id);
  };

  const fetchUserDramas = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("user_dramas")
        .select(`
          drama_id,
          status,
          last_watched_at,
          drama:dramas(id, title, slug, synopsis, thumbnail_url, cover_url, genres)
        `)
        .eq("user_id", userId)
        .order("last_watched_at", { ascending: false });

      if (error) throw error;

      setUserDramas((data as any) || []);
    } catch (error) {
      console.error("Error fetching user dramas:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar sua lista.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const watchingDramas = userDramas.filter((item) => item.status === "watching");
  const watchedDramas = userDramas.filter((item) => item.status === "watched");

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-12 flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-12 h-12 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Espaçador para compensar o navbar fixo */}
      <div className="h-16"></div>
      
      <div className="container mx-auto px-4 py-8 pb-12">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Minha Lista</h1>
          <p className="text-muted-foreground">
            Seus filmes favoritos em um só lugar
          </p>
        </div>

        {userDramas.length === 0 ? (
          <div className="flex flex-col items-center justify-center min-h-[50vh] text-center">
            <Film className="w-20 h-20 text-muted-foreground mb-4" />
            <h2 className="text-2xl font-bold mb-2">Sua lista está vazia</h2>
            <p className="text-muted-foreground mb-6 max-w-md">
              Comece a assistir filmes para que eles apareçam aqui automaticamente.
            </p>
            <button
              onClick={() => navigate("/")}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-smooth"
            >
              Explorar Filmes
            </button>
          </div>
        ) : (
          <div className="space-y-12">
            {/* Assistindo */}
            {watchingDramas.length > 0 && (
              <section>
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                  <span className="w-2 h-8 bg-primary rounded-full" />
                  Assistindo
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                  {watchingDramas.map((item) => (
                    <DramaCard
                      key={item.drama_id}
                      id={item.drama.id}
                      title={item.drama.title}
                      slug={item.drama.slug}
                      genres={item.drama.genres}
                      thumbnail={item.drama.thumbnail_url}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Assistido */}
            {watchedDramas.length > 0 && (
              <section>
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                  <span className="w-2 h-8 bg-green-500 rounded-full" />
                  Assistido
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                  {watchedDramas.map((item) => (
                    <DramaCard
                      key={item.drama_id}
                      id={item.drama.id}
                      title={item.drama.title}
                      slug={item.drama.slug}
                      genres={item.drama.genres}
                      thumbnail={item.drama.thumbnail_url}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyList;
