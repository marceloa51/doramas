import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { XCircle, ArrowLeft, CreditCard } from "lucide-react";

const PaymentCanceled = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
        <title>Pagamento Cancelado | Doramas Super</title>
      </Helmet>

      <Navbar />
      <div className="h-16"></div>
      
      <div className="container mx-auto px-4 py-16">
        <Card className="max-w-2xl mx-auto bg-drama-card border-drama-border p-8 md:p-12 text-center">
          <div className="mb-6">
            <div className="w-24 h-24 mx-auto rounded-full bg-muted/20 flex items-center justify-center">
              <XCircle className="w-16 h-16 text-muted-foreground" />
            </div>
          </div>
          
          <h1 className="text-3xl md:text-4xl font-display font-black mb-4 text-foreground">
            Pagamento Cancelado
          </h1>
          
          <p className="text-lg text-muted-foreground mb-8">
            Nenhuma cobrança foi realizada. Você pode tentar novamente quando quiser.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => navigate('/paywall')}
              className="bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold transition-all duration-300"
            >
              <CreditCard className="w-5 h-5 mr-2" />
              Tentar Novamente
            </Button>
            
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate('/')}
              className="border-drama-border hover:bg-drama-card transition-all duration-300"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Voltar ao Início
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default PaymentCanceled;
