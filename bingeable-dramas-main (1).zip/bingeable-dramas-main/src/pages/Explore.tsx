import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import DramaCard from "@/components/DramaCard";
import PlanBanner from "@/components/PlanBanner";
import { DramaCarousel } from "@/components/DramaCarousel";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { ArrowUpDown, Filter } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type PlanStatus = Database["public"]["Enums"]["plan_status"];

interface Drama {
  id: string;
  title: string;
  slug: string;
  synopsis: string;
  thumbnail_url: string;
  cover_url: string;
  genres: string[];
  total_episodes: number;
  created_at: string;
}

const Explore = () => {
  const [dramas, setDramas] = useState<Drama[]>([]);
  const [filteredDramas, setFilteredDramas] = useState<Drama[]>([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [planStatus, setPlanStatus] = useState<PlanStatus>("none");
  const [selectedGenre, setSelectedGenre] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("recent");
  const [genres, setGenres] = useState<string[]>([]);
  const [topWeek, setTopWeek] = useState<Drama[]>([]);
  const [recentDramas, setRecentDramas] = useState<Drama[]>([]);

  useEffect(() => {
    checkAuth();
    fetchDramas();
  }, []);

  useEffect(() => {
    filterAndSortDramas();
  }, [dramas, selectedGenre, sortBy]);

  const checkAuth = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (session?.user) {
      setUserId(session.user.id);
      fetchPlanStatus(session.user.id);
    }
  };

  const fetchPlanStatus = async (uid: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("plan_status")
      .eq("id", uid)
      .maybeSingle();

    if (data?.plan_status) {
      setPlanStatus(data.plan_status);
    }
  };

  const fetchDramas = async () => {
    try {
      const { data, error } = await supabase
        .from("dramas")
        .select("*")
        .eq("status", "active")
        .order("created_at", { ascending: false });

      if (error) throw error;

      if (data) {
        setDramas(data);
        setRecentDramas(data.slice(0, 10));
        
        // Extract all unique genres from all dramas
        const allGenres = new Set<string>();
        data.forEach((drama) => {
          if (drama.genres && Array.isArray(drama.genres)) {
            drama.genres.forEach((genre) => allGenres.add(genre));
          }
        });
        setGenres(Array.from(allGenres).sort());

        await fetchTopWeek(data);
      }
    } catch (error) {
      console.error("Error fetching dramas:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTopWeek = async (allDramas: Drama[]) => {
    try {
      const { data: weekViews } = await supabase
        .from("video_views")
        .select("drama_id, watch_duration")
        .gte("watched_at", new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());

      const countViews = (views: any[] | null) => {
        if (!views) return new Map();
        const counts = new Map<string, number>();
        views.forEach((view) => {
          counts.set(view.drama_id, (counts.get(view.drama_id) || 0) + 1);
        });
        return counts;
      };

      const weekCounts = countViews(weekViews);
      
      const weekTop = allDramas
        .filter((d) => weekCounts.has(d.id))
        .sort((a, b) => (weekCounts.get(b.id) || 0) - (weekCounts.get(a.id) || 0))
        .slice(0, 10);
      setTopWeek(weekTop);
    } catch (error) {
      console.error("Error fetching week stats:", error);
    }
  };

  const filterAndSortDramas = () => {
    let result = [...dramas];

    if (selectedGenre !== "all") {
      result = result.filter((d) => d.genres?.includes(selectedGenre));
    }

    switch (sortBy) {
      case "recent":
        result.sort(
          (a, b) =>
            new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        );
        break;
      case "oldest":
        result.sort(
          (a, b) =>
            new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        );
        break;
      case "title":
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
    }

    setFilteredDramas(result);
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Explorar Doramas - Catálogo Completo | Doramas Super</title>
        <meta name="description" content="Explore nosso catálogo completo de doramas dublados em português. Filtre por gênero, descubra os mais assistidos e encontre seu próximo drama favorito." />
        <link rel="canonical" href="https://doramassuper.site/explorar" />
        <meta property="og:title" content="Explorar Doramas - Catálogo Completo | Doramas Super" />
        <meta property="og:description" content="Catálogo completo de doramas dublados em português. Filtre por gênero e descubra novos dramas." />
        <meta property="og:url" content="https://doramassuper.site/explorar" />
        <meta property="og:type" content="website" />
      </Helmet>

      {/* Hidden SEO Content */}
      <div className="sr-only">
        <p>Explore nossa coleção completa de doramas dublados em português. Filtre por gênero incluindo romance, ação, comédia, drama familiar, fantasia e muito mais. Descubra os doramas mais assistidos da semana, lançamentos recentes e clássicos atemporais. Todos os títulos disponíveis com qualidade HD e streaming sem anúncios na melhor plataforma de doramas do Brasil.</p>
      </div>

      <Navbar />
      <div className="h-16"></div>
      {userId && <PlanBanner hasActivePlan={planStatus === "active"} />}

      <div className="container mx-auto px-4 py-8 sm:py-12">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">Explorar</h1>
          <p className="text-muted-foreground">
            Descubra todos os doramas disponíveis
          </p>
        </div>

        <div className="mb-12">
          {topWeek.length > 0 && (
            <DramaCarousel
              title="🔥 Mais Assistidos da Semana"
              dramas={topWeek}
              loading={loading}
            />
          )}

          {recentDramas.length > 0 && (
            <div className="mt-8">
              <DramaCarousel
                title="✨ Lançamentos"
                dramas={recentDramas}
                loading={loading}
              />
            </div>
          )}
        </div>

        <div className="border-t border-drama-border pt-8">
          <h2 className="text-2xl font-bold mb-6">Todos os Doramas</h2>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="w-full sm:w-[200px] bg-drama-card border-drama-border">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filtrar por gênero" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os gêneros</SelectItem>
                {genres.map((genre) => (
                  <SelectItem key={genre} value={genre}>
                    {genre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full sm:w-[200px] bg-drama-card border-drama-border">
                <ArrowUpDown className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Mais recentes</SelectItem>
                <SelectItem value="oldest">Mais antigos</SelectItem>
                <SelectItem value="title">Título (A-Z)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {[...Array(15)].map((_, i) => (
                <div
                  key={i}
                  className="aspect-[2/3] bg-drama-card animate-pulse rounded-lg"
                />
              ))}
            </div>
          ) : filteredDramas.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted-foreground text-lg mb-2">
                Nenhum dorama encontrado
              </p>
              <p className="text-sm text-muted-foreground/70">
                Tente ajustar os filtros
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {filteredDramas.map((drama) => (
                <DramaCard
                  key={drama.id}
                  id={drama.id}
                  title={drama.title}
                  thumbnail={drama.thumbnail_url}
                  genres={drama.genres}
                  slug={drama.slug}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Explore;
