import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Clock, ShieldCheck, Zap, PlayCircle, MonitorSmartphone, Check, Loader2 } from "lucide-react";
import { PixPaymentModal } from "@/components/PixPaymentModal";
import { PaymentMethodSelector } from "@/components/PaymentMethodSelector";
import { CreditCardForm } from "@/components/CreditCardPaymentForm";
import { getOrCreateVisitorId, saveLastOrder, getPendingPixModal, savePendingPixModal, clearPendingPixModal } from "@/utils/visitorManager";

interface Drama {
  id: string;
  title: string;
  slug: string;
  synopsis: string;
  thumbnail_url: string | null;
  cover_url: string | null;
  price: number;
}

const DramaCheckout = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [drama, setDrama] = useState<Drama | null>(null);
  const [loading, setLoading] = useState(true);
  const [customerWhatsApp, setCustomerWhatsApp] = useState("");
  const [processingPayment, setProcessingPayment] = useState(false);
  const [showPixModal, setShowPixModal] = useState(false);
  const [pixCode, setPixCode] = useState("");
  const [checkoutUrl, setCheckoutUrl] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [showUpsellModal, setShowUpsellModal] = useState(false);
  const [isFullAccess, setIsFullAccess] = useState(false);
  
  // Payment method selection
  const [showPaymentSelector, setShowPaymentSelector] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit_card'>('pix');
  const [showCreditCardForm, setShowCreditCardForm] = useState(false);
  const [pendingAmount, setPendingAmount] = useState(0);
  const [cardPaymentSuccess, setCardPaymentSuccess] = useState(false);

  useEffect(() => {
    const savedPix = getPendingPixModal();
    if (savedPix) {
      console.log('🔄 Recuperando modal PIX do localStorage');
      setPixCode(savedPix.pixCode);
      setCheckoutUrl(savedPix.checkoutUrl);
      setTransactionId(savedPix.transactionId);
      setShowPixModal(true);
    }
  }, []);

  useEffect(() => {
    fetchDrama();
  }, [slug]);

  useEffect(() => {
    if (drama?.id) {
      checkVisitorOrders();
    }
  }, [drama?.id]);

  const checkVisitorOrders = async () => {
    try {
      const visitorId = getOrCreateVisitorId();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-visitor-orders?visitor_id=${visitorId}`,
        {
          headers: {
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
        }
      );

      if (!response.ok) return;

      const { paidOrdersWithoutUser, pendingOrders, expiredOrders } = await response.json();

      // Verificar se há PIX expirado para este drama
      if (expiredOrders && expiredOrders.length > 0 && drama) {
        const expiredForThisDrama = expiredOrders.find((o: any) => 
          o.items && o.items.some((item: any) => item.drama_id === drama.id)
        );

        if (expiredForThisDrama) {
          // Limpar localStorage do PIX expirado
          clearPendingPixModal();
          localStorage.removeItem('pending_purchase');
          
          toast({
            title: "⏰ PIX Expirado",
            description: "Seu PIX expirou. Por favor, gere um novo pagamento.",
            variant: "destructive",
          });
          // Não retorna - permite que o usuário gere novo PIX
        }
      }

      // Se há compras pagas sem usuário e o visitante atual NÃO está logado
      if (paidOrdersWithoutUser && paidOrdersWithoutUser.length > 0) {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session?.user) {
          // Usuário não logado - redirecionar para criar conta
          const order = paidOrdersWithoutUser[0];
          localStorage.setItem('pending_purchase', JSON.stringify({
            checkout_session_id: order.id,
            dramaTitle: order.items[0]?.title || 'Dorama',
            amount: order.amount,
            customerName: order.customer_name,
          }));
          navigate('/receber-compra');
          return;
        }
        // Se usuário está logado, ignorar - o dorama já deve estar atribuído
      }

      if (pendingOrders && pendingOrders.length > 0 && drama) {
        const pendingForThisDrama = pendingOrders.find((o: any) =>
          o.items && o.items.some((item: any) => item.drama_id === drama.id)
        );

        if (pendingForThisDrama) {
          const currentPrice = Number(drama.price ?? 12.90);
          const pendingAmount = Number(pendingForThisDrama.amount ?? 0);

          // Se houver um PIX pendente com valor antigo, não reaproveitar.
          if (Math.abs(pendingAmount - currentPrice) > 0.001) {
            console.log('🔁 Pending PIX com valor antigo detectado. Limpando...', {
              pendingAmount,
              currentPrice,
              checkoutSessionId: pendingForThisDrama.id,
            });

            clearPendingPixModal();
            localStorage.removeItem('pending_purchase');
            setShowPixModal(false);

            toast({
              title: "Preço atualizado",
              description: "Seu PIX anterior estava com valor antigo. Gere um novo pagamento para continuar.",
            });

            return;
          }

          setPixCode(pendingForThisDrama.pix_code || '');
          setCheckoutUrl(pendingForThisDrama.checkout_url || '');
          setTransactionId(pendingForThisDrama.reference_id || '');

          localStorage.setItem(
            'pending_purchase',
            JSON.stringify({
              checkout_session_id: pendingForThisDrama.id,
              dramaTitle: pendingForThisDrama.items[0]?.title || drama.title,
              amount: pendingForThisDrama.amount,
              customerName: pendingForThisDrama.customer_name,
            })
          );

          setShowPixModal(true);
        }
      }
    } catch (error) {
      console.error('Error checking visitor orders:', error);
    }
  };

  const fetchDrama = async () => {
    try {
      // Decodificar o slug da URL (caracteres especiais como vírgulas e acentos)
      const decodedSlug = slug ? decodeURIComponent(slug) : slug;
      
      let { data, error } = await supabase
        .from("dramas")
        .select("*")
        .eq("slug", decodedSlug)
        .maybeSingle();

      if (!data && decodedSlug?.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
        const result = await supabase
          .from("dramas")
          .select("*")
          .eq("id", decodedSlug)
          .maybeSingle();
        
        data = result.data;
        error = result.error;
      }

      if (error) throw error;
      if (!data) throw new Error("Dorama não encontrado");
      
      setDrama(data);
    } catch (error) {
      console.error("Error fetching drama:", error);
      toast({
        title: "Erro",
        description: "Dorama não encontrado",
        variant: "destructive",
      });
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async () => {
    const phoneDigits = customerWhatsApp.replace(/\D/g, '');
    if (phoneDigits.length < 7) {
      toast({
        title: "WhatsApp inválido",
        description: "Por favor, informe pelo menos 7 dígitos",
        variant: "destructive",
      });
      return;
    }

    if (!drama) return;
    setShowUpsellModal(true);
  };

  const handleDeclineUpsell = async () => {
    setShowUpsellModal(false);
    setPendingAmount(drama?.price || 12.90);
    setShowPaymentSelector(true);
  };

  const handleFullAccessPurchase = async () => {
    setIsFullAccess(true);
    setShowUpsellModal(false);
    setPendingAmount(24.90);
    setShowPaymentSelector(true);
  };

  const handlePaymentMethodConfirm = () => {
    if (paymentMethod === 'pix') {
      setShowPaymentSelector(false);
      if (isFullAccess) {
        generateFullAccessPayment('pix');
      } else {
        generatePayment('pix');
      }
    } else {
      setShowPaymentSelector(false);
      setShowCreditCardForm(true);
    }
  };

  const handleCreditCardSubmit = async (cardToken: string) => {
    if (isFullAccess) {
      await generateFullAccessPayment('credit_card', cardToken);
    } else {
      await generatePayment('credit_card', cardToken);
    }
  };

  const generateFullAccessPayment = async (method: 'pix' | 'credit_card', cardToken?: string) => {
    if (!drama) return;
    setProcessingPayment(true);

    try {
      const visitorId = getOrCreateVisitorId();
      const { data: { session } } = await supabase.auth.getSession();
      const isLoggedIn = !!session?.user;

      const purchaseData = {
        dramaId: drama.id,
        dramaTitle: drama.title,
        amount: 24.90,
        customerName: customerWhatsApp.trim(),
        isFullAccess: true,
      };

      if (!isLoggedIn) {
        localStorage.setItem('pending_purchase', JSON.stringify(purchaseData));
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-fullaccess-payment`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            customerName: customerWhatsApp.trim(),
            visitor_id: visitorId,
            paymentMethod: method,
            ...(cardToken && { cardToken }),
            ...(isLoggedIn && { userId: session.user.id }),
          }),
        }
      ).then(res => res.json());

      if (response.error) throw new Error(response.error);

      if (response.status === 'paid') {
        // Card payment approved
        if (isLoggedIn) {
          // Limpar localStorage para usuário logado
          localStorage.removeItem('pending_purchase');
        } else {
          // Salvar para criar conta depois
          localStorage.setItem('pending_purchase', JSON.stringify({
            checkout_session_id: response.checkoutSessionId,
            dramaTitle: "Acesso Completo 30 Dias",
            amount: 24.90,
            customerName: customerWhatsApp.trim(),
            isFullAccess: true,
          }));
        }
        
        setShowCreditCardForm(false);
        setCardPaymentSuccess(true);
        toast({ title: "🎉 Pagamento aprovado!", description: "Seu acesso foi liberado!" });
        setTimeout(() => {
          window.location.href = isLoggedIn ? '/meus-doramas' : '/receber-compra';
        }, 2000);
        return;
      }

      if (response.success || response.checkoutUrl) {
        const purchaseDataUpdated = JSON.parse(localStorage.getItem('pending_purchase') || '{}');
        purchaseDataUpdated.checkout_session_id = response.checkoutSessionId;
        purchaseDataUpdated.reference_id = response.referenceId;
        purchaseDataUpdated.isFullAccess = true;
        localStorage.setItem('pending_purchase', JSON.stringify(purchaseDataUpdated));

        savePendingPixModal({
          pixCode: response.pixCode || "",
          checkoutUrl: response.checkoutUrl || "",
          transactionId: response.transactionId || "",
          checkout_session_id: response.checkoutSessionId,
          amount: 24.90,
          dramaTitle: "Acesso Completo 30 Dias",
          dramaId: 'full_access_30_days',
          isFullAccess: true
        });

        setPixCode(response.pixCode || "");
        setCheckoutUrl(response.checkoutUrl || "");
        setTransactionId(response.transactionId || "");
        setShowPixModal(true);
      } else {
        throw new Error("Erro ao gerar pagamento");
      }
    } catch (error: any) {
      console.error("Full access payment error:", error);
      toast({
        title: "Erro no pagamento",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    } finally {
      setProcessingPayment(false);
    }
  };

  const generatePayment = async (method: 'pix' | 'credit_card', cardToken?: string) => {
    if (!drama) return;
    setProcessingPayment(true);

    try {
      const visitorId = getOrCreateVisitorId();
      const { data: { session } } = await supabase.auth.getSession();
      const isLoggedIn = !!session?.user;
      
      const purchaseData = {
        dramaId: drama.id,
        dramaTitle: drama.title,
        amount: drama.price,
        customerName: customerWhatsApp.trim(),
      };

      if (!isLoggedIn) {
        localStorage.setItem('pending_purchase', JSON.stringify(purchaseData));
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-payment`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            customerName: customerWhatsApp.trim(),
            dramaId: drama.id,
            visitor_id: visitorId,
            paymentMethod: method,
            ...(cardToken && { cardToken }),
            ...(isLoggedIn && { userId: session.user.id }),
          }),
        }
      ).then(res => res.json());

      if (response.error) throw new Error(response.error);

      if (response.status === 'paid') {
        // Card payment approved
        if (isLoggedIn) {
          // Limpar localStorage para usuário logado
          localStorage.removeItem('pending_purchase');
        } else {
          // Salvar para criar conta depois
          localStorage.setItem('pending_purchase', JSON.stringify({
            checkout_session_id: response.checkout_session_id,
            dramaTitle: drama?.title,
            amount: drama?.price,
            customerName: customerWhatsApp.trim(),
            dramaId: drama?.id,
          }));
        }
        
        setShowCreditCardForm(false);
        setCardPaymentSuccess(true);
        toast({ title: "🎉 Pagamento aprovado!", description: "Seu acesso foi liberado!" });
        setTimeout(() => {
          window.location.href = isLoggedIn ? '/meus-doramas' : '/receber-compra';
        }, 2000);
        return;
      }

      if (response.success || response.checkoutUrl) {
        const purchaseDataUpdated = JSON.parse(localStorage.getItem('pending_purchase') || '{}');
        purchaseDataUpdated.checkout_session_id = response.checkout_session_id;
        purchaseDataUpdated.reference_id = response.reference_id;
        localStorage.setItem('pending_purchase', JSON.stringify(purchaseDataUpdated));
        
        savePendingPixModal({
          pixCode: response.pixCode || "",
          checkoutUrl: response.checkoutUrl || "",
          transactionId: response.transactionId || "",
          checkout_session_id: response.checkout_session_id,
          amount: drama.price,
          dramaTitle: drama.title,
          dramaId: drama.id,
        });
        
        setPixCode(response.pixCode || "");
        setCheckoutUrl(response.checkoutUrl || "");
        setTransactionId(response.transactionId || "");
        setShowPixModal(true);
      } else {
        throw new Error("Erro ao gerar pagamento");
      }
    } catch (error: any) {
      console.error("Payment error:", error);
      toast({
        title: "Erro no pagamento",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    } finally {
      setProcessingPayment(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4 max-w-2xl mx-auto">
            <div className="h-8 bg-card rounded w-3/4" />
            <div className="h-96 bg-card rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!drama) return null;

  // Card payment success screen
  if (cardPaymentSuccess) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center p-8">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center mx-auto mb-6 animate-pulse shadow-[0_0_50px_rgba(255,140,0,0.8)]">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-fire-yellow-bright mb-3">
            🎉 Pagamento Aprovado!
          </h2>
          <p className="text-muted-foreground mb-4">Redirecionando...</p>
          <Loader2 className="w-8 h-8 animate-spin text-fire-orange mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Comprar {drama.title} - Doramas Super</title>
      </Helmet>

      <Navbar />
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="mb-6 sm:mb-8">
            <Button
              variant="ghost"
              onClick={() => navigate(`/movie/${drama.slug}`)}
              className="mb-4 hover:text-fire-orange"
            >
              ← Voltar
            </Button>
            <h1 className="text-2xl sm:text-3xl font-bold mb-2 text-fire-yellow-bright">Quase lá! 🎬</h1>
            <p className="text-sm sm:text-base text-muted-foreground px-2 sm:px-0">
              Confirme e assista ao dorama completo agora mesmo
            </p>
          </div>

          <div className="bg-card rounded-lg p-4 sm:p-6 mb-6 border border-border">
            <div className="flex flex-col sm:flex-row gap-4 mb-4">
              {(drama.thumbnail_url || drama.cover_url) && (
                <img
                  src={drama.thumbnail_url || drama.cover_url || ""}
                  alt={drama.title}
                  className="w-full sm:w-24 h-48 sm:h-36 object-cover rounded"
                />
              )}
              <div className="flex-1 space-y-3">
                <h2 className="text-lg sm:text-xl font-bold break-words">{drama.title}</h2>
                <p className="text-2xl sm:text-3xl font-bold text-fire-orange">R$ {drama.price.toFixed(2)}</p>
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 text-xs sm:text-sm text-muted-foreground flex-wrap">
                  <span className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5 text-[#FFD03C] flex-shrink-0" />
                    PIX ou Cartão
                  </span>
                  <span className="flex items-center gap-2">
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-[#FFD03C] flex-shrink-0" />
                    Acesso liberado em segundos
                  </span>
                  <span className="flex items-center gap-2">
                    <PlayCircle className="w-4 h-4 sm:w-5 sm:h-5 text-[#FFD03C] flex-shrink-0" />
                    Assista quantas vezes quiser
                  </span>
                  <span className="flex items-center gap-2">
                    <MonitorSmartphone className="w-4 h-4 sm:w-5 sm:h-5 text-[#FFD03C] flex-shrink-0" />
                    Compatível com celular e TV
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card rounded-lg p-6 border border-border">
            <h3 className="text-lg font-semibold mb-4">Informações</h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="whatsapp">WhatsApp</Label>
                <Input
                  id="whatsapp"
                  type="tel"
                  inputMode="numeric"
                  placeholder="(99) 99999-9999"
                  value={customerWhatsApp}
                  onChange={(e) => {
                    const numbersOnly = e.target.value.replace(/\D/g, '').slice(0, 11);
                    let formatted = '';
                    if (numbersOnly.length > 0) formatted = '(' + numbersOnly.slice(0, 2);
                    if (numbersOnly.length > 2) formatted += ') ' + numbersOnly.slice(2, 7);
                    if (numbersOnly.length > 7) formatted += '-' + numbersOnly.slice(7, 11);
                    setCustomerWhatsApp(formatted);
                  }}
                  className="mt-1"
                />
              </div>

              <Button
                onClick={handlePurchase}
                disabled={processingPayment || customerWhatsApp.replace(/\D/g, '').length < 7}
                className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_40px_rgba(255,140,0,0.6)] hover:scale-[1.02] text-white font-bold py-6 text-base sm:text-lg transition-all duration-300 min-h-[44px]"
              >
                {processingPayment ? "Preparando..." : `🔓 Liberar Acesso Imediato - R$ ${drama.price.toFixed(2)}`}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Upsell Modal */}
      {showUpsellModal && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-3 sm:p-4">
          <div className="bg-drama-card border border-fire-orange/30 rounded-xl w-full max-w-md shadow-[0_10px_60px_rgba(255,140,0,0.3)]">
            <div className="p-5 sm:p-6 md:p-8">
              <div className="flex items-center justify-center gap-2 bg-[#FF2A2A] text-white px-4 py-3 rounded-lg mb-4 shadow-[0px_0px_12px_rgba(255,0,0,0.25)]">
                <span className="text-lg">🔥</span>
                <span className="font-bold text-sm sm:text-base uppercase tracking-wide">VOCÊ RECEBEU UMA OFERTA ESPECIAL</span>
                <Clock className="w-4 h-4 animate-spin" style={{ animationDuration: '3s' }} />
              </div>

              <div className="flex justify-center mb-4">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-fire-orange/20 rounded-full flex items-center justify-center">
                  <Sparkles className="w-7 h-7 sm:w-8 sm:h-8 text-fire-orange" />
                </div>
              </div>

              <h2 className="text-xl sm:text-2xl font-bold text-center mb-2 text-fire-yellow-bright">🔥 OFERTA ESPECIAL!</h2>
              <p className="text-center text-sm sm:text-base text-muted-foreground mb-6">Escolha a melhor opção para você</p>

              <div className="bg-gradient-to-r from-fire-orange/15 to-fire-yellow-intense/15 border-2 border-fire-orange/50 rounded-xl p-4 sm:p-5 mb-4">
                <div className="flex justify-center mb-3">
                  <span className="inline-block bg-red-600/80 text-white px-3 py-1 rounded text-xs font-semibold">⭐ MAIS POPULAR</span>
                </div>
                <div className="text-center mb-3">
                  <h3 className="text-base sm:text-lg font-bold text-fire-yellow-bright">🎁 Acesso Completo por 30 Dias</h3>
                  <p className="text-2xl sm:text-3xl font-bold text-fire-orange mt-1">R$ 24,90</p>
                </div>
                <p className="text-center text-xs sm:text-sm text-muted-foreground mb-4">Assista <span className="text-fire-yellow-intense font-semibold">TODOS</span> os doramas do site durante 30 dias!</p>
                <Button onClick={handleFullAccessPurchase} disabled={processingPayment} className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_40px_rgba(255,140,0,0.7)] hover:scale-[1.02] text-white font-bold py-4 sm:py-5 text-sm sm:text-base transition-all duration-300 min-h-[48px] shadow-lg">
                  {processingPayment ? "Preparando..." : "SIM! Quero Acesso Completo 🔥"}
                </Button>
              </div>

              <div className="flex items-center gap-3 my-5">
                <div className="flex-1 h-px bg-white/30" />
                <span className="text-white text-xs sm:text-sm font-medium uppercase tracking-wider">OU</span>
                <div className="flex-1 h-px bg-white/30" />
              </div>

              <Button onClick={handleDeclineUpsell} variant="outline" disabled={processingPayment} className="w-full py-3 text-xs sm:text-sm bg-[#3E9BFF]/35 border border-[#3E9BFF]/70 hover:bg-[#3E9BFF]/50 text-white transition-all min-h-[40px] rounded-lg mt-3">
                {processingPayment ? "Preparando..." : `Continuar só com 1 dorama - R$ ${drama.price.toFixed(2)}`}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Method Selector Modal */}
      {showPaymentSelector && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-3 sm:p-4">
          <div className="bg-drama-card border border-fire-orange/30 rounded-xl w-full max-w-md shadow-[0_10px_60px_rgba(255,140,0,0.3)]">
            <div className="p-5 sm:p-6 md:p-8">
              <h2 className="text-xl font-bold text-center mb-2 text-fire-yellow-bright">Forma de Pagamento</h2>
              <p className="text-center text-sm text-muted-foreground mb-6">
                Total: <span className="text-fire-orange font-bold">R$ {pendingAmount.toFixed(2)}</span>
              </p>

              <PaymentMethodSelector selectedMethod={paymentMethod} onSelect={setPaymentMethod} disabled={processingPayment} />

              <div className="mt-6 space-y-3">
                <Button onClick={handlePaymentMethodConfirm} disabled={processingPayment} className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white font-bold py-4 text-base hover:brightness-125 shadow-lg">
                  {processingPayment ? <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Processando...</> : 'Continuar'}
                </Button>
                <Button variant="ghost" onClick={() => { setShowPaymentSelector(false); setIsFullAccess(false); }} className="w-full text-muted-foreground">
                  ← Voltar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Credit Card Form Modal */}
      {showCreditCardForm && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-3 sm:p-4">
          <div className="bg-drama-card border border-fire-orange/30 rounded-xl w-full max-w-md shadow-[0_10px_60px_rgba(255,140,0,0.3)] max-h-[90vh] overflow-y-auto">
            <div className="p-5 sm:p-6 md:p-8">
              <h2 className="text-xl font-bold text-center mb-2 text-fire-yellow-bright">Pagamento com Cartão</h2>
              <p className="text-center text-sm text-muted-foreground mb-6">
                {isFullAccess ? 'Acesso Completo 30 Dias' : drama.title}
              </p>

              <CreditCardForm
                amount={pendingAmount}
                customerName={customerWhatsApp}
                onSuccess={async () => {
                  setShowCreditCardForm(false);
                  setCardPaymentSuccess(true);
                  toast({ title: "🎉 Pagamento aprovado!", description: "Seu acesso foi liberado!" });
                  
                  // Verificar se usuário está logado
                  const { data: { session } } = await supabase.auth.getSession();
                  
                  setTimeout(() => {
                    if (session?.user) {
                      // Usuário logado - ir direto para meus doramas
                      localStorage.removeItem('pending_purchase');
                      window.location.href = '/meus-doramas';
                    } else {
                      // Usuário não logado - ir para criar conta
                      window.location.href = '/receber-compra';
                    }
                  }, 2000);
                }}
                onCancel={() => {
                  setShowCreditCardForm(false);
                  setShowPaymentSelector(true);
                }}
                createPaymentEndpoint={isFullAccess ? "create-fullaccess-payment" : "create-payment"}
                paymentData={{
                  visitor_id: getOrCreateVisitorId(),
                  ...(isFullAccess ? {} : { dramaId: drama.id }),
                }}
              />
            </div>
          </div>
        </div>
      )}

      {showPixModal && (
        <PixPaymentModal
          isOpen={showPixModal}
          onClose={() => setShowPixModal(false)}
          pixCode={pixCode}
          checkoutUrl={checkoutUrl}
          transactionId={transactionId}
          checkoutSessionId={JSON.parse(localStorage.getItem('pending_purchase') || '{}').checkout_session_id || ''}
          amount={isFullAccess ? 24.90 : drama.price}
          dramaId={isFullAccess ? 'full_access_30_days' : drama.id}
          dramaTitle={isFullAccess ? 'Acesso Completo 30 Dias' : drama.title}
          isUpsell={isFullAccess}
        />
      )}
    </div>
  );
};

export default DramaCheckout;
