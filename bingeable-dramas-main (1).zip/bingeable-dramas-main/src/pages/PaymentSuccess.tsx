import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle, Sparkles, Film } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const PaymentSuccess = () => {
  const navigate = useNavigate();
  const [planStatus, setPlanStatus] = useState<string | null>(null);
  
  useEffect(() => {
    checkPremiumStatus();
  }, []);
  
  const checkPremiumStatus = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    
    const { data } = await supabase
      .from('profiles')
      .select('plan_status')
      .eq('id', user.id)
      .single();
    
    if (data) {
      setPlanStatus(data.plan_status);
    }
  };
  
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
        <title>Pagamento Confirmado | Doramas Super</title>
      </Helmet>

      <Navbar />
      <div className="h-16"></div>
      
      <div className="container mx-auto px-4 py-16">
        <Card className="max-w-2xl mx-auto bg-drama-card border-fire-orange/40 p-8 md:p-12 text-center shadow-[0_0_40px_rgba(255,140,0,0.2)]">
          <div className="mb-6">
            <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center animate-pulse shadow-[0_0_30px_rgba(255,170,0,0.5)]">
              <CheckCircle className="w-16 h-16 text-white" />
            </div>
          </div>
          
          <h1 className="text-3xl md:text-4xl font-display font-black mb-4 bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light bg-clip-text text-transparent">
            Pagamento Confirmado!
          </h1>
          
          <p className="text-lg text-muted-foreground mb-8">
            Sua assinatura Premium está <strong className="text-fire-yellow-intense">ATIVA</strong>! 
            Aproveite todos os Doramas sem limites.
          </p>
          
          <div className="bg-background/50 rounded-xl p-6 mb-8 space-y-3 border border-fire-orange/20">
            <div className="flex items-center gap-3 text-left">
              <Sparkles className="w-5 h-5 text-fire-orange flex-shrink-0" />
              <span className="text-sm">Acesso ilimitado a todo catálogo</span>
            </div>
            <div className="flex items-center gap-3 text-left">
              <Film className="w-5 h-5 text-fire-yellow-intense flex-shrink-0" />
              <span className="text-sm">Sem anúncios ou interrupções</span>
            </div>
            <div className="flex items-center gap-3 text-left">
              <CheckCircle className="w-5 h-5 text-fire-orange flex-shrink-0" />
              <span className="text-sm">Lançamentos exclusivos</span>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => navigate('/')}
              className="bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold transition-all duration-300"
            >
              <Film className="w-5 h-5 mr-2" />
              Ir para os Doramas
            </Button>
            
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate('/perfil')}
              className="border-fire-orange/40 hover:bg-fire-orange/10 transition-all duration-300"
            >
              Ver Meu Perfil
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default PaymentSuccess;
