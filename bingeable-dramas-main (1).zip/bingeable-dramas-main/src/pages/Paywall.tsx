import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles, Crown, Shield, Zap, Infinity, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PixPaymentModal } from "@/components/PixPaymentModal";

const Paywall = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showNameModal, setShowNameModal] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [showPixModal, setShowPixModal] = useState(false);
  const [pixData, setPixData] = useState<{
    checkoutUrl: string;
    pixCode?: string | null;
    transactionId: string;
    checkoutSessionId: string;
  } | null>(null);
  const [finalAmount] = useState(10.00);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (session?.user) {
      setIsAuthenticated(true);
    } else {
      setIsAuthenticated(false);
    }
    
    setLoading(false);
  };

  const handleActivatePlan = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      toast({
        title: "Login necessário",
        description: "Faça login para ativar o plano premium",
      });
      navigate("/auth");
      return;
    }
    
    setIsAuthenticated(true);
    setShowNameModal(true);
  };


  const handleConfirmPayment = async () => {
    if (!customerName.trim()) {
      toast({
        title: "Nome obrigatório",
        description: "Por favor, informe seu nome para continuar",
        variant: "destructive",
      });
      return;
    }

    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      toast({
        title: "Sessão expirada",
        description: "Faça login novamente para continuar com o pagamento.",
        variant: "destructive",
      });
      setShowNameModal(false);
      navigate("/auth");
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('create-payment', {
        body: { 
          customerName: customerName.trim(),
        }
      });

      if (error) {
        const msg = error.message || '';
        
        const isAuthError =
          msg.includes('Unauthorized') ||
          msg.includes('401') ||
          msg.includes('Auth session missing') ||
          msg.includes('session_not_found') ||
          msg.includes('AuthSessionMissingError');

        if (isAuthError) {
          toast({
            title: "Sessão expirada",
            description: "Faça login novamente para continuar.",
            variant: "destructive",
          });
          setShowNameModal(false);
          navigate("/auth");
          return;
        }
        throw error;
      }

      if (data?.success && data?.checkoutUrl) {
        setPixData({
          checkoutUrl: data.checkoutUrl,
          pixCode: data.pixCode,
          transactionId: data.transactionId,
          checkoutSessionId: data.checkout_session_id || '',
        });
        setShowPixModal(true);
        setShowNameModal(false);
      } else {
        throw new Error('Invalid response from payment service');
      }
    } catch (error: any) {
      console.error('Error creating payment:', error);
      toast({
        title: "Erro ao processar pagamento",
        description: error.message || "Não foi possível criar o pagamento. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const benefits = [
    { 
      icon: Infinity, 
      text: "Acesso ilimitado a todos os dramas",
    },
    { 
      icon: Zap, 
      text: "Lançamentos antecipados exclusivos",
    },
    { 
      icon: Shield, 
      text: "Assista sem anúncios ou interrupções",
    },
    { 
      icon: Crown, 
      text: "Suporte prioritário 24/7",
    },
    { 
      icon: Sparkles, 
      text: "Conteúdo exclusivo e especiais",
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
        <title>Plano Premium | Doramas Super</title>
      </Helmet>

      <Navbar />
      
      {/* Espaçador para compensar o navbar fixo */}
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-5xl mx-auto">
          
          {/* Header Section */}
          <div className="text-center mb-8 md:mb-12">
            <Badge className="mb-4 bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white border-none px-4 py-1.5 text-sm font-semibold">
              <Crown className="w-4 h-4 mr-2 inline" />
              PLANO PREMIUM DORAMAS SUPER
            </Badge>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-display font-black mb-3 md:mb-4 text-fire">
              Assista Sem Limites
            </h1>
            
            <p className="text-base md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Desbloqueie todo o catálogo de dramas, sem anúncios e com conteúdo exclusivo
            </p>
          </div>

          {/* Main Pricing Card */}
          <Card className="relative overflow-hidden bg-gradient-to-br from-drama-card to-drama-dark border-2 border-fire-orange/40 shadow-[0_20px_70px_rgba(255,140,0,0.4)] backdrop-blur-sm">
            {/* Decorative gradient overlay */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-fire-orange/30 to-transparent rounded-full blur-3xl"></div>
            
            <div className="relative p-6 sm:p-8 md:p-12">
              
              {/* Price Section */}
              <div className="text-center mb-8 md:mb-10">
                <div className="inline-flex items-baseline justify-center mb-2">
                  <span className="text-muted-foreground text-xl md:text-2xl mr-2">R$</span>
                  <span className="text-6xl sm:text-7xl md:text-8xl font-black text-white tracking-tight">
                    10
                  </span>
                  <span className="text-3xl sm:text-4xl md:text-5xl font-bold text-white">,00</span>
                </div>
                <p className="text-sm md:text-base text-muted-foreground font-medium">
                  <span className="text-fire-orange font-bold">Cancele quando quiser</span>
                </p>
              </div>

              {/* Benefits Grid */}
              <div className="grid gap-4 md:gap-5 mb-8 md:mb-10">
                {benefits.map((benefit, index) => {
                  const IconComponent = benefit.icon;
                  return (
                    <div 
                      key={index} 
                      className="flex items-start gap-4 p-4 rounded-xl bg-background/50 hover:bg-background/70 transition-all duration-300 group"
                    >
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                        <IconComponent className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-foreground font-medium text-sm md:text-base leading-relaxed">
                          {benefit.text}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* CTA Button */}
              <Button
                size="lg"
                className="w-full bg-gradient-to-r from-fire-orange-burnt via-fire-orange to-fire-yellow-intense hover:shadow-[0_15px_50px_rgba(255,170,0,0.6)] text-white font-black text-base md:text-lg py-6 md:py-7 rounded-xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={handleActivatePlan}
                disabled={loading}
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Processando...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <Crown className="w-5 h-5" />
                    Ativar Plano Premium
                  </span>
                )}
              </Button>

              {/* Trust Badges */}
              <div className="flex flex-wrap items-center justify-center gap-4 md:gap-6 mt-6 pt-6 border-t border-white/10">
                <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                  <Shield className="w-4 h-4 text-fire-orange" />
                  <span>Pagamento 100% seguro</span>
                </div>
                <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                  <Zap className="w-4 h-4 text-fire-yellow-intense" />
                  <span>Ativação imediata</span>
                </div>
                <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                  <Infinity className="w-4 h-4 text-fire-orange" />
                  <span>Sem fidelidade</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Payment Methods Placeholder */}
          <div className="mt-8 p-6 rounded-xl bg-background/50 border border-white/10">
            <p className="text-center text-sm text-muted-foreground mb-4 font-medium">
              Formas de pagamento aceitas
            </p>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <div className="px-4 py-2 bg-background rounded-lg border border-white/20 text-xs font-semibold text-muted-foreground">
                PIX
              </div>
              <div className="px-4 py-2 bg-background rounded-lg border border-white/20 text-xs font-semibold text-muted-foreground">
                Cartão de Crédito
              </div>
              <div className="px-4 py-2 bg-background rounded-lg border border-white/20 text-xs font-semibold text-muted-foreground">
                Em breve: Mais opções
              </div>
            </div>
          </div>

          {/* Additional Info */}
          <div className="mt-8 text-center">
            {!isAuthenticated && (
              <p className="text-sm md:text-base text-muted-foreground">
                Já é assinante?{" "}
                <button
                  onClick={() => navigate("/auth")}
                  className="text-fire-orange hover:text-fire-yellow-intense font-semibold hover:underline transition-colors"
                >
                  Faça login aqui
                </button>
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Modal para coletar nome do cliente */}
      <Dialog open={showNameModal} onOpenChange={setShowNameModal}>
        <DialogContent className="sm:max-w-[480px] bg-charcoal-black/95 border-2 border-fire-orange/40 rounded-2xl shadow-[0_20px_60px_rgba(255,106,0,0.3)] backdrop-blur-md">
          <DialogHeader className="space-y-2">
            <DialogTitle className="text-2xl font-black text-white uppercase tracking-wide text-center">
              CONFIRME SEUS DADOS
            </DialogTitle>
            <DialogDescription className="text-muted-foreground text-center text-sm">
              Preencha as informações abaixo para continuar com o pagamento
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-5 py-6">
            {/* Campo Nome Completo */}
            <div className="grid gap-2.5">
              <Label htmlFor="name" className="text-foreground font-semibold text-sm">
                Nome Completo *
              </Label>
              <Input
                id="name"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Digite seu nome completo"
                className="bg-background/50 border-2 border-border focus:border-fire-orange focus:ring-2 focus:ring-fire-orange/20 transition-all duration-200 h-12 text-base rounded-lg"
                autoFocus
              />
              {!customerName.trim() && (
                <p className="text-xs text-muted-foreground">
                  Campo obrigatório para continuar
                </p>
              )}
            </div>
          </div>
          
          <DialogFooter className="gap-3 sm:gap-0">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowNameModal(false)}
              className="border-2 border-border/60 hover:border-border hover:bg-background/50 text-foreground h-11 px-6 rounded-lg transition-all"
            >
              Cancelar
            </Button>
            <Button
              type="button"
              onClick={handleConfirmPayment}
              disabled={!customerName.trim() || loading}
              className="bg-gradient-to-r from-fire-orange-burnt via-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_30px_rgba(255,170,0,0.5)] text-white font-bold h-11 px-6 rounded-lg transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processando...
                </span>
              ) : (
                "Continuar para Pagamento"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de pagamento PIX */}
      {pixData && (
        <PixPaymentModal
          isOpen={showPixModal}
          onClose={() => setShowPixModal(false)}
          checkoutUrl={pixData.checkoutUrl}
          pixCode={pixData.pixCode}
          transactionId={pixData.transactionId}
          checkoutSessionId={pixData.checkoutSessionId}
          amount={finalAmount}
        />
      )}
    </div>
  );
};

export default Paywall;
