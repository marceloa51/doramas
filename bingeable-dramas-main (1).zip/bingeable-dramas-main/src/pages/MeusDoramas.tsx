import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { Play, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface PurchasedDrama {
  id: string;
  title: string;
  slug: string;
  thumbnail_url: string | null;
  cover_url: string | null;
  purchased_at: string;
  duration_seconds: number | null;
  last_position_seconds: number | null;
  progress_percent: number;
}

const formatTime = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}h ${mins}min`;
  }
  return `${mins}min ${secs}s`;
};

const MeusDoramas = () => {
  const navigate = useNavigate();
  const [dramas, setDramas] = useState<PurchasedDrama[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuthAndFetch();
  }, []);

  const checkAuthAndFetch = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
      return;
    }
    fetchPurchasedDramas();
  };

  const fetchPurchasedDramas = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      // Buscar doramas comprados
      const { data: purchases, error } = await supabase
        .from("user_purchases")
        .select(`
          purchased_at,
          dramas:drama_id (
            id,
            title,
            slug,
            thumbnail_url,
            cover_url,
            duration_seconds
          )
        `)
        .eq("user_id", session.user.id)
        .order("purchased_at", { ascending: false });

      if (error) throw error;

      // Buscar progresso de visualização
      const { data: movieViews } = await supabase
        .from("movie_views")
        .select("drama_id, last_position_seconds")
        .eq("user_id", session.user.id);

      const viewsMap = new Map(
        movieViews?.map(v => [v.drama_id, v.last_position_seconds]) || []
      );

      const formattedDramas = purchases?.map((p: any) => {
        const lastPosition = viewsMap.get(p.dramas.id) || 0;
        const duration = p.dramas.duration_seconds || 0;
        const progressPercent = duration > 0 ? Math.min((lastPosition / duration) * 100, 100) : 0;
        
        return {
          ...p.dramas,
          purchased_at: p.purchased_at,
          last_position_seconds: lastPosition,
          progress_percent: progressPercent,
        };
      }) || [];

      setDramas(formattedDramas);
    } catch (error) {
      console.error("Error fetching purchased dramas:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-card rounded w-1/3" />
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-64 bg-card rounded" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Meus Doramas - Doramas Super</title>
      </Helmet>

      <Navbar />
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Meus Doramas</h1>
          <p className="text-muted-foreground">
            {dramas.length > 0
              ? `Você possui ${dramas.length} dorama${dramas.length > 1 ? "s" : ""} comprado${dramas.length > 1 ? "s" : ""}`
              : "Você ainda não comprou nenhum dorama"}
          </p>
        </div>

        {dramas.length === 0 ? (
          <div className="text-center py-16">
            <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-xl font-semibold mb-2">Nenhum dorama comprado</h2>
            <p className="text-muted-foreground mb-6">
              Explore nosso catálogo e comece a assistir!
            </p>
            <Button
              onClick={() => navigate("/explorar")}
              className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_24px_rgba(255,140,0,0.4)] text-white font-bold"
            >
              Explorar Doramas
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {dramas.map((drama) => (
              <div
                key={drama.id}
                onClick={() => navigate(`/movie/${drama.slug}`)}
                className="group cursor-pointer"
              >
                <div className="relative rounded-lg overflow-hidden mb-2 aspect-[2/3]">
                  <img
                    src={drama.thumbnail_url || drama.cover_url || "/placeholder.svg"}
                    alt={drama.title}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-fire-orange flex items-center justify-center">
                      <Play className="w-6 h-6 text-white fill-white" />
                    </div>
                  </div>
                  
                  {/* Barra de progresso */}
                  {drama.last_position_seconds && drama.last_position_seconds > 0 && (
                    <div className="absolute bottom-0 left-0 right-0 p-2">
                      <Progress 
                        value={drama.progress_percent} 
                        className="h-1 bg-gray-700/80" 
                      />
                      <p className="text-[10px] text-white/80 mt-1 text-center">
                        {formatTime(drama.last_position_seconds)} assistido
                      </p>
                    </div>
                  )}
                </div>
                <h3 className="text-sm font-medium line-clamp-2 group-hover:text-fire-orange transition-colors">
                  {drama.title}
                </h3>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MeusDoramas;
