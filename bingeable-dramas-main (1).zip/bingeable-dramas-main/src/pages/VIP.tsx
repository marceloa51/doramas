import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import { VIPDramaCarousel } from "@/components/VIPDramaCarousel";
import { PixPaymentModal } from "@/components/PixPaymentModal";
import { PaymentMethodSelector } from "@/components/PaymentMethodSelector";
import { CreditCardForm } from "@/components/CreditCardPaymentForm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Check,
  Crown,
  Sparkles,
  Shield,
  Zap,
  Clock,
  HeadphonesIcon,
  Loader2,
  Flame,
  CheckCircle2,
} from "lucide-react";
import { getOrCreateVisitorId, savePendingPixModal } from "@/utils/visitorManager";

const VIP_PRICE = 24.90;

const VIP = () => {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showWhatsAppModal, setShowWhatsAppModal] = useState(false);
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [showPixModal, setShowPixModal] = useState(false);
  const [pixData, setPixData] = useState<{
    pixCode: string;
    checkoutUrl: string;
    transactionId: string;
    checkout_session_id: string;
  } | null>(null);

  // Payment method states
  const [showPaymentSelector, setShowPaymentSelector] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit_card'>('credit_card');
  const [showCreditCardForm, setShowCreditCardForm] = useState(false);
  const [cardPaymentSuccess, setCardPaymentSuccess] = useState(false);
  const [customerPhone, setCustomerPhone] = useState<string | null>(null);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setIsAuthenticated(!!session);
    };
    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setIsAuthenticated(!!session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSubscribe = async () => {
    if (!isAuthenticated) {
      setShowWhatsAppModal(true);
      return;
    }
    // Logged in users go directly to payment selector
    setShowPaymentSelector(true);
  };

  const handleWhatsAppSubmit = async () => {
    const cleanNumber = whatsappNumber.replace(/\D/g, "");
    if (cleanNumber.length < 10 || cleanNumber.length > 11) {
      toast.error("Digite um número de WhatsApp válido");
      return;
    }
    setCustomerPhone(whatsappNumber);
    setShowWhatsAppModal(false);
    setShowPaymentSelector(true);
  };

  const handlePaymentMethodConfirm = async () => {
    setShowPaymentSelector(false);
    if (paymentMethod === 'pix') {
      await generatePixPayment();
    } else {
      setShowCreditCardForm(true);
    }
  };

  const generatePixPayment = async () => {
    setLoading(true);
    try {
      const visitorId = getOrCreateVisitorId();
      const { data: { session } } = await supabase.auth.getSession();
      
      const payload: Record<string, unknown> = {
        customerName: customerPhone || "Usuário VIP",
        paymentMethod: "pix",
        visitorId,
      };

      if (session?.user?.id) {
        payload.userId = session.user.id;
      }

      const { data, error } = await supabase.functions.invoke("create-fullaccess-payment", {
        body: payload,
      });

      if (error) throw error;

      if (data?.pixCode) {
        const pixPayload = {
          pixCode: data.pixCode,
          checkoutUrl: data.checkoutUrl,
          transactionId: data.transactionId,
          checkout_session_id: data.checkout_session_id,
        };
        
        setPixData(pixPayload);
        setShowPixModal(true);

        savePendingPixModal({
          ...pixPayload,
          amount: VIP_PRICE,
          dramaTitle: "Plano VIP 30 Dias",
          dramaId: "vip-plan",
          isFullAccess: true,
        });
      }
    } catch (error) {
      console.error("Erro ao gerar pagamento:", error);
      toast.error("Erro ao gerar pagamento. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const handleCreditCardSuccess = () => {
    setShowCreditCardForm(false);
    
    if (isAuthenticated) {
      toast.success("VIP ativado com sucesso!");
      navigate("/meus-doramas");
    } else {
      // Save pending purchase for account creation
      localStorage.setItem('pending_purchase', JSON.stringify({
        dramaTitle: "Plano VIP 30 Dias",
        amount: VIP_PRICE,
        isFullAccess: true,
        purchasedAt: new Date().toISOString(),
      }));
      setCardPaymentSuccess(true);
    }
  };

  const handlePaymentSuccess = () => {
    setShowPixModal(false);
    if (isAuthenticated) {
      navigate("/meus-doramas");
    } else {
      navigate("/receber-compra");
    }
  };

  const benefits = [
    { icon: Crown, text: "Acesso a TODOS os doramas" },
    { icon: Zap, text: "Sem anúncios ou interrupções" },
    { icon: Clock, text: "Lançamentos exclusivos antecipados" },
    { icon: HeadphonesIcon, text: "Suporte prioritário 24/7" },
    { icon: Shield, text: "Cancele quando quiser" },
  ];

  // Card payment success screen
  if (cardPaymentSuccess) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center space-y-6">
            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-12 h-12 text-green-500" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Pagamento Aprovado!</h1>
            <p className="text-muted-foreground">
              Seu Plano VIP foi ativado. Agora crie sua conta para começar a assistir.
            </p>
            <Button
              onClick={() => navigate("/receber-compra")}
              className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
            >
              Criar Minha Conta
            </Button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Plano VIP - Doramas Super | Acesso Ilimitado</title>
        <meta
          name="description"
          content="Assine o Plano VIP do Doramas Super e tenha acesso ilimitado a todos os doramas dublados. Oferta especial por tempo limitado!"
        />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/5">
        <Navbar />

        <main className="container mx-auto px-4 pt-20 pb-12">
          {/* Hero Section */}
          <div className="text-center mb-8 md:mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 rounded-full mb-4 animate-pulse">
              <Flame className="w-4 h-4 text-amber-500" />
              <span className="text-amber-500 font-semibold text-sm">
                OFERTA ESPECIAL POR TEMPO LIMITADO
              </span>
              <Flame className="w-4 h-4 text-amber-500" />
            </div>
            
            <h1 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 bg-clip-text text-transparent">
              Plano VIP
            </h1>
            <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto">
              Desbloqueie todos os doramas e assista sem limites
            </p>
          </div>

          {/* Carousel Section */}
          <div className="mb-10 md:mb-14">
            <h2 className="text-center text-lg md:text-xl font-semibold mb-4 text-muted-foreground">
              Mais de <span className="text-primary">50+ doramas</span> esperando por você
            </h2>
            <VIPDramaCarousel />
          </div>

          {/* Pricing Card */}
          <div className="max-w-md mx-auto">
            <div className="relative bg-gradient-to-br from-card via-card to-primary/5 border-2 border-amber-500/50 rounded-2xl p-6 md:p-8 shadow-2xl shadow-amber-500/10">
              {/* Badge de Economia */}
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                  💰 ECONOMIZE 71%
                </div>
              </div>

              {/* Crown Icon */}
              <div className="flex justify-center mb-4 mt-2">
                <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full">
                  <Crown className="w-8 h-8 text-white" />
                </div>
              </div>

              {/* Title */}
              <h3 className="text-xl md:text-2xl font-bold text-center mb-2">
                Acesso VIP Completo
              </h3>
              <p className="text-muted-foreground text-center text-sm mb-6">
                30 dias de acesso ilimitado
              </p>

              {/* Price */}
              <div className="text-center mb-6">
                <div className="flex items-center justify-center gap-3 mb-2">
                  <span className="text-2xl text-muted-foreground line-through">
                    R$ 69,90
                  </span>
                  <Sparkles className="w-5 h-5 text-amber-500" />
                </div>
                <div className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">
                  R$ 24,90
                </div>
                <p className="text-muted-foreground text-sm mt-1">
                  pagamento único
                </p>
              </div>

              {/* Benefits */}
              <ul className="space-y-3 mb-8">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-green-500/20 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-green-500" />
                    </div>
                    <span className="text-foreground">{benefit.text}</span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <Button
                onClick={handleSubscribe}
                disabled={loading}
                className="w-full h-14 text-lg font-bold bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-600 hover:via-orange-600 hover:to-red-600 text-white shadow-lg shadow-orange-500/30 transition-all duration-300 hover:scale-[1.02]"
              >
                {loading ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <>
                    <Flame className="w-5 h-5 mr-2" />
                    APROVEITAR OFERTA AGORA
                  </>
                )}
              </Button>

              {/* Trust Badges */}
              <div className="flex items-center justify-center gap-4 mt-6 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Shield className="w-4 h-4 text-green-500" />
                  <span>Pagamento Seguro</span>
                </div>
                <div className="flex items-center gap-1">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <span>Ativação Imediata</span>
                </div>
              </div>
            </div>

            {/* Login Link */}
            <p className="text-center text-muted-foreground text-sm mt-6">
              Já tem uma conta?{" "}
              <button
                onClick={() => navigate("/auth")}
                className="text-primary hover:underline font-medium"
              >
                Faça login aqui
              </button>
            </p>
          </div>
        </main>
      </div>

      {/* WhatsApp Modal */}
      <Dialog open={showWhatsAppModal} onOpenChange={setShowWhatsAppModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              Quase lá!
            </DialogTitle>
            <DialogDescription>
              Informe seu WhatsApp para receber os dados de acesso após o pagamento
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <Input
              type="tel"
              placeholder="(11) 99999-9999"
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value)}
              className="h-12 text-lg"
            />
            <Button
              onClick={handleWhatsAppSubmit}
              disabled={loading}
              className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                "Continuar para Pagamento"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Method Selector Modal */}
      <Dialog open={showPaymentSelector} onOpenChange={setShowPaymentSelector}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              Escolha a forma de pagamento
            </DialogTitle>
            <DialogDescription>
              Plano VIP 30 Dias - R$ {VIP_PRICE.toFixed(2).replace('.', ',')}
            </DialogDescription>
          </DialogHeader>
          <div className="pt-4 space-y-4">
            <PaymentMethodSelector
              selectedMethod={paymentMethod}
              onSelect={setPaymentMethod}
            />
            <Button
              onClick={handlePaymentMethodConfirm}
              disabled={loading}
              className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                "Continuar"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Credit Card Form Modal */}
      <Dialog open={showCreditCardForm} onOpenChange={setShowCreditCardForm}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              Pagamento com Cartão
            </DialogTitle>
            <DialogDescription>
              Plano VIP 30 Dias - R$ {VIP_PRICE.toFixed(2).replace('.', ',')}
            </DialogDescription>
          </DialogHeader>
          <CreditCardForm
            amount={VIP_PRICE}
            onSuccess={handleCreditCardSuccess}
            onCancel={() => setShowCreditCardForm(false)}
            customerName={customerPhone || "Usuário VIP"}
            createPaymentEndpoint="create-fullaccess-payment"
            paymentData={{
              visitorId: getOrCreateVisitorId(),
              isFullAccess: true,
            }}
          />
        </DialogContent>
      </Dialog>

      {/* PIX Payment Modal */}
      {showPixModal && pixData && (
        <PixPaymentModal
          isOpen={showPixModal}
          onClose={() => setShowPixModal(false)}
          pixCode={pixData.pixCode}
          checkoutUrl={pixData.checkoutUrl}
          transactionId={pixData.transactionId}
          checkoutSessionId={pixData.checkout_session_id}
          amount={VIP_PRICE}
          dramaTitle="Plano VIP 30 Dias"
        />
      )}
    </>
  );
};

export default VIP;
