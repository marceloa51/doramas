import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Check, X } from "lucide-react";
import { PixPaymentModal } from "@/components/PixPaymentModal";
import { usePurchases } from "@/hooks/usePurchases";

interface Drama {
  id: string;
  title: string;
  slug: string;
  thumbnail_url: string | null;
  cover_url: string | null;
  price: number;
}

const UpsellOffer = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { hasPurchased } = usePurchases();
  
  const originalPurchaseId = location.state?.originalPurchaseId;
  const purchasedDramaId = location.state?.purchasedDramaId;

  const [dramas, setDramas] = useState<Drama[]>([]);
  const [selectedDramas, setSelectedDramas] = useState<string[]>([]);
  const [customerName, setCustomerName] = useState("");
  const [loading, setLoading] = useState(true);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [showPixModal, setShowPixModal] = useState(false);
  const [pixCode, setPixCode] = useState("");
  const [checkoutUrl, setCheckoutUrl] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [checkoutSessionId, setCheckoutSessionId] = useState("");

  useEffect(() => {
    fetchAvailableDramas();
  }, []);

  const fetchAvailableDramas = async () => {
    try {
      const { data, error } = await supabase
        .from("dramas")
        .select("*")
        .eq("status", "active")
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Filtrar doramas já comprados
      const available = data?.filter((d) => !hasPurchased(d.id) && d.id !== purchasedDramaId) || [];
      setDramas(available);
    } catch (error) {
      console.error("Error fetching dramas:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleDramaSelection = (dramaId: string) => {
    setSelectedDramas((prev) => {
      if (prev.includes(dramaId)) {
        return prev.filter((id) => id !== dramaId);
      }
      if (prev.length >= 2) {
        toast({
          title: "Limite atingido",
          description: "Você pode escolher no máximo 2 doramas",
        });
        return prev;
      }
      return [...prev, dramaId];
    });
  };

  const handleAcceptUpsell = async () => {
    if (selectedDramas.length !== 2) {
      toast({
        title: "Selecione 2 doramas",
        description: "Escolha exatamente 2 doramas para continuar",
        variant: "destructive",
      });
      return;
    }

    if (!customerName.trim()) {
      toast({
        title: "Nome obrigatório",
        description: "Informe seu nome para continuar",
        variant: "destructive",
      });
      return;
    }

    setProcessingPayment(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }

      const { data, error } = await supabase.functions.invoke("create-upsell-payment", {
        body: {
          customerName: customerName.trim(),
          dramaIds: selectedDramas,
          originalPurchaseId,
        },
      });

      if (error) throw error;

      if (data?.success) {
        setPixCode(data.pixCode || "");
        setCheckoutUrl(data.checkoutUrl || "");
        setTransactionId(data.transactionId || "");
        setCheckoutSessionId(data.checkout_session_id || "");
        setShowPixModal(true);
      } else {
        throw new Error(data?.error || "Erro ao processar upsell");
      }
    } catch (error: any) {
      console.error("Upsell error:", error);
      toast({
        title: "Erro no pagamento",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    } finally {
      setProcessingPayment(false);
    }
  };

  const handleDecline = () => {
    navigate("/meus-doramas");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-card rounded w-1/2 mx-auto" />
            <div className="h-96 bg-card rounded" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Oferta Especial - Doramas Super</title>
      </Helmet>

      <Navbar />
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-6 sm:mb-8 space-y-3">
            <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-fire-orange/20 rounded-full mb-3 sm:mb-4 animate-pulse">
              <Sparkles className="w-7 h-7 sm:w-8 sm:h-8 text-fire-orange" />
            </div>
            <h1 className="text-2xl sm:text-4xl font-bold mb-2 sm:mb-3 text-fire-yellow-bright px-2">
              🔥 OFERTA POR TEMPO LIMITADO!
            </h1>
            <p className="text-base sm:text-xl mb-2 px-3">
              Leve <span className="text-fire-yellow-intense font-bold">+2 doramas</span> por apenas{" "}
              <span className="text-fire-orange font-bold text-xl sm:text-2xl">R$ 16,00</span> no total!
            </p>
            <div className="inline-block bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white px-4 sm:px-6 py-2 sm:py-3 rounded-full text-sm sm:text-base md:text-lg font-bold shadow-lg">
              💰 ECONOMIA DE R$ 5,00
            </div>
          </div>

          {/* Drama Selection */}
          <div className="bg-card rounded-lg p-6 mb-6 border border-border">
            <h2 className="text-xl font-semibold mb-4">
              Escolha 2 doramas ({selectedDramas.length}/2)
            </h2>

            {dramas.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Nenhum dorama disponível no momento
              </p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
                {dramas.map((drama) => (
                  <div
                    key={drama.id}
                    onClick={() => toggleDramaSelection(drama.id)}
                    className={`
                      relative cursor-pointer rounded-lg overflow-hidden border-2 transition-all transform hover:scale-105
                      ${
                        selectedDramas.includes(drama.id)
                          ? "border-fire-orange shadow-[0_4px_20px_rgba(255,140,0,0.5)] scale-105"
                          : "border-transparent hover:border-fire-orange/50"
                      }
                    `}
                  >
                    <img
                      src={drama.thumbnail_url || drama.cover_url || "/placeholder.svg"}
                      alt={drama.title}
                      className="w-full aspect-[2/3] object-cover"
                    />
                    {selectedDramas.includes(drama.id) && (
                      <div className="absolute inset-0 bg-fire-orange/30 flex items-center justify-center">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-fire-orange flex items-center justify-center shadow-lg">
                          <Check className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-2">
                      <p className="text-white text-xs sm:text-sm font-medium line-clamp-2">
                        {drama.title}
                      </p>
                      {selectedDramas.includes(drama.id) && (
                        <p className="text-xs text-fire-yellow-bright font-bold mt-0.5">✓ Selecionado</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Customer Name */}
          {selectedDramas.length === 2 && (
            <div className="bg-card rounded-lg p-6 mb-6 border border-border">
              <label className="block text-sm font-medium mb-2">
                Nome completo *
              </label>
              <Input
                type="text"
                placeholder="Seu nome completo"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-col gap-3 max-w-2xl mx-auto">
            <Button
              onClick={handleAcceptUpsell}
              disabled={selectedDramas.length !== 2 || !customerName.trim() || processingPayment}
              className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_40px_rgba(255,140,0,0.7)] hover:scale-[1.02] text-white font-bold py-6 text-base sm:text-lg transition-all duration-300 min-h-[44px] shadow-lg"
            >
              {processingPayment ? "Preparando..." : "Quero os 3 Doramas por R$ 16,00"}
            </Button>

            <Button
              onClick={handleDecline}
              variant="ghost"
              className="py-3 text-sm text-muted-foreground hover:text-foreground"
            >
              Talvez depois
            </Button>
          </div>
        </div>
      </div>

      {showPixModal && (
        <PixPaymentModal
          isOpen={showPixModal}
          onClose={() => setShowPixModal(false)}
          pixCode={pixCode}
          checkoutUrl={checkoutUrl}
          transactionId={transactionId}
          checkoutSessionId={checkoutSessionId}
          amount={16.0}
          isUpsell={true}
        />
      )}
    </div>
  );
};

export default UpsellOffer;
