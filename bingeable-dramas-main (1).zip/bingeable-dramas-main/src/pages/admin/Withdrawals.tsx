import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { CheckCircle, XCircle, Clock, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

interface WithdrawalRequest {
  id: string;
  user_id: string;
  amount: number;
  pix_key: string;
  full_name: string;
  phone: string;
  status: string;
  admin_note: string | null;
  created_at: string;
  processed_at: string | null;
  user_profile: {
    email: string;
    full_name: string;
    referral_count: number;
  };
}

export default function Withdrawals() {
  const navigate = useNavigate();
  const [requests, setRequests] = useState<WithdrawalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRequest, setSelectedRequest] = useState<WithdrawalRequest | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [adminNote, setAdminNote] = useState("");
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    checkAdminAccess();
    fetchRequests();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin")
      .single();

    if (!roles) {
      toast.error("Acesso negado");
      navigate("/");
    }
  };

  const fetchRequests = async () => {
    try {
      const { data, error } = await supabase
        .from("withdrawal_requests")
        .select(`
          *,
          user_profile:profiles!user_id (
            email,
            full_name,
            referral_count
          )
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setRequests(data || []);
    } catch (error) {
      console.error("Error fetching requests:", error);
      toast.error("Erro ao carregar solicitações");
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!selectedRequest) return;

    setProcessing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();

      // Update request status
      const { error: updateError } = await supabase
        .from("withdrawal_requests")
        .update({
          status: "APPROVED",
          admin_id: user?.id,
          admin_note: adminNote || null,
          processed_at: new Date().toISOString()
        })
        .eq("id", selectedRequest.id);

      if (updateError) throw updateError;

      // Create transaction record
      await supabase
        .from("wallet_transactions")
        .insert({
          user_id: selectedRequest.user_id,
          type: "WITHDRAWAL_APPROVED",
          amount: 0,
          description: "Saque aprovado pelo admin."
        });

      // Update wallet total_withdrawn
      const { data: wallet } = await supabase
        .from("wallets")
        .select("total_withdrawn")
        .eq("user_id", selectedRequest.user_id)
        .single();

      if (wallet) {
        await supabase
          .from("wallets")
          .update({
            total_withdrawn: Number(wallet.total_withdrawn) + selectedRequest.amount,
            updated_at: new Date().toISOString()
          })
          .eq("user_id", selectedRequest.user_id);
      }

      toast.success("Saque aprovado! Lembre-se de fazer o Pix manualmente.");
      setShowDetailsModal(false);
      setAdminNote("");
      fetchRequests();
    } catch (error) {
      console.error("Error approving withdrawal:", error);
      toast.error("Erro ao aprovar saque");
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!selectedRequest || !adminNote) {
      toast.error("Informe o motivo da reprovação");
      return;
    }

    setProcessing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();

      // Update request status
      const { error: updateError } = await supabase
        .from("withdrawal_requests")
        .update({
          status: "REJECTED",
          admin_id: user?.id,
          admin_note: adminNote,
          processed_at: new Date().toISOString()
        })
        .eq("id", selectedRequest.id);

      if (updateError) throw updateError;

      // Return balance to wallet
      const { data: wallet } = await supabase
        .from("wallets")
        .select("available_balance")
        .eq("user_id", selectedRequest.user_id)
        .single();

      if (wallet) {
        await supabase
          .from("wallets")
          .update({
            available_balance: Number(wallet.available_balance) + selectedRequest.amount,
            updated_at: new Date().toISOString()
          })
          .eq("user_id", selectedRequest.user_id);
      }

      // Create transaction record
      await supabase
        .from("wallet_transactions")
        .insert({
          user_id: selectedRequest.user_id,
          type: "WITHDRAWAL_REJECTED",
          amount: selectedRequest.amount,
          description: `Saque recusado. Motivo: ${adminNote}`
        });

      toast.success("Saque recusado e valor devolvido à carteira.");
      setShowDetailsModal(false);
      setAdminNote("");
      fetchRequests();
    } catch (error) {
      console.error("Error rejecting withdrawal:", error);
      toast.error("Erro ao recusar saque");
    } finally {
      setProcessing(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: any; icon: any; label: string }> = {
      PENDING: { variant: "secondary", icon: Clock, label: "Pendente" },
      APPROVED: { variant: "default", icon: CheckCircle, label: "Aprovado" },
      REJECTED: { variant: "destructive", icon: XCircle, label: "Recusado" }
    };

    const config = variants[status] || variants.PENDING;
    const Icon = config.icon;

    return (
      <Badge variant={config.variant} className="gap-1">
        <Icon className="h-3 w-3" />
        {config.label}
      </Badge>
    );
  };

  const pendingCount = requests.filter(r => r.status === "PENDING").length;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Saques de Afiliados</h1>
            <p className="text-muted-foreground">
              {pendingCount > 0 ? `${pendingCount} solicitações pendentes` : "Nenhuma solicitação pendente"}
            </p>
          </div>
          <Button variant="outline" onClick={() => navigate("/admin/dashboard")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar ao Dashboard
          </Button>
        </div>

        {/* Pending Requests */}
        {pendingCount > 0 && (
          <Card className="border-yellow-500/20">
            <CardHeader>
              <CardTitle className="text-yellow-500">⏳ Solicitações Pendentes</CardTitle>
              <CardDescription>Requerem sua atenção imediata</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {requests
                  .filter(r => r.status === "PENDING")
                  .map((request) => (
                    <div
                      key={request.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-yellow-500/20 bg-yellow-500/5"
                    >
                      <div className="space-y-1">
                        <p className="font-semibold">{request.user_profile?.email}</p>
                        <p className="text-sm text-muted-foreground">
                          R$ {request.amount.toFixed(2)} • {new Date(request.created_at).toLocaleDateString("pt-BR")}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {request.user_profile?.referral_count || 0} indicações
                        </p>
                      </div>
                      <Button
                        onClick={() => {
                          setSelectedRequest(request);
                          setShowDetailsModal(true);
                        }}
                      >
                        Ver Detalhes
                      </Button>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* All Requests */}
        <Card>
          <CardHeader>
            <CardTitle>Histórico Completo</CardTitle>
            <CardDescription>Todas as solicitações de saque</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {requests.map((request) => (
                <div
                  key={request.id}
                  className="flex items-center justify-between p-4 rounded-lg border border-border/50 hover:border-[#FF6A00]/30 transition-colors"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold">{request.user_profile?.email}</p>
                      {getStatusBadge(request.status)}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      R$ {request.amount.toFixed(2)} • {new Date(request.created_at).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedRequest(request);
                      setShowDetailsModal(true);
                    }}
                  >
                    Detalhes
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Details Modal */}
      <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Solicitação</DialogTitle>
            <DialogDescription>Informações completas e ações disponíveis</DialogDescription>
          </DialogHeader>

          {selectedRequest && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">E-mail</Label>
                  <p className="font-medium">{selectedRequest.user_profile?.email}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Nome Completo</Label>
                  <p className="font-medium">{selectedRequest.full_name}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Valor</Label>
                  <p className="font-medium text-[#FFC93C]">R$ {selectedRequest.amount.toFixed(2)}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Chave Pix</Label>
                  <p className="font-medium">{selectedRequest.pix_key}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Telefone</Label>
                  <p className="font-medium">{selectedRequest.phone}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Indicações</Label>
                  <p className="font-medium">{selectedRequest.user_profile?.referral_count || 0}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Data Solicitação</Label>
                  <p className="font-medium">
                    {new Date(selectedRequest.created_at).toLocaleDateString("pt-BR", {
                      day: "2-digit",
                      month: "2-digit",
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit"
                    })}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Status</Label>
                  <div className="mt-1">{getStatusBadge(selectedRequest.status)}</div>
                </div>
              </div>

              {selectedRequest.status === "PENDING" && (
                <div className="space-y-2">
                  <Label htmlFor="note">Observação (opcional para aprovar, obrigatória para recusar)</Label>
                  <Textarea
                    id="note"
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    placeholder="Adicione uma observação sobre esta solicitação..."
                    rows={3}
                  />
                </div>
              )}

              {selectedRequest.admin_note && (
                <div className="space-y-2">
                  <Label>Observação do Admin</Label>
                  <p className="text-sm text-muted-foreground p-3 bg-muted rounded-lg">
                    {selectedRequest.admin_note}
                  </p>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="gap-2">
            {selectedRequest?.status === "PENDING" ? (
              <>
                <Button
                  variant="destructive"
                  onClick={handleReject}
                  disabled={processing}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Recusar
                </Button>
                <Button
                  onClick={handleApprove}
                  disabled={processing}
                  className="bg-gradient-to-r from-[#FF6A00] via-[#FFC93C] to-[#FFE066] text-white"
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Aprovar
                </Button>
              </>
            ) : (
              <Button variant="outline" onClick={() => setShowDetailsModal(false)}>
                Fechar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
