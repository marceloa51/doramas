import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, CreditCard, CheckCircle, Clock, DollarSign, TrendingUp } from "lucide-react";
import Navbar from "@/components/Navbar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface CheckoutSession {
  id: string;
  customer_name: string | null;
  amount: number;
  status: string;
  items: any;
  created_at: string;
  paid_at: string | null;
}

const ManagePayments = () => {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<CheckoutSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [periodFilter, setPeriodFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  // Stats
  const [stats, setStats] = useState({
    totalGenerated: 0,
    totalPaid: 0,
    totalAmount: 0,
    conversionRate: 0,
  });

  useEffect(() => {
    checkAdminAccess();
    fetchSessions();
  }, [statusFilter, periodFilter]);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      navigate("/");
    }
  };

  const fetchSessions = async () => {
    try {
      setLoading(true);

      // Build query
      let query = supabase
        .from("checkout_sessions")
        .select("*")
        .order("created_at", { ascending: false });

      // Apply status filter
      if (statusFilter !== "all") {
        query = query.eq("status", statusFilter);
      }

      // Apply period filter
      if (periodFilter !== "all") {
        const now = new Date();
        let startDate = new Date();

        switch (periodFilter) {
          case "today":
            startDate.setHours(0, 0, 0, 0);
            break;
          case "week":
            startDate.setDate(now.getDate() - 7);
            break;
          case "month":
            startDate.setMonth(now.getMonth() - 1);
            break;
        }

        if (periodFilter !== "all") {
          query = query.gte("created_at", startDate.toISOString());
        }
      }

      const { data, error } = await query;

      if (error) throw error;

      setSessions(data || []);

      // Calculate stats
      const allSessions = data || [];
      const paidSessions = allSessions.filter((s) => s.status === "paid");
      const totalAmount = paidSessions.reduce((sum, s) => sum + s.amount, 0);
      const conversionRate =
        allSessions.length > 0
          ? (paidSessions.length / allSessions.length) * 100
          : 0;

      setStats({
        totalGenerated: allSessions.length,
        totalPaid: paidSessions.length,
        totalAmount,
        conversionRate,
      });
    } catch (error) {
      console.error("Error fetching sessions:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getDramaCount = (items: any) => {
    try {
      const itemsArray = Array.isArray(items) ? items : JSON.parse(items);
      return itemsArray.length;
    } catch {
      return 0;
    }
  };

  // Pagination
  const totalPages = Math.ceil(sessions.length / itemsPerPage);
  const paginatedSessions = sessions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => navigate("/admin")}
              className="border-border hover:bg-accent"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <h1 className="text-3xl font-bold">💳 Pagamentos PIX</h1>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">PIX Gerados</p>
                <p className="text-3xl font-bold mt-2">{stats.totalGenerated}</p>
              </div>
              <CreditCard className="w-12 h-12 text-[#FF6A00] opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-card border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">PIX Pagos</p>
                <p className="text-3xl font-bold mt-2 text-green-500">
                  {stats.totalPaid}
                </p>
              </div>
              <CheckCircle className="w-12 h-12 text-green-500 opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-card border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Valor Total</p>
                <p className="text-2xl font-bold mt-2">
                  {formatCurrency(stats.totalAmount)}
                </p>
              </div>
              <DollarSign className="w-12 h-12 text-[#FFC93C] opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-card border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Taxa de Conversão</p>
                <p className="text-3xl font-bold mt-2">
                  {stats.conversionRate.toFixed(1)}%
                </p>
              </div>
              <TrendingUp className="w-12 h-12 text-[#FF6A00] opacity-80" />
            </div>
          </Card>
        </div>

        {/* Filters */}
        <Card className="p-4 mb-6 bg-card border-border">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="text-sm text-muted-foreground mb-2 block">
                Status
              </label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="pending">Pendentes</SelectItem>
                  <SelectItem value="paid">Pagos</SelectItem>
                  <SelectItem value="expired">Expirados</SelectItem>
                  <SelectItem value="canceled">Cancelados</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1">
              <label className="text-sm text-muted-foreground mb-2 block">
                Período
              </label>
              <Select value={periodFilter} onValueChange={setPeriodFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="today">Hoje</SelectItem>
                  <SelectItem value="week">Última Semana</SelectItem>
                  <SelectItem value="month">Último Mês</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Table */}
        <Card className="bg-card border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Doramas</TableHead>
                <TableHead>Criado em</TableHead>
                <TableHead>Pago em</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    Carregando...
                  </TableCell>
                </TableRow>
              ) : paginatedSessions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    Nenhum pagamento encontrado
                  </TableCell>
                </TableRow>
              ) : (
                paginatedSessions.map((session) => (
                  <TableRow key={session.id}>
                    <TableCell className="font-medium">
                      {session.customer_name || "N/A"}
                    </TableCell>
                    <TableCell className="font-bold text-[#FF6A00]">
                      {formatCurrency(session.amount)}
                    </TableCell>
                    <TableCell>
                      {session.status === "paid" ? (
                        <Badge className="bg-green-500/20 text-green-500 border-green-500/30">
                          ✅ Pago
                        </Badge>
                      ) : session.status === "pending" ? (
                        <Badge className="bg-[#FF6A00]/20 text-[#FF6A00] border-[#FF6A00]/30">
                          <Clock className="w-3 h-3 mr-1" />
                          Pendente
                        </Badge>
                      ) : session.status === "expired" ? (
                        <Badge variant="outline" className="text-muted-foreground">
                          Expirado
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-muted-foreground">
                          Cancelado
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>{getDramaCount(session.items)} dorama(s)</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDate(session.created_at)}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {session.paid_at ? formatDate(session.paid_at) : "-"}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center gap-2 mt-6">
            <Button
              variant="outline"
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
            >
              Anterior
            </Button>
            <span className="text-sm text-muted-foreground">
              Página {currentPage} de {totalPages}
            </span>
            <Button
              variant="outline"
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
            >
              Próxima
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManagePayments;
