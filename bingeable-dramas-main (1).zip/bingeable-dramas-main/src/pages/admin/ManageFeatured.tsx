import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus, X, GripVertical, Sparkles } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Drama {
  id: string;
  title: string;
  thumbnail_url: string;
  slug: string;
}

interface FeaturedDrama {
  id: string;
  drama_id: string;
  section: string;
  position: number;
  drama?: Drama;
}

const ManageFeatured = () => {
  const [featuredDramas, setFeaturedDramas] = useState<FeaturedDrama[]>([]);
  const [allDramas, setAllDramas] = useState<Drama[]>([]);
  const [selectedDramaId, setSelectedDramaId] = useState<string>("");
  const [currentHero, setCurrentHero] = useState<Drama | null>(null);
  const [selectedHeroId, setSelectedHeroId] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    checkAdminAccess();
    fetchData();
    fetchHero();
  }, []);

  const checkAdminAccess = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      toast({
        title: "Acesso negado",
        description: "Apenas administradores podem acessar esta página.",
        variant: "destructive",
      });
      navigate("/");
    }
  };

  const fetchData = async () => {
    try {
      const [featuredRes, dramasRes] = await Promise.all([
        supabase
          .from("featured_dramas")
          .select(`
            *,
            drama:dramas(id, title, thumbnail_url, slug)
          `)
          .eq("section", "top_all_time")
          .order("position", { ascending: true }),
        supabase
          .from("dramas")
          .select("id, title, thumbnail_url, slug")
          .eq("status", "active")
          .order("title", { ascending: true }),
      ]);

      if (featuredRes.data) {
        const mapped = featuredRes.data.map((item) => ({
          ...item,
          drama: Array.isArray(item.drama) ? item.drama[0] : item.drama,
        }));
        setFeaturedDramas(mapped as FeaturedDrama[]);
      }

      if (dramasRes.data) {
        setAllDramas(dramasRes.data);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const addFeaturedDrama = async () => {
    if (!selectedDramaId) {
      toast({
        title: "Atenção",
        description: "Selecione um dorama para adicionar.",
        variant: "destructive",
      });
      return;
    }

    try {
      const maxPosition = featuredDramas.length > 0
        ? Math.max(...featuredDramas.map((f) => f.position))
        : -1;

      const { error } = await supabase.from("featured_dramas").insert({
        drama_id: selectedDramaId,
        section: "top_all_time",
        position: maxPosition + 1,
      });

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Dorama adicionado aos destaques!",
      });

      setSelectedDramaId("");
      fetchData();
    } catch (error: any) {
      console.error("Error adding featured drama:", error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível adicionar o dorama.",
        variant: "destructive",
      });
    }
  };

  const removeFeaturedDrama = async (id: string) => {
    try {
      const { error } = await supabase
        .from("featured_dramas")
        .delete()
        .eq("id", id);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Dorama removido dos destaques!",
      });

      fetchData();
    } catch (error: any) {
      console.error("Error removing featured drama:", error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível remover o dorama.",
        variant: "destructive",
      });
    }
  };

  const moveUp = async (item: FeaturedDrama, index: number) => {
    if (index === 0) return;

    const prev = featuredDramas[index - 1];
    
    try {
      await Promise.all([
        supabase
          .from("featured_dramas")
          .update({ position: prev.position })
          .eq("id", item.id),
        supabase
          .from("featured_dramas")
          .update({ position: item.position })
          .eq("id", prev.id),
      ]);

      fetchData();
    } catch (error) {
      console.error("Error reordering:", error);
    }
  };

  const moveDown = async (item: FeaturedDrama, index: number) => {
    if (index === featuredDramas.length - 1) return;

    const next = featuredDramas[index + 1];
    
    try {
      await Promise.all([
        supabase
          .from("featured_dramas")
          .update({ position: next.position })
          .eq("id", item.id),
        supabase
          .from("featured_dramas")
          .update({ position: item.position })
          .eq("id", next.id),
      ]);

      fetchData();
    } catch (error) {
      console.error("Error reordering:", error);
    }
  };

  const fetchHero = async () => {
    try {
      const { data } = await supabase
        .from("featured_dramas")
        .select(`drama:dramas(*)`)
        .eq("section", "hero")
        .maybeSingle();
      
      if (data?.drama) {
        const drama = Array.isArray(data.drama) ? data.drama[0] : data.drama;
        setCurrentHero(drama as Drama);
      } else {
        setCurrentHero(null);
      }
    } catch (error) {
      console.error("Error fetching hero:", error);
    }
  };

  const setNewHero = async () => {
    if (!selectedHeroId) {
      toast({
        title: "Atenção",
        description: "Selecione um dorama",
        variant: "destructive"
      });
      return;
    }

    try {
      // Remove o hero antigo (se existir)
      await supabase
        .from("featured_dramas")
        .delete()
        .eq("section", "hero");

      // Insere o novo hero
      const { error } = await supabase
        .from("featured_dramas")
        .insert({
          drama_id: selectedHeroId,
          section: "hero",
          position: 0
        });

      if (error) throw error;

      toast({
        title: "✅ Sucesso",
        description: "Dorama em destaque atualizado!"
      });

      setSelectedHeroId("");
      fetchHero();
    } catch (error: any) {
      console.error("Error setting hero:", error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível atualizar o destaque",
        variant: "destructive"
      });
    }
  };

  const removeHero = async () => {
    try {
      await supabase
        .from("featured_dramas")
        .delete()
        .eq("section", "hero");

      toast({
        title: "Removido",
        description: "Sistema voltará a usar o dorama mais recente"
      });

      setCurrentHero(null);
    } catch (error) {
      console.error("Error removing hero:", error);
      toast({
        title: "Erro",
        description: "Não foi possível remover o destaque",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-drama-card rounded w-1/3" />
            <div className="h-40 bg-drama-card rounded" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/admin")}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Gerenciar Destaques</h1>
            <p className="text-muted-foreground">
              Configure os doramas em destaque na home
            </p>
          </div>
        </div>

        <Card className="p-6 mb-6 bg-drama-card border-fire-orange/20">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-fire-yellow-intense" />
            Dorama em Destaque Principal (Hero)
          </h2>
          <p className="text-sm text-muted-foreground mb-4">
            Este dorama aparecerá no banner grande da página inicial
          </p>

          {currentHero ? (
            <div className="flex items-center gap-4 p-4 bg-background rounded-lg border border-fire-orange mb-4">
              <img 
                src={currentHero.thumbnail_url || "/placeholder.svg"} 
                alt={currentHero.title}
                className="w-20 h-28 object-cover rounded" 
              />
              <div className="flex-1">
                <h3 className="font-semibold text-lg">{currentHero.title}</h3>
                <span className="text-sm text-fire-yellow-intense flex items-center gap-1 mt-1">
                  <Sparkles className="w-3 h-3" />
                  Destaque Atual
                </span>
              </div>
              <Button 
                onClick={removeHero} 
                variant="destructive"
                size="sm"
              >
                <X className="w-4 h-4 mr-2" />
                Remover
              </Button>
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-4 mb-4 bg-background rounded-lg">
              Nenhum dorama configurado. Sistema usando o mais recente.
            </p>
          )}

          <div className="flex gap-4">
            <Select value={selectedHeroId} onValueChange={setSelectedHeroId}>
              <SelectTrigger className="flex-1 bg-background border-drama-border">
                <SelectValue placeholder="Escolher novo dorama em destaque" />
              </SelectTrigger>
              <SelectContent>
                {allDramas.map((drama) => (
                  <SelectItem key={drama.id} value={drama.id}>
                    {drama.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              onClick={setNewHero}
              className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_24px_rgba(255,140,0,0.4)] text-white font-bold"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Definir como Destaque
            </Button>
          </div>
        </Card>

        <Card className="p-6 mb-6 bg-drama-card border-drama-border">
          <h2 className="text-xl font-bold mb-4">Adicionar aos Mais Assistidos</h2>
          <div className="flex gap-4">
            <Select value={selectedDramaId} onValueChange={setSelectedDramaId}>
              <SelectTrigger className="flex-1 bg-background border-drama-border">
                <SelectValue placeholder="Selecione um dorama" />
              </SelectTrigger>
              <SelectContent>
                {allDramas
                  .filter(
                    (d) =>
                      !featuredDramas.some((f) => f.drama_id === d.id)
                  )
                  .map((drama) => (
                    <SelectItem key={drama.id} value={drama.id}>
                      {drama.title}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <Button
              onClick={addFeaturedDrama}
              className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_24px_rgba(255,140,0,0.4)] text-white font-bold"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar
            </Button>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            Máximo de 5 doramas em destaque
          </p>
        </Card>

        <Card className="p-6 bg-drama-card border-drama-border">
          <h2 className="text-xl font-bold mb-4">
            Doramas em Destaque ({featuredDramas.length}/5)
          </h2>

          {featuredDramas.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>Nenhum dorama em destaque configurado.</p>
              <p className="text-sm mt-2">
                Quando vazio, o sistema usa os mais assistidos automaticamente.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {featuredDramas.map((item, index) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 p-4 bg-background rounded-lg border border-drama-border"
                >
                  <div className="flex flex-col gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => moveUp(item, index)}
                      disabled={index === 0}
                      className="h-6 w-6"
                    >
                      <GripVertical className="w-4 h-4" />
                    </Button>
                    <span className="text-xs text-center text-muted-foreground">
                      #{index + 1}
                    </span>
                  </div>

                  <img
                    src={item.drama?.thumbnail_url || "/placeholder.svg"}
                    alt={item.drama?.title}
                    className="w-16 h-24 object-cover rounded"
                  />

                  <div className="flex-1">
                    <h3 className="font-semibold">{item.drama?.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      Posição: {index + 1}
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => moveUp(item, index)}
                      disabled={index === 0}
                    >
                      ↑
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => moveDown(item, index)}
                      disabled={index === featuredDramas.length - 1}
                    >
                      ↓
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeFeaturedDrama(item.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default ManageFeatured;
