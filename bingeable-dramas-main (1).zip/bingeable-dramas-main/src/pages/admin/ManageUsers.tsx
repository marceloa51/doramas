import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import AdminWalletEditModal from "@/components/AdminWalletEditModal";
import { AdminAddDramaModal } from "@/components/AdminAddDramaModal";
import { AdminActivatePlanModal } from "@/components/AdminActivatePlanModal";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Plus, Trash2, Calendar } from "lucide-react";

interface UserData {
  id: string;
  email: string;
  full_name: string | null;
  username: string | null;
  created_at: string;
  plan_status: string;
  is_active: boolean;
  referral_count: number;
  ref_code: string;
  free_months_granted: number;
  phone: string | null;
}

interface ReferredUser {
  id: string;
  email: string;
  full_name: string | null;
  plan_status: string;
  created_at: string;
}

export default function ManageUsers() {
  const navigate = useNavigate();
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchEmail, setSearchEmail] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [planFilter, setPlanFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null);
  const [referredUsers, setReferredUsers] = useState<ReferredUser[]>([]);
  const [showReferralsDialog, setShowReferralsDialog] = useState(false);
  const [showWalletDialog, setShowWalletDialog] = useState(false);
  const [selectedUserWallet, setSelectedUserWallet] = useState<any>(null);
  const [showAddDramaDialog, setShowAddDramaDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [userToDelete, setUserToDelete] = useState<UserData | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [showActivatePlanDialog, setShowActivatePlanDialog] = useState(false);
  const itemsPerPage = 10;

  useEffect(() => {
    checkAdminAccess();
  }, []);

  useEffect(() => {
    if (!loading) {
      fetchUsers();
    }
  }, [currentPage, loading]);

  useEffect(() => {
    if (!loading) {
      setCurrentPage(1);
      fetchUsers();
    }
  }, [searchEmail, statusFilter, planFilter]);

  const checkAdminAccess = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id);

    const isAdmin = roles?.some((r) => r.role === "admin");
    if (!isAdmin) {
      toast.error("Acesso negado");
      navigate("/");
      return;
    }

    setLoading(false);
  };

  const extractPhone = (email: string): string | null => {
    if (email.endsWith('@doramassuper.internal')) {
      const phone = email.replace('@doramassuper.internal', '');
      if (phone.length === 11) {
        return `(${phone.slice(0, 2)}) ${phone.slice(2, 7)}-${phone.slice(7)}`;
      }
      return phone;
    }
    return null;
  };

  const fetchUsers = async () => {
    let query = supabase
      .from("profiles")
      .select("*", { count: "exact" });

    if (searchEmail) {
      query = query.ilike("email", `%${searchEmail}%`);
    }

    if (statusFilter !== "all") {
      query = query.eq("is_active", statusFilter === "active");
    }

    if (planFilter !== "all") {
      if (planFilter === "premium") {
        query = query.eq("plan_status", "active");
      } else {
        query = query.neq("plan_status", "active");
      }
    }

    const from = (currentPage - 1) * itemsPerPage;
    const to = from + itemsPerPage - 1;

    const { data, error, count } = await query
      .order("created_at", { ascending: false })
      .range(from, to);

    if (error) {
      toast.error("Erro ao carregar usuários");
      return;
    }

    // Add phone extraction to user data
    const usersWithPhone = (data || []).map(user => ({
      ...user,
      phone: extractPhone(user.email)
    }));

    setUsers(usersWithPhone);
    setTotalPages(Math.ceil((count || 0) / itemsPerPage));
  };

  const toggleUserStatus = async (userId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from("profiles")
      .update({ is_active: !currentStatus })
      .eq("id", userId);

    if (error) {
      toast.error("Erro ao atualizar status");
      return;
    }

    toast.success(currentStatus ? "Usuário desativado" : "Usuário ativado");
    fetchUsers();
  };

  const togglePlanStatus = async (userId: string, currentPlan: string, user: UserData) => {
    if (currentPlan !== "active") {
      // Abre modal para selecionar data de expiração
      setSelectedUser(user);
      setShowActivatePlanDialog(true);
      return;
    }
    
    // Desativar plano
    const { error } = await supabase
      .from("profiles")
      .update({ plan_status: "none", plan_renews_at: null })
      .eq("id", userId);

    if (error) {
      toast.error("Erro ao desativar plano");
      return;
    }

    toast.success("Plano Premium desativado");
    fetchUsers();
  };

  const viewReferrals = async (user: UserData) => {
    setSelectedUser(user);
    
    const { data, error } = await supabase
      .from("profiles")
      .select("id, email, full_name, plan_status, created_at")
      .eq("referred_by", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Erro ao carregar indicados");
      return;
    }

    setReferredUsers(data || []);
    setShowReferralsDialog(true);
  };

  const openWalletEdit = async (user: UserData) => {
    setSelectedUser(user);
    
    // Buscar dados da wallet
    const { data: wallet, error } = await supabase
      .from("wallets")
      .select("*")
      .eq("user_id", user.id)
      .single();

    if (error) {
      toast.error("Erro ao carregar carteira");
      return;
    }

    setSelectedUserWallet(wallet);
    setShowWalletDialog(true);
  };

  const openAddDrama = (user: UserData) => {
    setSelectedUser(user);
    setShowAddDramaDialog(true);
  };

  const confirmDeleteUser = (user: UserData) => {
    setUserToDelete(user);
    setShowDeleteDialog(true);
  };

  const deleteUser = async () => {
    if (!userToDelete) return;
    
    setDeleting(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Sessão expirada");
        return;
      }

      const response = await supabase.functions.invoke('admin-delete-user', {
        body: { user_id: userToDelete.id }
      });

      if (response.error) {
        toast.error("Erro ao excluir usuário: " + response.error.message);
        return;
      }

      toast.success(`Usuário ${userToDelete.full_name || userToDelete.phone || 'excluído'} foi removido com sucesso`);
      setShowDeleteDialog(false);
      setUserToDelete(null);
      fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error("Erro ao excluir usuário");
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-foreground">Gerenciar Usuários</h1>
          <Button variant="outline" onClick={() => navigate("/admin")}>
            Voltar ao Admin
          </Button>
        </div>

        <div className="bg-drama-card border-drama-border rounded-lg p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Buscar por e-mail ou telefone</label>
              <Input
                placeholder="Digite o e-mail ou telefone..."
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                className="bg-background border-drama-border"
              />
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Status da conta</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-background border-drama-border">
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="active">Ativos</SelectItem>
                  <SelectItem value="inactive">Desativados</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Tipo de plano</label>
              <Select value={planFilter} onValueChange={setPlanFilter}>
                <SelectTrigger className="bg-background border-drama-border">
                  <SelectValue placeholder="Todos os planos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os planos</SelectItem>
                  <SelectItem value="premium">Premium</SelectItem>
                  <SelectItem value="free">Gratuito</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="bg-drama-card border-drama-border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Telefone</TableHead>
                <TableHead>E-mail</TableHead>
                <TableHead>Data de Criação</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Plano</TableHead>
                <TableHead>Indicações</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    Nenhum usuário encontrado
                  </TableCell>
                </TableRow>
              ) : (
                users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.full_name || "-"}</TableCell>
                    <TableCell>
                      {user.phone ? (
                        <a 
                          href={`https://wa.me/55${user.email.replace('@doramassuper.internal', '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-mono text-sm text-fire-orange hover:text-fire-yellow-intense underline cursor-pointer transition-colors"
                        >
                          {user.phone}
                        </a>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {user.phone ? (
                        <span className="text-muted-foreground text-xs">Usuário por telefone</span>
                      ) : (
                        user.email
                      )}
                    </TableCell>
                    <TableCell>
                      {new Date(user.created_at).toLocaleDateString("pt-BR")}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={user.is_active ? "default" : "destructive"}
                        className={user.is_active 
                          ? "bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white border-none" 
                          : "bg-destructive text-white"
                        }
                      >
                        {user.is_active ? "Ativo" : "Desativado"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={user.plan_status === "active" ? "default" : "secondary"}
                        className={user.plan_status === "active" 
                          ? "bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white border-none" 
                          : "bg-muted text-muted-foreground"
                        }
                      >
                        {user.plan_status === "active" ? "Premium" : "Gratuito"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="link"
                        size="sm"
                        onClick={() => viewReferrals(user)}
                        className="text-fire-orange hover:text-fire-yellow-intense p-0"
                      >
                        {user.referral_count || 0} usuário{(user.referral_count || 0) !== 1 ? "s" : ""}
                      </Button>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2 justify-end flex-wrap">
                        <Button
                          variant={user.is_active ? "destructive" : "default"}
                          size="sm"
                          onClick={() => toggleUserStatus(user.id, user.is_active)}
                          className={user.is_active 
                            ? "bg-destructive hover:bg-destructive/90" 
                            : "bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_24px_rgba(255,140,0,0.4)] text-white"
                          }
                        >
                          {user.is_active ? "Desativar" : "Ativar"}
                        </Button>
                        <Button
                          variant={user.plan_status === "active" ? "outline" : "default"}
                          size="sm"
                          onClick={() => togglePlanStatus(user.id, user.plan_status, user)}
                          className={user.plan_status === "active"
                            ? "border-fire-orange text-fire-orange hover:bg-fire-orange/10"
                            : "bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_24px_rgba(255,140,0,0.4)] text-white"
                          }
                        >
                          {user.plan_status === "active" ? "Remover Premium" : (
                            <>
                              <Calendar className="w-4 h-4 mr-1" />
                              Ativar Premium
                            </>
                          )}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openWalletEdit(user)}
                          className="border-fire-orange text-fire-orange hover:bg-fire-orange/10"
                        >
                          Editar Carteira
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openAddDrama(user)}
                          className="border-green-500 text-green-500 hover:bg-green-500/10"
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Dorama
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => confirmDeleteUser(user)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {totalPages > 1 && (
          <div className="mt-6 flex justify-center">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <PaginationItem key={page}>
                    <PaginationLink
                      onClick={() => setCurrentPage(page)}
                      isActive={currentPage === page}
                      className="cursor-pointer"
                    >
                      {page}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                <PaginationItem>
                  <PaginationNext 
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        )}
      </div>

      <Dialog open={showReferralsDialog} onOpenChange={setShowReferralsDialog}>
        <DialogContent className="max-w-3xl bg-drama-card border-drama-border">
          <DialogHeader>
            <DialogTitle>
              Usuários indicados por {selectedUser?.full_name || selectedUser?.email}
            </DialogTitle>
          </DialogHeader>
          
          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-4">
              Total de indicações: <strong>{selectedUser?.referral_count || 0}</strong>
            </p>
            
            {referredUsers.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>E-mail</TableHead>
                    <TableHead>Status Premium</TableHead>
                    <TableHead>Data de Cadastro</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {referredUsers.map((referred) => (
                    <TableRow key={referred.id}>
                      <TableCell>{referred.full_name || "-"}</TableCell>
                      <TableCell>{referred.email}</TableCell>
                      <TableCell>
                        <Badge variant={referred.plan_status === "active" ? "default" : "secondary"}>
                          {referred.plan_status === "active" ? "Premium" : "Gratuito"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(referred.created_at).toLocaleDateString("pt-BR")}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                Nenhum usuário indicado ainda
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AdminWalletEditModal
        open={showWalletDialog}
        onClose={() => setShowWalletDialog(false)}
        user={selectedUser}
        wallet={selectedUserWallet}
        onSuccess={() => {
          fetchUsers();
          setShowWalletDialog(false);
        }}
      />

      {selectedUser && (
        <AdminAddDramaModal
          open={showAddDramaDialog}
          onOpenChange={setShowAddDramaDialog}
          user={selectedUser}
          onSuccess={() => {
            fetchUsers();
          }}
        />
      )}

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-drama-card border-drama-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">Excluir Usuário</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              Tem certeza que deseja excluir permanentemente o usuário{' '}
              <strong className="text-foreground">
                {userToDelete?.full_name || userToDelete?.phone || userToDelete?.email}
              </strong>
              ?
              <br /><br />
              Esta ação não pode ser desfeita. O usuário poderá se cadastrar novamente com o mesmo número.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              className="border-drama-border"
              disabled={deleting}
            >
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={deleteUser}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleting ? "Excluindo..." : "Excluir Usuário"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AdminActivatePlanModal
        isOpen={showActivatePlanDialog}
        onClose={() => setShowActivatePlanDialog(false)}
        user={selectedUser}
        onSuccess={fetchUsers}
      />
    </div>
  );
}
