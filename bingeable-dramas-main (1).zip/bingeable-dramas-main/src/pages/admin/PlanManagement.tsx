import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Clock, AlertTriangle, CheckCircle, XCircle, RefreshCw } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import { format, differenceInDays, isPast, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";

interface PlanUser {
  id: string;
  email: string;
  full_name: string | null;
  plan_status: string;
  plan_renews_at: string | null;
  is_active: boolean;
  created_at: string;
  phone: string;
  daysRemaining: number;
  status: 'expired' | 'expiring_soon' | 'active';
}

const PlanManagement = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState<PlanUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    checkAdminAccess();
    loadUsers();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      navigate("/");
    }
  };

  const extractPhone = (email: string): string => {
    if (email.includes('@doramassuper.internal')) {
      return email.split('@')[0];
    }
    return '';
  };

  const loadUsers = async () => {
    try {
      // Buscar todos os usuários com plano ativo
      const { data, error } = await supabase
        .from("profiles")
        .select("id, email, full_name, plan_status, plan_renews_at, is_active, created_at")
        .eq("plan_status", "active")
        .order("plan_renews_at", { ascending: true, nullsFirst: false });

      if (error) throw error;

      const now = new Date();
      const processedUsers: PlanUser[] = (data || []).map(user => {
        const expiryDate = user.plan_renews_at ? new Date(user.plan_renews_at) : null;
        const daysRemaining = expiryDate ? differenceInDays(expiryDate, now) : 999;
        
        let status: 'expired' | 'expiring_soon' | 'active' = 'active';
        if (expiryDate && isPast(expiryDate)) {
          status = 'expired';
        } else if (daysRemaining <= 5) {
          status = 'expiring_soon';
        }

        return {
          id: user.id,
          email: user.email,
          full_name: user.full_name,
          plan_status: user.plan_status || 'none',
          plan_renews_at: user.plan_renews_at,
          is_active: user.is_active ?? true,
          created_at: user.created_at || '',
          phone: extractPhone(user.email),
          daysRemaining,
          status,
        };
      });

      setUsers(processedUsers);
    } catch (error) {
      console.error("Error loading users:", error);
      toast({
        title: "Erro",
        description: "Falha ao carregar usuários",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const copyPhone = (phone: string) => {
    if (!phone) {
      toast({ title: "Telefone não disponível", variant: "destructive" });
      return;
    }
    navigator.clipboard.writeText(phone);
    toast({ title: "Telefone copiado!", description: phone });
  };

  const formatPhone = (phone: string): string => {
    if (!phone) return '-';
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 11) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`;
    }
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 6)}-${cleaned.slice(6)}`;
    }
    return phone;
  };

  const expiredUsers = users.filter(u => u.status === 'expired');
  const expiringUsers = users.filter(u => u.status === 'expiring_soon');
  const activeUsers = users.filter(u => u.status === 'active');

  const getStatusBadge = (status: 'expired' | 'expiring_soon' | 'active', daysRemaining: number) => {
    switch (status) {
      case 'expired':
        return (
          <Badge variant="destructive" className="flex items-center gap-1">
            <XCircle className="w-3 h-3" />
            Vencido
          </Badge>
        );
      case 'expiring_soon':
        return (
          <Badge variant="outline" className="border-yellow-500 text-yellow-500 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            {daysRemaining <= 0 ? 'Hoje' : `${daysRemaining} dias`}
          </Badge>
        );
      case 'active':
        return (
          <Badge className="bg-green-600 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            {daysRemaining} dias
          </Badge>
        );
    }
  };

  const UserTable = ({ userList, emptyMessage }: { userList: PlanUser[], emptyMessage: string }) => {
    if (userList.length === 0) {
      return (
        <div className="text-center py-12 text-muted-foreground">
          {emptyMessage}
        </div>
      );
    }

    return (
      <div className="rounded-md border border-drama-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-drama-card">
              <TableHead>Usuário</TableHead>
              <TableHead>Telefone</TableHead>
              <TableHead>Vencimento</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Conta</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {userList.map((user) => (
              <TableRow key={user.id} className="hover:bg-drama-card/50">
                <TableCell>
                  <div>
                    <p className="font-medium">{user.full_name || 'Sem nome'}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                </TableCell>
                <TableCell>
                  {user.phone ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyPhone(user.phone)}
                      className="flex items-center gap-2 h-auto py-1 px-2 font-mono text-sm hover:bg-drama-red/10"
                    >
                      {formatPhone(user.phone)}
                      <Copy className="w-3 h-3" />
                    </Button>
                  ) : (
                    <span className="text-muted-foreground text-sm">-</span>
                  )}
                </TableCell>
                <TableCell>
                  {user.plan_renews_at ? (
                    <div>
                      <p className="text-sm">
                        {format(new Date(user.plan_renews_at), "dd/MM/yyyy", { locale: ptBR })}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(user.plan_renews_at), "HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                  ) : (
                    <span className="text-muted-foreground">-</span>
                  )}
                </TableCell>
                <TableCell>
                  {getStatusBadge(user.status, user.daysRemaining)}
                </TableCell>
                <TableCell>
                  <Badge variant={user.is_active ? "secondary" : "destructive"}>
                    {user.is_active ? 'Ativa' : 'Inativa'}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="h-16"></div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">Gestão de Planos</h1>
            <p className="text-muted-foreground mt-1">
              Monitore planos de 30 dias e entre em contato com usuários
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => {
              setRefreshing(true);
              loadUsers();
            }}
            disabled={refreshing}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="p-4 bg-red-900/20 border-red-800">
            <div className="flex items-center gap-3">
              <XCircle className="w-8 h-8 text-red-500" />
              <div>
                <p className="text-2xl font-bold text-red-400">{expiredUsers.length}</p>
                <p className="text-sm text-red-400/80">Planos Vencidos</p>
              </div>
            </div>
          </Card>

          <Card className="p-4 bg-yellow-900/20 border-yellow-800">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-8 h-8 text-yellow-500" />
              <div>
                <p className="text-2xl font-bold text-yellow-400">{expiringUsers.length}</p>
                <p className="text-sm text-yellow-400/80">Vencendo em 5 dias</p>
              </div>
            </div>
          </Card>

          <Card className="p-4 bg-green-900/20 border-green-800">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-2xl font-bold text-green-400">{activeUsers.length}</p>
                <p className="text-sm text-green-400/80">Planos Ativos</p>
              </div>
            </div>
          </Card>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-drama-red mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Carregando...</p>
          </div>
        ) : (
          <Tabs defaultValue="expired" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="expired" className="flex items-center gap-2">
                <XCircle className="w-4 h-4" />
                Vencidos ({expiredUsers.length})
              </TabsTrigger>
              <TabsTrigger value="expiring" className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Vencendo ({expiringUsers.length})
              </TabsTrigger>
              <TabsTrigger value="active" className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Ativos ({activeUsers.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="expired">
              <Card className="p-4 bg-drama-card border-drama-border">
                <div className="flex items-center gap-2 mb-4">
                  <XCircle className="w-5 h-5 text-red-500" />
                  <h2 className="text-lg font-semibold">Planos Vencidos</h2>
                </div>
                <UserTable 
                  userList={expiredUsers} 
                  emptyMessage="🎉 Nenhum plano vencido!" 
                />
              </Card>
            </TabsContent>

            <TabsContent value="expiring">
              <Card className="p-4 bg-drama-card border-drama-border">
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle className="w-5 h-5 text-yellow-500" />
                  <h2 className="text-lg font-semibold">Vencendo em até 5 dias</h2>
                </div>
                <UserTable 
                  userList={expiringUsers} 
                  emptyMessage="Nenhum plano vencendo em breve" 
                />
              </Card>
            </TabsContent>

            <TabsContent value="active">
              <Card className="p-4 bg-drama-card border-drama-border">
                <div className="flex items-center gap-2 mb-4">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <h2 className="text-lg font-semibold">Planos Ativos</h2>
                </div>
                <UserTable 
                  userList={activeUsers} 
                  emptyMessage="Nenhum plano ativo" 
                />
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
};

export default PlanManagement;