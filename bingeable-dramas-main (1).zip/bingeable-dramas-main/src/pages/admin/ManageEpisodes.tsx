import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, ArrowLeft } from "lucide-react";
import Navbar from "@/components/Navbar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Episode {
  id: string;
  drama_id: string;
  title: string;
  description: string | null;
  episode_number: number;
  video_url: string;
  thumbnail_url: string | null;
  is_free: boolean | null;
  dramas?: {
    title: string;
  };
}

interface Drama {
  id: string;
  title: string;
}

const ManageEpisodes = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [dramas, setDramas] = useState<Drama[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEpisode, setEditingEpisode] = useState<Episode | null>(null);
  const [formData, setFormData] = useState({
    drama_id: "",
    title: "",
    description: "",
    episode_number: 1,
    video_url: "",
    thumbnail_url: "",
    is_free: false,
  });

  useEffect(() => {
    checkAdminAccess();
    loadData();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      navigate("/");
    }
  };

  const loadData = async () => {
    try {
      const [episodesRes, dramasRes] = await Promise.all([
        supabase
          .from("episodes")
          .select("*, dramas(title)")
          .order("created_at", { ascending: false }),
        supabase
          .from("dramas")
          .select("id, title")
          .eq("status", "active")
          .order("title"),
      ]);

      if (episodesRes.error) throw episodesRes.error;
      if (dramasRes.error) throw dramasRes.error;

      setEpisodes(episodesRes.data || []);
      setDramas(dramasRes.data || []);
    } catch (error) {
      console.error("Error loading data:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingEpisode) {
        const { error } = await supabase
          .from("episodes")
          .update({
            drama_id: formData.drama_id,
            title: formData.title,
            description: formData.description,
            episode_number: formData.episode_number,
            video_url: formData.video_url,
            thumbnail_url: formData.thumbnail_url,
            is_free: formData.is_free,
          })
          .eq("id", editingEpisode.id);

        if (error) throw error;

        toast({
          title: "Sucesso",
          description: "Episódio atualizado com sucesso",
        });
      } else {
        const { error } = await supabase.from("episodes").insert({
          drama_id: formData.drama_id,
          title: formData.title,
          description: formData.description,
          episode_number: formData.episode_number,
          video_url: formData.video_url,
          thumbnail_url: formData.thumbnail_url,
          is_free: formData.is_free,
        });

        if (error) throw error;

        toast({
          title: "Sucesso",
          description: "Episódio criado com sucesso",
        });
      }

      setDialogOpen(false);
      resetForm();
      loadData();
    } catch (error) {
      console.error("Error saving episode:", error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar o episódio",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (episode: Episode) => {
    setEditingEpisode(episode);
    setFormData({
      drama_id: episode.drama_id,
      title: episode.title,
      description: episode.description || "",
      episode_number: episode.episode_number,
      video_url: episode.video_url,
      thumbnail_url: episode.thumbnail_url || "",
      is_free: episode.is_free || false,
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este episódio?")) return;

    try {
      const { error } = await supabase.from("episodes").delete().eq("id", id);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Episódio excluído com sucesso",
      });

      loadData();
    } catch (error) {
      console.error("Error deleting episode:", error);
      toast({
        title: "Erro",
        description: "Não foi possível excluir o episódio",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      drama_id: "",
      title: "",
      description: "",
      episode_number: 1,
      video_url: "",
      thumbnail_url: "",
      is_free: false,
    });
    setEditingEpisode(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/admin")}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-3xl font-bold">Gerenciar Episódios</h1>
          </div>

          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-drama-red hover:bg-drama-red-hover">
                <Plus className="w-4 h-4 mr-2" />
                Novo Episódio
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-drama-card border-drama-border max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingEpisode ? "Editar Episódio" : "Novo Episódio"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="drama_id">Série</Label>
                  <Select
                    value={formData.drama_id}
                    onValueChange={(value) => setFormData({ ...formData, drama_id: value })}
                    required
                  >
                    <SelectTrigger className="bg-background border-drama-border">
                      <SelectValue placeholder="Selecione uma série" />
                    </SelectTrigger>
                    <SelectContent>
                      {dramas.map((drama) => (
                        <SelectItem key={drama.id} value={drama.id}>
                          {drama.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="episode_number">Número do Episódio</Label>
                  <Input
                    id="episode_number"
                    type="number"
                    min="1"
                    value={formData.episode_number}
                    onChange={(e) => setFormData({ ...formData, episode_number: parseInt(e.target.value) })}
                    required
                    className="bg-background border-drama-border"
                  />
                </div>

                <div>
                  <Label htmlFor="title">Título do Episódio</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    className="bg-background border-drama-border"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Descrição do Episódio</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="bg-background border-drama-border min-h-[100px]"
                  />
                </div>

                <div>
                  <Label htmlFor="video_url">URL do Vídeo</Label>
                  <Input
                    id="video_url"
                    value={formData.video_url}
                    onChange={(e) => setFormData({ ...formData, video_url: e.target.value })}
                    placeholder="https://..."
                    required
                    className="bg-background border-drama-border"
                  />
                </div>

                <div>
                  <Label htmlFor="thumbnail_url">URL da Thumbnail</Label>
                  <Input
                    id="thumbnail_url"
                    value={formData.thumbnail_url}
                    onChange={(e) => setFormData({ ...formData, thumbnail_url: e.target.value })}
                    placeholder="https://..."
                    className="bg-background border-drama-border"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="is_free"
                    checked={formData.is_free}
                    onChange={(e) => setFormData({ ...formData, is_free: e.target.checked })}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="is_free" className="cursor-pointer">
                    Episódio gratuito (parte dos 5 primeiros)
                  </Label>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-drama-red hover:bg-drama-red-hover"
                  >
                    {editingEpisode ? "Atualizar" : "Criar"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {loading ? (
          <p className="text-center text-muted-foreground">Carregando...</p>
        ) : episodes.length === 0 ? (
          <Card className="p-8 bg-drama-card border-drama-border text-center">
            <p className="text-muted-foreground">Nenhum episódio cadastrado ainda</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {episodes.map((episode) => (
              <Card key={episode.id} className="p-4 bg-drama-card border-drama-border">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-sm font-semibold text-drama-red">
                        EP {episode.episode_number}
                      </span>
                      <h3 className="text-lg font-bold">{episode.title}</h3>
                      {(episode.is_free || episode.episode_number <= 5) && (
                        <span className="text-xs px-2 py-1 rounded bg-green-500/20 text-green-500">
                          Grátis
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {episode.dramas?.title}
                    </p>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {episode.description}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(episode)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(episode.id)}
                      className="text-red-500 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageEpisodes;
