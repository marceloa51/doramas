import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, ArrowLeft, Search, Link2 } from "lucide-react";
import Navbar from "@/components/Navbar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Drama {
  id: string;
  title: string;
  slug: string;
  synopsis: string | null;
  genres: string[] | null;
  status: string | null;
  thumbnail_url: string | null;
  cover_url: string | null;
  file_url: string | null;
  total_episodes: number | null;
  start_position_seconds: number | null;
}

// Gera slug limpo removendo acentos e caracteres especiais
const generateSlug = (title: string): string => {
  const slug = title
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove acentos
    .replace(/[^a-z0-9\s]/g, '')      // Remove TODOS caracteres especiais (vírgulas, !, etc)
    .replace(/\s+/g, '-')             // Espaços → hífens
    .replace(/-+/g, '-')              // Remove hífens duplicados
    .replace(/^-|-$/g, '');           // Remove hífens no início/fim
  
  return slug || `drama-${Date.now()}`;
};

const AVAILABLE_GENRES = [
  "Romance",
  "Drama",
  "Suspense",
  "Ação",
  "Comédia",
  "Fantasia",
  "Aventura",
  "Mistério",
  "Melodrama",
  "Histórico",
  "Thriller",
  "Ficção Científica",
];

const ManageDramas = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [dramas, setDramas] = useState<Drama[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingDrama, setEditingDrama] = useState<Drama | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [formData, setFormData] = useState({
    title: "",
    synopsis: "",
    genres: [] as string[],
    status: "active",
    thumbnail_url: "",
    cover_url: "",
    file_url: "",
    startTime: "", // Formato MM:SS
  });

  useEffect(() => {
    checkAdminAccess();
    loadDramas();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      navigate("/");
    }
  };

  const loadDramas = async () => {
    try {
      const { data, error } = await supabase
        .from("dramas")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setDramas(data || []);
    } catch (error) {
      console.error("Error loading dramas:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os filmes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const timeToSeconds = (timeStr: string): number => {
    if (!timeStr || timeStr.trim() === "") return 0;
    
    const parts = timeStr.split(":");
    if (parts.length === 1) {
      // Se só tem um número, assume que são minutos
      return parseInt(parts[0]) * 60 || 0;
    } else if (parts.length === 2) {
      // Formato MM:SS
      const mins = parseInt(parts[0]) || 0;
      const secs = parseInt(parts[1]) || 0;
      return mins * 60 + secs;
    }
    return 0;
  };

  const secondsToTime = (seconds: number): string => {
    if (seconds === 0) return "";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${String(secs).padStart(2, '0')}`;
  };

  // Verifica se slug já existe e adiciona sufixo se necessário
  const getUniqueSlug = async (baseSlug: string, excludeId?: string): Promise<string> => {
    let slug = baseSlug;
    let counter = 1;

    while (true) {
      let query = supabase.from("dramas").select("id").eq("slug", slug);
      if (excludeId) query = query.neq("id", excludeId);

      const { data } = await query.maybeSingle();
      if (!data) return slug;

      counter++;
      slug = `${baseSlug}-${counter}`;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const trimmedTitle = formData.title.trim();
    
    if (!trimmedTitle) {
      toast({
        title: "Erro",
        description: "O título não pode estar vazio",
        variant: "destructive",
      });
      return;
    }

    try {
      const baseSlug = generateSlug(trimmedTitle);
      const startPositionSeconds = timeToSeconds(formData.startTime);

      // Verifica se já existe um drama com título similar (evita duplicados)
      if (!editingDrama) {
        const { data: existingDramas } = await supabase
          .from("dramas")
          .select("id, title, slug")
          .or(`slug.eq.${baseSlug},title.ilike.%${trimmedTitle}%`);

        if (existingDramas && existingDramas.length > 0) {
          const exactMatch = existingDramas.find(
            d => d.title.toLowerCase() === trimmedTitle.toLowerCase() || d.slug === baseSlug
          );
          
          if (exactMatch) {
            toast({
              title: "Erro",
              description: `Já existe um drama com título similar: "${exactMatch.title}"`,
              variant: "destructive",
            });
            return;
          }
        }
      }

      if (editingDrama) {
        // Na edição, mantém o slug original para não quebrar links existentes
        const { error } = await supabase
          .from("dramas")
          .update({
            title: formData.title,
            synopsis: formData.synopsis,
            genres: formData.genres,
            status: formData.status,
            thumbnail_url: formData.thumbnail_url,
            cover_url: formData.cover_url,
            file_url: formData.file_url,
            start_position_seconds: startPositionSeconds,
          })
          .eq("id", editingDrama.id);

        if (error) throw error;

        toast({
          title: "Sucesso",
          description: "Filme atualizado com sucesso",
        });
      } else {
        // Na criação, gera slug único
        const uniqueSlug = await getUniqueSlug(baseSlug);
        
        const { error } = await supabase.from("dramas").insert({
          title: formData.title,
          synopsis: formData.synopsis,
          genres: formData.genres,
          status: formData.status,
          thumbnail_url: formData.thumbnail_url,
          cover_url: formData.cover_url,
          file_url: formData.file_url,
          start_position_seconds: startPositionSeconds,
          slug: uniqueSlug,
        });

        if (error) throw error;

        toast({
          title: "Sucesso",
          description: "Filme criado com sucesso",
        });
      }

      setDialogOpen(false);
      resetForm();
      loadDramas();
    } catch (error) {
      console.error("Error saving drama:", error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar o filme",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (drama: Drama & { video_url?: string | null }) => {
    setEditingDrama(drama);
    setFormData({
      title: drama.title,
      synopsis: drama.synopsis || "",
      genres: drama.genres || [],
      status: drama.status || "active",
      thumbnail_url: drama.thumbnail_url || "",
      cover_url: drama.cover_url || "",
      file_url: drama.file_url || drama.video_url || "",
      startTime: secondsToTime(drama.start_position_seconds || 0),
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este filme?")) return;

    try {
      const { error } = await supabase.from("dramas").delete().eq("id", id);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Filme excluído com sucesso",
      });

      loadDramas();
    } catch (error) {
      console.error("Error deleting drama:", error);
      toast({
        title: "Erro",
        description: "Não foi possível excluir o filme",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      synopsis: "",
      genres: [],
      status: "active",
      thumbnail_url: "",
      cover_url: "",
      file_url: "",
      startTime: "",
    });
    setEditingDrama(null);
  };

  const copyCheckoutLink = async (slug: string) => {
    const baseUrl = window.location.origin;
    const checkoutUrl = `${baseUrl}/checkout/${slug}`;
    
    try {
      await navigator.clipboard.writeText(checkoutUrl);
      toast({
        title: "✅ Link copiado!",
        description: checkoutUrl,
      });
    } catch (error) {
      console.error("Erro ao copiar:", error);
      toast({
        title: "Erro",
        description: "Não foi possível copiar o link",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Espaçador para compensar o navbar fixo */}
      <div className="h-16"></div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/admin")}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl sm:text-3xl font-bold">Gerenciar Filmes</h1>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* Campo de Pesquisa */}
            <div className="relative flex-1 sm:flex-none">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Buscar filme..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-full sm:w-64 bg-background border-drama-border"
              />
            </div>

          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-drama-red hover:bg-drama-red-hover">
                <Plus className="w-4 h-4 mr-2" />
                Novo Filme
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-drama-card border-drama-border max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingDrama ? "Editar Filme" : "Novo Filme"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    className="bg-background border-drama-border"
                  />
                </div>

                <div>
                  <Label htmlFor="synopsis">Sinopse</Label>
                  <Textarea
                    id="synopsis"
                    value={formData.synopsis}
                    onChange={(e) => setFormData({ ...formData, synopsis: e.target.value })}
                    className="bg-background border-drama-border min-h-[100px]"
                  />
                </div>

                <div>
                  <Label htmlFor="genres">Gêneros</Label>
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {AVAILABLE_GENRES.map((genre) => (
                        <label
                          key={genre}
                          className="flex items-center gap-2 cursor-pointer p-2 rounded border border-drama-border hover:border-fire-orange transition-smooth"
                        >
                          <input
                            type="checkbox"
                            checked={formData.genres.includes(genre)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                if (formData.genres.length < 4) {
                                  setFormData({ ...formData, genres: [...formData.genres, genre] });
                                }
                              } else {
                                setFormData({ ...formData, genres: formData.genres.filter(g => g !== genre) });
                              }
                            }}
                            className="w-4 h-4"
                          />
                          <span className="text-sm">{genre}</span>
                        </label>
                      ))}
                    </div>
                    {formData.genres.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {formData.genres.map((genre) => (
                          <span
                            key={genre}
                            className="px-2 py-1 bg-fire-orange/20 text-fire-orange rounded text-xs"
                          >
                            {genre}
                          </span>
                        ))}
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Selecione de 1 a 4 gêneros (obrigatório pelo menos 1)
                    </p>
                  </div>
                </div>

                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger className="bg-background border-drama-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Ativo</SelectItem>
                      <SelectItem value="inactive">Inativo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="thumbnail_url">URL da Thumbnail (Capa Pequena)</Label>
                  <Input
                    id="thumbnail_url"
                    type="url"
                    value={formData.thumbnail_url}
                    onChange={(e) => setFormData({ ...formData, thumbnail_url: e.target.value })}
                    placeholder="https://exemplo.com/imagem.jpg"
                    className="bg-background border-drama-border"
                  />
                  {formData.thumbnail_url && (
                    <div className="mt-2">
                      <p className="text-xs text-muted-foreground mb-1">Preview:</p>
                      <img 
                        src={formData.thumbnail_url} 
                        alt="Preview thumbnail" 
                        className="w-32 h-48 object-cover rounded border border-drama-border"
                        onError={(e) => {
                          e.currentTarget.src = '';
                          e.currentTarget.alt = 'Erro ao carregar imagem';
                          e.currentTarget.className = 'w-32 h-48 flex items-center justify-center bg-drama-dark rounded border border-red-500';
                        }}
                      />
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    Use um link direto de imagem (ex: imgur, imgbb, GitHub)
                  </p>
                </div>

                <div>
                  <Label htmlFor="cover_url">URL da Capa (Imagem Grande)</Label>
                  <Input
                    id="cover_url"
                    type="url"
                    value={formData.cover_url}
                    onChange={(e) => setFormData({ ...formData, cover_url: e.target.value })}
                    placeholder="https://exemplo.com/capa.jpg"
                    className="bg-background border-drama-border"
                  />
                  {formData.cover_url && (
                    <div className="mt-2">
                      <p className="text-xs text-muted-foreground mb-1">Preview:</p>
                      <img 
                        src={formData.cover_url} 
                        alt="Preview capa" 
                        className="w-full h-32 object-cover rounded border border-drama-border"
                        onError={(e) => {
                          e.currentTarget.src = '';
                          e.currentTarget.alt = 'Erro ao carregar imagem';
                          e.currentTarget.className = 'w-full h-32 flex items-center justify-center bg-drama-dark rounded border border-red-500';
                        }}
                      />
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    Imagem widescreen para o hero (1920x1080 recomendado)
                  </p>
                </div>

                <div>
                  <Label htmlFor="file_url">URL do Vídeo</Label>
                  <Input
                    id="file_url"
                    type="url"
                    value={formData.file_url}
                    onChange={(e) => setFormData({ ...formData, file_url: e.target.value })}
                    placeholder="https://cdn.doramassuper.site/videos/nome-do-drama.mp4"
                    className="bg-background border-drama-border"
                    required
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Cole o link direto do vídeo MP4 hospedado no CDN (https://cdn.doramassuper.site/videos/...)
                  </p>
                </div>

                <div>
                  <Label htmlFor="startTime">⏱️ Minuto de Início (para "Continuar de onde parei")</Label>
                  <Input
                    id="startTime"
                    type="text"
                    value={formData.startTime}
                    onChange={(e) => {
                      const value = e.target.value;
                      // Permitir apenas números e ":"
                      const cleaned = value.replace(/[^0-9:]/g, '');
                      setFormData({ ...formData, startTime: cleaned });
                    }}
                    placeholder="0:00"
                    pattern="^[0-9]+:[0-9]{2}$|^[0-9]+$"
                    className="bg-background border-drama-border"
                    maxLength={6}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Ex: 5 = começa em 05:00 | Ex: 10:20 = começa em 10:20 | 0 = começa do início
                  </p>
                  {formData.startTime && formData.startTime !== "0" && (
                    <p className="text-xs text-fire-orange mt-1">
                      O vídeo começará em {(() => {
                        const seconds = timeToSeconds(formData.startTime);
                        const mins = Math.floor(seconds / 60);
                        const secs = seconds % 60;
                        return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
                      })()}
                    </p>
                  )}
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-drama-red hover:bg-drama-red-hover"
                    disabled={formData.genres.length === 0}
                  >
                    {editingDrama ? "Atualizar" : "Criar"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
          </div>
        </div>

        {/* Lista filtrada de dramas */}
        {(() => {
          const filteredDramas = dramas.filter(drama =>
            drama.title.toLowerCase().includes(searchQuery.toLowerCase())
          );
          
          if (loading) {
            return <p className="text-center text-muted-foreground">Carregando...</p>;
          }
          
          if (filteredDramas.length === 0 && searchQuery) {
            return (
              <Card className="p-8 bg-drama-card border-drama-border text-center">
                <p className="text-muted-foreground">Nenhum filme encontrado para "{searchQuery}"</p>
              </Card>
            );
          }
          
          if (dramas.length === 0) {
            return (
              <Card className="p-8 bg-drama-card border-drama-border text-center">
                <p className="text-muted-foreground">Nenhuma série cadastrada ainda</p>
              </Card>
            );
          }
          
          return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDramas.map((drama) => (
              <Card key={drama.id} className="p-4 bg-drama-card border-drama-border">
                {drama.thumbnail_url && (
                  <img
                    src={drama.thumbnail_url}
                    alt={drama.title}
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                )}
                <h3 className="text-xl font-bold mb-2">{drama.title}</h3>
                <div className="flex flex-wrap gap-1 mb-2">
                  {drama.genres && drama.genres.map((genre) => (
                    <span key={genre} className="text-xs px-2 py-1 bg-fire-orange/20 text-fire-orange rounded">
                      {genre}
                    </span>
                  ))}
                </div>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {drama.synopsis}
                </p>
                <div className="flex items-center justify-between">
                  <span className={`text-xs px-2 py-1 rounded ${
                    drama.status === "active" 
                      ? "bg-green-500/20 text-green-500" 
                      : "bg-gray-500/20 text-gray-500"
                  }`}>
                    {drama.status === "active" ? "Ativo" : "Inativo"}
                  </span>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyCheckoutLink(drama.slug)}
                      title="Copiar link de checkout"
                      className="text-blue-500 hover:text-blue-600"
                    >
                      <Link2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(drama)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(drama.id)}
                      className="text-red-500 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
          );
        })()}
      </div>
    </div>
  );
};

export default ManageDramas;
