import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Film, PlaySquare, Users, CreditCard, Plus, Bell, Phone, UserPlus, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

const Dashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalDramas: 0,
    totalEpisodes: 0,
    totalUsers: 0,
    activeSubscribers: 0,
  });
  const [loading, setLoading] = useState(true);
  const [recentNotifications, setRecentNotifications] = useState<any[]>([]);

  useEffect(() => {
    checkAdminAccess();
    loadStats();
    loadRecentNotifications();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      navigate("/");
    }
  };

  const loadStats = async () => {
    try {
      const [dramasRes, episodesRes, usersRes, subscribersRes] = await Promise.all([
        supabase.from("dramas").select("id", { count: "exact", head: true }),
        supabase.from("episodes").select("id", { count: "exact", head: true }),
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("profiles").select("id", { count: "exact", head: true }).eq("plan_status", "active"),
      ]);

      console.log("Dashboard stats:", {
        dramas: dramasRes.count,
        episodes: episodesRes.count,
        users: usersRes.count,
        subscribers: subscribersRes.count,
      });

      setStats({
        totalDramas: dramasRes.count || 0,
        totalEpisodes: episodesRes.count || 0,
        totalUsers: usersRes.count || 0,
        activeSubscribers: subscribersRes.count || 0,
      });
    } catch (error) {
      console.error("Error loading stats:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadRecentNotifications = async () => {
    const notifications: any[] = [];

    // Últimos leads
    const { data: leads } = await supabase
      .from("leads")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(2);

    leads?.forEach(lead => {
      notifications.push({
        id: `lead_${lead.id}`,
        type: "lead",
        icon: Phone,
        color: "text-green-400",
        label: "Lead Novo",
        description: `Telefone: ${lead.phone.slice(0, 15)}...`,
        timestamp: lead.created_at
      });
    });

    // Últimos usuários
    const { data: users } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(2);

    users?.forEach(user => {
      notifications.push({
        id: `user_${user.id}`,
        type: "user",
        icon: UserPlus,
        color: "text-blue-400",
        label: "Usuário Cadastrado",
        description: user.full_name || "Novo usuário",
        timestamp: user.created_at
      });
    });

    // Últimos pagamentos
    const { data: payments } = await supabase
      .from("checkout_sessions")
      .select("*")
      .eq("status", "paid")
      .order("paid_at", { ascending: false })
      .limit(1);

    payments?.forEach(payment => {
      notifications.push({
        id: `payment_${payment.id}`,
        type: "payment",
        icon: CheckCircle,
        color: "text-green-300",
        label: "Pagamento Confirmado",
        description: `R$ ${payment.amount?.toFixed(2)} - ${payment.customer_name || "Cliente"}`,
        timestamp: payment.paid_at
      });
    });

    // Ordenar por timestamp
    notifications.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    setRecentNotifications(notifications.slice(0, 5));
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Espaçador para compensar o navbar fixo */}
      <div className="h-16"></div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Dashboard Admin</h1>
          <Button
            onClick={() => navigate("/admin/dramas")}
            className="bg-drama-red hover:bg-drama-red-hover"
          >
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Filme
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6 bg-drama-card border-drama-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total de Filmes</p>
                <p className="text-3xl font-bold mt-2">{loading ? "..." : stats.totalDramas}</p>
              </div>
              <Film className="w-12 h-12 text-drama-red opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-drama-card border-drama-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total de Vídeos</p>
                <p className="text-3xl font-bold mt-2">{loading ? "..." : stats.totalEpisodes}</p>
              </div>
              <PlaySquare className="w-12 h-12 text-drama-red opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-drama-card border-drama-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Usuários Cadastrados</p>
                <p className="text-3xl font-bold mt-2">{loading ? "..." : stats.totalUsers}</p>
              </div>
              <Users className="w-12 h-12 text-drama-red opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-drama-card border-drama-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Assinantes Ativos</p>
                <p className="text-3xl font-bold mt-2">{loading ? "..." : stats.activeSubscribers}</p>
              </div>
              <CreditCard className="w-12 h-12 text-drama-red opacity-80" />
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-6 bg-drama-card border-drama-border">
            <h2 className="text-xl font-bold mb-4">Ações Rápidas</h2>
            <div className="space-y-3">
              <button
                onClick={() => navigate("/admin/dramas")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                Gerenciar Filmes
              </button>
              <button
                onClick={() => navigate("/admin/featured")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                Gerenciar Mais Assistidos
              </button>
              <button
                onClick={() => navigate("/admin/users")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                Gerenciar Usuários
              </button>
              <button
                onClick={() => navigate("/admin/reports")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                Relatórios
              </button>
              <button
                onClick={() => navigate("/admin/payments")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                💳 Pagamentos PIX
              </button>
              <button
                onClick={() => navigate("/admin/withdrawals")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                💰 Saques de Afiliados
              </button>
              <button
                onClick={() => navigate("/admin/leads")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                📱 Leads Capturados
              </button>
              <button
                onClick={() => navigate("/admin/plans")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                📅 Gestão de Planos
              </button>
              <button
                onClick={() => navigate("/admin/notifications")}
                className="w-full text-left px-4 py-3 rounded-lg bg-background hover:bg-drama-red/10 transition-smooth"
              >
                <Bell className="inline-block w-4 h-4 mr-2" />
                Notificações
              </button>
            </div>
          </Card>

          <Card className="p-6 bg-drama-card border-drama-border">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Últimas Atividades</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/admin/notifications")}
                className="text-drama-red hover:text-drama-red-hover"
              >
                Ver todas
              </Button>
            </div>
            {recentNotifications.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-8">Nenhuma atividade recente</p>
            ) : (
              <div className="space-y-3">
                {recentNotifications.map((notification) => {
                  const Icon = notification.icon;
                  const timeAgo = formatDistanceToNow(new Date(notification.timestamp), {
                    addSuffix: true,
                    locale: ptBR
                  });

                  return (
                    <div
                      key={notification.id}
                      className="flex items-start gap-3 p-3 rounded-lg bg-background/50 hover:bg-drama-red/5 transition-smooth"
                    >
                      <Icon className={`w-5 h-5 ${notification.color} mt-0.5`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{notification.label}</p>
                        <p className="text-xs text-muted-foreground truncate">{notification.description}</p>
                        <p className="text-xs text-muted-foreground/60 mt-1">{timeAgo}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
