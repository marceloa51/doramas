import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Phone, Calendar, Film, Download, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { format } from "date-fns";
import { toast } from "sonner";

interface Lead {
  id: string;
  phone: string;
  drama_title: string;
  created_at: string;
}

const Leads = () => {
  const navigate = useNavigate();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    today: 0,
    thisWeek: 0,
  });

  useEffect(() => {
    checkAdminAccess();
    loadLeads();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      navigate("/");
    }
  };

  const loadLeads = async () => {
    try {
      const { data, error } = await supabase
        .from("leads")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;

      setLeads(data || []);

      // Calculate stats
      const now = new Date();
      const todayStart = new Date(now.setHours(0, 0, 0, 0));
      const weekStart = new Date(now.setDate(now.getDate() - 7));

      const total = data?.length || 0;
      const today = data?.filter(lead => new Date(lead.created_at) >= todayStart).length || 0;
      const thisWeek = data?.filter(lead => new Date(lead.created_at) >= weekStart).length || 0;

      setStats({ total, today, thisWeek });
    } catch (error) {
      console.error("Error loading leads:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatPhone = (phone: string) => {
    if (phone.length === 11) {
      return `(${phone.slice(0, 2)}) ${phone.slice(2, 7)}-${phone.slice(7)}`;
    }
    return phone;
  };

  const copyWhatsAppLink = (phone: string) => {
    const cleanPhone = phone.replace(/\D/g, '');
    const whatsappLink = `wa.me/+55${cleanPhone}`;
    
    navigator.clipboard.writeText(whatsappLink);
    toast.success("Link copiado!", {
      description: whatsappLink
    });
  };

  const exportToCSV = () => {
    const headers = ["Telefone", "Dorama", "Data/Hora"];
    const rows = leads.map(lead => [
      formatPhone(lead.phone),
      lead.drama_title || "N/A",
      format(new Date(lead.created_at), "dd/MM/yyyy HH:mm"),
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `leads_${format(new Date(), "yyyy-MM-dd")}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="h-16"></div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
          <h1 className="text-3xl font-bold text-fire-yellow-bright">📱 Leads Capturados</h1>
          <Button
            onClick={exportToCSV}
            disabled={leads.length === 0}
            className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_30px_rgba(255,140,0,0.6)]"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar CSV
          </Button>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 bg-black border-fire-orange/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/60 text-sm">Total de Leads</p>
                <p className="text-3xl font-bold text-fire-yellow-bright mt-2">
                  {loading ? "..." : stats.total}
                </p>
              </div>
              <Phone className="w-12 h-12 text-fire-orange opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-black border-fire-orange/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/60 text-sm">Leads Hoje</p>
                <p className="text-3xl font-bold text-fire-yellow-bright mt-2">
                  {loading ? "..." : stats.today}
                </p>
              </div>
              <Calendar className="w-12 h-12 text-fire-orange opacity-80" />
            </div>
          </Card>

          <Card className="p-6 bg-black border-fire-orange/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/60 text-sm">Esta Semana</p>
                <p className="text-3xl font-bold text-fire-yellow-bright mt-2">
                  {loading ? "..." : stats.thisWeek}
                </p>
              </div>
              <Film className="w-12 h-12 text-fire-orange opacity-80" />
            </div>
          </Card>
        </div>

        {/* Leads Table */}
        <Card className="bg-black border-fire-orange/30">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-fire-orange/20 hover:bg-fire-orange/5">
                  <TableHead className="text-fire-yellow-bright">Telefone</TableHead>
                  <TableHead className="text-fire-yellow-bright">Dorama</TableHead>
                  <TableHead className="text-fire-yellow-bright">Data/Hora</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-white/60 py-8">
                      Carregando...
                    </TableCell>
                  </TableRow>
                ) : leads.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-white/60 py-8">
                      Nenhum lead capturado ainda
                    </TableCell>
                  </TableRow>
                ) : (
                  leads.map((lead) => (
                    <TableRow key={lead.id} className="border-fire-orange/10 hover:bg-fire-orange/5">
                      <TableCell className="text-white font-mono">
                        <div className="flex items-center gap-2">
                          <span>{formatPhone(lead.phone)}</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-fire-orange hover:text-fire-yellow-intense hover:bg-fire-orange/20"
                            onClick={() => copyWhatsAppLink(lead.phone)}
                            title="Copiar link WhatsApp"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell className="text-white/80">
                        {lead.drama_title || "N/A"}
                      </TableCell>
                      <TableCell className="text-white/60">
                        {format(new Date(lead.created_at), "dd/MM/yyyy 'às' HH:mm")}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Leads;
