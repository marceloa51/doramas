import { useEffect, useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import Navbar from "@/components/Navbar";
import { 
  Phone, 
  UserPlus, 
  QrCode, 
  CheckCircle, 
  Wallet, 
  ShoppingBag, 
  RefreshCw,
  Copy,
  ExternalLink,
  Bell,
  BellOff,
  CreditCard,
  CalendarIcon
} from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";

type NotificationType = 
  | "lead_novo" 
  | "usuario_cadastrado" 
  | "pix_gerado" 
  | "cartao_pago"
  | "cartao_recusado"
  | "pagamento_confirmado" 
  | "solicitacao_saque"
  | "compra_realizada";

interface Notification {
  id: string;
  type: NotificationType;
  timestamp: string;
  data: any;
}

// Função para tocar som de notificação usando Web Audio API
const playNotificationSound = () => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Som de "ding" agradável
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
    oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.2);
    
    oscillator.type = 'sine';
    
    // Volume moderado (30%)
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (error) {
    console.log('Erro ao tocar som:', error);
  }
};

const Notifications = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [filterType, setFilterType] = useState<string>("all");
  const [filterPeriod, setFilterPeriod] = useState<string>("7d");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [stats, setStats] = useState({
    leadsToday: 0,
    pixToday: 0,
    paymentsToday: 0,
    usersToday: 0,
    visitsToday: 0
  });
  
  // Estado para som de notificação
  const [soundEnabled, setSoundEnabled] = useState(() => {
    return localStorage.getItem('notifications_sound') !== 'false';
  });
  const previousNotificationIdsRef = useRef<Set<string>>(new Set());

  // Alternar som e salvar preferência
  const toggleSound = useCallback(() => {
    setSoundEnabled(prev => {
      const newValue = !prev;
      localStorage.setItem('notifications_sound', String(newValue));
      toast.success(newValue ? "🔔 Som ativado" : "🔕 Som desativado");
      return newValue;
    });
  }, []);

  useEffect(() => {
    checkAdminAccess();
    loadNotifications();
    loadStats();

    // Auto-refresh silencioso a cada 10 segundos
    const interval = setInterval(() => {
      loadNotifications(true);
      loadStats();
    }, 10000);

    return () => clearInterval(interval);
  }, [filterType, filterPeriod, selectedDate]);

  const checkAdminAccess = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id)
      .eq("role", "admin")
      .single();

    if (!roles) {
      toast.error("Acesso negado");
      navigate("/");
    }
  };

  const getDateRange = () => {
    // Se uma data específica foi selecionada no calendário
    if (selectedDate) {
      const startDate = new Date(selectedDate);
      startDate.setHours(0, 0, 0, 0);
      const endDate = new Date(selectedDate);
      endDate.setHours(23, 59, 59, 999);
      return { startDate, endDate };
    }

    const startDate = new Date();
    let endDate: Date | null = null;

    if (filterPeriod === "today") {
      startDate.setHours(0, 0, 0, 0);
    } else if (filterPeriod === "yesterday") {
      startDate.setDate(startDate.getDate() - 1);
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date(startDate);
      endDate.setHours(23, 59, 59, 999);
    } else {
      const days = parseInt(filterPeriod.replace("d", ""));
      startDate.setDate(startDate.getDate() - days);
      startDate.setHours(0, 0, 0, 0);
    }

    return { startDate, endDate };
  };

  const getPeriodLabel = () => {
    if (selectedDate) {
      return format(selectedDate, "dd/MM", { locale: ptBR });
    }
    switch (filterPeriod) {
      case "today": return "Hoje";
      case "yesterday": return "Ontem";
      case "7d": return "7 dias";
      case "30d": return "30 dias";
      case "90d": return "90 dias";
      default: return "";
    }
  };

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    if (date) {
      setFilterPeriod("custom");
    }
  };

  const clearDateFilter = () => {
    setSelectedDate(undefined);
    setFilterPeriod("7d");
  };

  const loadStats = async () => {
    const { startDate, endDate } = getDateRange();
    const start = startDate.toISOString();
    const end = endDate?.toISOString();

    // Build queries with optional end date
    let leadsQuery = supabase.from("leads").select("id", { count: "exact" }).gte("created_at", start);
    let pixQuery = supabase.from("checkout_sessions").select("id", { count: "exact" }).eq("status", "pending").gte("created_at", start);
    let paymentsQuery = supabase.from("checkout_sessions").select("id", { count: "exact" }).eq("status", "paid").gte("paid_at", start);
    let usersQuery = supabase.from("profiles").select("id", { count: "exact" }).gte("created_at", start);
    let visitsQuery = (supabase as any).from("page_visits").select("id", { count: "exact" }).gte("created_at", start);

    if (end) {
      leadsQuery = leadsQuery.lte("created_at", end);
      pixQuery = pixQuery.lte("created_at", end);
      paymentsQuery = paymentsQuery.lte("paid_at", end);
      usersQuery = usersQuery.lte("created_at", end);
      visitsQuery = visitsQuery.lte("created_at", end);
    }

    const [leads, pix, payments, users, visits] = await Promise.all([
      leadsQuery,
      pixQuery,
      paymentsQuery,
      usersQuery,
      visitsQuery
    ]);

    setStats({
      leadsToday: leads.count || 0,
      pixToday: pix.count || 0,
      paymentsToday: payments.count || 0,
      usersToday: users.count || 0,
      visitsToday: visits.count || 0
    });
  };

  const loadNotifications = async (silent = false) => {
    // Só mostrar loading na primeira carga inicial
    if (!silent && isInitialLoad) {
      setLoading(true);
    }
    
    const { startDate, endDate } = getDateRange();

    const allNotifications: Notification[] = [];

    // Leads novos
    if (filterType === "all" || filterType === "lead_novo") {
      let query = supabase
        .from("leads")
        .select("*")
        .gte("created_at", startDate.toISOString());
      if (endDate) query = query.lte("created_at", endDate.toISOString());
      const { data: leads } = await query.order("created_at", { ascending: false });

      leads?.forEach(lead => {
        allNotifications.push({
          id: `lead_${lead.id}`,
          type: "lead_novo",
          timestamp: lead.created_at,
          data: lead
        });
      });
    }

    // Usuários cadastrados
    if (filterType === "all" || filterType === "usuario_cadastrado") {
      let query = supabase
        .from("profiles")
        .select("*")
        .gte("created_at", startDate.toISOString());
      if (endDate) query = query.lte("created_at", endDate.toISOString());
      const { data: users } = await query.order("created_at", { ascending: false });

      users?.forEach(user => {
        allNotifications.push({
          id: `user_${user.id}`,
          type: "usuario_cadastrado",
          timestamp: user.created_at,
          data: user
        });
      });
    }

    // PIX gerados (pending ou expired com payment method pix)
    if (filterType === "all" || filterType === "pix_gerado") {
      let query = supabase
        .from("checkout_sessions")
        .select("*")
        .in("status", ["pending", "expired"])
        .or("payment_method.is.null,payment_method.eq.pix")
        .gte("created_at", startDate.toISOString());
      if (endDate) query = query.lte("created_at", endDate.toISOString());
      const { data: pixPending } = await query.order("created_at", { ascending: false });

      pixPending?.forEach(pix => {
        allNotifications.push({
          id: `pix_${pix.id}`,
          type: "pix_gerado",
          timestamp: pix.created_at,
          data: { ...pix, isExpired: pix.status === 'expired' }
        });
      });
    }

    // Cartão de crédito PAGO (transação aprovada)
    if (filterType === "all" || filterType === "cartao_pago") {
      let query = supabase
        .from("checkout_sessions")
        .select("*")
        .eq("status", "paid")
        .eq("payment_method", "credit_card")
        .gte("paid_at", startDate.toISOString());
      if (endDate) query = query.lte("paid_at", endDate.toISOString());
      const { data: cardPaid } = await query.order("paid_at", { ascending: false });

      cardPaid?.forEach(card => {
        allNotifications.push({
          id: `card_paid_${card.id}`,
          type: "cartao_pago",
          timestamp: card.paid_at || card.created_at,
          data: card
        });
      });
    }

    // Cartão de crédito RECUSADO (transação falhou)
    if (filterType === "all" || filterType === "cartao_recusado") {
      let query = supabase
        .from("checkout_sessions")
        .select("*")
        .in("status", ["failed", "canceled"])
        .eq("payment_method", "credit_card")
        .gte("created_at", startDate.toISOString());
      if (endDate) query = query.lte("created_at", endDate.toISOString());
      const { data: cardFailed } = await query.order("created_at", { ascending: false });

      cardFailed?.forEach(card => {
        allNotifications.push({
          id: `card_failed_${card.id}`,
          type: "cartao_recusado",
          timestamp: card.created_at,
          data: card
        });
      });
    }

    // Pagamentos confirmados
    if (filterType === "all" || filterType === "pagamento_confirmado") {
      let query = supabase
        .from("checkout_sessions")
        .select("*")
        .eq("status", "paid")
        .gte("paid_at", startDate.toISOString());
      if (endDate) query = query.lte("paid_at", endDate.toISOString());
      const { data: pixPaid } = await query.order("paid_at", { ascending: false });

      pixPaid?.forEach(pix => {
        allNotifications.push({
          id: `payment_${pix.id}`,
          type: "pagamento_confirmado",
          timestamp: pix.paid_at || pix.created_at,
          data: pix
        });
      });
    }

    // Solicitações de saque
    if (filterType === "all" || filterType === "solicitacao_saque") {
      let query = supabase
        .from("withdrawal_requests")
        .select("*")
        .gte("created_at", startDate.toISOString());
      if (endDate) query = query.lte("created_at", endDate.toISOString());
      const { data: withdrawals } = await query.order("created_at", { ascending: false });

      withdrawals?.forEach(withdrawal => {
        allNotifications.push({
          id: `withdrawal_${withdrawal.id}`,
          type: "solicitacao_saque",
          timestamp: withdrawal.created_at,
          data: withdrawal
        });
      });
    }

    // Compras realizadas
    if (filterType === "all" || filterType === "compra_realizada") {
      let query = supabase
        .from("user_purchases")
        .select("*, dramas(title)")
        .gte("purchased_at", startDate.toISOString());
      if (endDate) query = query.lte("purchased_at", endDate.toISOString());
      const { data: purchases } = await query.order("purchased_at", { ascending: false });

      purchases?.forEach(purchase => {
        allNotifications.push({
          id: `purchase_${purchase.id}`,
          type: "compra_realizada",
          timestamp: purchase.purchased_at,
          data: purchase
        });
      });
    }

    // Ordenar por timestamp
    allNotifications.sort((a, b) =>
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    // Detectar novas notificações e tocar som
    const currentIds = new Set(allNotifications.map(n => n.id));
    const previousIds = previousNotificationIdsRef.current;
    
    // Só tocar som se não for a primeira carga e se houver IDs novos
    if (!isInitialLoad && previousIds.size > 0 && soundEnabled) {
      const newIds = [...currentIds].filter(id => !previousIds.has(id));
      if (newIds.length > 0) {
        console.log(`🔔 ${newIds.length} nova(s) notificação(ões) detectada(s)!`);
        playNotificationSound();
      }
    }
    
    // Atualizar IDs anteriores
    previousNotificationIdsRef.current = currentIds;

    setNotifications(allNotifications);
    setLoading(false);
    setIsInitialLoad(false);
    setIsRefreshing(false);
  };

  const getNotificationConfig = (type: NotificationType) => {
    const configs = {
      lead_novo: {
        icon: Phone,
        color: "text-green-400",
        bgColor: "bg-green-500/10",
        borderColor: "border-green-500/30",
        label: "LEAD NOVO"
      },
      usuario_cadastrado: {
        icon: UserPlus,
        color: "text-blue-400",
        bgColor: "bg-blue-500/10",
        borderColor: "border-blue-500/30",
        label: "USUÁRIO CADASTRADO"
      },
      pix_gerado: {
        icon: QrCode,
        color: "text-fire-yellow-intense",
        bgColor: "bg-fire-yellow-intense/10",
        borderColor: "border-fire-yellow-intense/30",
        label: "PIX GERADO"
      },
      cartao_pago: {
        icon: CreditCard,
        color: "text-green-400",
        bgColor: "bg-green-500/10",
        borderColor: "border-green-500/30",
        label: "CARTÃO APROVADO"
      },
      cartao_recusado: {
        icon: CreditCard,
        color: "text-red-400",
        bgColor: "bg-red-500/10",
        borderColor: "border-red-500/30",
        label: "CARTÃO RECUSADO"
      },
      pagamento_confirmado: {
        icon: CheckCircle,
        color: "text-green-300",
        bgColor: "bg-green-400/10",
        borderColor: "border-green-400/30",
        label: "PAGAMENTO CONFIRMADO"
      },
      solicitacao_saque: {
        icon: Wallet,
        color: "text-fire-orange",
        bgColor: "bg-fire-orange/10",
        borderColor: "border-fire-orange/30",
        label: "SOLICITAÇÃO DE SAQUE"
      },
      compra_realizada: {
        icon: ShoppingBag,
        color: "text-pink-400",
        bgColor: "bg-pink-500/10",
        borderColor: "border-pink-500/30",
        label: "COMPRA REALIZADA"
      }
    };

    return configs[type];
  };

  const formatPhone = (phone: string) => {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 11) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`;
    }
    return phone;
  };

  const copyWhatsAppLink = (phone: string) => {
    const cleanPhone = phone.replace(/\D/g, '');
    const whatsappLink = `wa.me/+55${cleanPhone}`;
    
    navigator.clipboard.writeText(whatsappLink);
    toast.success("Link copiado!", {
      description: whatsappLink
    });
  };

  const renderNotificationContent = (notification: Notification) => {
    const config = getNotificationConfig(notification.type);
    const Icon = config.icon;
    const timeAgo = formatDistanceToNow(new Date(notification.timestamp), { 
      addSuffix: true, 
      locale: ptBR 
    });

    switch (notification.type) {
      case "lead_novo":
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 sm:mb-2 flex-wrap">
                <span className="font-mono text-white text-sm sm:text-base break-all">{formatPhone(notification.data.phone)}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-fire-orange hover:text-fire-yellow-intense hover:bg-fire-orange/20 shrink-0"
                  onClick={() => copyWhatsAppLink(notification.data.phone)}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
              <p className="text-xs sm:text-sm text-white/60 truncate">{notification.data.drama_title || "N/A"}</p>
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      case "usuario_cadastrado":
        const userPhone = notification.data.email?.replace("@doramassuper.internal", "");
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 sm:mb-2 flex-wrap">
                <span className="font-mono text-white text-sm sm:text-base break-all">{formatPhone(userPhone)}</span>
                {userPhone && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-fire-orange hover:text-fire-yellow-intense hover:bg-fire-orange/20 shrink-0"
                    onClick={() => copyWhatsAppLink(userPhone)}
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                )}
              </div>
              <p className="text-xs sm:text-sm text-white/60 truncate">{notification.data.full_name || "Nome não informado"}</p>
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      case "pix_gerado":
        const isExpired = notification.data.isExpired || notification.data.status === 'expired';
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className={`font-bold text-sm sm:text-base mb-1 ${isExpired ? 'text-red-400' : 'text-fire-yellow-intense'}`}>
                R$ {notification.data.amount?.toFixed(2)}
                {isExpired && <span className="ml-2 text-xs font-normal text-red-400/80">(EXPIRADO)</span>}
              </div>
              <p className="text-xs sm:text-sm text-white/60 truncate">{notification.data.customer_name || "Cliente anônimo"}</p>
              <p className={`text-xs mt-1 ${isExpired ? 'text-red-400/60' : 'text-fire-yellow-intense/60'}`}>
                {isExpired ? 'PIX expirado - não pago' : 'Aguardando pagamento PIX...'}
              </p>
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      case "cartao_pago":
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className="text-green-400 font-bold text-sm sm:text-base mb-1">
                R$ {notification.data.amount?.toFixed(2)}
              </div>
              <p className="text-xs sm:text-sm text-white/60 truncate">{notification.data.customer_name || "Cliente anônimo"}</p>
              <p className="text-xs text-green-400/60 mt-1">Pagamento com cartão aprovado ✓</p>
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      case "cartao_recusado":
        const declinedPhone = notification.data.customer_name;
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className="text-red-400 font-bold text-sm sm:text-base mb-1">
                R$ {notification.data.amount?.toFixed(2)}
              </div>
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className="font-mono text-white text-xs sm:text-sm break-all">{formatPhone(declinedPhone || "")}</span>
                {declinedPhone && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-fire-orange hover:text-fire-yellow-intense hover:bg-fire-orange/20 shrink-0"
                    onClick={() => copyWhatsAppLink(declinedPhone)}
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                )}
              </div>
              <p className="text-xs text-red-400/60 mt-1">Cartão recusado ✗</p>
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      case "pagamento_confirmado":
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className="text-green-300 font-bold text-sm sm:text-base mb-1">
                R$ {notification.data.amount?.toFixed(2)}
              </div>
              <p className="text-xs sm:text-sm text-white/60 truncate">{notification.data.customer_name || "Cliente anônimo"}</p>
              {notification.data.items && (
                <p className="text-xs text-white/40 mt-1">
                  {notification.data.items.length} dorama(s)
                </p>
              )}
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      case "solicitacao_saque":
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className="text-fire-orange font-bold text-sm sm:text-base mb-1">
                R$ {notification.data.amount?.toFixed(2)}
              </div>
              <p className="text-xs sm:text-sm text-white/60 truncate">{notification.data.full_name}</p>
              <p className="text-xs text-white/40 mt-1 break-all">
                PIX: {notification.data.pix_key}
              </p>
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      case "compra_realizada":
        return (
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
            <div className="flex-1 min-w-0">
              <div className="text-pink-400 font-bold text-sm sm:text-base mb-1">
                R$ {notification.data.amount?.toFixed(2)}
              </div>
              <p className="text-xs sm:text-sm text-white/60 truncate">
                {notification.data.dramas?.title || "Dorama"}
              </p>
            </div>
            <span className="text-xs text-white/40 whitespace-nowrap self-start sm:self-auto">{timeAgo}</span>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <Navbar />
      
      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 mb-6 sm:mb-8">
          <div>
            <h1 className="text-xl sm:text-3xl font-bold text-white mb-1 sm:mb-2">🔔 Central de Notificações</h1>
            <p className="text-sm sm:text-base text-white/60">Acompanhe todas as atividades do site em tempo real</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={toggleSound}
              variant="outline"
              size="icon"
              className={`border-fire-orange/50 ${
                soundEnabled 
                  ? 'bg-fire-orange/20 text-fire-orange hover:bg-fire-orange/30' 
                  : 'bg-transparent text-white/40 hover:bg-white/10'
              }`}
              title={soundEnabled ? "Som ativado - Clique para desativar" : "Som desativado - Clique para ativar"}
            >
              {soundEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
            </Button>
            <Button
              onClick={() => {
                loadNotifications();
                loadStats();
                toast.success("Atualizado!");
              }}
              disabled={isRefreshing}
              className="bg-fire-orange hover:bg-fire-yellow-intense text-white"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Atualizar
            </Button>
          </div>
        </div>

        {/* Resumo do Período */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 sm:gap-4 mb-6 sm:mb-8">
          <Card className="bg-gradient-to-br from-purple-500/20 to-purple-600/10 border-purple-500/30 p-3 sm:p-4">
            <div className="text-xl sm:text-2xl font-bold text-purple-400">{stats.visitsToday}</div>
            <div className="text-xs sm:text-sm text-white/60">Visitas ({getPeriodLabel()})</div>
          </Card>
          <Card className="bg-gradient-to-br from-green-500/20 to-green-600/10 border-green-500/30 p-3 sm:p-4">
            <div className="text-xl sm:text-2xl font-bold text-green-400">{stats.leadsToday}</div>
            <div className="text-xs sm:text-sm text-white/60">Leads ({getPeriodLabel()})</div>
          </Card>
          <Card className="bg-gradient-to-br from-fire-yellow-intense/20 to-fire-orange/10 border-fire-yellow-intense/30 p-3 sm:p-4">
            <div className="text-xl sm:text-2xl font-bold text-fire-yellow-intense">{stats.pixToday}</div>
            <div className="text-xs sm:text-sm text-white/60">PIX ({getPeriodLabel()})</div>
          </Card>
          <Card className="bg-gradient-to-br from-green-400/20 to-green-500/10 border-green-400/30 p-3 sm:p-4">
            <div className="text-xl sm:text-2xl font-bold text-green-300">{stats.paymentsToday}</div>
            <div className="text-xs sm:text-sm text-white/60">Pagamentos ({getPeriodLabel()})</div>
          </Card>
          <Card className="bg-gradient-to-br from-blue-400/20 to-blue-500/10 border-blue-400/30 p-3 sm:p-4">
            <div className="text-xl sm:text-2xl font-bold text-blue-400">{stats.usersToday}</div>
            <div className="text-xs sm:text-sm text-white/60">Usuários ({getPeriodLabel()})</div>
          </Card>
        </div>

        {/* Filtros */}
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mb-4 sm:mb-6">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-full sm:w-[180px] bg-charcoal-black border-fire-orange/30 text-white text-sm">
              <SelectValue placeholder="Tipo de evento" />
            </SelectTrigger>
            <SelectContent className="bg-charcoal-black border-fire-orange/30">
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="lead_novo">Leads</SelectItem>
              <SelectItem value="usuario_cadastrado">Usuários</SelectItem>
              <SelectItem value="pix_gerado">PIX Gerados</SelectItem>
              <SelectItem value="cartao_pago">Cartão Aprovado</SelectItem>
              <SelectItem value="cartao_recusado">Cartão Recusado</SelectItem>
              <SelectItem value="pagamento_confirmado">Pagamentos</SelectItem>
              <SelectItem value="solicitacao_saque">Saques</SelectItem>
              <SelectItem value="compra_realizada">Compras</SelectItem>
            </SelectContent>
          </Select>

          <Select 
            value={selectedDate ? "custom" : filterPeriod} 
            onValueChange={(val) => {
              if (val !== "custom") {
                setSelectedDate(undefined);
                setFilterPeriod(val);
              }
            }}
          >
            <SelectTrigger className="w-full sm:w-[180px] bg-charcoal-black border-fire-orange/30 text-white text-sm">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent className="bg-charcoal-black border-fire-orange/30">
              <SelectItem value="today">Hoje</SelectItem>
              <SelectItem value="yesterday">Ontem</SelectItem>
              <SelectItem value="7d">Últimos 7 dias</SelectItem>
              <SelectItem value="30d">Últimos 30 dias</SelectItem>
              <SelectItem value="90d">Últimos 90 dias</SelectItem>
              {selectedDate && <SelectItem value="custom">{format(selectedDate, "dd/MM/yyyy", { locale: ptBR })}</SelectItem>}
            </SelectContent>
          </Select>

          {/* Datepicker com calendário */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full sm:w-[200px] justify-start text-left font-normal bg-charcoal-black border-fire-orange/30 text-white text-sm",
                  selectedDate && "text-fire-orange"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? format(selectedDate, "dd/MM/yyyy", { locale: ptBR }) : "Escolher data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 bg-charcoal-black border-fire-orange/30" align="start">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                initialFocus
                locale={ptBR}
                className="p-3 pointer-events-auto"
                disabled={(date) => date > new Date()}
              />
            </PopoverContent>
          </Popover>

          {selectedDate && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearDateFilter}
              className="text-white/60 hover:text-white hover:bg-white/10"
            >
              Limpar
            </Button>
          )}
        </div>

        {/* Timeline de Notificações */}
        <div className="space-y-2 sm:space-y-3">
          {loading ? (
            <Card className="bg-charcoal-black border-fire-orange/20 p-4 sm:p-8 text-center">
              <p className="text-white/60 text-sm sm:text-base">Carregando notificações...</p>
            </Card>
          ) : notifications.length === 0 ? (
            <Card className="bg-charcoal-black border-fire-orange/20 p-4 sm:p-8 text-center">
              <p className="text-white/60 text-sm sm:text-base">Nenhuma notificação encontrada</p>
            </Card>
          ) : (
            notifications.map((notification) => {
              const config = getNotificationConfig(notification.type);
              const Icon = config.icon;

              return (
                <Card
                  key={notification.id}
                  className={`${config.bgColor} border ${config.borderColor} p-3 sm:p-4 transition-all hover:scale-[1.005] sm:hover:scale-[1.01]`}
                >
                  <div className="flex items-start gap-2 sm:gap-3">
                    <div className={`${config.color} mt-0.5 sm:mt-1 shrink-0`}>
                      <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`${config.color} font-bold text-xs sm:text-sm mb-1 sm:mb-2`}>
                        {config.label}
                      </div>
                      {renderNotificationContent(notification)}
                    </div>
                  </div>
                </Card>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default Notifications;
