import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Area, AreaChart, XAxis, YAxis, ResponsiveContainer, Legend } from "recharts";
import { ArrowLeft, Eye, DollarSign, QrCode, Phone, Users, TrendingUp } from "lucide-react";

interface TopDrama {
  id: string;
  title: string;
  thumbnail_url: string | null;
  view_count: number;
}

interface TopSearchTerm {
  term: string;
  search_count: number;
}

interface TopClickedDrama {
  id: string;
  title: string;
  click_count: number;
}

interface ChartDataPoint {
  date: string;
  displayDate: string;
  visits: number;
  sales: number;
  pix: number;
  leads: number;
  users: number;
}

interface SummaryData {
  visits: number;
  sales: number;
  pix: number;
  leads: number;
  users: number;
}

const chartConfig = {
  visits: {
    label: "Visitas",
    color: "#FFD03C",
  },
  sales: {
    label: "Vendas",
    color: "#22C55E",
  },
  pix: {
    label: "PIX Gerados",
    color: "#3B82F6",
  },
  leads: {
    label: "Leads",
    color: "#FF6A00",
  },
  users: {
    label: "Usuários",
    color: "#EF4444",
  },
};

export default function Reports() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [period, setPeriod] = useState("30");
  const [chartData, setChartData] = useState<ChartDataPoint[]>([]);
  const [summaryData, setSummaryData] = useState<SummaryData>({ visits: 0, sales: 0, pix: 0, leads: 0, users: 0 });
  const [topWatchedDramas, setTopWatchedDramas] = useState<TopDrama[]>([]);
  const [topSearchTerms, setTopSearchTerms] = useState<TopSearchTerm[]>([]);
  const [topClickedDramas, setTopClickedDramas] = useState<TopClickedDrama[]>([]);

  useEffect(() => {
    checkAdminAccess();
  }, []);

  useEffect(() => {
    if (isAdmin) {
      fetchAllData();
    }
  }, [period, isAdmin]);

  const checkAdminAccess = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
      return;
    }

    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id)
      .eq("role", "admin")
      .maybeSingle();

    if (!roleData) {
      navigate("/");
      return;
    }

    setIsAdmin(true);
    setLoading(false);
  };

  const fetchAllData = async () => {
    setDataLoading(true);
    await Promise.all([
      fetchChartData(),
      fetchTopWatchedDramas(),
      fetchTopSearchTerms(),
      fetchTopClickedDramas(),
    ]);
    setDataLoading(false);
  };

  const fetchChartData = async () => {
    const days = parseInt(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    const startDateStr = startDate.toISOString();

    // Fetch all data in parallel
    const [visitsRes, salesRes, pixRes, leadsRes, usersRes] = await Promise.all([
      supabase
        .from("page_visits")
        .select("created_at")
        .gte("created_at", startDateStr),
      supabase
        .from("transactions")
        .select("created_at")
        .eq("status", "paid")
        .gte("created_at", startDateStr),
      supabase
        .from("checkout_sessions")
        .select("created_at")
        .gte("created_at", startDateStr),
      supabase
        .from("leads")
        .select("created_at")
        .gte("created_at", startDateStr),
      supabase
        .from("profiles")
        .select("created_at")
        .gte("created_at", startDateStr),
    ]);

    // Create date range
    const dateMap: Record<string, ChartDataPoint> = {};
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split("T")[0];
      const displayDate = `${date.getDate().toString().padStart(2, "0")}/${(date.getMonth() + 1).toString().padStart(2, "0")}`;
      dateMap[dateStr] = {
        date: dateStr,
        displayDate,
        visits: 0,
        sales: 0,
        pix: 0,
        leads: 0,
        users: 0,
      };
    }

    // Aggregate data by date
    const aggregateByDate = (data: { created_at: string }[] | null, key: keyof ChartDataPoint) => {
      if (!data) return;
      data.forEach((item) => {
        const dateStr = item.created_at.split("T")[0];
        if (dateMap[dateStr]) {
          (dateMap[dateStr][key] as number)++;
        }
      });
    };

    aggregateByDate(visitsRes.data, "visits");
    aggregateByDate(salesRes.data, "sales");
    aggregateByDate(pixRes.data, "pix");
    aggregateByDate(leadsRes.data, "leads");
    aggregateByDate(usersRes.data, "users");

    const chartDataArray = Object.values(dateMap);
    setChartData(chartDataArray);

    // Calculate summary
    const summary: SummaryData = {
      visits: chartDataArray.reduce((acc, d) => acc + d.visits, 0),
      sales: chartDataArray.reduce((acc, d) => acc + d.sales, 0),
      pix: chartDataArray.reduce((acc, d) => acc + d.pix, 0),
      leads: chartDataArray.reduce((acc, d) => acc + d.leads, 0),
      users: chartDataArray.reduce((acc, d) => acc + d.users, 0),
    };
    setSummaryData(summary);
  };

  const fetchTopWatchedDramas = async () => {
    const days = parseInt(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const { data: viewsData } = await supabase
      .from("video_views")
      .select("drama_id")
      .gte("created_at", startDate.toISOString());

    if (!viewsData || viewsData.length === 0) {
      setTopWatchedDramas([]);
      return;
    }

    const dramaViewCounts: Record<string, number> = {};
    viewsData.forEach((view) => {
      dramaViewCounts[view.drama_id] = (dramaViewCounts[view.drama_id] || 0) + 1;
    });

    const sortedDramaIds = Object.entries(dramaViewCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([id]) => id);

    if (sortedDramaIds.length === 0) {
      setTopWatchedDramas([]);
      return;
    }

    const { data: dramasData } = await supabase
      .from("dramas")
      .select("id, title, thumbnail_url")
      .in("id", sortedDramaIds);

    if (dramasData) {
      const result: TopDrama[] = sortedDramaIds.map((id) => {
        const drama = dramasData.find((d) => d.id === id);
        return {
          id,
          title: drama?.title || "Desconhecido",
          thumbnail_url: drama?.thumbnail_url || null,
          view_count: dramaViewCounts[id],
        };
      });
      setTopWatchedDramas(result);
    }
  };

  const fetchTopSearchTerms = async () => {
    const days = parseInt(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const { data: searchData } = await supabase
      .from("search_queries")
      .select("query, user_id")
      .gte("created_at", startDate.toISOString());

    if (!searchData || searchData.length === 0) {
      setTopSearchTerms([]);
      return;
    }

    const termUserMap: Record<string, Set<string>> = {};
    searchData.forEach((search) => {
      const term = search.query.toLowerCase().trim();
      if (!termUserMap[term]) {
        termUserMap[term] = new Set();
      }
      if (search.user_id) {
        termUserMap[term].add(search.user_id);
      }
    });

    const termCounts: Record<string, number> = {};
    searchData.forEach((search) => {
      const term = search.query.toLowerCase().trim();
      termCounts[term] = (termCounts[term] || 0) + 1;
    });

    const filteredTerms = Object.entries(termCounts)
      .filter(([term]) => termUserMap[term].size >= 2)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([term, count]) => ({ term, search_count: count }));

    setTopSearchTerms(filteredTerms);
  };

  const fetchTopClickedDramas = async () => {
    const days = parseInt(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const { data: clickData } = await supabase
      .from("search_queries")
      .select("clicked_drama_id")
      .not("clicked_drama_id", "is", null)
      .gte("created_at", startDate.toISOString());

    if (!clickData || clickData.length === 0) {
      setTopClickedDramas([]);
      return;
    }

    const dramaClickCounts: Record<string, number> = {};
    clickData.forEach((click) => {
      if (click.clicked_drama_id) {
        dramaClickCounts[click.clicked_drama_id] = (dramaClickCounts[click.clicked_drama_id] || 0) + 1;
      }
    });

    const sortedDramaIds = Object.entries(dramaClickCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([id]) => id);

    if (sortedDramaIds.length === 0) {
      setTopClickedDramas([]);
      return;
    }

    const { data: dramasData } = await supabase
      .from("dramas")
      .select("id, title")
      .in("id", sortedDramaIds);

    if (dramasData) {
      const result: TopClickedDrama[] = sortedDramaIds.map((id) => {
        const drama = dramasData.find((d) => d.id === id);
        return {
          id,
          title: drama?.title || "Desconhecido",
          click_count: dramaClickCounts[id],
        };
      });
      setTopClickedDramas(result);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-fire-orange"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-6 sm:py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="flex items-center gap-3">
            <TrendingUp className="w-6 h-6 sm:w-8 sm:h-8 text-fire-orange" />
            <h1 className="text-2xl sm:text-3xl font-bold">Relatórios</h1>
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Últimos 7 dias</SelectItem>
                <SelectItem value="14">Últimos 14 dias</SelectItem>
                <SelectItem value="30">Últimos 30 dias</SelectItem>
                <SelectItem value="60">Últimos 60 dias</SelectItem>
                <SelectItem value="90">Últimos 90 dias</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => navigate("/admin")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Voltar</span>
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 mb-6">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Eye className="w-4 h-4 text-[#FFD03C]" />
                <span className="text-xs text-muted-foreground">Visitas</span>
              </div>
              <p className="text-xl sm:text-2xl font-bold">{summaryData.visits.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-[#22C55E]" />
                <span className="text-xs text-muted-foreground">Vendas</span>
              </div>
              <p className="text-xl sm:text-2xl font-bold">{summaryData.sales.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <QrCode className="w-4 h-4 text-[#3B82F6]" />
                <span className="text-xs text-muted-foreground">PIX Gerados</span>
              </div>
              <p className="text-xl sm:text-2xl font-bold">{summaryData.pix.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Phone className="w-4 h-4 text-[#FF6A00]" />
                <span className="text-xs text-muted-foreground">Leads</span>
              </div>
              <p className="text-xl sm:text-2xl font-bold">{summaryData.leads.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border col-span-2 sm:col-span-1">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-[#EF4444]" />
                <span className="text-xs text-muted-foreground">Usuários</span>
              </div>
              <p className="text-xl sm:text-2xl font-bold">{summaryData.users.toLocaleString()}</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Chart */}
        <Card className="bg-card border-border mb-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Evolução ao Longo do Tempo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full h-[300px] sm:h-[400px]">
              <ChartContainer config={chartConfig} className="w-full h-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorVisits" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FFD03C" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#FFD03C" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#22C55E" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#22C55E" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorPix" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FF6A00" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#FF6A00" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis
                      dataKey="displayDate"
                      stroke="#666"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                      interval="preserveStartEnd"
                    />
                    <YAxis
                      stroke="#666"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                      width={30}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend
                      wrapperStyle={{ fontSize: "12px", paddingTop: "10px" }}
                      iconType="circle"
                      iconSize={8}
                    />
                    <Area
                      type="monotone"
                      dataKey="visits"
                      name="Visitas"
                      stroke="#FFD03C"
                      strokeWidth={2}
                      fill="url(#colorVisits)"
                    />
                    <Area
                      type="monotone"
                      dataKey="sales"
                      name="Vendas"
                      stroke="#22C55E"
                      strokeWidth={2}
                      fill="url(#colorSales)"
                    />
                    <Area
                      type="monotone"
                      dataKey="pix"
                      name="PIX"
                      stroke="#3B82F6"
                      strokeWidth={2}
                      fill="url(#colorPix)"
                    />
                    <Area
                      type="monotone"
                      dataKey="leads"
                      name="Leads"
                      stroke="#FF6A00"
                      strokeWidth={2}
                      fill="url(#colorLeads)"
                    />
                    <Area
                      type="monotone"
                      dataKey="users"
                      name="Usuários"
                      stroke="#EF4444"
                      strokeWidth={2}
                      fill="url(#colorUsers)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </CardContent>
        </Card>

        {/* Top 10 Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Top Watched Dramas */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Top 10 Mais Assistidos</CardTitle>
            </CardHeader>
            <CardContent>
              {topWatchedDramas.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">Sem dados</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">#</TableHead>
                      <TableHead className="text-xs">Filme</TableHead>
                      <TableHead className="text-xs text-right">Views</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topWatchedDramas.map((drama, index) => (
                      <TableRow key={drama.id}>
                        <TableCell className="text-xs font-medium">{index + 1}</TableCell>
                        <TableCell className="text-xs max-w-[120px] truncate">{drama.title}</TableCell>
                        <TableCell className="text-xs text-right">{drama.view_count}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Top Search Terms */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Top 10 Pesquisas</CardTitle>
            </CardHeader>
            <CardContent>
              {topSearchTerms.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">Sem dados</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">#</TableHead>
                      <TableHead className="text-xs">Termo</TableHead>
                      <TableHead className="text-xs text-right">Buscas</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topSearchTerms.map((term, index) => (
                      <TableRow key={term.term}>
                        <TableCell className="text-xs font-medium">{index + 1}</TableCell>
                        <TableCell className="text-xs max-w-[120px] truncate">{term.term}</TableCell>
                        <TableCell className="text-xs text-right">{term.search_count}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Top Clicked Dramas */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Top 10 Clicados na Busca</CardTitle>
            </CardHeader>
            <CardContent>
              {topClickedDramas.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">Sem dados</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">#</TableHead>
                      <TableHead className="text-xs">Filme</TableHead>
                      <TableHead className="text-xs text-right">Cliques</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topClickedDramas.map((drama, index) => (
                      <TableRow key={drama.id}>
                        <TableCell className="text-xs font-medium">{index + 1}</TableCell>
                        <TableCell className="text-xs max-w-[120px] truncate">{drama.title}</TableCell>
                        <TableCell className="text-xs text-right">{drama.click_count}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
