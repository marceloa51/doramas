import { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

export default function ReferralRedirect() {
  const { username } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (username) {
      sessionStorage.setItem("ref_code", username);
      console.log(`Referral username captured: ${username}`);
      navigate("/auth");
    } else {
      navigate("/");
    }
  }, [username, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <p className="text-muted-foreground">Redirecionando...</p>
      </div>
    </div>
  );
}
