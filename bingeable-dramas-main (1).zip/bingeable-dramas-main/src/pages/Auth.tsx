import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/ui/password-input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { SITE_URL } from "@/config/site";
import { generateSessionId, saveSessionId, getDeviceFingerprint, getClientIp } from "@/utils/sessionManager";
import { PasswordResetModal } from "@/components/PasswordResetModal";

const Auth = () => {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Verificar se há um fluxo de reset de senha em andamento ao carregar
  const [showResetModal, setShowResetModal] = useState(() => {
    const saved = localStorage.getItem('password_reset_state');
    if (saved) {
      try {
        const state = JSON.parse(saved);
        // Se estava no meio do fluxo (step > 1) e não expirou, reabrir modal
        if (state.step > 1 && state.expiresAt && Date.now() < state.expiresAt) {
          return true;
        }
      } catch (e) {
        // Ignorar erro de parse
      }
    }
    return false;
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  const formatPhoneNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        // Verificar se existe redirect query param
        const params = new URLSearchParams(window.location.search);
        const redirectPath = params.get('redirect');
        
        // Validar que o redirect é uma rota interna válida (começa com /)
        if (redirectPath && redirectPath.startsWith('/')) {
          navigate(redirectPath);
        } else {
          navigate("/");
        }
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validação do nome no cadastro
      if (isSignUp) {
        if (!fullName.trim() || fullName.trim().length < 3) {
          throw new Error("Por favor, informe seu nome completo");
        }
      }

      const cleanPhone = phone.replace(/\D/g, '');
      
      if (cleanPhone.length < 10 || cleanPhone.length > 11) {
        throw new Error("Número de telefone inválido");
      }

      const userEmail = `${cleanPhone}@doramassuper.internal`;

      if (isSignUp) {
        // Signup
        const { error } = await supabase.auth.signUp({
          email: userEmail,
          password,
          options: {
            emailRedirectTo: `${SITE_URL}/`,
            data: {
              full_name: fullName || undefined,
            }
          }
        });

        if (error) throw error;

        await createUserSession();

        // Enviar webhook para usuário cadastrado (async, não bloqueia)
        // Não envia se usuário for VIP (verificado na edge function)
        supabase.functions.invoke('send-user-registered-webhook', {
          body: { phone: cleanPhone, fullName }
        }).then(result => {
          console.log('[Auth] Webhook result:', result.data);
        }).catch(err => {
          console.error('[Auth] Webhook error:', err);
        });

        toast({
          title: "Conta criada com sucesso!",
          description: "Você já pode assistir aos doramas.",
        });
      } else {
        // Login
        const { error } = await supabase.auth.signInWithPassword({
          email: userEmail,
          password,
        });

        if (error) throw error;

        await createUserSession();

        toast({
          title: "Bem-vindo de volta!",
          description: "Login realizado com sucesso.",
        });
      }
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const createUserSession = async () => {
    try {
      const sessionId = generateSessionId();
      saveSessionId(sessionId);

      const deviceFingerprint = getDeviceFingerprint();
      const userIp = await getClientIp();

      await supabase.functions.invoke('create-session', {
        body: {
          sessionId,
          deviceFingerprint,
          userIp,
        },
      });

      console.log('[Auth] Session created successfully');
    } catch (error) {
      console.error('[Auth] Error creating session:', error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
        <title>Login | Doramas Super</title>
      </Helmet>

      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-fire-orange/5 to-transparent" />

      <Card className="w-full max-w-md p-8 bg-drama-card border-drama-border relative z-10">
        {/* Logo */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-display font-black mb-2">
            <span className="text-fire-primary">DORAMAS</span>
            <span className="text-fire-yellow-intense"> SUPER</span>
          </h1>
          <p className="text-muted-foreground">
            {isSignUp ? "Crie sua conta com telefone" : "Entre na sua conta com seu telefone"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
          <div className="space-y-2">
            <Label htmlFor="fullName">Nome Completo</Label>
            <Input
              id="fullName"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value.replace(/[^a-zA-ZÀ-ÿ\s]/g, ''))}
              required
              className="bg-background border-drama-border"
              placeholder="Seu nome completo"
              minLength={3}
            />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="phone">Número de Telefone</Label>
            <Input
              id="phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
              required
              className="bg-background border-drama-border"
              placeholder="(11) 99999-9999"
              maxLength={15}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">{isSignUp ? "Crie uma Senha" : "Senha"}</Label>
            <PasswordInput
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="bg-background border-drama-border"
              placeholder="••••••••"
              minLength={6}
              autoComplete={isSignUp ? "new-password" : "current-password"}
            />
            {!isSignUp && (
              <div className="text-right">
                <button
                  type="button"
                  onClick={() => setShowResetModal(true)}
                  className="text-xs text-muted-foreground hover:text-fire-orange transition-smooth underline"
                >
                  Esqueci minha senha
                </button>
              </div>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold"
            disabled={loading || (isSignUp && fullName.trim().length < 3)}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processando...
              </>
            ) : (
              isSignUp ? "Cadastrar" : "Entrar"
            )}
          </Button>
        </form>

        <div className="mt-6 space-y-3">
          <div className="text-center">
            <button
              type="button"
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-sm text-muted-foreground hover:text-fire-orange transition-smooth"
            >
              {isSignUp ? "Já tem uma conta? " : "Não tem conta? "}
              <span className="font-bold underline">
                {isSignUp ? "Entre aqui" : "Cadastre-se"}
              </span>
            </button>
          </div>
          
          {!isSignUp && (
            <Button
              type="button"
              variant="default"
              className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:from-fire-orange-light hover:to-fire-yellow font-bold py-6"
              onClick={() => setIsSignUp(true)}
            >
              Cadastre-se
            </Button>
          )}
          
          <p className="text-center text-sm text-muted-foreground">
            Ou faça seu primeiro pagamento para criar conta automaticamente
          </p>
        </div>
      </Card>

      {/* Modal de Recuperação de Senha */}
      <PasswordResetModal 
        open={showResetModal} 
        onOpenChange={setShowResetModal}
      />
    </div>
  );
};

export default Auth;
