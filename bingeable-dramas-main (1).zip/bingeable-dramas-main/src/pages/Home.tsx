import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";

import { DramaCarousel } from "@/components/DramaCarousel";
import { ContinueWatchingCard } from "@/components/ContinueWatchingCard";
import { Button } from "@/components/ui/button";
import { Play, Sparkles, Settings, MousePointerClick, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type PlanStatus = Database["public"]["Enums"]["plan_status"];

interface Drama {
  id: string;
  title: string;
  slug: string;
  synopsis: string;
  thumbnail_url: string;
  cover_url: string;
  genres: string[];
  total_episodes: number;
  created_at: string;
}

interface WatchProgress {
  id: string;
  drama_id: string;
  position_seconds: number;
  duration_seconds: number;
  progress_percent: number;
  drama?: Drama;
}

const Home = () => {
  const [featuredDrama, setFeaturedDrama] = useState<Drama | null>(null);
  const [continueWatching, setContinueWatching] = useState<WatchProgress[]>([]);
  const [topAllTime, setTopAllTime] = useState<Drama[]>([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [planStatus, setPlanStatus] = useState<PlanStatus>("none");
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    checkAuth();
    fetchAllData();
  }, []);

  const checkAuth = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (session?.user) {
      setUserId(session.user.id);
      fetchPlanStatus(session.user.id);
      checkAdminStatus(session.user.id);
      fetchContinueWatching(session.user.id);
    }
  };

  const checkAdminStatus = async (uid: string) => {
    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", uid)
      .eq("role", "admin");

    if (roles && roles.length > 0) {
      setIsAdmin(true);
    }
  };

  const fetchPlanStatus = async (uid: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("plan_status")
      .eq("id", uid)
      .single();

    if (data?.plan_status) {
      setPlanStatus(data.plan_status);
    }
  };

  const fetchContinueWatching = async (uid: string) => {
    try {
      const { data, error } = await supabase
        .from("watch_progress")
        .select(`
          *,
          drama:dramas(*)
        `)
        .eq("user_id", uid)
        .lt("progress_percent", 90)
        .order("updated_at", { ascending: false })
        .limit(10);

      if (error) throw error;

      if (data) {
        const progressWithDrama = data
          .filter((item) => item.drama)
          .map((item) => ({
            ...item,
            drama: Array.isArray(item.drama) ? item.drama[0] : item.drama,
          }));
        setContinueWatching(progressWithDrama as WatchProgress[]);
      }
    } catch (error) {
      console.error("Error fetching continue watching:", error);
    }
  };

  const fetchAllData = async () => {
    try {
      // Buscar o drama configurado como hero
      const { data: heroData } = await supabase
        .from("featured_dramas")
        .select(`drama:dramas(*)`)
        .eq("section", "hero")
        .maybeSingle();

      // Se existir hero configurado, usa ele
      if (heroData?.drama) {
        const drama = Array.isArray(heroData.drama) 
          ? heroData.drama[0] 
          : heroData.drama;
        setFeaturedDrama(drama as Drama);
      } else {
        // Fallback: pega o mais recente como antes
        const { data: allDramas, error } = await supabase
          .from("dramas")
          .select("*")
          .eq("status", "active")
          .order("created_at", { ascending: false })
          .limit(1);
        
        if (error) throw error;
        
        if (allDramas && allDramas.length > 0) {
          setFeaturedDrama(allDramas[0]);
        }
      }

      // Buscar todos os dramas para as estatísticas
      const { data: allDramas } = await supabase
        .from("dramas")
        .select("*")
        .eq("status", "active")
        .order("created_at", { ascending: false });
      
      if (allDramas && allDramas.length > 0) {
        await fetchTopStats(allDramas);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTopStats = async (allDramas: Drama[]) => {
    try {
      // Primeiro busca doramas em destaque configurados pelos admins
      const { data: featuredData } = await supabase
        .from("featured_dramas")
        .select(`
          drama_id,
          position,
          drama:dramas(*)
        `)
        .eq("section", "top_all_time")
        .order("position", { ascending: true })
        .limit(5);

      if (featuredData && featuredData.length > 0) {
        const featured = featuredData
          .map((item) => {
            const drama = Array.isArray(item.drama) ? item.drama[0] : item.drama;
            return drama;
          })
          .filter(Boolean) as Drama[];
        
        setTopAllTime(featured);
        return;
      }

      // Fallback: usa estatísticas reais se não houver destaques configurados
      const { data: allTimeViews } = await supabase
        .from("video_views")
        .select("drama_id, watch_duration");

      const countViews = (views: any[] | null) => {
        if (!views) return new Map();
        const counts = new Map<string, number>();
        views.forEach((view) => {
          counts.set(view.drama_id, (counts.get(view.drama_id) || 0) + 1);
        });
        return counts;
      };

      const allTimeCounts = countViews(allTimeViews);

      const sortByViews = (counts: Map<string, number>) => {
        return allDramas
          .sort((a, b) => (counts.get(b.id) || 0) - (counts.get(a.id) || 0))
          .slice(0, 5);
      };

      setTopAllTime(sortByViews(allTimeCounts));
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Doramas Super - Assista Doramas Dublados Online em HD</title>
        <meta name="description" content="Plataforma completa de doramas coreanos, chineses e tailandeses dublados em português. Streaming em HD sem anúncios. Assista agora!" />
        <link rel="canonical" href="https://doramassuper.site/" />
        <meta property="og:title" content="Doramas Super - Assista Doramas Dublados Online em HD" />
        <meta property="og:description" content="Plataforma completa de doramas dublados em português. Streaming em HD sem anúncios." />
        <meta property="og:url" content="https://doramassuper.site/" />
        <meta property="og:type" content="website" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "Doramas Super",
            "url": "https://doramassuper.site",
            "description": "Plataforma completa de doramas dublados em português com streaming em HD",
            "inLanguage": "pt-BR",
            "potentialAction": {
              "@type": "SearchAction",
              "target": "https://doramassuper.site/explorar?search={search_term_string}",
              "query-input": "required name=search_term_string"
            }
          })}
        </script>
      </Helmet>

      {/* Hidden SEO Content */}
      <div className="sr-only">
        <h1>Doramas Super - A Melhor Plataforma de Doramas Dublados</h1>
        <p>Assista aos melhores doramas coreanos, chineses e tailandeses dublados em português com qualidade HD. Nossa plataforma oferece streaming sem anúncios, lançamentos exclusivos e um catálogo completo de dramas asiáticos. Descubra histórias emocionantes de romance, ação, comédia e drama familiar. Maratone seus doramas favoritos com qualidade profissional.</p>
      </div>

      <Navbar />
      <div className="h-16"></div>

      {featuredDrama && (
        <section className="relative h-[60vh] sm:h-[70vh] md:h-[85vh] flex items-end">
          <div className="absolute inset-0 bg-drama-dark">
            <img
              src={featuredDrama.cover_url || featuredDrama.thumbnail_url || "/placeholder.svg"}
              alt={featuredDrama.title}
              loading="lazy"
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = "none";
              }}
            />
            <div className="absolute inset-0 gradient-hero" />
          </div>

          <div className="relative container mx-auto px-4 pb-12 sm:pb-16 md:pb-20 z-10">
            <div className="max-w-2xl space-y-3 sm:space-y-4">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-fire-yellow-intense" />
                <span className="px-3 py-1 rounded-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white text-xs sm:text-sm font-semibold uppercase tracking-wider">
                  Em Destaque
                </span>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-white leading-tight">
                {featuredDrama.title}
              </h1>

              <p className="text-sm sm:text-base md:text-lg text-gray-200 line-clamp-2 sm:line-clamp-3">
                {featuredDrama.synopsis}
              </p>

              <div className="flex flex-wrap gap-2 text-xs sm:text-sm">
                {featuredDrama.genres?.slice(0, 3).map((genre) => (
                  <span key={genre} className="px-2 py-1 bg-fire-orange/20 rounded text-fire-yellow-intense font-semibold">
                    {genre}
                  </span>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2 sm:pt-4">
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-fire-orange-burnt via-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold"
                  onClick={() => navigate(`/movie/${featuredDrama.slug}`)}
                >
                  <Play className="w-4 h-4 sm:w-5 sm:h-5 mr-2 fill-white" />
                  Assistir Agora
                </Button>

                {isAdmin && (
                  <>
                    <Button
                      size="lg"
                      variant="outline"
                      className="w-full sm:w-auto border-fire-orange text-fire-orange hover:bg-fire-orange hover:text-white"
                      onClick={() => navigate("/admin/featured")}
                    >
                      <Settings className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                      Trocar Destaque
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      <section className="container mx-auto px-0 py-8 sm:py-12">
        {userId && continueWatching.length > 0 && (
          <div className="mb-8 sm:mb-12">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 px-4">
              Continuar Assistindo
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 px-4">
              {continueWatching.map((item) => (
                <ContinueWatchingCard
                  key={item.id}
                  id={item.drama_id}
                  title={item.drama?.title || ""}
                  slug={item.drama?.slug || ""}
                  thumbnail={item.drama?.thumbnail_url || ""}
                  progress={item.progress_percent}
                />
              ))}
            </div>
          </div>
        )}

        {topAllTime.length > 0 && (
          <DramaCarousel
            title="Mais Assistidos"
            dramas={topAllTime}
            loading={loading}
          />
        )}

        {/* Botão Ver Todos os Doramas */}
        <div className="flex justify-center mt-8 mb-12 px-4">
          <Button
            size="lg"
            onClick={() => navigate("/explorar")}
            className="w-full sm:w-auto min-w-[280px] py-6 text-lg font-bold bg-gradient-to-r from-fire-orange-burnt via-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white rounded-xl transition-all duration-300"
          >
            <MousePointerClick className="w-6 h-6 mr-3" />
            Ver todos os doramas
            <ChevronRight className="w-6 h-6 ml-2" />
          </Button>
        </div>
      </section>
    </div>
  );
};

export default Home;
