import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import VideoPlayer from "@/components/VideoPlayer";
import BunnyPlayer from "@/components/BunnyPlayer";
import DoramasHlsPlayer from "@/components/DoramasHlsPlayer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { analyzeVideoUrl, bunnyEmbedToHls } from "@/utils/videoDetector";
import { LegalDisclaimer } from "@/components/LegalDisclaimer";
import { generateDramaSEO } from "@/utils/seoGenerator";

interface Movie {
  id: string;
  title: string;
  slug: string;
  synopsis: string;
  cover_url: string | null;
  thumbnail_url: string | null;
  genres: string[];
  tags: string[] | null;
  file_url: string | null;
  video_url?: string | null;
  created_at?: string | null;
  start_position_seconds: number | null;
}

const Movie = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);
  const [isPremium, setIsPremium] = useState(false);
  const [hasPurchased, setHasPurchased] = useState(false);
  const [checkingPurchase, setCheckingPurchase] = useState(true);

  useEffect(() => {
    fetchMovieData();
    checkUserPlan();
  }, [slug]);

  // Verificar compra APÓS o movie ser carregado
  useEffect(() => {
    if (movie?.id) {
      checkPurchaseStatus();
    } else {
      setCheckingPurchase(false);
    }
  }, [movie?.id]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        checkUserPlan();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);

  const fetchMovieData = async () => {
    try {
      const { data: movieData, error: movieError } = await supabase
        .from("dramas")
        .select("*")
        .eq("slug", slug)
        .single();

      if (movieError) throw movieError;
      setMovie(movieData);
    } catch (error) {
      console.error("Error fetching movie:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar o filme.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const checkUserPlan = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      console.log("Movie: Usuário não logado");
      setIsPremium(false);
      return;
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("plan_status")
      .eq("id", session.user.id)
      .single();

    if (profile?.plan_status === "active") {
      setIsPremium(true);
    } else {
      setIsPremium(false);
    }
  };

  const checkPurchaseStatus = async () => {
    setCheckingPurchase(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session || !movie?.id) {
        console.log("[Movie] Sem sessão ou movie.id para verificar compra");
        setHasPurchased(false);
        return;
      }

      console.log("[Movie] Verificando compra para drama:", movie.id, "user:", session.user.id);

      const { data } = await supabase
        .from("user_purchases")
        .select("id")
        .eq("user_id", session.user.id)
        .eq("drama_id", movie.id)
        .maybeSingle();

      console.log("[Movie] Resultado da verificação de compra:", !!data);
      setHasPurchased(!!data);
    } finally {
      setCheckingPurchase(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-8">
            <div className="h-96 bg-card rounded-lg" />
            <div className="h-8 bg-card rounded w-3/4" />
            <div className="h-4 bg-card rounded w-1/2" />
          </div>
        </div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="h-16"></div>
        <div className="container mx-auto px-4 py-8">
          <div className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Filme não encontrado</h2>
            <Button onClick={() => navigate("/")}>Voltar para Home</Button>
          </div>
        </div>
      </div>
    );
  }

  const seoData = generateDramaSEO(movie, "movie");

  const effectiveVideoUrl = movie.file_url || movie.video_url || null;
  const analyzed = effectiveVideoUrl ? analyzeVideoUrl(effectiveVideoUrl) : null;

  console.log('[Movie] Análise de vídeo:', {
    effectiveVideoUrl,
    analyzed,
    userAgent: navigator.userAgent.substring(0, 100),
  });

  // Converter URLs Bunny iframe para HLS para usar player nativo
  let playerType = analyzed?.type ?? null;
  let finalVideoUrl = effectiveVideoUrl;
  let originalBunnyUrl: string | null = null;

  if (analyzed?.type === "bunny") {
    const hlsFromBunny = bunnyEmbedToHls(analyzed.url);
    console.log('[Movie] Tentativa de conversão Bunny->HLS:', {
      original: analyzed.url,
      hls: hlsFromBunny,
    });
    
    if (hlsFromBunny) {
      playerType = "hls";
      finalVideoUrl = hlsFromBunny;
      originalBunnyUrl = analyzed.url; // Guardar para fallback
    } else {
      // Se conversão falhar, manter iframe Bunny
      console.warn('[Movie] Conversão Bunny->HLS falhou, usando iframe');
      playerType = "bunny";
      finalVideoUrl = analyzed.url;
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{seoData.title}</title>
        <meta name="description" content={seoData.description} />
        <meta name="keywords" content={seoData.keywords.join(", ")} />
        <link rel="canonical" href={seoData.canonical} />
        
        {/* Open Graph */}
        <meta property="og:title" content={seoData.ogTitle} />
        <meta property="og:description" content={seoData.ogDescription} />
        <meta property="og:url" content={seoData.canonical} />
        <meta property="og:type" content="video.movie" />
        <meta property="og:image" content={seoData.ogImage} />
        <meta property="og:site_name" content="Doramas Super" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={seoData.ogTitle} />
        <meta name="twitter:description" content={seoData.ogDescription} />
        <meta name="twitter:image" content={seoData.ogImage} />
        
        {/* Schema.org */}
        <script type="application/ld+json">
          {JSON.stringify(seoData.schema)}
        </script>
      </Helmet>

      <Navbar />
      
      {/* Espaçador para compensar o navbar fixo */}
      <div className="h-16"></div>
      
      <div className="container mx-auto px-4 py-6 pb-12">
        {/* Video Player */}
        <div className="mb-8">
          {checkingPurchase ? (
            <div className="relative w-full aspect-video bg-card rounded-lg flex items-center justify-center border border-border">
              <p className="text-muted-foreground">Carregando...</p>
            </div>
          ) : finalVideoUrl && playerType ? (
            playerType === 'hls' ? (
              <DoramasHlsPlayer
                key={movie.id}
                hlsUrl={finalVideoUrl}
                dramaTitle={movie.title}
                dramaId={movie.id}
                isPremium={isPremium || hasPurchased}
                thumbnailUrl={movie.thumbnail_url || movie.cover_url || undefined}
                previewSeconds={1500}
                startPositionSeconds={movie.start_position_seconds || 0}
              />
            ) : playerType === 'bunny' ? (
              <BunnyPlayer
                key={movie.id}
                videoUrl={finalVideoUrl}
                thumbnailUrl={movie.thumbnail_url || movie.cover_url || undefined}
                dramaTitle={movie.title}
                dramaId={movie.id}
                isPremium={isPremium || hasPurchased}
                startPositionSeconds={movie.start_position_seconds || 0}
              />
            ) : (
              <VideoPlayer
                key={movie.id}
                videoUrl={finalVideoUrl}
                thumbnailUrl={movie.thumbnail_url || movie.cover_url || undefined}
                dramaTitle={movie.title}
                dramaId={movie.id}
                isPremium={isPremium || hasPurchased}
                startPositionSeconds={movie.start_position_seconds || 0}
              />
            )
          ) : (
            <div className="relative w-full aspect-video bg-card rounded-lg flex items-center justify-center border border-border">
              <p className="text-muted-foreground">Vídeo não disponível</p>
            </div>
          )}
        </div>

        {/* Movie Info */}
        <div className="space-y-6">
          <div>
            <div className="flex items-start gap-2 sm:gap-3 mb-3">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-drama-red flex-shrink-0 mt-1" />
              <h1 className="text-xl sm:text-2xl md:text-4xl font-bold leading-tight break-words">{movie.title}</h1>
            </div>
            
            <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-4">
              {movie.genres && movie.genres.map((genre) => (
                <Badge key={genre} variant="secondary" className="bg-drama-red/20 text-drama-red border-drama-red/30 text-xs sm:text-sm">
                  {genre}
                </Badge>
              ))}
              
              {movie.tags && movie.tags.length > 0 && (
                movie.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="border-muted-foreground/30 text-xs sm:text-sm">
                    {tag}
                  </Badge>
                ))
              )}
            </div>
          </div>

          {movie.synopsis && (
            <div className="prose prose-invert max-w-none">
              <h2 className="text-lg sm:text-xl font-semibold mb-3">SINOPSE</h2>
              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed break-words">
                {movie.synopsis}
              </p>
            </div>
          )}

          <div className="pt-6 border-t border-white/10">
            <Button
              variant="outline"
              onClick={() => navigate("/")}
              className="hover:bg-accent"
            >
              ← Voltar para Home
            </Button>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <div className="mt-12">
          <LegalDisclaimer />
        </div>
      </div>
    </div>
  );
};

export default Movie;
