import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Play, Lock, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { getSessionId, clearSessionId, clearSupabaseAuthStorage } from "@/utils/sessionManager";
import { toast } from "sonner";

interface VideoPlayerProps {
  videoUrl: string;
  thumbnailUrl?: string;
  dramaTitle: string;
  dramaId: string;
  isPremium: boolean;
  startPositionSeconds?: number;
}

const LEAD_CAPTURE_TIME = 600; // 10 minutes in seconds
const EXTENDED_PREVIEW_LIMIT = 1500; // 25 minutes (10 + 15 extra) in seconds

const VideoPlayer = ({ videoUrl, thumbnailUrl, dramaTitle, dramaId, isPremium, startPositionSeconds = 0 }: VideoPlayerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  const [watchedTime, setWatchedTime] = useState(0);
  const [showPreview, setShowPreview] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedPosition, setSavedPosition] = useState<number>(0);
  const [isBuffering, setIsBuffering] = useState(true);
  const [showSlowConnectionWarning, setShowSlowConnectionWarning] = useState(false);
  const [sessionInvalid, setSessionInvalid] = useState(false);
  const lastSaveTime = useRef<number>(0);
  const navigate = useNavigate();

  // Lead capture states
  const [showLeadModal, setShowLeadModal] = useState(false);
  const [leadPhone, setLeadPhone] = useState("");
  const [leadSubmitted, setLeadSubmitted] = useState(false);
  const [extendedTime, setExtendedTime] = useState(false);
  const [leadModalShown, setLeadModalShown] = useState(false);
  const [isSubmittingLead, setIsSubmittingLead] = useState(false);

  useEffect(() => {
    const isMobile = /mobile/i.test(navigator.userAgent);
    console.log("[VideoPlayer] Inicializando:", {
      dramaId,
      dramaTitle,
      videoUrl,
      isPremium,
      isMobile,
      userAgent: navigator.userAgent.substring(0, 100),
      platform: navigator.platform,
    });
    
    // Detectar conexão lenta
    if ('connection' in navigator) {
      const conn = (navigator as any).connection;
      if (conn?.effectiveType === '3g' || conn?.effectiveType === '2g' || conn?.effectiveType === 'slow-2g') {
        setShowSlowConnectionWarning(true);
        console.warn("[VideoPlayer] Conexão lenta detectada:", conn.effectiveType);
      }
    }
    
    loadSavedProgress();
    
    // Verificar se usuário está logado
    const checkLeadStatus = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        console.log('[VideoPlayer] Usuário logado - pulando lead capture');
        setLeadSubmitted(true);
        setExtendedTime(true);
        return;
      }
      
      // Visitante anônimo: verificar localStorage
      const submitted = localStorage.getItem(`lead_submitted_${dramaId}`);
      if (submitted === 'true') {
        setLeadSubmitted(true);
        setExtendedTime(true);
      }
    };
    
    checkLeadStatus();
  }, [isPremium, videoUrl, dramaId]);

  // Auto-submit quando telefone completar 11 dígitos
  useEffect(() => {
    const phoneDigits = leadPhone.replace(/\D/g, '');
    if (phoneDigits.length === 11 && showLeadModal) {
      handleLeadSubmit();
    }
  }, [leadPhone, showLeadModal]);

  const loadSavedProgress = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user || !dramaId) return;

    const { data } = await supabase
      .from("watch_progress")
      .select("position_seconds")
      .eq("user_id", session.user.id)
      .eq("drama_id", dramaId)
      .single();

    if (data?.position_seconds) {
      setSavedPosition(data.position_seconds);
      console.log("[VideoPlayer] Posição salva encontrada:", data.position_seconds);
      // ✅ NÃO setar currentTime aqui - vai setar no onLoadedMetadata
    }
  };

  const saveProgress = async (currentTime: number, duration: number) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user || !dramaId) return;

    const now = Date.now();
    if (now - lastSaveTime.current < 10000) return; // ✅ Aumentado para 10s
    lastSaveTime.current = now;

    const sessionId = getSessionId();

    // ✅ Não bloquear o thread principal
    setTimeout(async () => {
      const { error } = await supabase.functions.invoke('track-video-progress', {
        body: {
          dramaId,
          currentPosition: Math.floor(currentTime),
          totalDuration: Math.floor(duration),
        },
        headers: {
          'x-session-id': sessionId || '',
        },
      });

        if (error?.message?.includes('INVALID_SESSION')) {
          setSessionInvalid(true);
          videoRef.current?.pause();
          clearSessionId();
          clearSupabaseAuthStorage();
          supabase.auth.signOut().catch(() => {});
        }
    }, 0);
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      const currentTime = Math.floor(video.currentTime);
      setWatchedTime(currentTime);

      // Save progress periodically
      if (video.duration) {
        saveProgress(currentTime, video.duration);
      }

      // For non-premium users
      if (!isPremium) {
        // If reached 10 minutes and hasn't submitted lead yet
        if (!leadSubmitted && !leadModalShown && currentTime >= LEAD_CAPTURE_TIME) {
          video.pause();
          // Sair do fullscreen antes de mostrar o modal
          if (document.fullscreenElement) {
            document.exitFullscreen().catch(() => {});
          }
          setShowLeadModal(true);
          setLeadModalShown(true);
          return;
        }
        
        // If submitted lead, can watch until 25 minutes
        if (leadSubmitted && currentTime >= EXTENDED_PREVIEW_LIMIT) {
          video.pause();
          setShowPaywall(true);
          return;
        }
      }
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    // Prevent seeking beyond limits for non-premium users
    const handleSeeking = () => {
      if (!isPremium) {
        const limit = leadSubmitted ? EXTENDED_PREVIEW_LIMIT : LEAD_CAPTURE_TIME;
        if (video.currentTime > limit) {
          video.currentTime = limit;
        }
      }
    };

    video.addEventListener("timeupdate", handleTimeUpdate);
    video.addEventListener("play", handlePlay);
    video.addEventListener("pause", handlePause);
    video.addEventListener("seeking", handleSeeking);

    return () => {
      video.removeEventListener("timeupdate", handleTimeUpdate);
      video.removeEventListener("play", handlePlay);
      video.removeEventListener("pause", handlePause);
      video.removeEventListener("seeking", handleSeeking);
    };
  }, [isPremium, leadSubmitted, leadModalShown, dramaId]);

  const handleVideoError = () => {
    const video = videoRef.current;
    console.error("[VideoPlayer] ERRO DE VÍDEO:", {
      error: video?.error,
      errorCode: video?.error?.code,
      errorMessage: video?.error?.message,
      networkState: video?.networkState,
      readyState: video?.readyState,
      src: video?.currentSrc,
      dramaId,
      videoUrl,
    });
    setErrorMessage("Não foi possível reproduzir este vídeo. Tente novamente mais tarde ou contate o suporte.");
  };

  const handleLoadedMetadata = () => {
    const video = videoRef.current;
    console.log("[VideoPlayer] Vídeo carregado:", {
      duration: video?.duration,
      readyState: video?.readyState,
      src: video?.currentSrc,
      isPremium,
    });
    
    // ✅ AGORA SIM setar posição salva
    if (savedPosition > 0 && video) {
      video.currentTime = savedPosition;
      console.log("[VideoPlayer] Posição restaurada:", savedPosition);
    }
  };

  const handleCanPlay = () => {
    console.log("[VideoPlayer] Vídeo pronto para reprodução:", {
      readyState: videoRef.current?.readyState,
      networkState: videoRef.current?.networkState,
    });
    setIsBuffering(false);
  };

  const handleStalled = () => {
    console.warn("[VideoPlayer] Reprodução interrompida (stalled). Problema de rede/CDN.");
  };
  
  const handleWaiting = () => {
    console.log("[VideoPlayer] Buffering...");
    setIsBuffering(true);
  };
  
  const handlePlaying = () => {
    console.log("[VideoPlayer] Reproduzindo");
    setIsBuffering(false);
  };

  const handlePlayClick = (startPosition?: number) => {
    console.log("[VideoPlayer] handlePlayClick iniciado:", {
      videoElement: !!videoRef.current,
      videoSrc: videoRef.current?.src,
      readyState: videoRef.current?.readyState,
      dramaId,
      isPremium,
      startPosition,
    });
    
    const video = videoRef.current;
    if (!video) {
      console.error("[VideoPlayer] Elemento de vídeo não encontrado");
      return;
    }

    // Se tem posição de início, setar antes de dar play
    if (startPosition !== undefined && startPosition > 0) {
      video.currentTime = startPosition;
      console.log(`[VideoPlayer] Posição inicial setada para ${startPosition}s`);
    }

    // ✅ SOLUÇÃO: Chamar play() IMEDIATAMENTE (dentro do user gesture)
    const playPromise = video.play();
    
    // ✅ Esconder preview DEPOIS (não afeta o play)
    setShowPreview(false);
    
    // ✅ Logging assíncrono em BACKGROUND (não bloqueia)
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          console.log("✅ Mobile: Vídeo reproduzindo com sucesso");
          setIsPlaying(true);
          
          // Registrar view DEPOIS que começar a tocar
          supabase.auth.getSession().then(({ data: { session } }) => {
            if (session?.user && dramaId) {
              supabase.from("video_views").insert({
                user_id: session.user.id,
                drama_id: dramaId,
                device: /mobile/i.test(navigator.userAgent) ? "mobile" : "desktop",
              }).then(() => console.log("View registrada"));
            }
          });
        })
        .catch((error) => {
          console.error("❌ Mobile: Erro ao reproduzir:", error);
          console.error("Detalhes:", {
            name: error.name,
            message: error.message,
            code: error.code,
          });
          
          // Se falhou, mostrar preview novamente
          setShowPreview(true);
          setIsPlaying(false);
          
          // Mostrar mensagem amigável
          if (error.name === "NotAllowedError") {
            setErrorMessage("Toque no botão de play para iniciar o vídeo");
          }
        });
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleActivatePlan = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
    } else {
      navigate("/paywall");
    }
  };

  // Block right-click and drag on video
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const isValidPhone = (phone: string) => {
    const cleaned = phone.replace(/\D/g, '');
    return cleaned.length >= 10 && cleaned.length <= 11; // DDD + 8 ou 9 dígitos
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    
    // Formatar: (XX) XXXXX-XXXX (11 dígitos) ou (XX) XXXX-XXXX (10 dígitos)
    if (value.length > 10) {
      value = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7, 11)}`;
    } else if (value.length === 10) {
      value = `(${value.slice(0, 2)}) ${value.slice(2, 6)}-${value.slice(6)}`;
    } else if (value.length > 6) {
      value = `(${value.slice(0, 2)}) ${value.slice(2, 6)}-${value.slice(6)}`;
    } else if (value.length > 2) {
      value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
    } else if (value.length > 0) {
      value = `(${value}`;
    }
    
    setLeadPhone(value);
  };

  const handleLeadSubmit = async () => {
    // Prevenir double-submit
    if (isSubmittingLead || leadSubmitted) return;
    
    const cleaned = leadPhone.replace(/\D/g, '');
    
    if (!isValidPhone(leadPhone)) {
      toast.error("Por favor, insira um número de telefone válido");
      return;
    }

    setIsSubmittingLead(true);

    // Salvar no Supabase - o trigger do banco envia automaticamente para Dispara Aí
    try {
      const { data: { session } } = await supabase.auth.getSession();

      const { error } = await supabase.from('leads').insert({
        phone: cleaned,
        drama_id: dramaId,
        drama_title: dramaTitle,
        user_id: session?.user?.id || null,
      });

      if (error) {
        console.warn('[VideoPlayer] Erro ao salvar lead:', error);
      } else {
        console.log('[VideoPlayer] Lead salvo - webhook será disparado automaticamente');
      }
    } catch (error: any) {
      console.warn('[VideoPlayer] Erro ao salvar lead:', error);
    }

    // Atualizar UI
    setLeadSubmitted(true);
    setExtendedTime(true);
    setShowLeadModal(false);
    localStorage.setItem(`lead_submitted_${dramaId}`, 'true');
    setIsSubmittingLead(false);
    
    // Resume video
    videoRef.current?.play();
    
    toast.success("🎉 Mais 15 minutos liberados!");
  };

  if (sessionInvalid) {
    return (
      <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/95 p-4 sm:p-8 text-center z-50">
          <div className="w-12 h-12 sm:w-16 sm:h-16 mb-3 sm:mb-4 bg-fire-orange/20 rounded-full flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 sm:w-8 sm:h-8 text-fire-orange" />
          </div>
          <h3 className="text-xl sm:text-2xl font-bold mb-2 text-white">Sessão encerrada</h3>
          <p className="text-sm sm:text-base text-white/80 mb-4 sm:mb-6 max-w-md">
            Sua conta foi acessada em outro dispositivo. Faça login novamente para continuar assistindo.
          </p>
          <Button
            onClick={() => {
              clearSessionId();
              window.location.href = '/auth';
            }}
            className="w-full sm:w-auto bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_10px_30px_rgba(255,140,0,0.5)] text-white font-bold px-6 sm:px-8 py-2.5 sm:py-3 text-sm sm:text-base"
          >
            Fazer login novamente
          </Button>
        </div>
      </div>
    );
  }


  if (showPaywall) {
    return (
      <div className="w-full max-w-xl mx-auto bg-black rounded-xl overflow-hidden border border-border px-4 py-5 sm:px-6 sm:py-6 flex items-center justify-center">
        <div className="w-full max-w-md mx-auto text-center space-y-3 sm:space-y-4">
          <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto bg-gradient-to-br from-fire-orange to-fire-yellow-intense rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,140,0,0.5)]">
            <Lock className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
          </div>

          <div className="space-y-2 sm:space-y-3">
            <h3 className="text-lg sm:text-xl font-bold leading-tight text-white">
              🔒 Preview Finalizado
            </h3>
            <p className="text-sm sm:text-base text-white/90">
              Você assistiu 25 minutos gratuitos!
            </p>
            <p className="text-sm sm:text-base text-white/90">
              Quer continuar assistindo{" "}
              <span className="font-bold text-fire-yellow-bright">{dramaTitle}</span>{" "}
              SEM travar e até o final?
            </p>
            <p className="text-xs sm:text-sm text-red-400/60 italic">
              Oferta exclusiva enquanto a janela estiver aberta.
            </p>
            <div className="text-base sm:text-lg pt-1">
              <span className="text-white/60 line-through mr-2">De R$ 39,00</span>
              <span className="text-white">→ por apenas </span>
              <span className="text-2xl sm:text-3xl font-extrabold text-fire-yellow-intense">
                R$ 12,90
              </span>
            </div>
          </div>

          <Button
            onClick={() => navigate(`/checkout/${dramaId}`)}
            className="w-full min-h-[44px] sm:min-h-[48px] bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_8px_30px_rgba(255,140,0,0.7)] text-black font-bold px-4 sm:px-6 py-3 text-sm sm:text-base transition-all duration-300"
          >
            🔘 Liberar dorama completo por R$ 12,90
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
      {/* Lead Capture Modal */}
      {showLeadModal && (
        <div className="absolute inset-0 bg-black/95 flex items-center justify-center z-50 p-4">
          <div className="bg-black border-2 border-fire-orange rounded-xl p-6 max-w-md w-full mx-4 text-center shadow-[0_0_40px_rgba(255,140,0,0.4)]">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-fire-orange to-fire-yellow-intense rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,140,0,0.6)]">
              <span className="text-3xl">🔥</span>
            </div>
            
            <h3 className="text-xl sm:text-2xl font-bold text-fire-yellow-bright mb-3">
              Continue Assistindo Grátis!
            </h3>
            
            <p className="text-white/80 mb-6 text-sm sm:text-base">
              Informe seu telefone para liberar <span className="font-bold text-fire-yellow-intense">mais 15 minutos grátis</span>
            </p>
            
            <Input
              type="tel"
              placeholder="(99) 99999-9999"
              value={leadPhone}
              onChange={handlePhoneChange}
              className="mb-4 bg-white/10 border-fire-orange/40 text-white placeholder:text-white/40 focus:border-fire-yellow-intense focus:bg-white/15 h-12 text-center text-lg"
              maxLength={15}
            />
            
            <Button
              onClick={handleLeadSubmit}
              disabled={!isValidPhone(leadPhone)}
              className="w-full min-h-[48px] bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_10px_40px_rgba(255,140,0,0.8)] text-white font-bold text-base sm:text-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
            >
              LIBERAR MAIS 15 MINUTOS GRÁTIS
            </Button>
            
            <p className="text-xs text-white/50 mt-4">
              Sem custo adicional. Apenas para continuar assistindo.
            </p>
          </div>
        </div>
      )}

      {showPreview && (
        <div 
          className="absolute inset-0 z-10 flex items-center justify-center bg-black/70"
        >
          <div className="text-center">
            {thumbnailUrl && (
              <img
                src={thumbnailUrl}
                alt={dramaTitle}
                className="absolute inset-0 w-full h-full object-cover opacity-30"
                draggable={false}
              />
            )}
            
            {startPositionSeconds > 0 ? (
              // Mostrar 2 botões quando tem posição de início configurada
              <div className="relative z-20 flex flex-col gap-3 px-6 w-full max-w-md">
                <Button
                  onClick={() => handlePlayClick(startPositionSeconds)}
                  size="lg"
                  className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:from-fire-yellow-intense hover:to-fire-orange text-white font-bold text-base sm:text-lg px-6 py-4 min-h-[56px] shadow-[0_4px_20px_rgba(255,140,0,0.4)] hover:shadow-[0_8px_30px_rgba(255,140,0,0.6)] transition-all duration-300 rounded-xl"
                >
                  🔥 Continuar de onde parei
                </Button>
                
                <Button
                  onClick={() => handlePlayClick(0)}
                  variant="outline"
                  size="lg"
                  className="w-full border-2 border-fire-orange/50 bg-transparent hover:bg-fire-orange/10 text-white font-semibold text-base sm:text-lg px-6 py-4 min-h-[52px] transition-all duration-300 rounded-xl"
                >
                  ▶️ Começar do início
                </Button>
              </div>
            ) : (
              // Botão único quando não tem posição de início
              <div className="relative z-20" onClick={() => handlePlayClick(0)}>
                <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 bg-gradient-to-br from-fire-orange to-fire-yellow-intense rounded-full flex items-center justify-center shadow-[0_10px_40px_rgba(255,140,0,0.6)] cursor-pointer hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 sm:w-10 sm:h-10 ml-1 text-white" fill="currentColor" />
                </div>
                <p className="text-white font-semibold text-sm sm:text-base mb-2">
                  Assistir {dramaTitle}
                </p>
                {!isPremium && (
                  <p className="text-xs sm:text-sm text-white/80">
                    ⏱️ Prévia gratuita: 25 minutos
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Indicador de loading durante buffering */}
      {isBuffering && !showPreview && isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70 z-20 pointer-events-none">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-fire-orange border-t-fire-yellow-intense rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-white text-lg font-medium">Carregando vídeo...</p>
            {showSlowConnectionWarning && (
              <p className="text-fire-yellow-intense text-sm mt-2 max-w-xs px-4">
                Conexão lenta detectada. O vídeo pode demorar para carregar.
              </p>
            )}
          </div>
        </div>
      )}

      {/* SUPORTE MULTI-CDN PARA VÍDEOS DIRETOS
          ✅ CDN Próprio: https://cdn.doramassuper.site/videos/...mp4
          ✅ FileMoon: https://filemoon.to/d/{id}/{slug}.mp4
          ✅ Outros CDNs diretos: qualquer URL que termine em .mp4 com CORS habilitado

          O atributo crossOrigin="anonymous" permite:
          - Ler currentTime/duration para limite de prévia (10 minutos)
          - Disparar e tratar eventos de timeupdate para salvamento de progresso
          - Funcionar com domínios externos preservando segurança */}
      <video
            key={`${dramaId}-${videoUrl}`}
            ref={videoRef}
            className="w-full h-full"
            controls
            controlsList="nodownload"
            onContextMenu={handleContextMenu}
            onDragStart={handleDragStart}
            poster={thumbnailUrl}
            disablePictureInPicture
            playsInline
            x-webkit-airplay="allow"
            preload="metadata"
            crossOrigin="anonymous"
            onError={handleVideoError}
            onLoadedMetadata={handleLoadedMetadata}
            onCanPlay={handleCanPlay}
            onStalled={handleStalled}
            onWaiting={handleWaiting}
            onPlaying={handlePlaying}
          >
        <source src={videoUrl} type="video/mp4" />
        Seu navegador não suporta a reprodução de vídeo.
      </video>

      {errorMessage && (
        <div className="mt-3 text-sm text-red-400 bg-black/60 px-3 py-2 rounded">
          {errorMessage}
        </div>
      )}

      {!isPremium && !showPaywall && !showPreview && (
        <div className="absolute bottom-20 left-4 bg-black/80 px-3 py-1 rounded text-sm">
          {leadSubmitted ? (
            <>Prévia estendida: {Math.floor(watchedTime / 60)}:{(watchedTime % 60).toString().padStart(2, '0')} / 25:00</>
          ) : (
            <>Prévia: {Math.floor(watchedTime / 60)}:{(watchedTime % 60).toString().padStart(2, '0')} / 10:00</>
          )}
        </div>
      )}
    </div>
  );
};

export default VideoPlayer;
