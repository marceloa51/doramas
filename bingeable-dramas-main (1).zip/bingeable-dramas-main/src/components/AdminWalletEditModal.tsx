import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

interface WalletData {
  available_balance: number;
  total_earned: number;
  total_withdrawn: number;
}

interface ProfileData {
  id: string;
  email: string;
  full_name: string | null;
  referral_count: number;
  free_months_granted: number;
}

interface AdminWalletEditModalProps {
  open: boolean;
  onClose: () => void;
  user: ProfileData | null;
  wallet: WalletData | null;
  onSuccess: () => void;
}

export default function AdminWalletEditModal({
  open,
  onClose,
  user,
  wallet,
  onSuccess
}: AdminWalletEditModalProps) {
  const [loading, setLoading] = useState(false);
  const [balanceAdjustment, setBalanceAdjustment] = useState("");
  const [earnedAdjustment, setEarnedAdjustment] = useState("");
  const [referralAdjustment, setReferralAdjustment] = useState("");
  const [withdrawnAdjustment, setWithdrawnAdjustment] = useState("");
  const [reason, setReason] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;

    // Validar que pelo menos um ajuste foi feito
    const hasAdjustments = balanceAdjustment || earnedAdjustment || referralAdjustment || withdrawnAdjustment;
    if (!hasAdjustments) {
      toast.error("Informe pelo menos um ajuste");
      return;
    }

    if (!reason.trim()) {
      toast.error("Informe o motivo do ajuste");
      return;
    }

    setLoading(true);

    try {
      const adjustments: any = {};

      if (balanceAdjustment) {
        adjustments.available_balance = parseFloat(balanceAdjustment);
      }
      if (earnedAdjustment) {
        adjustments.total_earned = parseFloat(earnedAdjustment);
      }
      if (referralAdjustment) {
        adjustments.referral_count = parseInt(referralAdjustment);
      }
      if (withdrawnAdjustment) {
        adjustments.total_withdrawn = parseFloat(withdrawnAdjustment);
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Sessão expirada");
        return;
      }

      const { data, error } = await supabase.functions.invoke('admin-adjust-wallet', {
        body: {
          userId: user.id,
          adjustments,
          reason: reason.trim()
        }
      });

      if (error) throw error;

      toast.success("Carteira ajustada com sucesso");
      setBalanceAdjustment("");
      setEarnedAdjustment("");
      setReferralAdjustment("");
      setWithdrawnAdjustment("");
      setReason("");
      onSuccess();
      onClose();
    } catch (error: any) {
      console.error('Error adjusting wallet:', error);
      toast.error(error.message || "Erro ao ajustar carteira");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      setBalanceAdjustment("");
      setEarnedAdjustment("");
      setReferralAdjustment("");
      setWithdrawnAdjustment("");
      setReason("");
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl bg-drama-card border-drama-border">
        <DialogHeader>
          <DialogTitle className="text-xl">
            Editar Carteira - {user?.full_name || user?.email}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Informações atuais */}
          <div className="bg-background/50 rounded-lg p-4 space-y-2">
            <h3 className="font-semibold text-sm text-muted-foreground mb-3">Informações Atuais</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Saldo disponível:</span>
                <p className="font-medium text-fire-orange">
                  R$ {wallet?.available_balance?.toFixed(2) || "0.00"}
                </p>
              </div>
              <div>
                <span className="text-muted-foreground">Total ganho:</span>
                <p className="font-medium">R$ {wallet?.total_earned?.toFixed(2) || "0.00"}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Total sacado:</span>
                <p className="font-medium">R$ {wallet?.total_withdrawn?.toFixed(2) || "0.00"}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Indicações:</span>
                <p className="font-medium">{user?.referral_count || 0}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Meses gratuitos:</span>
                <p className="font-medium">{user?.free_months_granted || 0}</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Ajustes */}
            <div className="space-y-4">
              <h3 className="font-semibold text-sm text-muted-foreground">Ajustes Manuais</h3>
              
              <div className="space-y-2">
                <Label htmlFor="balance">
                  Ajustar Saldo Disponível (+ adiciona, - remove)
                </Label>
                <Input
                  id="balance"
                  type="number"
                  step="0.01"
                  placeholder="Ex: +50.00 ou -20.00"
                  value={balanceAdjustment}
                  onChange={(e) => setBalanceAdjustment(e.target.value)}
                  className="bg-background border-drama-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="earned">
                  Ajustar Total Ganho (+ adiciona, - remove)
                </Label>
                <Input
                  id="earned"
                  type="number"
                  step="0.01"
                  placeholder="Ex: +100.00 ou -50.00"
                  value={earnedAdjustment}
                  onChange={(e) => setEarnedAdjustment(e.target.value)}
                  className="bg-background border-drama-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="referrals">
                  Ajustar Contagem de Indicações (+ adiciona, - remove)
                </Label>
                <Input
                  id="referrals"
                  type="number"
                  placeholder="Ex: +5 ou -2"
                  value={referralAdjustment}
                  onChange={(e) => setReferralAdjustment(e.target.value)}
                  className="bg-background border-drama-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="withdrawn">
                  Ajustar Total Sacado (+ adiciona, - remove)
                </Label>
                <Input
                  id="withdrawn"
                  type="number"
                  step="0.01"
                  placeholder="Ex: +100.00 ou -50.00"
                  value={withdrawnAdjustment}
                  onChange={(e) => setWithdrawnAdjustment(e.target.value)}
                  className="bg-background border-drama-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">
                  Motivo do Ajuste <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="reason"
                  placeholder="Descreva o motivo deste ajuste manual..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="bg-background border-drama-border min-h-[80px]"
                  required
                />
              </div>
            </div>

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={loading}
                className="border-drama-border"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={loading}
                className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_24px_rgba(255,140,0,0.4)] text-white"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  "Salvar Ajustes"
                )}
              </Button>
            </DialogFooter>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
