import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Play, Film, Globe, Mic, Monitor, Users, Zap, ChevronRight, ChevronDown, Home, Star } from "lucide-react";
import { useState, useEffect } from "react";
import type { FAQItem, TechnicalInfo } from "@/data/seoContent";
import { seoContent } from "@/data/seoContent";
import { supabase } from "@/integrations/supabase/client";
import { SearchBar } from "@/components/SearchBar";
import { userReviews } from "@/data/userReviews";

interface SEODramaPageProps {
  title: string;
  metaTitle: string;
  metaDescription: string;
  h1: string;
  dramaName: string;
  genre: string;
  content: string;
  slug: string;
  currentPath: string;
  introduction?: string;
  synopsis?: string;
  faq?: FAQItem[];
  technicalInfo?: TechnicalInfo;
  thumbnailAlt?: string;
  relatedSlugs?: string[];
}

export const SEODramaPage = ({
  title,
  metaTitle,
  metaDescription,
  h1,
  dramaName,
  genre,
  content,
  slug,
  currentPath,
  introduction,
  synopsis,
  faq,
  technicalInfo,
  thumbnailAlt,
  relatedSlugs,
}: SEODramaPageProps) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  const [dramaThumbnail, setDramaThumbnail] = useState<string | null>(null);
  const [dramaCover, setDramaCover] = useState<string | null>(null);
  const [dbSynopsis, setDbSynopsis] = useState<string | null>(null);
  
  const canonicalUrl = `https://doramassuper.site${currentPath}`;
  const playerUrl = `/movie/${slug}`;
  const defaultOgImage = "https://doramassuper.site/og-image.jpg";

  // Fetch drama data from database (thumbnail, cover, synopsis)
  useEffect(() => {
    const fetchDramaData = async () => {
      // Try exact match first
      let { data } = await supabase
        .from('dramas')
        .select('thumbnail_url, cover_url, slug, synopsis')
        .eq('slug', slug)
        .single();
      
      // If not found, try with ilike for accent variations
      if (!data) {
        const slugPattern = slug.replace(/-/g, '%');
        const { data: fuzzyData } = await supabase
          .from('dramas')
          .select('thumbnail_url, cover_url, slug, synopsis')
          .ilike('slug', `%${slugPattern}%`)
          .limit(1)
          .single();
        data = fuzzyData;
      }

      // If still not found, try matching by normalized slug (remove accents)
      if (!data) {
        const { data: allDramas } = await supabase
          .from('dramas')
          .select('thumbnail_url, cover_url, slug, synopsis');
        
        if (allDramas) {
          // Normalize function to remove accents
          const normalize = (str: string) => 
            str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
          
          const normalizedSlug = normalize(slug);
          const match = allDramas.find(d => normalize(d.slug) === normalizedSlug);
          if (match) {
            data = match;
          }
        }
      }
      
      if (data) {
        setDramaThumbnail(data.thumbnail_url);
        setDramaCover(data.cover_url);
        setDbSynopsis(data.synopsis);
      }
    };
    
    fetchDramaData();
  }, [slug]);

  const ogImage = dramaCover || dramaThumbnail || defaultOgImage;
  const displayImage = dramaThumbnail || dramaCover;

  // Get related dramas data
  const relatedDramas = relatedSlugs?.map(relSlug => 
    seoContent.find(d => d.slug === relSlug)
  ).filter(Boolean) || [];

  // Schema: VideoObject
  const videoSchema = {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    name: dramaName,
    description: metaDescription,
    genre: genre,
    inLanguage: "pt-BR",
    contentUrl: `https://doramassuper.site${playerUrl}`,
    thumbnailUrl: ogImage,
    publisher: {
      "@type": "Organization",
      name: "Doramas Super",
      url: "https://doramassuper.site",
    },
  };

  // Schema: BreadcrumbList
  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Início",
        item: "https://doramassuper.site/"
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Doramas",
        item: "https://doramassuper.site/explorar"
      },
      {
        "@type": "ListItem",
        position: 3,
        name: dramaName,
        item: `https://doramassuper.site/movie/${slug}`
      }
    ]
  };

  // Schema: FAQPage
  const faqSchema = faq && faq.length > 0 ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faq.map(item => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: item.answer
      }
    }))
  } : null;

  // Schema: Organization
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Doramas Super",
    url: "https://doramassuper.site",
    logo: "https://doramassuper.site/favicon.png",
    sameAs: []
  };

  // Schema: AggregateRating
  const aggregateRatingSchema = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: dramaName,
    description: metaDescription,
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: "1847",
      bestRating: "5",
      worstRating: "1"
    }
  };

  // Get 6 random reviews for display
  const displayReviews = userReviews.slice(0, 6);

  return (
    <>
      <Helmet>
        <title>{metaTitle}</title>
        <meta name="description" content={metaDescription} />
        <link rel="canonical" href={canonicalUrl} />
        
        {/* Open Graph */}
        <meta property="og:title" content={metaTitle} />
        <meta property="og:description" content={metaDescription} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:type" content="video.other" />
        <meta property="og:image" content={ogImage} />
        <meta property="og:site_name" content="Doramas Super" />
        <meta property="og:locale" content="pt_BR" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={metaTitle} />
        <meta name="twitter:description" content={metaDescription} />
        <meta name="twitter:image" content={ogImage} />
        <meta name="twitter:site" content="@doramassuper" />
        
        {/* Additional SEO */}
        <meta name="robots" content="index, follow" />
        <meta name="keywords" content={`${dramaName}, ${dramaName} dublado, ${dramaName} completo, assistir ${dramaName}, onde assistir ${dramaName}, dorama ${dramaName}, ${genre}`} />
        
        {/* Schema.org - Multiple schemas */}
        <script type="application/ld+json">
          {JSON.stringify(videoSchema)}
        </script>
        <script type="application/ld+json">
          {JSON.stringify(breadcrumbSchema)}
        </script>
        {faqSchema && (
          <script type="application/ld+json">
            {JSON.stringify(faqSchema)}
          </script>
        )}
        <script type="application/ld+json">
          {JSON.stringify(organizationSchema)}
        </script>
        <script type="application/ld+json">
          {JSON.stringify(aggregateRatingSchema)}
        </script>
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header/Navbar with Search */}
        <header className="border-b border-border/20 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-between gap-4">
              {/* Logo */}
              <Link to="/" className="flex-shrink-0">
                <h2 className="text-xl md:text-2xl font-bold bg-gradient-to-r from-[#FF6A00] via-[#FFC93C] to-[#FFE066] bg-clip-text text-transparent">
                  DORAMAS SUPER
                </h2>
              </Link>
              
              {/* Search Bar - Desktop */}
              <div className="hidden md:block flex-1 max-w-md">
                <SearchBar variant="desktop" />
              </div>
              
              {/* Right side buttons */}
              <div className="flex items-center gap-2">
                {/* Search - Mobile */}
                <div className="md:hidden">
                  <SearchBar variant="mobile" />
                </div>
                
                {/* Início Button */}
                <Link to="/">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="border-[#FF6A00]/30 hover:border-[#FF6A00] hover:bg-[#FF6A00]/10 text-foreground"
                  >
                    <Home className="w-4 h-4 mr-1" />
                    <span className="hidden sm:inline">Início</span>
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </header>

        {/* Breadcrumb */}
        <nav className="container mx-auto px-4 py-3 text-sm text-muted-foreground" aria-label="Breadcrumb">
          <ol className="flex items-center flex-wrap gap-1">
            <li>
              <Link to="/" className="hover:text-foreground transition-colors">Início</Link>
            </li>
            <li className="flex items-center">
              <ChevronRight className="w-4 h-4 mx-1" />
              <Link to="/explorar" className="hover:text-foreground transition-colors">Doramas</Link>
            </li>
            <li className="flex items-center">
              <ChevronRight className="w-4 h-4 mx-1" />
              <Link to={playerUrl} className="hover:text-foreground transition-colors">{dramaName}</Link>
            </li>
            <li className="flex items-center">
              <ChevronRight className="w-4 h-4 mx-1" />
              <span className="text-foreground">{title}</span>
            </li>
          </ol>
        </nav>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8 md:py-12">
          <article className="max-w-4xl mx-auto">
            {/* H1 Title */}
            <h1 className="text-3xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-[#FFE066] via-[#FFC93C] to-[#FF6A00] bg-clip-text text-transparent leading-tight">
              {h1}
            </h1>

            {/* Drama Thumbnail Image */}
            {displayImage && (
              <div className="mb-8">
                <Link to={playerUrl} className="block">
                  <div className="relative aspect-video md:aspect-[21/9] overflow-hidden rounded-xl border border-[#FF6A00]/20 group">
                    <img
                      src={displayImage}
                      alt={thumbnailAlt || `Poster do dorama ${dramaName} dublado em português`}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="eager"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                      <div>
                        <span className="text-sm text-[#FFC93C] font-medium">Dorama Dublado</span>
                        <h3 className="text-xl md:text-2xl font-bold text-foreground">{dramaName}</h3>
                      </div>
                      <div className="bg-[#FF6A00] rounded-full p-3 group-hover:bg-[#FFC93C] transition-colors">
                        <Play className="w-6 h-6 text-background" />
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            )}

            {/* CTA Button #1 - Top */}
            <div className="text-center py-6 mb-8">
              <Link to={playerUrl}>
                <Button 
                  size="lg" 
                  className="w-full md:w-auto bg-gradient-to-r from-[#FF6A00] via-[#FFC93C] to-[#FFE066] text-background font-bold text-lg px-12 py-6 rounded-lg hover:brightness-110 hover:shadow-[0_0_30px_rgba(255,170,0,0.5)] transition-all"
                >
                  <Play className="mr-2 w-6 h-6" />
                  Assistir {dramaName} Agora
                </Button>
              </Link>
            </div>

            {/* Introduction Section */}
            {introduction && (
              <section className="mb-10">
                <h2 className="text-2xl md:text-3xl font-bold mb-4 text-[#FFC93C]">
                  Sobre o Dorama {dramaName}
                </h2>
                <div className="prose prose-invert max-w-none">
                  {introduction.split('\n\n').map((paragraph, index) => (
                    <p key={index} className="text-lg leading-relaxed text-foreground/90 mb-4">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </section>
            )}

            {/* Technical Info Box */}
            <section className="bg-[#0A0A0A] border border-[#FF6A00]/20 rounded-lg p-6 mb-10">
              <h2 className="text-xl font-bold mb-4 text-[#FFC93C]">Informações Técnicas</h2>
              
              {technicalInfo ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="flex items-center gap-3">
                    <Film className="w-5 h-5 text-[#FFC93C] flex-shrink-0" />
                    <div>
                      <span className="text-muted-foreground text-sm">Gênero</span>
                      <p className="text-foreground font-medium">{technicalInfo.genres.join(", ")}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Play className="w-5 h-5 text-[#FFC93C] flex-shrink-0" />
                    <div>
                      <span className="text-muted-foreground text-sm">Tipo</span>
                      <p className="text-foreground font-medium">{technicalInfo.type}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mic className="w-5 h-5 text-[#FFC93C] flex-shrink-0" />
                    <div>
                      <span className="text-muted-foreground text-sm">Idioma</span>
                      <p className="text-foreground font-medium">{technicalInfo.language}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Monitor className="w-5 h-5 text-[#FFC93C] flex-shrink-0" />
                    <div>
                      <span className="text-muted-foreground text-sm">Qualidade</span>
                      <p className="text-foreground font-medium">{technicalInfo.quality}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-[#FFC93C] flex-shrink-0" />
                    <div>
                      <span className="text-muted-foreground text-sm">Público</span>
                      <p className="text-foreground font-medium">{technicalInfo.audience}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Zap className="w-5 h-5 text-[#FFC93C] flex-shrink-0" />
                    <div>
                      <span className="text-muted-foreground text-sm">Acesso</span>
                      <p className="text-foreground font-medium">{technicalInfo.access}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Film className="w-5 h-5 text-[#FFC93C]" />
                    <span className="text-foreground font-semibold">{dramaName}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Play className="w-5 h-5 text-[#FFC93C]" />
                    <span className="text-muted-foreground">Gênero: <span className="text-foreground">{genre}</span></span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Globe className="w-5 h-5 text-[#FFC93C]" />
                    <span className="text-muted-foreground">Tipo: <span className="text-foreground">Dorama / Série</span></span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mic className="w-5 h-5 text-[#FFC93C]" />
                    <span className="text-muted-foreground">Idioma: <span className="text-foreground">Dublado em Português</span></span>
                  </div>
                </div>
              )}
              
              <div className="pt-4 mt-4 border-t border-border/20">
                <span className="text-muted-foreground">Disponível em: </span>
                <Link to="/" className="text-[#FFC93C] font-semibold hover:text-[#FFE066] transition-colors">
                  Doramas Super
                </Link>
              </div>
            </section>

            {/* Synopsis Section - Uses database synopsis if available */}
            {(dbSynopsis || synopsis) ? (
              <section className="mb-10">
                <h2 className="text-2xl md:text-3xl font-bold mb-4 text-[#FFC93C]">
                  Sinopse Completa de {dramaName}
                </h2>
                <div className="prose prose-invert max-w-none">
                  {(dbSynopsis || synopsis || "").split('\n\n').map((paragraph, index) => (
                    <p key={index} className="text-lg leading-relaxed text-foreground/90 mb-4">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </section>
            ) : content ? (
              <section className="mb-10">
                <div className="prose prose-invert max-w-none">
                  <div className="text-lg leading-relaxed text-foreground/90 whitespace-pre-line">
                    {content}
                  </div>
                </div>
              </section>
            ) : null}

            {/* FAQ Section */}
            {faq && faq.length > 0 && (
              <section className="mb-10">
                <h2 className="text-2xl md:text-3xl font-bold mb-6 text-[#FFC93C]">
                  Perguntas Frequentes sobre {dramaName}
                </h2>
                <div className="space-y-3">
                  {faq.map((item, index) => (
                    <div 
                      key={index}
                      className="bg-[#0A0A0A] border border-[#FF6A00]/20 rounded-lg overflow-hidden"
                    >
                      <button
                        onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                        className="w-full flex items-center justify-between p-4 text-left hover:bg-[#1A1A1A] transition-colors"
                        aria-expanded={openFaqIndex === index}
                      >
                        <h3 className="text-lg font-medium text-foreground pr-4">
                          {item.question}
                        </h3>
                        <ChevronDown 
                          className={`w-5 h-5 text-[#FFC93C] flex-shrink-0 transition-transform ${
                            openFaqIndex === index ? 'rotate-180' : ''
                          }`}
                        />
                      </button>
                      {openFaqIndex === index && (
                        <div className="px-4 pb-4">
                          <p className="text-foreground/80 leading-relaxed">
                            {item.answer}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Related Dramas - Internal Links */}
            {relatedDramas.length > 0 && (
              <section className="mb-10">
                <h3 className="text-xl md:text-2xl font-bold mb-4 text-[#FFC93C]">
                  Outros Doramas que Você Vai Amar
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {relatedDramas.map((drama) => (
                    <Link
                      key={drama!.slug}
                      to={`/movie/${drama!.slug}`}
                      className="bg-[#0A0A0A] border border-[#FF6A00]/20 rounded-lg p-4 hover:border-[#FF6A00]/50 hover:bg-[#1A1A1A] transition-all group"
                    >
                      <h4 className="font-medium text-foreground group-hover:text-[#FFC93C] transition-colors">
                        {drama!.name}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1">{drama!.genre}</p>
                      <span className="text-[#FF6A00] text-sm mt-2 inline-flex items-center gap-1">
                        Assistir <ChevronRight className="w-4 h-4" />
                      </span>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* User Reviews Section */}
            <section className="mb-10">
              <h2 className="text-2xl md:text-3xl font-bold mb-2 text-[#FFC93C]">
                O Que Nossos Usuários Dizem sobre {dramaName}
              </h2>
              <div className="flex items-center gap-2 mb-6">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-5 h-5 fill-[#FFC93C] text-[#FFC93C]" />
                  ))}
                </div>
                <span className="text-foreground font-medium">4.9</span>
                <span className="text-muted-foreground">• 1.847 avaliações</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {displayReviews.map((review, index) => (
                  <div
                    key={index}
                    className="bg-[#0A0A0A] border border-[#FF6A00]/20 rounded-lg p-5 hover:border-[#FF6A00]/40 transition-colors"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#FF6A00] to-[#FFC93C] flex items-center justify-center text-background font-bold text-sm">
                        {review.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-foreground text-sm">{review.name}</h4>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <div className="flex">
                            {[...Array(review.rating)].map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-[#FFC93C] text-[#FFC93C]" />
                            ))}
                          </div>
                          <span>•</span>
                          <span>{review.location}</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-foreground/85 leading-relaxed text-sm italic">
                      "{review.review}"
                    </p>
                    <p className="text-xs text-muted-foreground mt-3">{review.date}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* More Internal Links */}
            <section className="mb-10">
              <h3 className="text-xl font-bold mb-4 text-[#FFC93C]">
                Navegue pelo Doramas Super
              </h3>
              <div className="flex flex-wrap gap-3">
                <Link 
                  to="/explorar" 
                  className="bg-[#0A0A0A] border border-[#FF6A00]/20 rounded-full px-4 py-2 text-sm text-foreground hover:bg-[#1A1A1A] hover:border-[#FF6A00]/50 transition-all"
                >
                  📺 Ver Todos os Doramas
                </Link>
                <Link 
                  to="/" 
                  className="bg-[#0A0A0A] border border-[#FF6A00]/20 rounded-full px-4 py-2 text-sm text-foreground hover:bg-[#1A1A1A] hover:border-[#FF6A00]/50 transition-all"
                >
                  🏠 Página Inicial
                </Link>
                <Link 
                  to={playerUrl} 
                  className="bg-[#0A0A0A] border border-[#FF6A00]/20 rounded-full px-4 py-2 text-sm text-foreground hover:bg-[#1A1A1A] hover:border-[#FF6A00]/50 transition-all"
                >
                  🎬 Assistir {dramaName}
                </Link>
              </div>
            </section>

            {/* CTA Button #2 - Bottom */}
            <section className="text-center py-8 bg-gradient-to-r from-[#FF6A00]/10 via-[#FFC93C]/5 to-transparent rounded-lg border border-[#FF6A00]/20">
              <h3 className="text-xl md:text-2xl font-bold mb-3 text-foreground">
                Pronto para assistir {dramaName}?
              </h3>
              <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
                Clique no botão abaixo e comece a assistir agora mesmo em HD, dublado em português e sem anúncios!
              </p>
              <Link to={playerUrl}>
                <Button 
                  size="lg" 
                  className="w-full md:w-auto bg-gradient-to-r from-[#FF6A00] via-[#FFC93C] to-[#FFE066] text-background font-bold text-lg px-12 py-6 rounded-lg hover:brightness-110 hover:shadow-[0_0_30px_rgba(255,170,0,0.5)] transition-all"
                >
                  <Play className="mr-2 w-6 h-6" />
                  🔥 Assistir {dramaName} Agora
                </Button>
              </Link>
            </section>
          </article>
        </main>

        {/* Footer */}
        <footer className="border-t border-border/20 bg-[#0A0A0A] py-8 mt-12">
          <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
            <p>&copy; 2025 Doramas Super. Todos os direitos reservados.</p>
            <p className="mt-2">
              Assista seus doramas favoritos dublados em português com qualidade HD.
            </p>
          </div>
        </footer>
      </div>
    </>
  );
};
