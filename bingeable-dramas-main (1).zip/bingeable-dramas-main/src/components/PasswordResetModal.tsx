import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PasswordInput } from '@/components/ui/password-input';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { Label } from '@/components/ui/label';
import { Loader2, CheckCircle2, AlertCircle, ArrowLeft } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ResetFlowState {
  step: 'phone' | 'code' | 'new_password' | 'done';
  phone: string;
  requestId: string;
  expiresAt: number;
}

interface PasswordResetModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

const STORAGE_KEY = 'password_reset_flow';

export function PasswordResetModal({ open, onOpenChange, onSuccess }: PasswordResetModalProps) {
  const [step, setStep] = useState<'phone' | 'code' | 'new_password' | 'done'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [requestId, setRequestId] = useState('');
  const [expiresAt, setExpiresAt] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [canResend, setCanResend] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  // Formatar telefone
  const formatPhoneNumber = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 2) return digits;
    if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
  };

  // Carregar estado salvo
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const state: ResetFlowState = JSON.parse(saved);
        
        // Verificar se ainda não expirou
        if (state.expiresAt > Date.now()) {
          setStep(state.step);
          setPhone(state.phone);
          setRequestId(state.requestId);
          setExpiresAt(state.expiresAt);
          
          // Se tem estado salvo, abrir modal automaticamente
          if (state.step !== 'done') {
            onOpenChange(true);
          }
        } else {
          // Expirado - limpar
          localStorage.removeItem(STORAGE_KEY);
        }
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
  }, []);

  // Salvar estado
  const saveState = (newStep: typeof step) => {
    const state: ResetFlowState = {
      step: newStep,
      phone,
      requestId,
      expiresAt,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  };

  // Timer para reenvio
  useEffect(() => {
    if (step === 'code' && !canResend) {
      setResendTimer(60);
      const interval = setInterval(() => {
        setResendTimer(prev => {
          if (prev <= 1) {
            setCanResend(true);
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [step, requestId]);

  // Limpar ao fechar (exceto se não completou)
  const handleClose = (newOpen: boolean) => {
    if (!newOpen && step === 'done') {
      localStorage.removeItem(STORAGE_KEY);
      setStep('phone');
      setPhone('');
      setOtp('');
      setNewPassword('');
      setConfirmPassword('');
      setRequestId('');
      setError('');
    }
    onOpenChange(newOpen);
  };

  // Solicitar código
  const handleRequestCode = async () => {
    setError('');
    setLoading(true);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('password-reset-request', {
        body: { phone: phone.replace(/\D/g, '') },
      });

      if (fnError) throw fnError;

      if (data.ok) {
        setRequestId(data.requestId);
        setExpiresAt(data.expiresAt);
        setStep('code');
        saveState('code');
        setCanResend(false);
      } else {
        if (data.code === 'RATE_LIMITED') {
          setError('Muitas tentativas. Aguarde alguns minutos.');
        } else {
          setError('Verifique se o número está correto (DDD + WhatsApp ativo) e tente novamente.');
        }
      }
    } catch (err: any) {
      console.error('Request code error:', err);
      setError('Não conseguimos enviar o código. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // Verificar código
  const handleVerifyCode = async () => {
    setError('');
    setLoading(true);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('password-reset-verify', {
        body: { requestId, otp },
      });

      if (fnError) throw fnError;

      if (data.ok && data.verified) {
        setStep('new_password');
        saveState('new_password');
      } else {
        if (data.code === 'EXPIRED') {
          setError('Esse código expirou. Solicite um novo código para continuar.');
        } else if (data.code === 'MAX_ATTEMPTS') {
          setError('Muitas tentativas incorretas. Solicite um novo código.');
        } else {
          setError('Código incorreto. Confira os 4 dígitos e tente novamente.');
        }
      }
    } catch (err: any) {
      console.error('Verify code error:', err);
      setError('Erro ao verificar código. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // Alterar senha
  const handleChangePassword = async () => {
    if (newPassword !== confirmPassword) {
      setError('As senhas não coincidem.');
      return;
    }

    if (newPassword.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('password-reset-confirm', {
        body: { requestId, newPassword },
      });

      if (fnError) throw fnError;

      if (data.ok) {
        setStep('done');
        localStorage.removeItem(STORAGE_KEY);
        toast.success('Senha alterada com sucesso!');
        onSuccess?.();
      } else {
        setError(data.message || 'Erro ao alterar senha.');
      }
    } catch (err: any) {
      console.error('Change password error:', err);
      setError('Erro ao alterar senha. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // Reenviar código
  const handleResend = () => {
    setOtp('');
    setStep('phone');
    setCanResend(false);
    localStorage.removeItem(STORAGE_KEY);
  };

  // Voltar para telefone
  const handleBack = () => {
    setStep('phone');
    setOtp('');
    setError('');
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step !== 'phone' && step !== 'done' && (
              <Button variant="ghost" size="icon" onClick={handleBack} className="h-8 w-8">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            )}
            {step === 'phone' && 'Recuperar senha'}
            {step === 'code' && 'Código enviado no WhatsApp'}
            {step === 'new_password' && 'Nova senha'}
            {step === 'done' && 'Senha alterada!'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* PASSO 1: Telefone */}
          {step === 'phone' && (
            <>
              <p className="text-sm text-muted-foreground">
                Digite seu número de WhatsApp e enviaremos um código de verificação.
              </p>
              
              <div className="space-y-2">
                <Label htmlFor="phone">Telefone (WhatsApp)</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(11) 99999-9999"
                  value={formatPhoneNumber(phone)}
                  onChange={(e) => setPhone(e.target.value)}
                  disabled={loading}
                />
              </div>

              {error && (
                <div className="flex items-start gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
                  <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-medium text-sm">Não conseguimos enviar o código</p>
                    <p className="text-sm">{error}</p>
                  </div>
                </div>
              )}

              <Button 
                className="w-full" 
                onClick={handleRequestCode}
                disabled={loading || phone.replace(/\D/g, '').length < 10}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  'Enviar código'
                )}
              </Button>
            </>
          )}

          {/* PASSO 2: Código OTP */}
          {step === 'code' && (
            <>
              <p className="text-sm text-muted-foreground">
                Enviamos um código de 4 dígitos para o seu WhatsApp. Digite o código abaixo para continuar.
              </p>
              
              <div className="flex justify-center py-4">
                <InputOTP 
                  maxLength={4} 
                  value={otp} 
                  onChange={setOtp}
                  disabled={loading}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              {error && (
                <div className="flex items-center gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
                  <AlertCircle className="h-5 w-5 shrink-0" />
                  <p className="text-sm">{error}</p>
                </div>
              )}

              <Button 
                className="w-full" 
                onClick={handleVerifyCode}
                disabled={loading || otp.length !== 4}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Verificando...
                  </>
                ) : (
                  'Confirmar'
                )}
              </Button>

              <div className="text-center">
                {canResend ? (
                  <Button variant="link" onClick={handleResend} className="text-sm">
                    Reenviar código
                  </Button>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Reenviar código em {resendTimer}s
                  </p>
                )}
              </div>
            </>
          )}

          {/* PASSO 3: Nova Senha */}
          {step === 'new_password' && (
            <>
              <p className="text-sm text-muted-foreground">
                Digite sua nova senha abaixo.
              </p>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="newPassword">Nova senha</Label>
                  <PasswordInput
                    id="newPassword"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    disabled={loading}
                    placeholder="Mínimo 6 caracteres"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirmar senha</Label>
                  <PasswordInput
                    id="confirmPassword"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    disabled={loading}
                    placeholder="Digite novamente"
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
                  <AlertCircle className="h-5 w-5 shrink-0" />
                  <p className="text-sm">{error}</p>
                </div>
              )}

              <Button 
                className="w-full" 
                onClick={handleChangePassword}
                disabled={loading || !newPassword || !confirmPassword}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Alterando...
                  </>
                ) : (
                  'Alterar senha'
                )}
              </Button>
            </>
          )}

          {/* PASSO 4: Sucesso */}
          {step === 'done' && (
            <div className="text-center space-y-4 py-4">
              <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto" />
              <p className="text-lg font-medium">Senha alterada com sucesso!</p>
              <p className="text-sm text-muted-foreground">
                Você já pode fazer login com sua nova senha.
              </p>
              <Button className="w-full" onClick={() => handleClose(false)}>
                Fazer login
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
