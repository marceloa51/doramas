import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Play, Lock, Phone } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { getSessionId } from "@/utils/sessionManager";
import { toast } from "sonner";
interface BunnyPlayerProps {
  videoUrl: string;
  dramaTitle: string;
  dramaId: string;
  isPremium: boolean;
  thumbnailUrl?: string;
  startPositionSeconds?: number;
}

const BunnyPlayer = ({
  videoUrl,
  dramaTitle,
  dramaId,
  isPremium,
  thumbnailUrl,
  startPositionSeconds = 0,
}: BunnyPlayerProps) => {
  const navigate = useNavigate();
  const [showPaywall, setShowPaywall] = useState(false);
  const [watchedTime, setWatchedTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [savedPosition, setSavedPosition] = useState(0);
  const [showLeadModal, setShowLeadModal] = useState(false);
  const [leadPhone, setLeadPhone] = useState("");
  const [leadSubmitted, setLeadSubmitted] = useState(false);
  const [extendedTime, setExtendedTime] = useState(false);
  const [leadModalShown, setLeadModalShown] = useState(false);
  const [isSubmittingLead, setIsSubmittingLead] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const lastSaveTimeRef = useRef(0);

  const LEAD_CAPTURE_TIME = 600; // 10 minutos
  const EXTENDED_PREVIEW_LIMIT = 1500; // 25 minutos

  // Verificar se já enviou lead para este drama ou se está logado
  useEffect(() => {
    console.log('[BunnyPlayer] Inicializando:', {
      videoUrl,
      dramaTitle,
      dramaId,
      isPremium,
      userAgent: navigator.userAgent.substring(0, 100),
    });
    
    const checkLeadStatus = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        console.log('[BunnyPlayer] Usuário logado - pulando lead capture');
        setLeadSubmitted(true);
        setExtendedTime(true);
        return;
      }
      
      // Visitante anônimo: verificar localStorage
      const leadKey = `lead_submitted_${dramaId}`;
      const submitted = localStorage.getItem(leadKey) === "true";
      setLeadSubmitted(submitted);
      if (submitted) setExtendedTime(true);
    };
    
    checkLeadStatus();
  }, [dramaId]);

  // Auto-submit quando telefone completar 11 dígitos
  useEffect(() => {
    const phoneDigits = leadPhone.replace(/\D/g, '');
    if (phoneDigits.length === 11 && showLeadModal) {
      handleLeadSubmit();
    }
  }, [leadPhone, showLeadModal]);

  // Carregar progresso salvo ao montar
  useEffect(() => {
    loadSavedProgress();
  }, [dramaId]);

  // Monitorar tempo de reprodução
  useEffect(() => {
    if (!isPlaying || isPremium) return;

    const interval = setInterval(() => {
      setWatchedTime((prev) => {
        const newTime = prev + 1;
        
        // Lead capture aos 10 minutos (SEM janela de tempo restritiva)
        if (!leadSubmitted && !leadModalShown && newTime >= LEAD_CAPTURE_TIME) {
          pauseVideo();
          // Sair do fullscreen antes de mostrar o modal
          if (document.fullscreenElement) {
            document.exitFullscreen().catch(() => {});
          }
          setShowLeadModal(true);
          setLeadModalShown(true);
          return LEAD_CAPTURE_TIME;
        }

        // Paywall aos 25 minutos (se já passou do lead capture)
        const limit = extendedTime ? EXTENDED_PREVIEW_LIMIT : LEAD_CAPTURE_TIME;
        if (newTime >= limit && leadSubmitted) {
          setShowPaywall(true);
          pauseVideo();
          return limit;
        }
        
        return newTime;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlaying, isPremium, leadSubmitted, extendedTime, leadModalShown]);

  // Salvar progresso periodicamente
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      const now = Date.now();
      if (now - lastSaveTimeRef.current >= 10000) {
        saveProgress(watchedTime);
        lastSaveTimeRef.current = now;
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [isPlaying, watchedTime]);

  const loadSavedProgress = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase
        .from("watch_progress")
        .select("position_seconds")
        .eq("user_id", session.user.id)
        .eq("drama_id", dramaId)
        .maybeSingle();

      if (data && !error) {
        setSavedPosition(data.position_seconds);
        setWatchedTime(data.position_seconds);
      }
    } catch (error) {
      console.error("Erro ao carregar progresso:", error);
    }
  };

  const saveProgress = async (currentPosition: number) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const sessionId = getSessionId();
      if (!sessionId) return;

      await supabase.functions.invoke("track-video-progress", {
        body: {
          dramaId,
          currentPosition,
          sessionId,
        },
        headers: {
          "x-session-id": sessionId,
        },
      });
    } catch (error) {
      console.error("Erro ao salvar progresso:", error);
    }
  };

  const pauseVideo = () => {
    if (iframeRef.current?.contentWindow) {
      iframeRef.current.contentWindow.postMessage(
        JSON.stringify({ method: "pause" }),
        "*"
      );
    }
    setIsPlaying(false);
  };

  const playVideo = () => {
    if (iframeRef.current?.contentWindow) {
      iframeRef.current.contentWindow.postMessage(
        JSON.stringify({ method: "play" }),
        "*"
      );
    }
    setIsPlaying(true);
  };

  const seekToPosition = (seconds: number) => {
    if (iframeRef.current?.contentWindow) {
      iframeRef.current.contentWindow.postMessage(
        JSON.stringify({ method: "seek", value: seconds }),
        "*"
      );
    }
  };

  const handlePlayClick = (startPosition?: number) => {
    setHasStarted(true);
    
    // Se tem posição de início, setar antes de dar play
    if (startPosition !== undefined && startPosition > 0) {
      seekToPosition(startPosition);
      console.log(`[BunnyPlayer] Posição inicial setada para ${startPosition}s`);
    } else if (savedPosition > 0) {
      seekToPosition(savedPosition);
    }
    playVideo();
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleActivatePlan = () => {
    navigate("/paywall");
  };

  const isValidPhone = (phone: string): boolean => {
    const digitsOnly = phone.replace(/\D/g, '');
    return digitsOnly.length >= 10 && digitsOnly.length <= 11;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    
    // Formatar: (XX) XXXXX-XXXX (11 dígitos) ou (XX) XXXX-XXXX (10 dígitos)
    if (value.length >= 2) {
      value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
    }
    if (value.length >= 10) {
      const digits = e.target.value.replace(/\D/g, '');
      if (digits.length === 10) {
        value = `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
      } else {
        value = `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
      }
    }
    
    setLeadPhone(value);
  };

  const handleLeadSubmit = async () => {
    // Prevenir double-submit
    if (isSubmittingLead || leadSubmitted) return;
    
    if (!isValidPhone(leadPhone)) {
      toast.error("Por favor, informe um telefone válido");
      return;
    }

    setIsSubmittingLead(true);
    const phoneDigits = leadPhone.replace(/\D/g, '');
    
    // Salvar no Supabase - o trigger do banco envia automaticamente para Dispara Aí
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const { error } = await supabase
        .from('leads')
        .insert({
          phone: phoneDigits,
          drama_id: dramaId,
          drama_title: dramaTitle,
          user_id: session?.user?.id || null,
        });

      if (error) {
        console.warn('[BunnyPlayer] Erro ao salvar lead:', error);
      } else {
        console.log('[BunnyPlayer] Lead salvo - webhook será disparado automaticamente');
      }
    } catch (error: any) {
      console.warn('[BunnyPlayer] Erro ao salvar lead:', error);
    }

    // Atualizar UI
    const leadKey = `lead_submitted_${dramaId}`;
    localStorage.setItem(leadKey, "true");
    
    setLeadSubmitted(true);
    setExtendedTime(true);
    setShowLeadModal(false);
    setIsSubmittingLead(false);
    toast.success("Obrigado! Você ganhou +15 minutos grátis!");
    
    playVideo();
  };

  const limit = extendedTime ? EXTENDED_PREVIEW_LIMIT : LEAD_CAPTURE_TIME;
  const remainingTime = Math.max(0, limit - watchedTime);
  const remainingMinutes = Math.floor(remainingTime / 60);
  const remainingSeconds = remainingTime % 60;

  return (
    <section className="episode-player-section">
      <div className="episode-player-wrapper">
        {/* Iframe do Bunny Player */}
        <iframe
          ref={iframeRef}
          src={videoUrl}
          className="bunny-player-iframe"
          allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture; fullscreen"
          allowFullScreen
          frameBorder="0"
          title={`Player de vídeo - ${dramaTitle}`}
          loading="lazy"
        />

        {/* Overlay de Preview (não-VIP) */}
        {!isPremium && !showPaywall && !showLeadModal && isPlaying && (
          <div className="preview-badge">
            <p className="text-white text-xs sm:text-sm font-medium whitespace-nowrap">
              Preview: {remainingMinutes}:{remainingSeconds.toString().padStart(2, "0")}
            </p>
          </div>
        )}

        {/* Modal de Lead Capture */}
        {showLeadModal && (
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md flex items-center justify-center z-20 p-4">
            <div className="max-w-md w-full mx-auto bg-gradient-to-br from-charcoal-black to-absolute-black border border-fire-orange/30 rounded-xl p-6 space-y-4 shadow-[0_0_40px_rgba(255,140,0,0.3)]">
              <div className="w-16 h-16 mx-auto bg-gradient-to-br from-fire-orange to-fire-yellow-intense rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,140,0,0.5)]">
                <Phone className="w-8 h-8 text-white" />
              </div>

              <div className="text-center space-y-2">
                <h3 className="text-xl font-bold text-glow-yellow-vivid">
                  Ganhe +15 minutos grátis!
                </h3>
                <p className="text-sm text-white/85">
                  Informe seu telefone para continuar assistindo <strong className="text-fire-yellow-bright">{dramaTitle}</strong>
                </p>
              </div>

              <Input
                type="tel"
                placeholder="(99) 99999-9999"
                value={leadPhone}
                onChange={handlePhoneChange}
                className="bg-white/10 border-fire-orange/40 text-white placeholder:text-white/40 focus:border-fire-yellow-intense focus:bg-white/15"
                maxLength={15}
              />

              <Button
                onClick={handleLeadSubmit}
                className="w-full bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_8px_30px_rgba(255,140,0,0.7)] text-white font-bold"
              >
                Continuar Assistindo
              </Button>
            </div>
          </div>
        )}

        {/* Overlay de Paywall */}
        {showPaywall && (
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md flex items-center justify-center z-20 p-4 sm:p-0">
            <div className="max-w-md w-full mx-auto text-center px-4 py-6 sm:p-8 space-y-3 sm:space-y-4">
              <div className="w-12 h-12 sm:w-14 sm:h-14 mx-auto bg-gradient-to-br from-fire-orange to-fire-yellow-intense rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,140,0,0.5)]">
                <Lock className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
              </div>

              <div className="space-y-2 sm:space-y-3">
                <h3 className="text-lg sm:text-xl font-bold text-white">
                  🔒 Preview Finalizado
                </h3>
                <p className="text-sm sm:text-base text-white/90">
                  Você assistiu 25 minutos gratuitos!
                </p>
                <p className="text-sm sm:text-base text-white/90">
                  Quer continuar assistindo{" "}
                  <span className="font-bold text-fire-yellow-bright">{dramaTitle}</span>{" "}
                  SEM travar e até o final?
                </p>
                <p className="text-xs sm:text-sm text-red-400/60 italic">
                  Oferta exclusiva enquanto a janela estiver aberta.
                </p>
                <div className="text-base sm:text-lg pt-1">
                  <span className="text-white/60 line-through mr-2">De R$ 39,00</span>
                  <span className="text-white">→ por apenas </span>
                  <span className="text-2xl sm:text-3xl font-extrabold text-fire-yellow-intense">
                    R$ 12,90
                  </span>
                </div>
              </div>

              <Button
                onClick={() => navigate(`/checkout/${dramaId}`)}
                className="w-full min-h-[44px] sm:min-h-[48px] bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_8px_30px_rgba(255,140,0,0.7)] text-black font-bold px-4 sm:px-6 py-3 text-sm sm:text-base transition-all duration-300"
              >
                🔘 Liberar dorama completo por R$ 12,90
              </Button>
            </div>
          </div>
        )}

        {/* Botão de Play Inicial */}
        {!hasStarted && !showPaywall && !showLeadModal && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
            {startPositionSeconds > 0 ? (
              // Mostrar 2 botões quando tem posição de início configurada
              <div className="flex flex-col gap-3 px-6 w-full max-w-md">
                <Button
                  onClick={() => handlePlayClick(startPositionSeconds)}
                  size="lg"
                  className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:from-fire-yellow-intense hover:to-fire-orange text-white font-bold text-base sm:text-lg px-6 py-4 min-h-[56px] shadow-[0_4px_20px_rgba(255,140,0,0.4)] hover:shadow-[0_8px_30px_rgba(255,140,0,0.6)] transition-all duration-300 rounded-xl"
                >
                  🔥 Continuar de onde parei
                </Button>
                
                <Button
                  onClick={() => handlePlayClick(0)}
                  variant="outline"
                  size="lg"
                  className="w-full border-2 border-fire-orange/50 bg-transparent hover:bg-fire-orange/10 text-white font-semibold text-base sm:text-lg px-6 py-4 min-h-[52px] transition-all duration-300 rounded-xl"
                >
                  ▶️ Começar do início
                </Button>
              </div>
            ) : (
              // Botão único quando não tem posição de início
              <Button
                onClick={() => handlePlayClick(0)}
                size="lg"
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-fire-orange hover:bg-fire-glow shadow-2xl transition-transform hover:scale-110 active:scale-95"
                aria-label={`Reproduzir ${dramaTitle}`}
              >
                <Play className="w-6 h-6 sm:w-8 sm:h-8 text-white fill-white" />
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Informações do Vídeo */}
      <div className="episode-player-info">
        <h2 className="text-lg sm:text-xl font-bold text-white line-clamp-2">{dramaTitle}</h2>
        {!isPremium && (
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">
            {extendedTime ? "Preview gratuito: primeiros 25 minutos" : "Preview gratuito: primeiros 10 minutos (+ 15 min com telefone)"}
          </p>
        )}
      </div>
    </section>
  );
};

export default BunnyPlayer;
