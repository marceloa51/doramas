import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface YouTubePlayerProps {
  youtubeId: string;
  dramaId: string;
  dramaTitle: string;
  onPreviewFinished?: () => void;
}

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

const YouTubePlayer = ({ youtubeId, dramaId, dramaTitle, onPreviewFinished }: YouTubePlayerProps) => {
  const [player, setPlayer] = useState<any>(null);
  const [isPreviewFinished, setIsPreviewFinished] = useState(false);
  const [hasActivePlan, setHasActivePlan] = useState(false);
  const [watchTime, setWatchTime] = useState(0);
  const [loading, setLoading] = useState(true);
  const playerRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const PREVIEW_LIMIT_SECONDS = 1500; // 25 minutes

  useEffect(() => {
    checkUserSubscription();
    loadYouTubeAPI();
    disableKeyboardShortcuts();

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      enableKeyboardShortcuts();
    };
  }, []);

  const checkUserSubscription = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setHasActivePlan(false);
        setLoading(false);
        return;
      }

      const { data: profile } = await supabase
        .from("profiles")
        .select("plan_status")
        .eq("id", user.id)
        .single();

      setHasActivePlan(profile?.plan_status === "active");
      setLoading(false);
    } catch (error) {
      console.error("Error checking subscription:", error);
      setHasActivePlan(false);
      setLoading(false);
    }
  };

  const loadYouTubeAPI = () => {
    if (window.YT) {
      initializePlayer();
      return;
    }

    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    const firstScriptTag = document.getElementsByTagName("script")[0];
    firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);

    window.onYouTubeIframeAPIReady = initializePlayer;
  };

  const initializePlayer = () => {
    if (!playerRef.current || !window.YT) return;

    const newPlayer = new window.YT.Player(playerRef.current, {
      videoId: youtubeId,
      playerVars: {
        autoplay: 0,
        controls: 0,
        disablekb: 1,
        fs: 0,
        modestbranding: 1,
        rel: 0,
        showinfo: 0,
        iv_load_policy: 3,
        cc_load_policy: 0,
        playsinline: 1,
      },
      events: {
        onReady: onPlayerReady,
        onStateChange: onPlayerStateChange,
      },
    });

    setPlayer(newPlayer);
  };

  const onPlayerReady = (event: any) => {
    console.log("YouTube player ready");
  };

  const onPlayerStateChange = (event: any) => {
    // 1 = playing
    if (event.data === 1 && !hasActivePlan && !intervalRef.current) {
      startWatchTimer();
    }
    // 2 = paused, 0 = ended
    if (event.data === 2 || event.data === 0) {
      stopWatchTimer();
    }
  };

  const startWatchTimer = () => {
    if (intervalRef.current) return;

    intervalRef.current = setInterval(() => {
      setWatchTime((prev) => {
        const newTime = prev + 1;

        if (newTime >= PREVIEW_LIMIT_SECONDS && !hasActivePlan) {
          handlePreviewEnd();
          return prev;
        }

        // Track progress every 10 seconds
        if (newTime % 10 === 0) {
          trackProgress(newTime);
        }

        return newTime;
      });
    }, 1000);
  };

  const stopWatchTimer = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const handlePreviewEnd = () => {
    stopWatchTimer();
    
    if (player) {
      player.pauseVideo();
    }

    setIsPreviewFinished(true);
    
    toast({
      title: "Prévia encerrada",
      description: "Assine para continuar assistindo!",
      variant: "destructive",
    });

    if (onPreviewFinished) {
      onPreviewFinished();
    }
  };

  const trackProgress = async (currentTime: number) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.functions.invoke("track-video-progress", {
        body: {
          dramaId,
          currentPosition: currentTime,
          totalDuration: player?.getDuration() || 0,
        },
      });
    } catch (error) {
      console.error("Error tracking progress:", error);
    }
  };

  const disableKeyboardShortcuts = () => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Block F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, Ctrl+S
      if (
        e.key === "F12" ||
        (e.ctrlKey && e.shiftKey && (e.key === "I" || e.key === "J")) ||
        (e.ctrlKey && e.key === "u") ||
        (e.ctrlKey && e.key === "s")
      ) {
        e.preventDefault();
        return false;
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  };

  const enableKeyboardShortcuts = () => {
    // Cleanup is handled in useEffect return
  };

  const handleActivatePlan = () => {
    navigate("/paywall");
  };

  if (loading) {
    return (
      <div className="relative w-full aspect-video bg-card rounded-lg flex items-center justify-center">
        <div className="animate-pulse">Carregando player...</div>
      </div>
    );
  }

  if (isPreviewFinished) {
    return (
      <div className="relative w-full aspect-video bg-gradient-to-br from-card via-background to-card rounded-lg overflow-hidden border border-border">
        <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center space-y-6">
          <div className="space-y-3">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Prévia Encerrada
            </h2>
            <p className="text-lg text-muted-foreground max-w-md">
              Você assistiu aos primeiros 25 minutos de <span className="font-semibold text-foreground">{dramaTitle}</span>
            </p>
          </div>
          
          <div className="bg-drama-red/10 border border-drama-red/30 rounded-lg p-6 max-w-lg">
            <p className="text-foreground mb-4">
              Assine o <span className="font-bold text-drama-red">Plano Premium</span> por apenas <span className="text-2xl font-bold text-drama-red">R$ 10,00</span> e tenha acesso completo a todos os filmes!
            </p>
            <Button 
              onClick={handleActivatePlan}
              className="w-full bg-drama-red hover:bg-drama-red/90 text-white font-semibold py-6 text-lg"
            >
              Ativar Plano Premium
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const remainingTime = hasActivePlan ? null : Math.max(0, PREVIEW_LIMIT_SECONDS - watchTime);
  const minutes = remainingTime ? Math.floor(remainingTime / 60) : 0;
  const seconds = remainingTime ? remainingTime % 60 : 0;

  return (
    <div className="relative w-full">
      {!hasActivePlan && watchTime > 0 && (
        <div className="absolute top-4 right-4 z-10 bg-black/80 text-white px-4 py-2 rounded-lg text-sm font-semibold">
          Prévia: {minutes}:{seconds.toString().padStart(2, "0")} restantes
        </div>
      )}
      
      <div 
        className="relative w-full aspect-video bg-black rounded-lg overflow-hidden"
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* Overlay to prevent direct interaction with YouTube iframe */}
        <div 
          className="absolute inset-0 z-[1] pointer-events-none"
          style={{ userSelect: "none" }}
        />
        
        <div 
          ref={playerRef}
          className="w-full h-full"
          style={{ pointerEvents: "all" }}
        />
      </div>
    </div>
  );
};

export default YouTubePlayer;
