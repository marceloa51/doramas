import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { X, Gift, TrendingUp, Wallet as WalletIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const AffiliatePopup = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Rotas onde o popup NÃO deve aparecer
  const excludedRoutes = [
    '/auth',
    '/admin',
    '/wallet',
    '/paywall',
    '/pagamento-sucesso',
    '/pagamento-cancelado',
    '/payment-success',
    '/payment-canceled',
    '/payment-confirmed'
  ];

  useEffect(() => {
    const checkAndShowPopup = () => {
      // Verificar se está em uma rota excluída
      const isExcludedRoute = excludedRoutes.some(route => 
        location.pathname.startsWith(route)
      );

      if (isExcludedRoute) return;

      // Ler contador de visitas do localStorage
      const visitsKey = 'ds_aff_popup_visits';
      const closedKey = 'ds_aff_popup_closed';
      
      let visits = parseInt(localStorage.getItem(visitsKey) || '0', 10);
      const lastClosed = localStorage.getItem(closedKey);

      // Verificar se foi fechado recentemente (últimos 10 minutos)
      if (lastClosed) {
        const lastClosedTime = parseInt(lastClosed, 10);
        const now = Date.now();
        const tenMinutes = 10 * 60 * 1000;
        
        if (now - lastClosedTime < tenMinutes) {
          return;
        }
      }

      // Incrementar contador de visitas
      visits += 1;
      localStorage.setItem(visitsKey, visits.toString());

      // Mostrar popup a cada 2 visitas
      if (visits % 2 === 0) {
        setIsOpen(true);
      }
    };

    checkAndShowPopup();
  }, [location.pathname]);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem('ds_aff_popup_closed', Date.now().toString());
  };

  const handleCTA = async () => {
    setIsLoading(true);
    
    try {
      // Verificar se o usuário está logado
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user) {
        // Usuário logado - redirecionar direto para wallet
        navigate('/wallet');
      } else {
        // Usuário não logado - redirecionar para login com redirect
        navigate('/auth?redirect=/wallet');
      }
      
      handleClose();
    } catch (error) {
      console.error('[AffiliatePopup] Error checking session:', error);
      navigate('/auth?redirect=/wallet');
      handleClose();
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="relative w-full max-w-[90vw] md:max-w-[450px] max-h-[80vh] overflow-y-auto bg-drama-card border-2 border-fire-orange/30 rounded-2xl p-6 md:p-7 shadow-[0_20px_60px_rgba(255,106,0,0.3)] animate-in zoom-in duration-300">
        {/* Botão Fechar */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-fire-orange/10 transition-colors"
          aria-label="Fechar popup"
        >
          <X className="w-5 h-5 text-muted-foreground hover:text-fire-orange" />
        </button>

        {/* Ícone Principal */}
        <div className="flex justify-center mb-4">
          <div className="p-3 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense shadow-[0_0_30px_rgba(255,140,0,0.5)]">
            <Gift className="w-8 h-8 text-white" />
          </div>
        </div>

        {/* Título */}
        <h2 className="text-xl md:text-2xl font-bold text-center mb-2 bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light bg-clip-text text-transparent leading-tight">
          Ganhe dinheiro indicando doramas 🎬💰
        </h2>

        {/* Subtítulo */}
        <p className="text-base text-center text-fire-yellow-intense font-semibold mb-4">
          Você pode ganhar até R$ 200 por dia divulgando o Doramas Super.
        </p>

        {/* Lista de Benefícios */}
        <div className="space-y-2 mb-5 bg-background/50 rounded-xl p-4 border border-fire-orange/10">
          <div className="flex items-start gap-2">
            <TrendingUp className="w-4 h-4 text-fire-yellow-intense flex-shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              Cada amigo que você convida e começa a usar o site pode gerar comissão pra você
            </p>
          </div>
          <div className="flex items-start gap-2">
            <TrendingUp className="w-4 h-4 text-fire-yellow-intense flex-shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              Quanto mais gente você traz, mais você ganha
            </p>
          </div>
          <div className="flex items-start gap-2">
            <WalletIcon className="w-4 h-4 text-fire-yellow-intense flex-shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              Tudo é controlado pela sua Carteira Doramas Super: ganhos, indicações e saques
            </p>
          </div>
        </div>

        {/* CTA Principal */}
        <Button
          onClick={handleCTA}
          disabled={isLoading}
          className="w-full h-12 text-base font-bold bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light text-white hover:shadow-[0_15px_50px_rgba(255,140,0,0.6)] hover:scale-105 transition-all duration-300 active:scale-95 mb-3"
        >
          {isLoading ? (
            <>Carregando...</>
          ) : (
            <>
              <WalletIcon className="w-5 h-5 mr-2" />
              Ver minha carteira
            </>
          )}
        </Button>

        {/* Botão Secundário */}
        <Button
          onClick={handleClose}
          variant="ghost"
          className="w-full h-10 text-sm text-muted-foreground hover:text-fire-orange hover:bg-fire-orange/5 transition-colors"
        >
          Não tenho interesse agora
        </Button>
      </div>
    </div>
  );
};
