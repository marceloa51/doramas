import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";

interface Drama {
  id: string;
  title: string;
  thumbnail_url: string | null;
  cover_url: string | null;
}

export const VIPDramaCarousel = () => {
  const [dramas, setDramas] = useState<Drama[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDramas = async () => {
      const { data, error } = await supabase
        .from("dramas")
        .select("id, title, thumbnail_url, cover_url")
        .eq("status", "active")
        .limit(10);

      if (!error && data) {
        setDramas(data);
      }
      setLoading(false);
    };

    fetchDramas();
  }, []);

  if (loading) {
    return (
      <div className="flex gap-4 overflow-hidden">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="w-32 h-48 md:w-40 md:h-56 bg-muted/30 rounded-lg animate-pulse flex-shrink-0"
          />
        ))}
      </div>
    );
  }

  if (dramas.length === 0) return null;

  return (
    <Carousel
      opts={{
        align: "start",
        loop: true,
      }}
      plugins={[
        Autoplay({
          delay: 3000,
          stopOnInteraction: false,
          stopOnMouseEnter: true,
        }),
      ]}
      className="w-full"
    >
      <CarouselContent className="-ml-2 md:-ml-4">
        {dramas.map((drama) => (
          <CarouselItem
            key={drama.id}
            className="pl-2 md:pl-4 basis-1/3 md:basis-1/4 lg:basis-1/5"
          >
            <div className="relative group overflow-hidden rounded-lg aspect-[2/3] shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <img
                src={drama.thumbnail_url || drama.cover_url || "/placeholder.svg"}
                alt={drama.title}
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 left-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <p className="text-white text-xs md:text-sm font-medium line-clamp-2 text-center">
                  {drama.title}
                </p>
              </div>
            </div>
          </CarouselItem>
        ))}
      </CarouselContent>
    </Carousel>
  );
};
