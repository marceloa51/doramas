import { useState } from "react";
import { Link } from "react-router-dom";
import { Play, Film } from "lucide-react";
import { Card } from "@/components/ui/card";

interface DramaCardProps {
  id: string;
  title: string;
  thumbnail: string;
  genres?: string[];
  totalEpisodes?: number;
  slug: string;
}

const DramaCard = ({ id, title, thumbnail, genres, totalEpisodes, slug }: DramaCardProps) => {
  const [imgError, setImgError] = useState(false);
  
  return (
    <Link to={`/movie/${slug}`}>
      <Card className="group relative overflow-hidden bg-drama-card border-drama-border hover:border-fire-orange hover:shadow-[0_0_20px_rgba(255,170,0,0.6)] transition-all duration-300 cursor-pointer">
        <div className="aspect-[2/3] relative overflow-hidden bg-drama-dark">
          {!imgError && thumbnail ? (
            <img
              src={encodeURI(thumbnail)}
              alt={title}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              onError={(e) => {
                console.error('[DramaCard] Erro ao carregar imagem:', thumbnail, e);
                setImgError(true);
              }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-drama-dark to-drama-card">
              <div className="text-center p-4">
                <Film className="w-12 h-12 mx-auto mb-2 text-drama-red opacity-50" />
                <p className="text-sm text-muted-foreground">{title}</p>
              </div>
            </div>
          )}
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Play Button */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center shadow-[0_8px_32px_rgba(255,140,0,0.5)]">
              <Play className="w-6 h-6 text-white fill-white ml-1" />
            </div>
          </div>

          {/* Info Overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
            <h3 className="font-bold text-white mb-1 line-clamp-2">{title}</h3>
            <div className="flex flex-wrap gap-1 text-xs">
              {genres?.slice(0, 3).map((genre) => (
                <span key={genre} className="px-2 py-0.5 bg-fire-orange/30 text-fire-yellow-intense rounded">
                  {genre}
                </span>
              ))}
            </div>
          </div>
        </div>
      </Card>
    </Link>
  );
};

export default DramaCard;
