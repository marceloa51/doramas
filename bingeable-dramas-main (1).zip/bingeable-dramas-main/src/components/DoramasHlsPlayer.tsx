import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Play, Lock, Phone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { getSessionId } from "@/utils/sessionManager";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface DoramasHlsPlayerProps {
  hlsUrl: string;
  dramaTitle: string;
  dramaId: string;
  isPremium: boolean;
  thumbnailUrl?: string;
  previewSeconds?: number;
  startPositionSeconds?: number;
}

const DoramasHlsPlayer = ({ 
  hlsUrl, 
  dramaTitle, 
  dramaId, 
  isPremium, 
  thumbnailUrl,
  previewSeconds = 1500,
  startPositionSeconds = 0,
}: DoramasHlsPlayerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const navigate = useNavigate();
  
  const LEAD_CAPTURE_TIME = 600; // 10 minutos
  const EXTENDED_PREVIEW_LIMIT = 1500; // 25 minutos
  const MAX_RETRIES = 3;
  const LOADING_TIMEOUT = 15000; // 15 segundos
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  const [watchedTime, setWatchedTime] = useState(0);
  const [savedPosition, setSavedPosition] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [showLeadModal, setShowLeadModal] = useState(false);
  const [leadPhone, setLeadPhone] = useState("");
  const [leadSubmitted, setLeadSubmitted] = useState(false);
  const [extendedTime, setExtendedTime] = useState(false);
  const [leadModalShown, setLeadModalShown] = useState(false);
  const [isSubmittingLead, setIsSubmittingLead] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [retryCount, setRetryCount] = useState(0);
  const [showIframeFallback, setShowIframeFallback] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const lastSaveTime = useRef<number>(0);
  const loadingTimeoutRef = useRef<NodeJS.Timeout>();

  // Verificar se já enviou lead para este drama ou se está logado
  useEffect(() => {
    const checkLeadStatus = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        console.log('[DoramasHlsPlayer] Usuário logado - pulando lead capture');
        setLeadSubmitted(true);
        setExtendedTime(true);
        return;
      }
      
      // Visitante anônimo: verificar localStorage
      const leadKey = `lead_submitted_${dramaId}`;
      const submitted = localStorage.getItem(leadKey) === "true";
      setLeadSubmitted(submitted);
      if (submitted) setExtendedTime(true);
    };
    
    checkLeadStatus();
  }, [dramaId]);

  // Auto-submit quando telefone completar 11 dígitos
  useEffect(() => {
    const phoneDigits = leadPhone.replace(/\D/g, '');
    if (phoneDigits.length === 11 && showLeadModal) {
      handleLeadSubmit();
    }
  }, [leadPhone, showLeadModal]);

  // 1. INICIALIZAÇÃO DO HLS
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    console.log('[DoramasHlsPlayer] Inicializando:', {
      hlsUrl,
      dramaTitle,
      userAgent: navigator.userAgent.substring(0, 100),
      retryCount,
      platform: navigator.platform,
    });

    // Carregar progresso salvo
    loadSavedProgress();

    // Timeout para loading infinito
    loadingTimeoutRef.current = setTimeout(() => {
      if (isLoading) {
        console.error('[DoramasHlsPlayer] Timeout após 15s');
        setErrorMessage('O vídeo demorou muito para carregar. Verifique sua conexão.');
        setHasError(true);
        setIsLoading(false);
      }
    }, LOADING_TIMEOUT);

    // Safari suporta HLS nativamente
    if (video.canPlayType('application/vnd.apple.mpegurl')) {
      console.log('[DoramasHlsPlayer] Usando HLS nativo (Safari)');
      video.src = hlsUrl;
      
      video.addEventListener('loadedmetadata', () => {
        setIsLoading(false);
        setHasError(false);
        if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
        console.log('[DoramasHlsPlayer] Metadata carregada (Safari)');
      });

      video.addEventListener('error', (e) => {
        console.error('[DoramasHlsPlayer] Erro (Safari):', {
          error: video.error,
          code: video.error?.code,
          message: video.error?.message,
        });
        if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
        
        if (retryCount < MAX_RETRIES) {
          console.log(`[DoramasHlsPlayer] Retry ${retryCount + 1}/${MAX_RETRIES}`);
          setRetryCount(prev => prev + 1);
          setTimeout(() => video.load(), 1000);
        } else {
          setErrorMessage('Erro ao carregar o vídeo. Tentando outro método...');
          setHasError(true);
          setIsLoading(false);
        }
      });

      return () => {
        if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
      };
    } 
    // Outros navegadores: usar hls.js
    else if (Hls.isSupported()) {
      console.log('[DoramasHlsPlayer] Usando HLS.js');
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: false,
        backBufferLength: 90,
      });
      
      hls.loadSource(hlsUrl);
      hls.attachMedia(video);
      
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setIsLoading(false);
        setHasError(false);
        if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
        console.log('[DoramasHlsPlayer] Manifest parsed');
      });
      
      hls.on(Hls.Events.ERROR, (event, data) => {
        console.error('[DoramasHlsPlayer] HLS Error:', {
          type: data.type,
          details: data.details,
          fatal: data.fatal,
          url: data.url,
        });
        
        if (data.fatal) {
          if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
          
          if (retryCount < MAX_RETRIES) {
            console.log(`[DoramasHlsPlayer] Retry fatal ${retryCount + 1}/${MAX_RETRIES}`);
            setRetryCount(prev => prev + 1);
            
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                setTimeout(() => hls.startLoad(), 1000);
                break;
              case Hls.ErrorTypes.MEDIA_ERROR:
                setTimeout(() => hls.recoverMediaError(), 1000);
                break;
              default:
                setErrorMessage('Erro ao carregar o vídeo. Tentando outro método...');
                setHasError(true);
                setIsLoading(false);
                break;
            }
          } else {
            console.error('[DoramasHlsPlayer] Max retries atingido');
            setErrorMessage('Não foi possível carregar após várias tentativas.');
            setHasError(true);
            setIsLoading(false);
          }
        }
      });
      
      hlsRef.current = hls;
      
      return () => {
        if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
        if (hlsRef.current) {
          hlsRef.current.destroy();
          hlsRef.current = null;
        }
      };
    } else {
      console.error('[DoramasHlsPlayer] HLS não suportado');
      if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
      setErrorMessage('Seu navegador não suporta este formato de vídeo.');
      setHasError(true);
      setIsLoading(false);
    }
  }, [hlsUrl, retryCount]);

  // 2. CARREGAR PROGRESSO SALVO
  const loadSavedProgress = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) return;

    // Buscar da tabela movie_views (onde o progresso é salvo)
    const { data } = await supabase
      .from("movie_views")
      .select("last_position_seconds")
      .eq("user_id", session.user.id)
      .eq("drama_id", dramaId)
      .maybeSingle();

    console.log('[DoramasHlsPlayer] Progresso carregado:', data?.last_position_seconds, 'isPremium:', isPremium);
    
    // Carregar progresso para quem tem acesso (comprou ou tem VIP)
    if (data?.last_position_seconds && data.last_position_seconds > 0 && isPremium) {
      setSavedPosition(data.last_position_seconds);
    }
  };

  // 3. MONITORAR TEMPO E APLICAR PREVIEW LIMIT
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      const currentTime = video.currentTime;
      
      // Não-premium: verificar lead capture aos 10 minutos (SEM janela de tempo restritiva)
      if (!isPremium && !leadSubmitted && !leadModalShown && currentTime >= LEAD_CAPTURE_TIME) {
        video.pause();
        // Sair do fullscreen antes de mostrar o modal
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
        setShowLeadModal(true);
        setLeadModalShown(true);
        setIsPlaying(false);
        return;
      }

      // Não-premium: bloquear após extended preview limit (25 min)
      const limit = extendedTime ? EXTENDED_PREVIEW_LIMIT : previewSeconds;
      if (!isPremium && currentTime >= limit) {
        video.pause();
        video.currentTime = limit;
        setShowPaywall(true);
        setIsPlaying(false);
        return;
      }

      setWatchedTime(Math.floor(currentTime));
      
      // Salvar progresso
      if (video.duration) {
        saveProgress(currentTime, video.duration);
      }
    };

    const handleSeeking = () => {
      // Impedir seek além do limite para não-premium
      const limit = extendedTime ? EXTENDED_PREVIEW_LIMIT : previewSeconds;
      if (!isPremium && video.currentTime > limit) {
        video.currentTime = limit;
      }
    };

    const handleLoadedMetadata = () => {
      // Restaurar posição salva
      if (savedPosition > 0 && isPremium) {
        video.currentTime = savedPosition;
      }
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('seeking', handleSeeking);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('play', handlePlay);
    video.addEventListener('pause', handlePause);

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('seeking', handleSeeking);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('pause', handlePause);
    };
  }, [isPremium, previewSeconds, savedPosition, dramaId, leadSubmitted, extendedTime, leadModalShown]);

  // 4. SALVAR PROGRESSO (apenas para quem comprou/tem VIP)
  const saveProgress = async (currentTime: number, duration: number) => {
    // Só salvar progresso para quem tem acesso
    if (!isPremium) return;
    
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) return;

    const now = Date.now();
    // Salvar a cada 5 segundos para garantir que não perca progresso
    if (now - lastSaveTime.current < 5000) return;
    lastSaveTime.current = now;

    const position = Math.floor(currentTime);
    
    console.log('[DoramasHlsPlayer] Salvando progresso:', position, 'segundos');

    try {
      // Verificar se já existe registro
      const { data: existing } = await supabase
        .from("movie_views")
        .select("id")
        .eq("user_id", session.user.id)
        .eq("drama_id", dramaId)
        .maybeSingle();
      
      if (existing) {
        // Atualizar registro existente
        await supabase
          .from("movie_views")
          .update({
            last_position_seconds: position,
            updated_at: new Date().toISOString(),
          })
          .eq("id", existing.id);
      } else {
        // Inserir novo registro
        await supabase
          .from("movie_views")
          .insert({
            user_id: session.user.id,
            drama_id: dramaId,
            last_position_seconds: position,
          });
      }
    } catch (err) {
      console.error('[DoramasHlsPlayer] Erro ao salvar progresso:', err);
    }
  };

  // 5. HANDLERS
  const handlePlayClick = (startPosition?: number) => {
    const video = videoRef.current;
    if (!video) return;

    setHasStarted(true);

    // Se tem posição de início, setar antes de dar play
    if (startPosition !== undefined && startPosition > 0) {
      video.currentTime = startPosition;
      console.log(`[DoramasHlsPlayer] Posição inicial setada para ${startPosition}s`);
    }

    video.play();
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const isValidPhone = (phone: string): boolean => {
    const digitsOnly = phone.replace(/\D/g, '');
    return digitsOnly.length >= 10 && digitsOnly.length <= 11;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    
    // Formatar: (XX) XXXXX-XXXX (11 dígitos) ou (XX) XXXX-XXXX (10 dígitos)
    if (value.length >= 2) {
      value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
    }
    if (value.length >= 10) {
      const digits = e.target.value.replace(/\D/g, '');
      if (digits.length === 10) {
        value = `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
      } else {
        value = `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
      }
    }
    
    setLeadPhone(value);
  };

  const handleLeadSubmit = async () => {
    // Prevenir double-submit
    if (isSubmittingLead || leadSubmitted) return;
    
    if (!isValidPhone(leadPhone)) {
      toast.error("Por favor, informe um telefone válido");
      return;
    }

    setIsSubmittingLead(true);
    const phoneDigits = leadPhone.replace(/\D/g, '');
    
    // Salvar no Supabase - o trigger do banco envia automaticamente para Dispara Aí
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const { error } = await supabase
        .from('leads')
        .insert({
          phone: phoneDigits,
          drama_id: dramaId,
          drama_title: dramaTitle,
          user_id: session?.user?.id || null,
        });

      if (error) {
        console.warn('[DoramasHlsPlayer] Erro ao salvar lead:', error);
      } else {
        console.log('[DoramasHlsPlayer] Lead salvo - webhook será disparado automaticamente');
      }
    } catch (error: any) {
      console.warn('[DoramasHlsPlayer] Erro ao salvar lead:', error);
    }

    // Atualizar UI
    const leadKey = `lead_submitted_${dramaId}`;
    localStorage.setItem(leadKey, "true");
    
    setLeadSubmitted(true);
    setExtendedTime(true);
    setShowLeadModal(false);
    setIsSubmittingLead(false);
    toast.success("Obrigado! Você ganhou +15 minutos grátis!");
    
    videoRef.current?.play();
  };

  const handleTryIframe = () => {
    setShowIframeFallback(true);
    setHasError(false);
  };

  const limit = extendedTime ? EXTENDED_PREVIEW_LIMIT : previewSeconds;
  const remainingTime = Math.max(0, limit - watchedTime);
  const remainingMinutes = Math.floor(remainingTime / 60);
  const remainingSeconds = remainingTime % 60;

  // Calcular URL do iframe fallback (mas não retorna componente separado!)
  const bunnyIframeUrl = showIframeFallback && hlsUrl 
    ? (() => {
        const videoIdMatch = hlsUrl.match(/\/([a-f0-9-]{36})\//);
        return videoIdMatch 
          ? `https://iframe.mediadelivery.net/play/547891/${videoIdMatch[1]}`
          : null;
      })()
    : null;

  if (showIframeFallback && bunnyIframeUrl) {
    console.log('[DoramasHlsPlayer] Usando iframe fallback com visual idêntico:', bunnyIframeUrl);
  }

  // 6. RENDER
  if (hasError) {
    return (
      <section className="episode-player-section">
        <div className="episode-player-wrapper">
          <div className="absolute inset-0 flex items-center justify-center bg-black p-4">
            <div className="text-center max-w-md space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-fire-orange/20 flex items-center justify-center">
                <Play className="w-8 h-8 text-fire-orange" />
              </div>
              <h3 className="text-xl font-bold text-white">Problema ao carregar</h3>
              <p className="text-sm text-gray-300">{errorMessage}</p>
              <div className="flex flex-col gap-3">
                <Button
                  onClick={() => {
                    setHasError(false);
                    setRetryCount(0);
                    setIsLoading(true);
                  }}
                  className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white font-bold"
                >
                  Tentar Novamente
                </Button>
                <Button
                  onClick={handleTryIframe}
                  variant="outline"
                  className="border-fire-orange/50 text-white hover:bg-fire-orange/20"
                >
                  Tentar Outro Método
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (showPaywall) {
    return (
      <section className="episode-player-section">
        <div className="w-full max-w-xl mx-auto bg-black rounded-xl overflow-hidden border border-border px-4 py-5 sm:px-6 sm:py-6 flex items-center justify-center">
          <div className="w-full max-w-md mx-auto text-center space-y-3 sm:space-y-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto bg-gradient-to-br from-fire-orange to-fire-yellow-intense rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,140,0,0.5)]">
              <Lock className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>

            <div className="space-y-2 sm:space-y-3">
              <h3 className="text-lg sm:text-xl font-bold leading-tight text-white">
                🔒 Preview Finalizado
              </h3>
              <p className="text-sm sm:text-base text-white/90">
                Você assistiu 25 minutos gratuitos!
              </p>
              <p className="text-sm sm:text-base text-white/90">
                Quer continuar assistindo{" "}
                <span className="font-bold text-fire-yellow-bright">{dramaTitle}</span>{" "}
                SEM travar e até o final?
              </p>
              <p className="text-xs sm:text-sm text-red-400/60 italic">
                Oferta exclusiva enquanto a janela estiver aberta.
              </p>
              <div className="text-base sm:text-lg pt-1">
                <span className="text-white/60 line-through mr-2">De R$ 39,00</span>
                <span className="text-white">→ por apenas </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-fire-yellow-intense">
                  R$ 12,90
                </span>
              </div>
            </div>

            <Button
              onClick={() => navigate(`/checkout/${dramaId}`)}
              className="w-full min-h-[44px] sm:min-h-[48px] bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_8px_30px_rgba(255,140,0,0.7)] text-black font-bold px-4 sm:px-6 py-3 text-sm sm:text-base transition-all duration-300"
            >
              🔘 Liberar dorama completo por R$ 12,90
            </Button>
          </div>
        </div>
      </section>
    );
  }

  // 6. RENDER
  return (
    <section className="episode-player-section">
      <div className="episode-player-wrapper">
        {/* VIDEO ou IFRAME dependendo do modo */}
        {showIframeFallback && bunnyIframeUrl ? (
          <iframe
            ref={iframeRef}
            src={bunnyIframeUrl}
            className="absolute inset-0 w-full h-full border-0 bg-black"
            allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowFullScreen
            title={`Player de vídeo - ${dramaTitle}`}
          />
        ) : (
          <video
            ref={videoRef}
            className="hls-video-element"
            playsInline
            controls
            controlsList="nodownload"
            onContextMenu={(e) => e.preventDefault()}
            poster={thumbnailUrl}
          />
        )}

        {/* BADGE DE PREVIEW */}
        {!isPremium && isPlaying && !showPaywall && !showLeadModal && (
          <div className="preview-badge">
            <p className="text-xs sm:text-sm font-medium text-white">
              Preview: {remainingMinutes}:{remainingSeconds.toString().padStart(2, "0")}
            </p>
          </div>
        )}

        {/* MODAL DE LEAD CAPTURE */}
        {showLeadModal && (
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md flex items-center justify-center z-20 p-4">
            <div className="max-w-md w-full mx-auto bg-gradient-to-br from-charcoal-black to-absolute-black border border-fire-orange/30 rounded-xl p-6 space-y-4 shadow-[0_0_40px_rgba(255,140,0,0.3)]">
              <div className="w-16 h-16 mx-auto bg-gradient-to-br from-fire-orange to-fire-yellow-intense rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,140,0,0.5)]">
                <Phone className="w-8 h-8 text-white" />
              </div>

              <div className="text-center space-y-2">
                <h3 className="text-xl font-bold text-glow-yellow-vivid">
                  Ganhe +15 minutos grátis!
                </h3>
                <p className="text-sm text-white/85">
                  Informe seu telefone para continuar assistindo <strong className="text-fire-yellow-bright">{dramaTitle}</strong>
                </p>
              </div>

              <Input
                type="tel"
                placeholder="(99) 99999-9999"
                value={leadPhone}
                onChange={handlePhoneChange}
                className="bg-white/10 border-fire-orange/40 text-white placeholder:text-white/40 focus:border-fire-yellow-intense focus:bg-white/15"
                maxLength={15}
              />

              <Button
                onClick={handleLeadSubmit}
                className="w-full bg-gradient-to-r from-fire-orange via-fire-yellow-intense to-fire-yellow-light hover:shadow-[0_8px_30px_rgba(255,140,0,0.7)] text-white font-bold"
              >
                Continuar Assistindo
              </Button>
            </div>
          </div>
        )}

        {/* OVERLAY DE PAYWALL */}
        {showPaywall && (
          <div className="absolute inset-0" />
        )}

        {/* BOTÃO DE PLAY INICIAL */}
        {!hasStarted && !showPaywall && !showLeadModal && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-10">
            {startPositionSeconds > 0 ? (
              // Mostrar 2 botões quando tem posição de início configurada
              <div className="flex flex-col gap-3 px-6 w-full max-w-md">
                <Button
                  onClick={() => handlePlayClick(startPositionSeconds)}
                  size="lg"
                  className="w-full bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:from-fire-yellow-intense hover:to-fire-orange text-white font-bold text-base sm:text-lg px-6 py-4 min-h-[56px] shadow-[0_4px_20px_rgba(255,140,0,0.4)] hover:shadow-[0_8px_30px_rgba(255,140,0,0.6)] transition-all duration-300 rounded-xl"
                >
                  🔥 Continuar de onde parei
                </Button>
                
                <Button
                  onClick={() => handlePlayClick(0)}
                  variant="outline"
                  size="lg"
                  className="w-full border-2 border-fire-orange/50 bg-transparent hover:bg-fire-orange/10 text-white font-semibold text-base sm:text-lg px-6 py-4 min-h-[52px] transition-all duration-300 rounded-xl"
                >
                  ▶️ Começar do início
                </Button>
              </div>
            ) : (
              // Botão único quando não tem posição de início
              <Button
                onClick={() => handlePlayClick(0)}
                size="lg"
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-fire-orange hover:bg-fire-glow shadow-2xl transition-transform hover:scale-110 active:scale-95"
                aria-label={`Reproduzir ${dramaTitle}`}
              >
                <Play className="w-6 h-6 sm:w-8 sm:h-8 text-white fill-white" />
              </Button>
            )}
          </div>
        )}
      </div>

      {/* INFORMAÇÕES DO VÍDEO */}
      <div className="episode-player-info">
        <h2 className="text-lg sm:text-xl font-bold text-white line-clamp-2">
          {dramaTitle}
        </h2>
        {!isPremium && (
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">
            {extendedTime ? "Preview gratuito: primeiros 25 minutos" : "Preview gratuito: primeiros 10 minutos (+ 15 min com telefone)"}
          </p>
        )}
      </div>
    </section>
  );
};

export default DoramasHlsPlayer;
