import { CreditCard, QrCode } from "lucide-react";

interface PaymentMethodSelectorProps {
  selectedMethod: 'pix' | 'credit_card';
  onSelect: (method: 'pix' | 'credit_card') => void;
  disabled?: boolean;
}

export function PaymentMethodSelector({
  selectedMethod,
  onSelect,
  disabled = false,
}: PaymentMethodSelectorProps) {
  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-foreground text-center mb-4">
        Como você quer pagar?
      </p>

      <button
        type="button"
        onClick={() => onSelect('credit_card')}
        disabled={disabled}
        className={`
          w-full p-4 rounded-lg border-2 transition-all flex items-center gap-4
          ${selectedMethod === 'credit_card'
            ? 'border-fire-orange bg-fire-orange/10 shadow-[0_0_20px_rgba(255,140,0,0.3)]'
            : 'border-border hover:border-fire-orange/50 bg-card'
          }
          ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
        `}
      >
        <div className={`
          w-12 h-12 rounded-full flex items-center justify-center
          ${selectedMethod === 'credit_card'
            ? 'bg-fire-orange text-white'
            : 'bg-muted text-muted-foreground'
          }
        `}>
          <CreditCard className="w-6 h-6" />
        </div>
        <div className="text-left flex-1">
          <p className={`font-bold text-base ${selectedMethod === 'credit_card' ? 'text-fire-yellow-bright' : 'text-foreground'}`}>
            💳 Cartão de Crédito
          </p>
          <p className="text-xs text-muted-foreground">
            Aprovação instantânea
          </p>
        </div>
        {selectedMethod === 'credit_card' && (
          <div className="w-6 h-6 rounded-full bg-fire-orange flex items-center justify-center">
            <span className="text-white text-sm">✓</span>
          </div>
        )}
      </button>

      <button
        type="button"
        onClick={() => onSelect('pix')}
        disabled={disabled}
        className={`
          w-full p-4 rounded-lg border-2 transition-all flex items-center gap-4
          ${selectedMethod === 'pix'
            ? 'border-fire-orange bg-fire-orange/10 shadow-[0_0_20px_rgba(255,140,0,0.3)]'
            : 'border-border hover:border-fire-orange/50 bg-card'
          }
          ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
        `}
      >
        <div className={`
          w-12 h-12 rounded-full flex items-center justify-center
          ${selectedMethod === 'pix'
            ? 'bg-fire-orange text-white'
            : 'bg-muted text-muted-foreground'
          }
        `}>
          <QrCode className="w-6 h-6" />
        </div>
        <div className="text-left flex-1">
          <p className={`font-bold text-base ${selectedMethod === 'pix' ? 'text-fire-yellow-bright' : 'text-foreground'}`}>
            📱 PIX
          </p>
          <p className="text-xs text-muted-foreground">
            Pague em segundos
          </p>
        </div>
        {selectedMethod === 'pix' && (
          <div className="w-6 h-6 rounded-full bg-fire-orange flex items-center justify-center">
            <span className="text-white text-sm">✓</span>
          </div>
        )}
      </button>
    </div>
  );
}
