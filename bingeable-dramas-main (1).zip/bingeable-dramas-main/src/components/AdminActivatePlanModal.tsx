import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { CalendarIcon } from "lucide-react";
import { format, addDays, addMonths } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AdminActivatePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: {
    id: string;
    email: string;
    full_name: string | null;
  } | null;
  onSuccess: () => void;
}

export function AdminActivatePlanModal({ isOpen, onClose, user, onSuccess }: AdminActivatePlanModalProps) {
  const [expirationDate, setExpirationDate] = useState<Date | undefined>(addMonths(new Date(), 1));
  const [saving, setSaving] = useState(false);

  const handleClose = () => {
    setExpirationDate(addMonths(new Date(), 1));
    onClose();
  };

  const handleSave = async () => {
    if (!user || !expirationDate) {
      toast.error("Selecione uma data de expiração");
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          plan_status: "active",
          plan_renews_at: expirationDate.toISOString(),
        })
        .eq("id", user.id);

      if (error) {
        toast.error("Erro ao ativar plano: " + error.message);
        return;
      }

      toast.success(`Plano Premium ativado até ${format(expirationDate, "dd/MM/yyyy", { locale: ptBR })}`);
      onSuccess();
      handleClose();
    } catch (error) {
      console.error("Error activating plan:", error);
      toast.error("Erro ao ativar plano");
    } finally {
      setSaving(false);
    }
  };

  const quickDates = [
    { label: "7 dias", date: addDays(new Date(), 7) },
    { label: "15 dias", date: addDays(new Date(), 15) },
    { label: "1 mês", date: addMonths(new Date(), 1) },
    { label: "3 meses", date: addMonths(new Date(), 3) },
    { label: "6 meses", date: addMonths(new Date(), 6) },
    { label: "1 ano", date: addMonths(new Date(), 12) },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Ativar Plano Premium</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-muted/50 rounded-lg p-3">
            <p className="text-sm text-muted-foreground">Usuário:</p>
            <p className="font-medium">{user?.full_name || user?.email || "Usuário"}</p>
          </div>

          <div className="space-y-2">
            <Label>Data de Expiração do Plano</Label>
            
            {/* Quick date buttons */}
            <div className="flex flex-wrap gap-2 mb-3">
              {quickDates.map((item) => (
                <Button
                  key={item.label}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setExpirationDate(item.date)}
                  className={cn(
                    "text-xs",
                    expirationDate?.toDateString() === item.date.toDateString() &&
                      "border-fire-orange bg-fire-orange/10 text-fire-orange"
                  )}
                >
                  {item.label}
                </Button>
              ))}
            </div>

            {/* Calendar picker */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !expirationDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {expirationDate ? (
                    format(expirationDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
                  ) : (
                    "Selecione uma data"
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={expirationDate}
                  onSelect={setExpirationDate}
                  disabled={(date) => date < new Date()}
                  initialFocus
                  locale={ptBR}
                />
              </PopoverContent>
            </Popover>
          </div>

          {expirationDate && (
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
              <p className="text-sm text-green-600">
                O plano estará ativo até: <strong>{format(expirationDate, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</strong>
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={saving}>
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving || !expirationDate}
            className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-lg text-white"
          >
            {saving ? "Salvando..." : "Ativar Plano"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
