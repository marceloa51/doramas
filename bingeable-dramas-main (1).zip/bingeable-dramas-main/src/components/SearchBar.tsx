import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Search, X } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";

interface Drama {
  id: string;
  title: string;
  slug: string;
  thumbnail_url: string | null;
  genres: string[] | null;
}

interface SearchBarProps {
  variant?: "desktop" | "mobile";
}

export function SearchBar({ variant = "desktop" }: SearchBarProps) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Drama[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getUserId();
  }, []);

  useEffect(() => {
    if (query.trim().length > 0) {
      searchDramas();
      setShowResults(true);
    } else {
      setResults([]);
      setShowResults(false);
    }
  }, [query]);

  useEffect(() => {
    if (mobileOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [mobileOpen]);

  const getUserId = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    setUserId(session?.user?.id || null);
  };

  const searchDramas = async () => {
    const searchTerms = query.toLowerCase().split(" ").filter(t => t.length > 0);
    
    let queryBuilder = supabase
      .from("dramas")
      .select("id, title, slug, thumbnail_url, genres")
      .eq("status", "active");

    searchTerms.forEach(term => {
      queryBuilder = queryBuilder.ilike("title", `%${term}%`);
    });

    const { data, error } = await queryBuilder.limit(10);

    if (!error && data) {
      setResults(data);
      
      await supabase.from("search_queries").insert({
        user_id: userId,
        query: query,
        results_count: data.length,
      });
    }
  };

  const handleDramaClick = async (drama: Drama) => {
    await supabase.from("search_queries").insert({
      user_id: userId,
      query: query,
      clicked_drama_id: drama.id,
    });

    setShowResults(false);
    setQuery("");
    setMobileOpen(false);
    navigate(`/movie/${drama.slug}`);
  };

  const handleClose = () => {
    setMobileOpen(false);
    setQuery("");
    setShowResults(false);
  };

  if (variant === "mobile") {
    return (
      <>
        <button
          onClick={() => setMobileOpen(true)}
          className="p-2 hover:bg-drama-card rounded-lg transition-smooth"
          aria-label="Buscar"
        >
          <Search className="w-5 h-5 text-fire-orange" />
        </button>

        <Dialog open={mobileOpen} onOpenChange={setMobileOpen}>
          <DialogContent className="bg-[#0A0A0A] border-fire-orange/20 p-0 max-w-full w-full h-full sm:h-auto sm:max-w-lg">
            <VisuallyHidden>
              <DialogTitle>Buscar Doramas</DialogTitle>
              <DialogDescription>Digite o nome do dorama que você procura</DialogDescription>
            </VisuallyHidden>
            <div className="p-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-fire-orange h-5 w-5" />
                  <Input
                    ref={inputRef}
                    type="text"
                    placeholder="Buscar doramas..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="pl-11 pr-4 h-12 bg-[#1C1C1C] border-fire-orange/30 focus:border-fire-orange text-white placeholder:text-gray-400 rounded-lg text-base"
                  />
                </div>
                <button
                  onClick={handleClose}
                  className="p-2 hover:bg-drama-card rounded-lg transition-smooth"
                  aria-label="Fechar busca"
                >
                  <X className="w-6 h-6 text-fire-orange" />
                </button>
              </div>

              {showResults && results.length > 0 && (
                <div className="max-h-[60vh] overflow-y-auto">
                  <p className="text-xs text-muted-foreground mb-3 px-2">
                    {results.length} resultado{results.length !== 1 ? "s" : ""} encontrado{results.length !== 1 ? "s" : ""}
                  </p>
                  <div className="space-y-2">
                    {results.map((drama) => (
                      <div
                        key={drama.id}
                        onClick={() => handleDramaClick(drama)}
                        className="flex items-center gap-3 p-3 hover:bg-[#1C1C1C] rounded-lg cursor-pointer transition-smooth"
                      >
                        <img
                          src={drama.thumbnail_url || "/placeholder.svg"}
                          alt={drama.title}
                          className="w-16 h-24 object-cover rounded"
                        />
                        <div>
                          <h3 className="font-medium text-sm text-white">{drama.title}</h3>
                          {drama.genres && drama.genres.length > 0 && (
                            <p className="text-xs text-muted-foreground">{drama.genres.slice(0, 2).join(" • ")}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {showResults && query && results.length === 0 && (
                <div className="p-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    Nenhum resultado encontrado para "{query}"
                  </p>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <div className="relative w-full max-w-md min-w-[280px]">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-fire-orange h-4 w-4" />
        <Input
          type="text"
          placeholder="Buscar doramas..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => query && setShowResults(true)}
          onBlur={() => setTimeout(() => setShowResults(false), 200)}
          className="pl-10 pr-4 h-10 bg-[#1C1C1C] border-fire-orange/30 focus:border-fire-orange text-white placeholder:text-gray-400 rounded-lg"
        />
      </div>

      {showResults && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-[#0A0A0A] border border-fire-orange/20 rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto">
          <div className="p-2">
            <p className="text-xs text-muted-foreground mb-2 px-2">
              {results.length} resultado{results.length !== 1 ? "s" : ""} encontrado{results.length !== 1 ? "s" : ""}
            </p>
            <div className="grid grid-cols-1 gap-2">
              {results.map((drama) => (
                <div
                  key={drama.id}
                  onClick={() => handleDramaClick(drama)}
                  className="flex items-center gap-3 p-2 hover:bg-[#1C1C1C] rounded-lg cursor-pointer transition-smooth"
                >
                  <img
                    src={drama.thumbnail_url || "/placeholder.svg"}
                    alt={drama.title}
                    className="w-16 h-24 object-cover rounded"
                  />
                  <div>
                    <h3 className="font-medium text-sm text-white">{drama.title}</h3>
                    {drama.genres && drama.genres.length > 0 && (
                      <p className="text-xs text-muted-foreground">{drama.genres.slice(0, 2).join(" • ")}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showResults && query && results.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-[#0A0A0A] border border-fire-orange/20 rounded-lg shadow-lg z-50 p-4">
          <p className="text-sm text-muted-foreground text-center">
            Nenhum resultado encontrado para "{query}"
          </p>
        </div>
      )}
    </div>
  );
}
