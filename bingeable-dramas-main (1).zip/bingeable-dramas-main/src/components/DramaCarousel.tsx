import DramaCard from "./DramaCard";
import { HorizontalCarousel } from "./HorizontalCarousel";

interface Drama {
  id: string;
  title: string;
  slug: string;
  thumbnail_url: string;
  genres: string[];
}

interface DramaCarouselProps {
  title: string;
  dramas: Drama[];
  loading?: boolean;
}

export const DramaCarousel = ({ title, dramas, loading = false }: DramaCarouselProps) => {

  if (loading) {
    return (
      <div className="mb-8 sm:mb-12">
        <h2 className="text-xl sm:text-2xl font-bold mb-4 px-4">{title}</h2>
        <div className="relative px-4">
          <div className="flex gap-3 sm:gap-4 overflow-hidden">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="flex-none w-[140px] sm:w-[180px] md:w-[200px] aspect-[2/3] bg-drama-card animate-pulse rounded-lg"
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!dramas || dramas.length === 0) {
    return null;
  }

  return (
    <div className="mb-8 sm:mb-12">
      <h2 className="text-xl sm:text-2xl font-bold mb-4 px-4">{title}</h2>
      <div className="px-4">
        <HorizontalCarousel>
          {dramas.map((drama) => (
            <div
              key={drama.id}
              className="flex-none w-[140px] sm:w-[180px] md:w-[200px]"
            >
              <DramaCard
                id={drama.id}
                title={drama.title}
                thumbnail={drama.thumbnail_url}
                genres={drama.genres}
                slug={drama.slug}
              />
            </div>
          ))}
        </HorizontalCarousel>
      </div>
    </div>
  );
};
