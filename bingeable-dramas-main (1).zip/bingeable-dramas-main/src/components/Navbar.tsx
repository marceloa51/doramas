import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { SearchBar } from "./SearchBar";
import { Button } from "@/components/ui/button";
import { Search, User, Menu, X, Film } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";

const Navbar = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-drama-dark/95 backdrop-blur-sm border-b border-drama-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Film className="h-7 w-7 text-fire-orange" />
            <span className="text-2xl font-display font-black tracking-tight">
              <span className="text-fire-primary">DORAMAS</span>
              <span className="text-fire-yellow-intense ml-1" style={{ textShadow: '0 0 20px rgba(255, 170, 0, 0.6)' }}> SUPER</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-foreground hover:text-fire-orange transition-smooth fire-link">
              Início
            </Link>
            <Link to="/explorar" className="text-foreground hover:text-fire-orange transition-smooth fire-link">
              Explorar
            </Link>
            {session && (
              <Link to="/meus-doramas" className="text-foreground hover:text-fire-orange transition-smooth fire-link">
                Meus Doramas
              </Link>
            )}
            <SearchBar variant="desktop" />
          </div>

          {/* Right Actions */}
          <div className="flex items-center space-x-2 md:space-x-4">
            {/* Mobile Search */}
            <div className="md:hidden">
              <SearchBar variant="mobile" />
            </div>

            {session ? (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate("/perfil")}
                className="hover:bg-drama-card"
              >
                <User className="w-5 h-5" />
              </Button>
            ) : (
              <Button
                onClick={() => navigate("/auth")}
                className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense hover:shadow-[0_8px_24px_rgba(255,140,0,0.4)] text-white font-bold"
              >
                Entrar
              </Button>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2 border-t border-drama-border">
            <Link
              to="/"
              className="block px-4 py-2 text-foreground hover:bg-drama-card rounded transition-smooth"
              onClick={() => setMobileMenuOpen(false)}
            >
              Início
            </Link>
            <Link
              to="/explorar"
              className="block px-4 py-2 text-foreground hover:bg-drama-card rounded transition-smooth"
              onClick={() => setMobileMenuOpen(false)}
            >
              Explorar
            </Link>
            {session && (
              <Link
                to="/meus-doramas"
                className="block px-4 py-2 text-foreground hover:bg-drama-card rounded transition-smooth"
                onClick={() => setMobileMenuOpen(false)}
              >
                Meus Doramas
              </Link>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
