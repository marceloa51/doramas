import { useState } from "react";
import { Sparkles, Crown, Loader2, Check, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { getOrCreateVisitorId, savePendingPixModal } from "@/utils/visitorManager";
import { PixPaymentModal } from "@/components/PixPaymentModal";
import { PaymentMethodSelector } from "@/components/PaymentMethodSelector";
import { CreditCardForm } from "@/components/CreditCardPaymentForm";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

type PlanBannerProps = {
  hasActivePlan: boolean;
};

const PlanBanner: React.FC<PlanBannerProps> = ({ hasActivePlan }) => {
  // Modal de benefícios
  const [showBenefitsModal, setShowBenefitsModal] = useState(false);
  const [customerWhatsApp, setCustomerWhatsApp] = useState("");

  // Modal PIX
  const [showPixModal, setShowPixModal] = useState(false);
  const [pixCode, setPixCode] = useState("");
  const [checkoutUrl, setCheckoutUrl] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [checkoutSessionId, setCheckoutSessionId] = useState("");
  const [processingPayment, setProcessingPayment] = useState(false);

  // Payment method states
  const [showPaymentSelector, setShowPaymentSelector] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit_card'>('pix');
  const [showCreditCardForm, setShowCreditCardForm] = useState(false);
  const [cardPaymentSuccess, setCardPaymentSuccess] = useState(false);

  if (hasActivePlan) return null;

  // Abre modal de benefícios
  const handlePlanClick = () => {
    setShowBenefitsModal(true);
  };

  // After WhatsApp is validated, show payment selector
  const handleContinueToPayment = () => {
    const phoneDigits = customerWhatsApp.replace(/\D/g, '');
    if (phoneDigits.length < 7) {
      toast({
        title: "WhatsApp inválido",
        description: "Por favor, informe pelo menos 7 dígitos",
        variant: "destructive"
      });
      return;
    }
    setShowBenefitsModal(false);
    setShowPaymentSelector(true);
  };

  // Gera PIX após confirmação
  const handleConfirmSubscription = async () => {
    setProcessingPayment(true);
    setShowPaymentSelector(false);
    
    try {
      const visitorId = getOrCreateVisitorId();
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-fullaccess-payment`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            customerName: customerWhatsApp.trim(),
            visitor_id: visitorId,
            paymentMethod: 'pix',
            ...(session?.user && { userId: session.user.id }),
          }),
        }
      ).then(res => res.json());

      if (response.error) throw new Error(response.error);

      if (response.success || response.checkoutUrl) {
        const purchaseData = {
          checkout_session_id: response.checkoutSessionId,
          amount: 24.90,
          isFullAccess: true,
        };
        localStorage.setItem('pending_purchase', JSON.stringify(purchaseData));

        savePendingPixModal({
          pixCode: response.pixCode || "",
          checkoutUrl: response.checkoutUrl || "",
          transactionId: response.transactionId || "",
          checkout_session_id: response.checkoutSessionId,
          amount: 24.90,
          dramaTitle: "Acesso Completo 30 Dias",
          dramaId: 'full_access_30_days',
          isFullAccess: true
        });

        setPixCode(response.pixCode || "");
        setCheckoutUrl(response.checkoutUrl || "");
        setTransactionId(response.transactionId || "");
        setCheckoutSessionId(response.checkoutSessionId);
        setShowPixModal(true);
      }
    } catch (error) {
      console.error("Erro ao gerar pagamento:", error);
      toast({
        title: "Erro",
        description: "Não foi possível gerar o pagamento. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setProcessingPayment(false);
    }
  };

  // Handle payment method selection
  const handlePaymentMethodSelect = (method: 'pix' | 'credit_card') => {
    setPaymentMethod(method);
    if (method === 'pix') {
      handleConfirmSubscription();
    } else {
      setShowPaymentSelector(false);
      setShowCreditCardForm(true);
    }
  };

  // Handle credit card payment success
  const handleCardPaymentSuccess = () => {
    setShowCreditCardForm(false);
    setCardPaymentSuccess(true);
  };

  return (
    <>
      <div className="w-full bg-gradient-to-r from-drama-red via-[#C20812] to-drama-red-hover shadow-[0_4px_12px_rgba(0,0,0,0.5)] border-b border-white/10">
        <div className="container mx-auto px-4 py-3.5 lg:py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-6 max-w-[1600px] mx-auto">
            
            {/* CONTEÚDO TEXTUAL */}
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <div className="hidden lg:flex items-center justify-center w-9 h-9 rounded-full bg-white/15 backdrop-blur-sm shrink-0">
                <Sparkles className="w-4 h-4 text-yellow-300" />
              </div>

              <p className="text-sm lg:text-[15px] font-medium text-white/95 text-center sm:text-left leading-snug">
                <strong className="text-yellow-200 font-bold">Acesso Premium</strong>
                <span className="hidden md:inline"> — 30 dias por <strong className="text-white font-bold">R$24,90</strong></span>
                <span className="md:hidden"> — 30 dias por <strong>R$24,90</strong></span>
              </p>
            </div>

            {/* BOTÃO PREMIUM */}
            <button
              onClick={handlePlanClick}
              disabled={processingPayment}
              className="group relative inline-flex items-center justify-center gap-2 px-6 py-2.5 lg:px-7 lg:py-3 
                         bg-gradient-to-br from-fire-red-deep via-fire-orange to-fire-yellow-intense
                         text-white font-bold text-[13px] lg:text-[15px] tracking-wide
                         rounded-full shadow-[0_6px_20px_rgba(255,140,0,0.4)]
                         transition-all duration-300 ease-out
                         hover:shadow-[0_10px_35px_rgba(255,170,0,0.6)] hover:scale-[1.04]
                         active:scale-[0.98] active:shadow-[0_4px_15px_rgba(255,140,0,0.3)]
                         border border-fire-orange/30
                         whitespace-nowrap shrink-0
                         focus:outline-none focus:ring-2 focus:ring-fire-yellow-intense focus:ring-offset-2 focus:ring-offset-black
                         disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              <span className="absolute inset-0 rounded-full bg-gradient-to-br from-glow-yellow-vivid/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
              
              {processingPayment ? (
                <>
                  <Loader2 className="w-4 h-4 lg:w-[18px] lg:h-[18px] relative z-10 animate-spin" />
                  <span className="relative z-10">Gerando...</span>
                </>
              ) : (
                <>
                  <Crown className="w-4 h-4 lg:w-[18px] lg:h-[18px] relative z-10 group-hover:rotate-12 transition-transform duration-300" />
                  <span className="relative z-10">
                    <span className="hidden sm:inline">Assinar </span>Premium
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Modal de Benefícios do Premium */}
      <Dialog open={showBenefitsModal} onOpenChange={setShowBenefitsModal}>
        <DialogContent className="max-w-[95vw] sm:max-w-[450px] bg-charcoal-black border-fire-orange/20">
          <DialogHeader>
            <DialogTitle className="text-xl font-black text-fire-yellow-bright text-center">
              🔥 Oferta Especial
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Preço */}
            <div className="text-center">
              <p className="text-4xl font-black text-white">R$ 24,90</p>
              <p className="text-sm text-muted-foreground">Acesso completo por 30 dias</p>
            </div>
            
            {/* Benefícios */}
            <div className="space-y-3 bg-fire-orange/10 border border-fire-orange/30 rounded-lg p-4">
              <p className="text-sm font-bold text-fire-yellow-bright">✨ Benefícios Premium:</p>
              <ul className="space-y-2 text-sm text-foreground">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Acesso a TODOS os doramas
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Sem limite de tempo de assistir
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Novos lançamentos liberados
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-orange" />
                  Assista quantas vezes quiser
                </li>
              </ul>
            </div>
            
            {/* Campo WhatsApp */}
            <div className="space-y-2">
              <Label htmlFor="customerWhatsApp" className="text-sm font-medium text-foreground">
                WhatsApp *
              </Label>
              <Input
                id="customerWhatsApp"
                type="tel"
                inputMode="numeric"
                value={customerWhatsApp}
                onChange={(e) => {
                  const numbersOnly = e.target.value.replace(/\D/g, '').slice(0, 11);
                  let formatted = '';
                  if (numbersOnly.length > 0) formatted = '(' + numbersOnly.slice(0, 2);
                  if (numbersOnly.length > 2) formatted += ') ' + numbersOnly.slice(2, 7);
                  if (numbersOnly.length > 7) formatted += '-' + numbersOnly.slice(7, 11);
                  setCustomerWhatsApp(formatted);
                }}
                placeholder="(99) 99999-9999"
                className="bg-background border-border text-foreground"
              />
            </div>
            
            {/* Botão Continuar */}
            <Button
              onClick={handleContinueToPayment}
              disabled={customerWhatsApp.replace(/\D/g, '').length < 7}
              className="w-full min-h-[52px] bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white font-bold text-lg hover:brightness-125 shadow-lg hover:shadow-[0_10px_40px_rgba(255,140,0,0.5)] transition-all disabled:opacity-50"
            >
              <Crown className="w-5 h-5 mr-2" />
              Continuar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Seleção de Pagamento */}
      <Dialog open={showPaymentSelector} onOpenChange={setShowPaymentSelector}>
        <DialogContent className="max-w-[95vw] sm:max-w-[450px] bg-charcoal-black border-fire-orange/20">
          <DialogHeader>
            <DialogTitle className="text-xl font-black text-fire-yellow-bright text-center">
              Acesso Completo 30 Dias
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <div className="text-center mb-6">
              <p className="text-3xl font-black text-white">R$ 24,90</p>
            </div>
            
            <PaymentMethodSelector
              selectedMethod={paymentMethod}
              onSelect={handlePaymentMethodSelect}
              disabled={processingPayment}
            />
            
            {processingPayment && (
              <div className="flex items-center justify-center mt-4 text-muted-foreground">
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Gerando pagamento...
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Cartão de Crédito */}
      <Dialog open={showCreditCardForm} onOpenChange={setShowCreditCardForm}>
        <DialogContent className="max-w-[95vw] sm:max-w-[450px] bg-charcoal-black border-fire-orange/20">
          <DialogHeader>
            <DialogTitle className="text-xl font-black text-fire-yellow-bright text-center">
              💳 Pagamento com Cartão
            </DialogTitle>
          </DialogHeader>
          
          <CreditCardForm
            amount={24.90}
            customerName={customerWhatsApp}
            onSuccess={handleCardPaymentSuccess}
            onCancel={() => {
              setShowCreditCardForm(false);
              setShowPaymentSelector(true);
            }}
            createPaymentEndpoint="create-fullaccess-payment"
            paymentData={{
              visitor_id: getOrCreateVisitorId(),
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Modal de Sucesso Cartão */}
      <Dialog open={cardPaymentSuccess} onOpenChange={setCardPaymentSuccess}>
        <DialogContent className="max-w-[95vw] sm:max-w-[400px] bg-charcoal-black border-fire-orange/20">
          <div className="text-center py-8">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center mx-auto mb-6 animate-pulse">
              <CheckCircle2 className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-2xl font-black text-fire-yellow-bright mb-2">
              Pagamento Aprovado!
            </h2>
            <p className="text-muted-foreground mb-6">
              Seu acesso Premium foi ativado com sucesso.
            </p>
            <Button
              onClick={() => {
                setCardPaymentSuccess(false);
                window.location.reload();
              }}
              className="bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white font-bold"
            >
              Continuar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Pagamento PIX */}
      <PixPaymentModal
        isOpen={showPixModal}
        onClose={() => setShowPixModal(false)}
        checkoutUrl={checkoutUrl}
        pixCode={pixCode}
        transactionId={transactionId}
        checkoutSessionId={checkoutSessionId}
        amount={24.90}
        dramaTitle="Acesso Completo 30 Dias"
        isUpsell={true}
      />
    </>
  );
};

export default PlanBanner;
