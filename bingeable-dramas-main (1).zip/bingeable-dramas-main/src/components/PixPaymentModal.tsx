import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Check, Loader2, Crown, ArrowLeft, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { QRCodeSVG } from "qrcode.react";
import { clearPendingPixModal } from "@/utils/visitorManager";

interface PixPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  checkoutUrl: string;
  pixCode?: string | null;
  transactionId: string;
  checkoutSessionId: string;
  amount: number;
  discountApplied?: boolean;
  dramaId?: string;
  dramaTitle?: string;
  isUpsell?: boolean;
}

export function PixPaymentModal({
  isOpen,
  onClose,
  checkoutUrl,
  pixCode,
  transactionId,
  checkoutSessionId,
  amount,
  discountApplied = false,
  dramaId,
  dramaTitle,
  isUpsell = false,
}: PixPaymentModalProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [checking, setChecking] = useState(false);
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);

  // Debug: Log pixCode when component mounts or props change
  useEffect(() => {
    console.log('PixPaymentModal - pixCode received:', pixCode);
    console.log('PixPaymentModal - checkoutUrl:', checkoutUrl);
    console.log('PixPaymentModal - transactionId:', transactionId);
    
    if (!pixCode) {
      console.error('PIX code is undefined or null!');
    }
  }, [pixCode, checkoutUrl, transactionId]);

  useEffect(() => {
    if (!isOpen || !checkoutSessionId) return;

    // Poll transaction status every 5 seconds using dedicated endpoint
    const intervalId = setInterval(async () => {
      try {
        console.log('🔄 Polling automático - Checkout Session ID:', checkoutSessionId);
        
        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/check-transaction-status?checkout_session_id=${checkoutSessionId}`,
          {
            headers: {
              'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
              'Cache-Control': 'no-cache, no-store, must-revalidate',
              'Pragma': 'no-cache',
              'Expires': '0'
            },
          }
        );

        if (!response.ok) {
          console.error('❌ Polling error - Status:', response.status);
          return;
        }

        const data = await response.json();
        console.log('📊 Polling data:', data);

        // Verificar se PIX expirou
        if (data.status === 'expired') {
          console.log('⏰ PIX expirado detectado');
          clearInterval(intervalId);
          clearPendingPixModal();
          localStorage.removeItem('pending_purchase');
          
          toast({
            title: "⏰ PIX Expirado",
            description: "Seu PIX expirou. Por favor, gere um novo pagamento.",
            variant: "destructive",
          });
          
          onClose();
          return;
        }

        if (data.status === 'paid') {
          console.log('✅ Pagamento detectado automaticamente!');
          setPaymentConfirmed(true);
          clearInterval(intervalId);
          
          // Limpar localStorage do modal PIX
          clearPendingPixModal();
          
          toast({
            title: "🎉 Pagamento Confirmado!",
            description: isUpsell ? "Seus doramas foram liberados!" : "Dorama adquirido com sucesso!",
          });
          
          // Auto-redirect after 2 seconds
          setTimeout(async () => {
            onClose();
            
            // MODIFICADO: Verificar se usuário está logado
            const { data: { session } } = await supabase.auth.getSession();
            const pendingPurchase = localStorage.getItem('pending_purchase');
            
            if (pendingPurchase && !session?.user) {
              // Compra anônima - redirecionar para criar conta
              window.location.href = `/receber-compra`;
            } else {
              // Usuário logado - ir direto para meus doramas
              localStorage.removeItem('pending_purchase');
              window.location.href = '/meus-doramas';
            }
          }, 2000);
        }
      } catch (error) {
        console.error('❌ Error checking payment status:', error);
      }
    }, 5000);

    return () => {
      clearInterval(intervalId);
      console.log('🛑 Polling stopped (modal closed)');
    };
  }, [isOpen, checkoutSessionId, toast, onClose, isUpsell, dramaId]);

  const handleCopyPixCode = async () => {
    if (!pixCode) {
      toast({
        title: "Código não disponível",
        description: "Use o QR Code para pagar",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(pixCode);
      setCopied(true);
      toast({
        title: "Código copiado!",
        description: "Cole no app do seu banco para pagar",
      });
      setTimeout(() => setCopied(false), 3000);
    } catch (error) {
      toast({
        title: "Erro ao copiar",
        description: "Tente copiar manualmente",
        variant: "destructive",
      });
    }
  };

  const handleManualCheck = async () => {
    setChecking(true);
    try {
      console.log('🔍 Verificação manual iniciada - Checkout Session ID:', checkoutSessionId);
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/check-transaction-status?checkout_session_id=${checkoutSessionId}`,
        {
          headers: {
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
          },
        }
      );
      
      console.log('📡 Response status:', response.status);
      console.log('📡 Response ok:', response.ok);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', errorText);
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }
      
      const data = await response.json();
      console.log('📊 Data recebida:', data);
      
        if (data.status === 'paid') {
          console.log('✅ Pagamento confirmado! Exibindo tela de sucesso...');
          setPaymentConfirmed(true);
          
          // Limpar localStorage do modal PIX
          clearPendingPixModal();
          
          toast({
            title: "🎉 Pagamento Confirmado!",
            description: isUpsell ? "Seus doramas foram liberados!" : "Dorama adquirido com sucesso!",
          });
          
          setTimeout(async () => {
            onClose();
            
            // MODIFICADO: Verificar se usuário está logado
            const { data: { session } } = await supabase.auth.getSession();
            const pendingPurchase = localStorage.getItem('pending_purchase');
            
            if (pendingPurchase && !session?.user) {
              // Compra anônima - redirecionar para criar conta
              window.location.href = `/receber-compra`;
            } else {
              // Usuário logado - ir direto para meus doramas
              localStorage.removeItem('pending_purchase');
              window.location.href = '/meus-doramas';
            }
          }, 2000);
        } else {
          console.log('⏳ Pagamento ainda pendente:', { status: data.status });
          toast({
            title: "⏳ Aguardando confirmação",
            description: "O pagamento ainda não foi confirmado. Por favor, aguarde alguns instantes.",
          });
        }
    } catch (error) {
      console.error('❌ Erro ao verificar pagamento:', error);
      toast({
        title: "Erro ao verificar pagamento",
        description: error instanceof Error ? error.message : "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setChecking(false);
    }
  };

  if (paymentConfirmed) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-[95vw] sm:max-w-[500px] bg-black border-fire-orange/20">
          <div className="flex flex-col items-center justify-center py-8 px-4 sm:py-12 sm:px-6 text-center">
            {/* Ícone de Check com animação */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center mb-4 sm:mb-6 animate-pulse shadow-[0_0_50px_rgba(255,140,0,0.8)]">
              <Check className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
            </div>
            
            {/* Título */}
            <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-fire-yellow-bright mb-3 drop-shadow-[0_0_10px_rgba(255,184,0,0.8)] px-2">
              🎉 Pronto! Seu acesso foi liberado!
            </h2>
            
            {/* Subtítulo */}
            <p className="text-sm sm:text-base md:text-lg text-white/90 mb-2 px-3">
              {isUpsell ? "Seus doramas estão prontos para assistir!" : dramaTitle ? `Pode assistir ${dramaTitle} agora mesmo.` : "Pode assistir agora mesmo ao seu dorama completo."}
            </p>
            
            <p className="text-xs sm:text-sm text-muted-foreground mb-6 sm:mb-8">
              Preparando seu dorama...
            </p>
            
            {/* Spinner elegante */}
            <Loader2 className="w-8 h-8 animate-spin text-fire-orange" />
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-[550px] max-h-[90vh] bg-charcoal-black border-fire-orange/20 p-0 overflow-hidden">
        {/* Custom Header com botão Voltar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-white/10">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              clearPendingPixModal();
              onClose();
            }}
            className="hover:bg-fire-orange/20 text-fire-orange h-10 w-10 sm:h-9 sm:w-9"
          >
            <ArrowLeft className="h-5 w-5 sm:h-4 sm:w-4" />
          </Button>
          <DialogTitle className="text-lg sm:text-xl font-black text-fire-yellow-bright">
            Pagamento PIX
          </DialogTitle>
          <div className="w-10 sm:w-9" /> {/* Spacer para centralizar o título */}
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
          <div className="space-y-4 sm:space-y-6 py-4 px-4 sm:px-6">
          {/* Plan Info */}
          <div className="text-center border-b border-white/10 pb-6">
            <h3 className="text-lg font-semibold text-foreground mb-1">
              {dramaTitle || (isUpsell ? "Oferta Especial" : "Dorama")}
            </h3>
            <p className="text-3xl font-black text-white">
              R$ {amount.toFixed(2).replace('.', ',')}
            </p>
          </div>

          {/* QR Code */}
          <div className="flex flex-col items-center">
            <div className="bg-white p-3 sm:p-4 rounded-lg sm:rounded-xl mb-4 max-w-full mx-auto">
              {pixCode ? (
                <QRCodeSVG 
                  value={pixCode} 
                  size={180}
                  className="w-[180px] h-[180px] sm:w-[200px] sm:h-[200px] md:w-[220px] md:h-[220px] max-w-full"
                />
              ) : (
                <div className="w-[180px] h-[180px] sm:w-[200px] sm:h-[200px] md:w-[220px] md:h-[220px] flex items-center justify-center bg-background text-muted-foreground text-xs sm:text-sm">
                  QR Code não disponível
                </div>
              )}
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground text-center mb-2 px-4">
              Escaneie o QR Code com o app do seu banco
            </p>
          </div>

          {/* PIX Code */}
          {pixCode && (
            <div className="space-y-3">
              <p className="text-xs sm:text-sm font-medium text-foreground text-center">
                Ou copie o código PIX:
              </p>
              <div className="relative">
                <div className="bg-background border border-border rounded-lg p-3 pr-12 text-xs sm:text-sm text-foreground break-all max-h-24 overflow-x-auto overflow-y-auto">
                  {pixCode}
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="absolute right-2 top-1/2 -translate-y-1/2 hover:bg-fire-orange/20"
                  onClick={handleCopyPixCode}
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-fire-orange" />
                  ) : (
                    <Copy className="w-4 h-4 text-muted-foreground" />
                  )}
                </Button>
              </div>
              
              {/* Instruções de pagamento */}
              <div className="bg-fire-orange/10 border border-fire-orange/30 rounded-lg p-3 sm:p-4">
                <p className="text-xs sm:text-sm text-foreground text-center font-medium">
                  📱 <span className="font-bold">Como pagar:</span>
                </p>
                <p className="text-xs sm:text-sm text-muted-foreground text-center mt-2">
                  Abra seu banco → Pagar com PIX → PIX Copia e Cola → Cole o código e finalize o pagamento
                </p>
              </div>

              <Button
                onClick={handleCopyPixCode}
                className="w-full min-h-[44px] sm:min-h-[48px] bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white hover:brightness-125 text-sm sm:text-base font-bold shadow-lg hover:shadow-[0_10px_40px_rgba(255,140,0,0.5)] transition-all"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                    Código Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                    Copiar código PIX
                  </>
                )}
              </Button>
              
              {/* Botão "Já paguei" - DESTACADO */}
              <Button
                onClick={handleManualCheck}
                disabled={checking}
                className="w-full min-h-[44px] sm:min-h-[48px] bg-black border-2 border-fire-orange text-fire-yellow-bright hover:bg-fire-orange/20 hover:border-fire-yellow-intense text-sm sm:text-base font-bold disabled:opacity-50 shadow-[0_0_20px_rgba(255,140,0,0.3)] hover:shadow-[0_0_30px_rgba(255,140,0,0.6)] transition-all animate-pulse"
              >
                {checking ? (
                  <span className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
                    Verificando pagamento...
                  </span>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                    Já paguei
                  </>
                )}
              </Button>
              
              {/* Botão de Suporte WhatsApp - VERDE */}
              <a
                href="https://wa.me/5521965469714"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full min-h-[44px] px-4 py-3 text-sm sm:text-base text-white bg-[#25D366] hover:bg-[#20BA5A] rounded-md transition-all font-medium shadow-md hover:shadow-lg"
              >
                <svg 
                  viewBox="0 0 24 24" 
                  fill="currentColor" 
                  className="w-5 h-5 sm:w-6 sm:h-6"
                >
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                Com Problemas? Clique aqui
              </a>
            </div>
          )}

          {/* Info */}
          <div className="bg-background/50 rounded-lg p-3 sm:p-4 text-center">
            <p className="text-xs sm:text-sm text-muted-foreground px-2">
              Após o pagamento, seu acesso será liberado instantaneamente.
            </p>
          </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
