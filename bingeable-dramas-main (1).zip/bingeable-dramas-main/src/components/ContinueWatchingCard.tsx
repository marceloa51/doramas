import { Link } from "react-router-dom";
import { Play } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ContinueWatchingCardProps {
  id: string;
  title: string;
  slug: string;
  thumbnail: string;
  progress: number;
}

export const ContinueWatchingCard = ({
  id,
  title,
  slug,
  thumbnail,
  progress,
}: ContinueWatchingCardProps) => {
  return (
    <Link to={`/movie/${slug}`}>
      <Card className="group relative overflow-hidden bg-drama-card border-drama-border hover:border-fire-orange hover:shadow-[0_0_20px_rgba(255,170,0,0.6)] transition-all duration-300 cursor-pointer">
        <div className="aspect-[16/9] relative overflow-hidden bg-drama-dark">
          <img
            src={thumbnail}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-fire-orange to-fire-yellow-intense flex items-center justify-center shadow-[0_8px_32px_rgba(255,140,0,0.5)]">
              <Play className="w-6 h-6 text-white fill-white ml-1" />
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-3">
            <h3 className="font-bold text-white text-sm mb-2 line-clamp-1">
              {title}
            </h3>
            <Progress value={progress} className="h-1 bg-gray-700" />
          </div>
        </div>
      </Card>
    </Link>
  );
};
