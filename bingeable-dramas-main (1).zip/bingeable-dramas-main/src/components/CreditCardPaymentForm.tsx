import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, CreditCard, Lock, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Bestfy Public Key
const BESTFY_PUBLIC_KEY = "pk_live_v2N2LTusJGqICzx36EsU9bYWJ1CAFO3GMM";

declare global {
  interface Window {
    Bestfy: {
      setPublicKey: (key: string) => void;
      setTestMode: (enabled: boolean) => void;
      encrypt: (data: {
        number: string;
        holderName: string;
        expMonth: string;
        expYear: string;
        cvv: string;
      }) => string | { token?: string } | null;
    };
  }
}

// Helper para traduzir erros técnicos em mensagens amigáveis
const getErrorMessage = (error: string): string => {
  const lowerError = error.toLowerCase();
  
  if (lowerError.includes('refused') || lowerError.includes('recusado')) {
    return 'Pagamento recusado. Verifique os dados do cartão ou tente outro cartão.';
  }
  if (lowerError.includes('insufficient') || lowerError.includes('saldo')) {
    return 'Saldo insuficiente. Tente outro cartão.';
  }
  if (lowerError.includes('expired') || lowerError.includes('expirado')) {
    return 'Cartão expirado. Use um cartão válido.';
  }
  if (lowerError.includes('antifraud') || lowerError.includes('fraude')) {
    return 'Transação não autorizada. Tente outro cartão ou forma de pagamento.';
  }
  if (lowerError.includes('card') || lowerError.includes('cartão')) {
    return 'Erro no cartão. Verifique os dados e tente novamente.';
  }
  if (lowerError.includes('network') || lowerError.includes('timeout')) {
    return 'Erro de conexão. Tente novamente em alguns segundos.';
  }
  if (lowerError.includes('invalid') || lowerError.includes('inválido')) {
    return 'Dados inválidos. Verifique as informações e tente novamente.';
  }
  
  return 'Não foi possível processar o pagamento. Tente novamente ou use outro método.';
};

// Formatar CPF: 000.000.000-00
const formatCPF = (value: string) => {
  const numbers = value.replace(/\D/g, "").slice(0, 11);
  return numbers
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
};

export interface CreditCardFormProps {
  /** Payment amount in BRL */
  amount: number;
  /** Callback when payment succeeds */
  onSuccess: () => void;
  /** Callback when user cancels */
  onCancel: () => void;
  /** Customer WhatsApp/phone number */
  customerName: string;
  /** Edge function endpoint to call */
  createPaymentEndpoint: string;
  /** Additional payload data */
  paymentData?: Record<string, unknown>;
}

export function CreditCardForm({
  amount,
  onSuccess,
  onCancel,
  customerName,
  createPaymentEndpoint,
  paymentData = {},
}: CreditCardFormProps) {
  const { toast } = useToast();
  const [sdkLoaded, setSdkLoaded] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [cpf, setCpf] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (window.Bestfy) {
      setSdkLoaded(true);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://api.bestfybr.com.br/v1/js";
    script.async = true;
    script.onload = () => setSdkLoaded(true);
    script.onerror = () => {
      toast({
        title: "Erro",
        description: "Não foi possível carregar o processador de pagamento",
        variant: "destructive",
      });
    };
    document.head.appendChild(script);
  }, [toast]);

  const formatCardNumber = (value: string) => {
    const numbers = value.replace(/\D/g, "").slice(0, 16);
    return numbers.replace(/(\d{4})(?=\d)/g, "$1 ");
  };

  const formatExpiry = (value: string) => {
    const numbers = value.replace(/\D/g, "").slice(0, 4);
    if (numbers.length >= 2) {
      return numbers.slice(0, 2) + "/" + numbers.slice(2);
    }
    return numbers;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const cardNumberClean = cardNumber.replace(/\s/g, "");
    if (cardNumberClean.length < 13) {
      toast({ title: "Número inválido", description: "Verifique o número do cartão", variant: "destructive" });
      return;
    }

    if (!cardName.trim()) {
      toast({ title: "Nome obrigatório", description: "Informe o nome no cartão", variant: "destructive" });
      return;
    }

    const cpfClean = cpf.replace(/\D/g, "");
    if (cpfClean.length !== 11) {
      toast({ title: "CPF inválido", description: "Informe um CPF válido com 11 dígitos", variant: "destructive" });
      return;
    }

    const expiryParts = expiry.split("/");
    if (expiryParts.length !== 2 || expiryParts[0].length !== 2 || expiryParts[1].length !== 2) {
      toast({ title: "Validade inválida", description: "Use o formato MM/AA", variant: "destructive" });
      return;
    }

    if (cvv.length < 3) {
      toast({ title: "CVV inválido", description: "O CVV deve ter 3 ou 4 dígitos", variant: "destructive" });
      return;
    }

    // Converter para números inteiros
    const expMonth = parseInt(expiryParts[0], 10);
    const expYear = parseInt("20" + expiryParts[1], 10);
    const holderName = cardName.trim().toUpperCase();
    const cvvClean = cvv.replace(/\D/g, "");

    setSubmitting(true);

    try {
      // Tentar tokenizar se SDK disponível
      let cardToken: string | null = null;
      
      if (sdkLoaded && window.Bestfy) {
        try {
          // Ativar modo de teste em ambientes de desenvolvimento
          const isTestEnv = window.location.hostname.includes('localhost') || 
                           window.location.hostname.includes('lovableproject.com') ||
                           window.location.hostname.includes('preview');
          
          if (isTestEnv && typeof window.Bestfy.setTestMode === 'function') {
            window.Bestfy.setTestMode(true);
            console.log('Bestfy test mode enabled');
          }
          
          window.Bestfy.setPublicKey(BESTFY_PUBLIC_KEY);
          const encryptResult = window.Bestfy.encrypt({
            number: cardNumberClean,
            holderName: holderName,
            expMonth: String(expMonth),
            expYear: String(expYear),
            cvv: cvvClean,
          });
          
          // Validar se é um token real (string não-vazia ou objeto com token)
          if (typeof encryptResult === 'string' && encryptResult.length > 10) {
            cardToken = encryptResult;
            console.log('Card token generated (string):', cardToken.substring(0, 20) + '...');
          } else if (encryptResult && typeof encryptResult === 'object' && 'token' in encryptResult) {
            const tokenValue = encryptResult.token;
            if (typeof tokenValue === 'string' && tokenValue.length > 10) {
              cardToken = tokenValue;
              console.log('Card token extracted from object:', cardToken.substring(0, 20) + '...');
            }
          }
          
          if (!cardToken) {
            console.warn('Encrypt returned invalid/empty result:', typeof encryptResult, encryptResult);
          }
        } catch (tokenError) {
          console.error('Token generation failed:', tokenError);
          cardToken = null;
        }
      }

      // Preparar payload - com token OU dados brutos
      const requestBody: Record<string, unknown> = {
        customerName,
        customerCpf: cpf.replace(/\D/g, ""),
        paymentMethod: 'credit_card',
        ...paymentData,
      };

      if (cardToken) {
        requestBody.cardToken = cardToken;
        console.log('Sending cardToken to backend');
      } else {
        // Fallback: enviar dados brutos (backend vai sanitizar)
        console.log('Token unavailable, sending raw cardData');
        requestBody.cardData = {
          number: cardNumberClean,
          holderName: holderName,
          expirationMonth: expMonth,
          expirationYear: expYear,
          cvv: cvvClean,
        };
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${createPaymentEndpoint}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify(requestBody),
        }
      ).then(res => res.json());

      console.log('Payment response:', response);

      // Verificar erro explícito
      if (response.error) {
        throw new Error(response.error);
      }

      // Verificar success=false (pagamento recusado)
      if (response.success === false) {
        throw new Error(response.error || 'Pagamento não autorizado');
      }

      // Verificar status do pagamento
      if (response.status === 'refused' || response.status === 'failed' || response.status === 'canceled') {
        throw new Error(response.error || 'Pagamento recusado pela operadora');
      }

      // Verificar se realmente foi aprovado
      if (response.success && (response.status === 'paid' || response.status === 'authorized')) {
        toast({ title: "Pagamento aprovado!", description: "Seu acesso foi liberado." });
        onSuccess();
      } else if (response.success && response.status === 'pending') {
        // Status pendente - aguardar webhook
        toast({ 
          title: "Processando pagamento", 
          description: "Aguarde, estamos confirmando seu pagamento...",
        });
        // Para pending, vamos considerar como sucesso e deixar o webhook atualizar
        onSuccess();
      } else {
        throw new Error("Pagamento não processado corretamente");
      }
    } catch (error: unknown) {
      const rawError = error instanceof Error ? error.message : "Verifique os dados e tente novamente";
      const friendlyMessage = getErrorMessage(rawError);
      toast({
        title: "Erro no pagamento",
        description: friendlyMessage,
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const cpfClean = cpf.replace(/\D/g, "");
  const isFormValid = cardNumber.replace(/\s/g, "").length >= 13 && cardName.trim().length > 0 && cpfClean.length === 11 && expiry.length === 5 && cvv.length >= 3;

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="text-center mb-4">
        <div className="inline-flex items-center gap-2 bg-fire-orange/10 px-3 py-2 rounded-lg">
          <Lock className="w-4 h-4 text-fire-orange" />
          <span className="text-xs text-fire-yellow-bright font-medium">Pagamento 100% seguro</span>
        </div>
      </div>

      <div className="space-y-3">
        <div>
          <Label htmlFor="cardNumber" className="text-sm">Número do Cartão</Label>
          <div className="relative">
            <Input id="cardNumber" type="text" inputMode="numeric" placeholder="0000 0000 0000 0000" value={cardNumber} onChange={(e) => setCardNumber(formatCardNumber(e.target.value))} className="pl-10" disabled={submitting} />
            <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          </div>
        </div>

        <div>
          <Label htmlFor="cardName" className="text-sm">Nome no Cartão</Label>
          <Input id="cardName" type="text" placeholder="NOME COMO NO CARTÃO" value={cardName} onChange={(e) => setCardName(e.target.value.toUpperCase())} disabled={submitting} />
        </div>

        <div>
          <Label htmlFor="cpf" className="text-sm">CPF do Titular</Label>
          <Input id="cpf" type="text" inputMode="numeric" placeholder="000.000.000-00" value={cpf} onChange={(e) => setCpf(formatCPF(e.target.value))} disabled={submitting} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="expiry" className="text-sm">Validade</Label>
            <Input id="expiry" type="text" inputMode="numeric" placeholder="MM/AA" value={expiry} onChange={(e) => setExpiry(formatExpiry(e.target.value))} disabled={submitting} />
          </div>
          <div>
            <Label htmlFor="cvv" className="text-sm">CVV</Label>
            <Input id="cvv" type="text" inputMode="numeric" placeholder="123" value={cvv} onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))} disabled={submitting} />
          </div>
        </div>
      </div>

      <div className="pt-2 space-y-3">
        <Button type="submit" disabled={!isFormValid || submitting || !sdkLoaded} className="w-full min-h-[48px] bg-gradient-to-r from-fire-orange to-fire-yellow-intense text-white font-bold text-base hover:brightness-125 shadow-lg">
          {submitting ? <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Processando...</> : <><Check className="w-5 h-5 mr-2" />Pagar R$ {amount.toFixed(2).replace(".", ",")}</>}
        </Button>
        <Button type="button" variant="ghost" onClick={onCancel} disabled={submitting} className="w-full text-muted-foreground hover:text-foreground">← Voltar</Button>
      </div>

      <p className="text-xs text-muted-foreground text-center">Seus dados estão protegidos e não são armazenados.</p>
    </form>
  );
}
