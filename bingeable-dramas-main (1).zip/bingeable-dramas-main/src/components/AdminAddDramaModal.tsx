import { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Loader2, Search, Check, Film } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface UserData {
  id: string;
  email: string;
  username: string | null;
  phone: string;
}

interface Drama {
  id: string;
  title: string;
  slug: string;
  thumbnail_url: string | null;
}

interface AdminAddDramaModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: UserData;
  onSuccess: () => void;
}

export const AdminAddDramaModal = ({ open, onOpenChange, user, onSuccess }: AdminAddDramaModalProps) => {
  const [dramas, setDramas] = useState<Drama[]>([]);
  const [selectedDramaId, setSelectedDramaId] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [reason, setReason] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [loadingDramas, setLoadingDramas] = useState(true);

  useEffect(() => {
    if (open) {
      loadDramas();
      setSelectedDramaId("");
      setSearchQuery("");
      setReason("");
    }
  }, [open]);

  const loadDramas = async () => {
    setLoadingDramas(true);
    try {
      const { data, error } = await supabase
        .from("dramas")
        .select("id, title, slug, thumbnail_url")
        .eq("status", "active")
        .order("title");

      if (error) throw error;
      setDramas(data || []);
    } catch (error) {
      console.error("Error loading dramas:", error);
      toast.error("Erro ao carregar doramas");
    } finally {
      setLoadingDramas(false);
    }
  };

  const filteredDramas = useMemo(() => {
    if (!searchQuery.trim()) return dramas;
    const query = searchQuery.toLowerCase();
    return dramas.filter(d => d.title.toLowerCase().includes(query));
  }, [dramas, searchQuery]);

  const selectedDrama = dramas.find(d => d.id === selectedDramaId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedDramaId) {
      toast.error("Selecione um dorama");
      return;
    }

    setLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Sessão expirada");
        return;
      }

      const response = await supabase.functions.invoke("admin-add-purchase", {
        body: {
          userId: user.id,
          dramaId: selectedDramaId,
          amount: 0,
          reason: reason.trim() || "Adição manual pelo admin"
        }
      });

      if (response.error) {
        console.error("Error adding purchase:", response.error);
        throw new Error(response.error.message || "Erro ao adicionar dorama");
      }

      toast.success(`Dorama "${selectedDrama?.title}" adicionado com sucesso!`);
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error("Error:", error);
      
      if (error.message.includes("already owns")) {
        toast.error("Usuário já possui este dorama");
      } else {
        toast.error(error.message || "Erro ao adicionar dorama");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px] bg-card border-border p-0 overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-4 border-b border-border bg-card">
          <DialogTitle className="text-xl font-bold text-primary flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Adicionar Dorama ao Usuário
          </DialogTitle>
        </DialogHeader>

        <div className="px-6 py-4 bg-card">
          {/* User Info Card */}
          <div className="p-4 bg-muted rounded-lg border border-border mb-4">
            <p className="text-xs text-muted-foreground mb-1">Adicionando para:</p>
            <p className="font-semibold text-foreground">
              {user.username || user.email.split("@")[0]}
            </p>
            <p className="text-sm text-muted-foreground">{user.phone}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Search Input */}
            <div className="space-y-2">
              <Label className="text-foreground font-medium">
                Buscar Dorama
              </Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Digite o nome do dorama..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-background border-border text-foreground"
                />
              </div>
            </div>

            {/* Drama List */}
            <div className="space-y-2">
              <Label className="text-foreground font-medium">
                Selecione o Dorama *
              </Label>
              {loadingDramas ? (
                <div className="flex items-center justify-center py-8 bg-background rounded-lg border border-border">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : (
                <ScrollArea className="h-[200px] rounded-lg border border-border bg-background">
                  <div className="p-2 space-y-1">
                    {filteredDramas.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        Nenhum dorama encontrado
                      </p>
                    ) : (
                      filteredDramas.map((drama) => (
                        <button
                          key={drama.id}
                          type="button"
                          onClick={() => setSelectedDramaId(drama.id)}
                          className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all text-left ${
                            selectedDramaId === drama.id
                              ? "bg-primary/20 border-2 border-primary"
                              : "bg-muted/50 border-2 border-transparent hover:bg-muted hover:border-border"
                          }`}
                        >
                          {drama.thumbnail_url ? (
                            <img
                              src={drama.thumbnail_url}
                              alt={drama.title}
                              className="w-12 h-16 object-cover rounded"
                            />
                          ) : (
                            <div className="w-12 h-16 bg-muted rounded flex items-center justify-center">
                              <Film className="w-5 h-5 text-muted-foreground" />
                            </div>
                          )}
                          <span className="flex-1 font-medium text-foreground line-clamp-2">
                            {drama.title}
                          </span>
                          {selectedDramaId === drama.id && (
                            <Check className="w-5 h-5 text-primary flex-shrink-0" />
                          )}
                        </button>
                      ))
                    )}
                  </div>
                </ScrollArea>
              )}
            </div>

            {/* Selected Drama Preview */}
            {selectedDrama && (
              <div className="p-3 bg-primary/10 rounded-lg border border-primary/30">
                <p className="text-xs text-primary mb-1">Dorama selecionado:</p>
                <p className="font-semibold text-foreground">{selectedDrama.title}</p>
              </div>
            )}

            {/* Reason (optional) */}
            <div className="space-y-2">
              <Label htmlFor="reason" className="text-foreground font-medium">
                Observação <span className="text-muted-foreground font-normal">(opcional)</span>
              </Label>
              <Textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="bg-background border-border text-foreground min-h-[70px] resize-none"
                placeholder="Ex: Venda pelo WhatsApp, cortesia, etc..."
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
                disabled={loading}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-bold"
                disabled={loading || !selectedDramaId}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Adicionando...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Dorama
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};
