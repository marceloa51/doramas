import { useRef } from "react";
import { cn } from "@/lib/utils";

interface HorizontalCarouselProps {
  children: React.ReactNode;
  className?: string;
}

export const HorizontalCarousel = ({ children, className }: HorizontalCarouselProps) => {
  const wrapperRef = useRef<HTMLDivElement | null>(null);

  const scroll = (direction: "left" | "right") => {
    const area = wrapperRef.current;
    if (!area) return;

    const scrollAmount = 350;
    area.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth",
    });
  };

  return (
    <div className={cn("carousel-container", className)}>
      <button
        type="button"
        className="carousel-arrow left hidden md:flex"
        data-direction="left"
        onClick={() => scroll("left")}
        aria-label="Anterior"
      >
        <span className="flex items-center justify-center">‹</span>
      </button>

      <button
        type="button"
        className="carousel-arrow right hidden md:flex"
        data-direction="right"
        onClick={() => scroll("right")}
        aria-label="Próximo"
      >
        <span className="flex items-center justify-center">›</span>
      </button>

      <div
        ref={wrapperRef}
        className="carousel-wrapper"
      >
        {children}
      </div>
    </div>
  );
};
