export const LegalDisclaimer = () => {
  return (
    <div className="pt-8 border-t border-white/5">
      <p className="text-center text-xs text-[#999999] opacity-75 leading-relaxed max-w-4xl mx-auto">
        Este site não hospeda nenhum vídeo em nossa VPS. Todo o conteúdo reproduzido no player é obtido exclusivamente de plataformas e provedores terceiros. Apenas indexamos links públicos já existentes na internet.
      </p>
    </div>
  );
};
