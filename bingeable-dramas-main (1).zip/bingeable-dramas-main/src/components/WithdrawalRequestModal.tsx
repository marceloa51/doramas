import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface WithdrawalRequestModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  availableBalance: number;
}

export default function WithdrawalRequestModal({
  open,
  onClose,
  onSuccess,
  availableBalance
}: WithdrawalRequestModalProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    pixKey: "",
    phone: "",
    amount: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const amount = parseFloat(formData.amount);
    
    // Validations
    if (!formData.fullName || !formData.pixKey || !formData.phone || !formData.amount) {
      toast.error("Preencha todos os campos");
      return;
    }
    
    if (amount < 30) {
      toast.error("Valor mínimo de saque é R$ 30,00");
      return;
    }
    
    if (amount > availableBalance) {
      toast.error("Saldo insuficiente");
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      // Get current wallet
      const { data: wallet } = await supabase
        .from("wallets")
        .select("available_balance")
        .eq("user_id", user.id)
        .single();

      if (!wallet || wallet.available_balance < amount) {
        throw new Error("Saldo insuficiente");
      }

      // Create withdrawal request
      const { error: requestError } = await supabase
        .from("withdrawal_requests")
        .insert({
          user_id: user.id,
          amount: amount,
          pix_key: formData.pixKey,
          full_name: formData.fullName,
          phone: formData.phone,
          status: "PENDING"
        });

      if (requestError) throw requestError;

      // Create transaction record
      const { error: txError } = await supabase
        .from("wallet_transactions")
        .insert({
          user_id: user.id,
          type: "WITHDRAWAL_REQUEST",
          amount: -amount,
          description: "Solicitação de saque via Pix"
        });

      if (txError) throw txError;

      // Update wallet balance
      const { error: walletError } = await supabase
        .from("wallets")
        .update({
          available_balance: wallet.available_balance - amount,
          updated_at: new Date().toISOString()
        })
        .eq("user_id", user.id);

      if (walletError) throw walletError;

      toast.success("Saque solicitado com sucesso! Será processado em até 48h.");
      setFormData({ fullName: "", pixKey: "", phone: "", amount: "" });
      onSuccess();
      onClose();

    } catch (error) {
      console.error("Error requesting withdrawal:", error);
      toast.error("Erro ao solicitar saque");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Solicitar Saque</DialogTitle>
          <DialogDescription>
            Preencha os dados para receber seu saque via Pix
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fullName">Nome Completo</Label>
            <Input
              id="fullName"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              placeholder="Seu nome completo"
              disabled={loading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pixKey">Chave Pix</Label>
            <Input
              id="pixKey"
              value={formData.pixKey}
              onChange={(e) => setFormData({ ...formData, pixKey: e.target.value })}
              placeholder="CPF, e-mail, telefone ou chave aleatória"
              disabled={loading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Telefone/WhatsApp</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="(00) 00000-0000"
              disabled={loading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Valor do Saque</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              min="30"
              max={availableBalance}
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              placeholder="30.00"
              disabled={loading}
            />
            <p className="text-xs text-muted-foreground">
              Saque mínimo: R$ 30,00 • Seu saldo: R$ {availableBalance.toFixed(2)}
            </p>
          </div>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-gradient-to-r from-[#FF6A00] via-[#FFC93C] to-[#FFE066] text-white"
            >
              {loading ? "Processando..." : "Solicitar Saque"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
