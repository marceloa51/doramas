import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lock, Play, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { getSessionId, clearSessionId, clearSupabaseAuthStorage } from "@/utils/sessionManager";

interface SecureVideoPlayerProps {
  dramaId: string;
  dramaTitle: string;
  coverUrl?: string;
  onPreviewFinished?: () => void;
}

const SecureVideoPlayer: React.FC<SecureVideoPlayerProps> = ({
  dramaId,
  dramaTitle,
  coverUrl,
  onPreviewFinished,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const [videoUrl, setVideoUrl] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [remainingSeconds, setRemainingSeconds] = useState<number | null>(null);

  const urlRenewalIntervalRef = useRef<number | null>(null);
  const progressIntervalRef = useRef<number | null>(null);
  const fingerprintRef = useRef<string>("");

  // Gerar fingerprint do dispositivo
  useEffect(() => {
    const generateFingerprint = async () => {
      const data = {
        userAgent: navigator.userAgent,
        language: navigator.language,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        screen: `${window.screen.width}x${window.screen.height}`,
        colorDepth: window.screen.colorDepth,
      };

      const encoder = new TextEncoder();
      const dataString = JSON.stringify(data);
      const buffer = await crypto.subtle.digest('SHA-256', encoder.encode(dataString));
      const hashArray = Array.from(new Uint8Array(buffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      
      fingerprintRef.current = hashHex;
    };

    generateFingerprint();
  }, []);

  const fetchVideoUrl = async () => {
    try {
      const sessionId = getSessionId();
      const { data, error } = await supabase.functions.invoke('generate-video-url', {
        body: {
          dramaId,
          userAgent: navigator.userAgent,
          fingerprint: fingerprintRef.current,
        },
        headers: {
          'x-session-id': sessionId || '',
        },
      });

      if (error) throw error;

      if (data?.error === 'PREVIEW_FINISHED') {
        console.log('[SecureVideoPlayer] Preview finished');
        setShowPaywall(true);
        setIsPlaying(false);
        if (onPreviewFinished) onPreviewFinished();
        return null;
      }

      if (data?.error === 'ANTI_SHARE_TRIGGERED') {
        console.warn('[SecureVideoPlayer] Anti-share triggered');
        toast({
          title: "Sessão bloqueada",
          description: data.message || "Detectamos acesso de outro dispositivo. Faça login novamente.",
          variant: "destructive",
        });
        setIsPlaying(false);
        clearSessionId();
        clearSupabaseAuthStorage();
        await supabase.auth.signOut();
        navigate('/auth');
        return null;
      }

      if (data?.videoUrl) {
        console.log('[SecureVideoPlayer] Got new video URL');
        setVideoUrl(data.videoUrl);
        setIsPreviewMode(data.isPreviewMode);
        if (data.remainingPreviewSeconds !== undefined) {
          setRemainingSeconds(data.remainingPreviewSeconds);
        }
        return data;
      }

      return null;
    } catch (error: any) {
      console.error('[SecureVideoPlayer] Error fetching video URL:', error);
      toast({
        title: "Erro ao carregar vídeo",
        description: error.message || "Tente novamente mais tarde",
        variant: "destructive",
      });
      return null;
    }
  };

  const trackProgress = async () => {
    if (!videoRef.current || !isPlaying) return;

    const currentTime = Math.floor(videoRef.current.currentTime);
    const duration = Math.floor(videoRef.current.duration || 0);

    try {
      const sessionId = getSessionId();
      const { data } = await supabase.functions.invoke('track-video-progress', {
        body: {
          dramaId,
          currentPosition: currentTime,
          totalDuration: duration,
        },
        headers: {
          'x-session-id': sessionId || '',
        },
      });

      if (data?.isPreviewFinished) {
        console.log('[SecureVideoPlayer] Preview finished during playback');
        setShowPaywall(true);
        setIsPlaying(false);
        if (videoRef.current) {
          videoRef.current.pause();
        }
        if (onPreviewFinished) onPreviewFinished();
      }

      if (data?.remainingPreviewSeconds !== undefined) {
        setRemainingSeconds(data.remainingPreviewSeconds);
      }
    } catch (error) {
      console.error('[SecureVideoPlayer] Error tracking progress:', error);
    }
  };

  // Iniciar reprodução
  const handlePlay = async () => {
    setLoading(true);
    
    const data = await fetchVideoUrl();
    
    if (data && videoRef.current) {
      // Aguardar o vídeo carregar
      videoRef.current.onloadedmetadata = () => {
        if (videoRef.current) {
          // Restaurar posição salva
          if (data.currentPosition > 0) {
            videoRef.current.currentTime = data.currentPosition;
          }
          videoRef.current.play();
          setIsPlaying(true);
          setLoading(false);

          // Iniciar renovação automática de URL a cada 50 segundos
          urlRenewalIntervalRef.current = window.setInterval(async () => {
            console.log('[SecureVideoPlayer] Renewing video URL');
            await fetchVideoUrl();
          }, 50000);

          // Iniciar rastreamento de progresso a cada 5 segundos
          progressIntervalRef.current = window.setInterval(() => {
            trackProgress();
          }, 5000);
        }
      };
    } else {
      setLoading(false);
    }
  };

  // Pausa
  const handlePause = () => {
    if (videoRef.current) {
      videoRef.current.pause();
    }
    setIsPlaying(false);
    trackProgress(); // Salvar progresso ao pausar
  };

  // Cleanup
  useEffect(() => {
    return () => {
      if (urlRenewalIntervalRef.current) {
        clearInterval(urlRenewalIntervalRef.current);
      }
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
      // Salvar progresso ao sair
      trackProgress();
    };
  }, []);

  // Prevenir ações indesejadas
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Bloquear F12, CTRL+S, CTRL+U, etc.
    if (
      e.key === 'F12' ||
      (e.ctrlKey && (e.key === 's' || e.key === 'u' || e.key === 'S' || e.key === 'U'))
    ) {
      e.preventDefault();
    }
  };

  if (showPaywall) {
    return (
      <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center">
        <Card className="p-4 sm:p-8 max-w-md mx-3 sm:mx-4 text-center bg-drama-card border-fire-orange">
          <div className="w-14 h-14 sm:w-20 sm:h-20 mx-auto mb-3 sm:mb-4 bg-fire-orange/20 rounded-full flex items-center justify-center">
            <Lock className="w-7 h-7 sm:w-10 sm:h-10 text-fire-orange" />
          </div>
          <h3 className="text-lg sm:text-2xl font-bold mb-2 text-white">Preview encerrado</h3>
          <p className="text-xs sm:text-base text-gray-300 mb-2">
            Você assistiu aos primeiros 25 minutos gratuitamente.
          </p>
          <p className="text-xs sm:text-base text-gray-300 mb-4 sm:mb-6">
            Assista <strong>{dramaTitle}</strong> completo por apenas <strong className="text-fire-orange">R$ 12,90</strong>!
          </p>
          <Button
            onClick={() => navigate(`/checkout/${dramaId}`)}
            className="w-full bg-gradient-to-r from-fire-orange via-fire-glow to-fire-bright hover:brightness-110 text-white font-semibold py-3 sm:py-4 text-sm sm:text-base"
          >
            <Lock className="w-4 h-4 mr-2" />
            Assistir Completo - R$ 12,90
          </Button>
        </Card>
      </div>
    );
  }

  if (!isPlaying) {
    return (
      <div
        className="relative w-full aspect-video bg-black rounded-lg overflow-hidden cursor-pointer group"
        style={{
          backgroundImage: coverUrl ? `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.7)), url(${coverUrl})` : 'none',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
        onClick={handlePlay}
      >
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          {loading ? (
            <Loader2 className="w-16 h-16 animate-spin text-drama-red" />
          ) : (
            <>
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-drama-red flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Play className="w-8 h-8 sm:w-10 sm:h-10 text-white ml-1" fill="currentColor" />
              </div>
              <p className="text-base sm:text-lg font-semibold">Assistir {dramaTitle}</p>
              {isPreviewMode && (
                <p className="text-white/80 text-xs sm:text-sm mt-2">
                  ⏱️ Prévia gratuita de 25 minutos
                </p>
              )}
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
      {isPreviewMode && remainingSeconds !== null && remainingSeconds > 0 && (
        <div className="absolute top-4 right-4 z-10 bg-drama-red/90 text-white px-3 py-1.5 rounded-lg text-sm font-semibold">
          ⏱️ {Math.floor(remainingSeconds / 60)}:{String(remainingSeconds % 60).padStart(2, '0')} restantes
        </div>
      )}
      
      <video
        ref={videoRef}
        src={videoUrl}
        className="w-full h-full"
        controls
        controlsList="nodownload"
        playsInline
        crossOrigin="anonymous"
        onContextMenu={handleContextMenu}
        onKeyDown={handleKeyDown}
        onPause={handlePause}
        onPlay={() => setIsPlaying(true)}
        onEnded={() => {
          setIsPlaying(false);
          trackProgress();
        }}
      >
        Seu navegador não suporta a reprodução de vídeos.
      </video>
    </div>
  );
};

export default SecureVideoPlayer;
