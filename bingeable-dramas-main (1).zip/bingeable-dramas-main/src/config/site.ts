/**
 * Configuração central do domínio oficial da aplicação
 * Usado para garantir que todas as URLs geradas usem o domínio correto
 */
export const SITE_URL = "https://doramassuper.site";
