export interface FAQItem {
  question: string;
  answer: string;
}

export interface TechnicalInfo {
  genres: string[];
  type: string;
  language: string;
  quality: string;
  audience: string;
  access: string;
  platform: string;
}

export interface DramaSEOPageContent {
  h1: string;
  metaTitle: string;
  metaDescription: string;
  content: string;
  introduction?: string;
  synopsis?: string;
  faq?: FAQItem[];
  technicalInfo?: TechnicalInfo;
}

export interface DramaSEOContent {
  name: string;
  slug: string;
  genre: string;
  synopsis: string;
  thumbnailAlt?: string;
  relatedSlugs?: string[];
  pages: {
    assistirDublado: DramaSEOPageContent;
    ondeAssistir: DramaSEOPageContent;
    comoAssistir: DramaSEOPageContent;
    completo: DramaSEOPageContent;
  };
}

export const seoContent: DramaSEOContent[] = [
  {
    name: "Esplendor de um Pai",
    slug: "esplendor-de-um-pai",
    genre: "Drama Familiar, Redenção",
    synopsis: "Um homem simples, desacreditado pela família e pela sociedade, descobre que tem dentro de si uma força que nunca imaginou.",
    pages: {
      assistirDublado: {
        h1: "Assistir Esplendor de um Pai Dublado Online",
        metaTitle: "Assistir Esplendor de um Pai Dublado | Doramas Super",
        metaDescription: "Assista Esplendor de um Pai dublado em português. Drama familiar emocionante sobre redenção e coragem. Streaming HD sem anúncios.",
        content: `Um homem simples, desacreditado pela família e pela sociedade, descobre uma força interior impressionante. Este drama familiar emocionante explora temas de redenção, amor paternal e a coragem de escolher o bem.`
      },
      ondeAssistir: {
        h1: "Onde Assistir Esplendor de um Pai Dublado e Completo",
        metaTitle: "Onde Assistir Esplendor de um Pai Completo | Doramas Super",
        metaDescription: "Descubra onde assistir Esplendor de um Pai completo e dublado. Disponível no Doramas Super com qualidade HD.",
        content: `Assista Esplendor de um Pai completo no Doramas Super. Streaming profissional em alta definição, sem anúncios.`
      },
      comoAssistir: {
        h1: "Como Assistir Esplendor de um Pai Dublado",
        metaTitle: "Como Assistir Esplendor de um Pai Dublado | Doramas Super",
        metaDescription: "Passo a passo para assistir Esplendor de um Pai dublado online no Doramas Super.",
        content: `Assista facilmente no Doramas Super. Acesso simples, qualidade premium, dublagem profissional.`
      },
      completo: {
        h1: "Esplendor de um Pai Completo e Dublado",
        metaTitle: "Esplendor de um Pai Completo e Dublado | Doramas Super",
        metaDescription: "Assista Esplendor de um Pai completo e dublado. Todos os episódios em HD no Doramas Super.",
        content: `Todos os episódios disponíveis no Doramas Super. Drama familiar completo e dublado em português.`
      }
    }
  },
  {
    name: "Fortuna e Poder em Minutos",
    slug: "fortuna-e-poder-em-minutos",
    genre: "Drama, Suspense, Ambição",
    synopsis: "Uma oportunidade misteriosa promete riqueza instantânea, mas cada escolha tem seu preço.",
    pages: {
      assistirDublado: {
        h1: "Assistir Fortuna e Poder em Minutos Dublado",
        metaTitle: "Assistir Fortuna e Poder em Minutos Dublado | Doramas Super",
        metaDescription: "Assista Fortuna e Poder em Minutos dublado. Drama intenso sobre ambição e escolhas. Streaming HD.",
        content: `Drama intenso sobre ambição, poder e as consequências das escolhas. Streaming de qualidade no Doramas Super.`
      },
      ondeAssistir: {
        h1: "Onde Assistir Fortuna e Poder em Minutos",
        metaTitle: "Onde Assistir Fortuna e Poder em Minutos | Doramas Super",
        metaDescription: "Descubra onde assistir Fortuna e Poder em Minutos completo e dublado no Doramas Super.",
        content: `Assista completo no Doramas Super com qualidade premium e sem anúncios.`
      },
      comoAssistir: {
        h1: "Como Assistir Fortuna e Poder em Minutos Dublado",
        metaTitle: "Como Assistir Fortuna e Poder em Minutos | Doramas Super",
        metaDescription: "Guia para assistir Fortuna e Poder em Minutos dublado no Doramas Super.",
        content: `Acesso fácil e direto no Doramas Super. Streaming profissional em alta definição.`
      },
      completo: {
        h1: "Fortuna e Poder em Minutos Completo e Dublado",
        metaTitle: "Fortuna e Poder em Minutos Completo | Doramas Super",
        metaDescription: "Assista Fortuna e Poder em Minutos completo e dublado em HD no Doramas Super.",
        content: `Todos os episódios disponíveis. Drama completo sobre ambição e poder.`
      }
    }
  },
  {
    name: "O Novato Mais Forte do Mundo",
    slug: "o-novato-mais-forte-do-mundo",
    genre: "Ação, Aventura, Superação",
    synopsis: "Um novato surpreende a todos revelando ser o mais forte. Ação e superação em cada episódio.",
    pages: {
      assistirDublado: {
        h1: "Assistir O Novato Mais Forte do Mundo Dublado",
        metaTitle: "Assistir O Novato Mais Forte do Mundo Dublado | Doramas Super",
        metaDescription: "Assista O Novato Mais Forte do Mundo dublado. Ação intensa e superação. Streaming HD.",
        content: `Ação vibrante e superação em cada episódio. Assista dublado no Doramas Super.`
      },
      ondeAssistir: {
        h1: "Onde Assistir O Novato Mais Forte do Mundo",
        metaTitle: "Onde Assistir O Novato Mais Forte do Mundo | Doramas Super",
        metaDescription: "Descubra onde assistir O Novato Mais Forte do Mundo completo no Doramas Super.",
        content: `Disponível completo no Doramas Super. Streaming de alta qualidade.`
      },
      comoAssistir: {
        h1: "Como Assistir O Novato Mais Forte do Mundo Dublado",
        metaTitle: "Como Assistir O Novato Mais Forte do Mundo | Doramas Super",
        metaDescription: "Guia para assistir O Novato Mais Forte do Mundo dublado online.",
        content: `Acesso simples no Doramas Super. Qualidade premium em português.`
      },
      completo: {
        h1: "O Novato Mais Forte do Mundo Completo e Dublado",
        metaTitle: "O Novato Mais Forte do Mundo Completo | Doramas Super",
        metaDescription: "Assista O Novato Mais Forte do Mundo completo e dublado no Doramas Super.",
        content: `Todos os episódios de ação e superação disponíveis no Doramas Super.`
      }
    }
  },
  {
    name: "Meu Companheiro é um Licano de Rua",
    slug: "meu-companheiro-e-um-licano-de-rua",
    genre: "Fantasia, Romance, Drama",
    synopsis: "Romance proibido entre humana e licano em fantasia urbana emocionante.",
    pages: {
      assistirDublado: {
        h1: "Assistir Meu Companheiro é um Licano de Rua Dublado",
        metaTitle: "Assistir Meu Companheiro é um Licano de Rua | Doramas Super",
        metaDescription: "Assista Meu Companheiro é um Licano de Rua dublado. Fantasia urbana e romance. Streaming HD.",
        content: `Fantasia urbana com romance intenso. Assista dublado no Doramas Super.`
      },
      ondeAssistir: {
        h1: "Onde Assistir Meu Companheiro é um Licano de Rua",
        metaTitle: "Onde Assistir Meu Companheiro é um Licano de Rua | Doramas Super",
        metaDescription: "Descubra onde assistir Meu Companheiro é um Licano de Rua completo no Doramas Super.",
        content: `Disponível completo no Doramas Super com qualidade premium.`
      },
      comoAssistir: {
        h1: "Como Assistir Meu Companheiro é um Licano de Rua Dublado",
        metaTitle: "Como Assistir Meu Companheiro é um Licano de Rua | Doramas Super",
        metaDescription: "Guia para assistir Meu Companheiro é um Licano de Rua dublado online.",
        content: `Acesso fácil no Doramas Super. Fantasia urbana em alta definição.`
      },
      completo: {
        h1: "Meu Companheiro é um Licano de Rua Completo e Dublado",
        metaTitle: "Meu Companheiro é um Licano de Rua Completo | Doramas Super",
        metaDescription: "Assista Meu Companheiro é um Licano de Rua completo no Doramas Super.",
        content: `Todos os episódios de fantasia urbana disponíveis no Doramas Super.`
      }
    }
  },
  {
    name: "A Imperatriz Esquecida",
    slug: "a-imperatriz-esquecida",
    genre: "Drama Histórico, Romance",
    synopsis: "Uma imperatriz esquecida luta para reconquistar seu lugar e revelar a verdade.",
    pages: {
      assistirDublado: {
        h1: "Assistir A Imperatriz Esquecida Dublado",
        metaTitle: "Assistir A Imperatriz Esquecida Dublado | Doramas Super",
        metaDescription: "Assista A Imperatriz Esquecida dublado. Drama histórico intenso. Streaming HD.",
        content: `Drama histórico envolvente sobre poder e verdade. Assista dublado no Doramas Super.`
      },
      ondeAssistir: {
        h1: "Onde Assistir A Imperatriz Esquecida",
        metaTitle: "Onde Assistir A Imperatriz Esquecida | Doramas Super",
        metaDescription: "Descubra onde assistir A Imperatriz Esquecida completo no Doramas Super.",
        content: `Disponível completo no Doramas Super. Streaming profissional.`
      },
      comoAssistir: {
        h1: "Como Assistir A Imperatriz Esquecida Dublado",
        metaTitle: "Como Assistir A Imperatriz Esquecida | Doramas Super",
        metaDescription: "Guia para assistir A Imperatriz Esquecida dublado online.",
        content: `Acesso simples no Doramas Super. Drama histórico em português.`
      },
      completo: {
        h1: "A Imperatriz Esquecida Completo e Dublado",
        metaTitle: "A Imperatriz Esquecida Completo | Doramas Super",
        metaDescription: "Assista A Imperatriz Esquecida completo e dublado no Doramas Super.",
        content: `Todos os episódios do drama histórico disponíveis no Doramas Super.`
      }
    }
  },
  {
    name: "Casamento Blindado: Um Contrato de Natal",
    slug: "casamento-blindado-um-contrato-de-natal",
    genre: "Romance, Drama, Natal",
    synopsis: "Um contrato de casamento natalino que se transforma em romance verdadeiro.",
    pages: {
      assistirDublado: {
        h1: "Assistir Casamento Blindado: Um Contrato de Natal Dublado",
        metaTitle: "Assistir Casamento Blindado Um Contrato de Natal | Doramas Super",
        metaDescription: "Assista Casamento Blindado: Um Contrato de Natal dublado. Romance natalino. Streaming HD.",
        content: `Romance natalino envolvente. Assista dublado no Doramas Super.`
      },
      ondeAssistir: {
        h1: "Onde Assistir Casamento Blindado: Um Contrato de Natal",
        metaTitle: "Onde Assistir Casamento Blindado Um Contrato de Natal | Doramas Super",
        metaDescription: "Descubra onde assistir Casamento Blindado: Um Contrato de Natal completo.",
        content: `Disponível completo no Doramas Super. Romance de Natal em HD.`
      },
      comoAssistir: {
        h1: "Como Assistir Casamento Blindado: Um Contrato de Natal Dublado",
        metaTitle: "Como Assistir Casamento Blindado Um Contrato de Natal | Doramas Super",
        metaDescription: "Guia para assistir Casamento Blindado: Um Contrato de Natal dublado.",
        content: `Acesso fácil no Doramas Super. Romance natalino em português.`
      },
      completo: {
        h1: "Casamento Blindado: Um Contrato de Natal Completo e Dublado",
        metaTitle: "Casamento Blindado Um Contrato de Natal Completo | Doramas Super",
        metaDescription: "Assista Casamento Blindado: Um Contrato de Natal completo no Doramas Super.",
        content: `Todos os episódios do romance natalino disponíveis no Doramas Super.`
      }
    }
  },
  {
    name: "Criando o Filho Bastardo do Meu Marido",
    slug: "criando-o-filho-bastardo-do-meu-marido",
    genre: "Drama, Família, Superação",
    synopsis: "Uma mulher decide criar o filho ilegítimo do marido, transformando dor em amor.",
    pages: {
      assistirDublado: {
        h1: "Assistir Criando o Filho Bastardo do Meu Marido Dublado",
        metaTitle: "Assistir Criando o Filho Bastardo do Meu Marido | Doramas Super",
        metaDescription: "Assista Criando o Filho Bastardo do Meu Marido dublado. Drama familiar intenso. Streaming HD.",
        content: `Drama familiar emocionante sobre superação e amor. Assista dublado no Doramas Super.`
      },
      ondeAssistir: {
        h1: "Onde Assistir Criando o Filho Bastardo do Meu Marido",
        metaTitle: "Onde Assistir Criando o Filho Bastardo do Meu Marido | Doramas Super",
        metaDescription: "Descubra onde assistir Criando o Filho Bastardo do Meu Marido completo.",
        content: `Disponível completo no Doramas Super. Drama familiar em alta qualidade.`
      },
      comoAssistir: {
        h1: "Como Assistir Criando o Filho Bastardo do Meu Marido Dublado",
        metaTitle: "Como Assistir Criando o Filho Bastardo do Meu Marido | Doramas Super",
        metaDescription: "Guia para assistir Criando o Filho Bastardo do Meu Marido dublado online.",
        content: `Acesso simples no Doramas Super. Drama familiar em português.`
      },
      completo: {
        h1: "Criando o Filho Bastardo do Meu Marido Completo e Dublado",
        metaTitle: "Criando o Filho Bastardo do Meu Marido Completo | Doramas Super",
        metaDescription: "Assista Criando o Filho Bastardo do Meu Marido completo no Doramas Super.",
        content: `Todos os episódios do drama familiar disponíveis no Doramas Super.`
      }
    }
  },
  // INDEX 7 - DEVOLVA MEU CARRO (OTIMIZADO)
  {
    name: "Devolva Meu Carro",
    slug: "devolva-meu-carro",
    genre: "Comédia, Ação, Aventura",
    synopsis: "Uma busca frenética para recuperar um carro roubado leva a situações hilárias e tensas.",
    thumbnailAlt: "Cena do dorama Devolva Meu Carro dublado em português",
    relatedSlugs: ["fortuna-e-poder-em-minutos", "o-novato-mais-forte-do-mundo", "criando-o-filho-bastardo-do-meu-marido"],
    pages: {
      assistirDublado: {
        h1: "Assistir Devolva Meu Carro Dublado Online em HD",
        metaTitle: "Assistir Devolva Meu Carro Dublado Online em HD | Doramas Super",
        metaDescription: "Assista Devolva Meu Carro dublado em português com qualidade HD. Comédia de ação sem anúncios no Doramas Super. Streaming rápido e seguro!",
        content: `Comédia de ação envolvente com momentos hilários e tensos. Assista Devolva Meu Carro dublado no Doramas Super com qualidade HD.`,
        introduction: `Está procurando onde assistir Devolva Meu Carro dublado online? Você chegou ao lugar certo! No Doramas Super, você pode assistir este dorama de comédia e ação com qualidade HD, dublagem profissional em português e sem interrupções de anúncios irritantes.

Devolva Meu Carro é um dos doramas mais procurados por fãs que adoram uma boa mistura de comédia com cenas de ação eletrizantes. A história envolvente e os personagens carismáticos fazem deste título uma escolha perfeita para maratonar no seu celular, computador ou smart TV.

Se você está cansado de procurar "Devolva Meu Carro dublado" em vários sites e só encontrar links quebrados ou com legendas ruins, pode relaxar. O Doramas Super oferece streaming profissional com servidores rápidos, player intuitivo e acesso imediato a todos os episódios completos.`,
        synopsis: `A história de Devolva Meu Carro começa quando o protagonista tem seu veículo roubado de forma completamente inesperada. O que parecia ser um simples roubo rapidamente se transforma em uma aventura caótica e absolutamente hilária, repleta de perseguições malucas, encontros inusitados e situações que vão do dramático ao completamente absurdo.

Misturando comédia física com momentos de tensão genuína, o dorama conquista o público com diálogos afiados e cenas que alternam entre o suspense de uma perseguição e o humor de situações cotidianas levadas ao extremo. Os personagens secundários adicionam camadas de complexidade à trama, cada um com suas próprias motivações, segredos e momentos de destaque.

Devolva Meu Carro é perfeito para quem busca entretenimento leve mas cheio de adrenalina. Se você gosta de histórias que combinam risadas com reviravoltas inesperadas, este dorama vai te prender do primeiro ao último episódio. A produção de qualidade e as atuações convincentes elevam ainda mais a experiência, tornando cada cena memorável.`,
        technicalInfo: {
          genres: ["Comédia", "Ação", "Aventura"],
          type: "Dorama / Série",
          language: "Dublado em Português",
          quality: "HD 1080p",
          audience: "Jovens e Adultos",
          access: "Streaming Imediato",
          platform: "Doramas Super"
        },
        faq: [
          {
            question: "Onde posso assistir Devolva Meu Carro dublado online?",
            answer: "Você pode assistir Devolva Meu Carro dublado em português no Doramas Super. A plataforma oferece streaming em HD sem anúncios, com acesso rápido e seguro a todos os episódios completos."
          },
          {
            question: "O dorama Devolva Meu Carro tem dublagem em português brasileiro?",
            answer: "Sim! No Doramas Super, Devolva Meu Carro está disponível com dublagem profissional em português brasileiro, permitindo que você aproveite toda a história sem precisar ler legendas."
          },
          {
            question: "Devolva Meu Carro está disponível em qualidade HD?",
            answer: "Sim, todos os episódios de Devolva Meu Carro estão disponíveis em qualidade HD 1080p no Doramas Super, garantindo a melhor experiência visual possível em qualquer dispositivo."
          },
          {
            question: "É seguro assistir doramas no Doramas Super?",
            answer: "Absolutamente! O Doramas Super é uma plataforma segura, sem pop-ups invasivos, sem vírus e sem redirecionamentos suspeitos. Você pode assistir tranquilamente no celular, tablet, PC ou smart TV."
          },
          {
            question: "O Doramas Super funciona em celular e smart TV?",
            answer: "Sim, o Doramas Super é totalmente responsivo e funciona perfeitamente em smartphones, tablets, computadores e smart TVs. Basta acessar pelo navegador e começar a assistir imediatamente."
          },
          {
            question: "Quantos episódios tem o dorama Devolva Meu Carro?",
            answer: "Devolva Meu Carro possui todos os episódios completos disponíveis para você maratonar no Doramas Super, do primeiro ao último, sem precisar esperar por novos lançamentos."
          }
        ]
      },
      ondeAssistir: {
        h1: "Onde Assistir Devolva Meu Carro Dublado e Completo Online",
        metaTitle: "Onde Assistir Devolva Meu Carro Dublado e Completo Online | Doramas Super",
        metaDescription: "Descubra onde assistir Devolva Meu Carro completo e dublado em português. Streaming HD sem anúncios no Doramas Super. Acesso rápido e seguro!",
        content: `Disponível completo no Doramas Super. Comédia de ação em HD com dublagem profissional.`,
        introduction: `Está procurando onde assistir Devolva Meu Carro dublado e completo online? Você chegou ao lugar certo! No Doramas Super, você pode assistir este dorama de comédia e ação com qualidade HD, dublagem profissional em português e sem interrupções de anúncios.

Devolva Meu Carro é um dos doramas mais procurados por fãs que adoram uma boa mistura de comédia com cenas de ação eletrizantes. A história envolvente e os personagens carismáticos fazem deste título uma escolha perfeita para maratonar no seu celular, computador ou smart TV.

Se você está cansado de procurar "Devolva Meu Carro onde assistir" em vários sites e só encontrar links quebrados ou com legendas ruins, pode relaxar. O Doramas Super oferece streaming profissional com servidores rápidos, player intuitivo e acesso imediato a todos os episódios de Devolva Meu Carro completo e dublado.`,
        synopsis: `A história de Devolva Meu Carro começa quando o protagonista tem seu veículo roubado de forma completamente inesperada. O que parecia ser um simples roubo rapidamente se transforma em uma aventura caótica e absolutamente hilária, repleta de perseguições malucas, encontros inusitados e situações que vão do dramático ao completamente absurdo.

Misturando comédia física com momentos de tensão genuína, o dorama conquista o público com diálogos afiados e cenas que alternam entre o suspense de uma perseguição e o humor de situações cotidianas levadas ao extremo. Os personagens secundários adicionam camadas de complexidade à trama, cada um com suas próprias motivações, segredos e momentos de destaque.

Devolva Meu Carro é perfeito para quem busca entretenimento leve mas cheio de adrenalina. Se você gosta de histórias que combinam risadas com reviravoltas inesperadas, este dorama vai te prender do primeiro ao último episódio. A produção de qualidade e as atuações convincentes elevam ainda mais a experiência, tornando cada cena memorável.`,
        technicalInfo: {
          genres: ["Comédia", "Ação", "Aventura"],
          type: "Dorama / Série",
          language: "Dublado em Português",
          quality: "HD 1080p",
          audience: "Jovens e Adultos",
          access: "Streaming Imediato",
          platform: "Doramas Super"
        },
        faq: [
          {
            question: "Onde assistir Devolva Meu Carro completo e dublado online?",
            answer: "Você pode assistir Devolva Meu Carro completo e dublado em português no Doramas Super. A plataforma oferece streaming em HD sem anúncios, com acesso rápido e seguro a todos os episódios."
          },
          {
            question: "Devolva Meu Carro tem versão dublada em português?",
            answer: "Sim! No Doramas Super, Devolva Meu Carro está disponível com dublagem profissional em português brasileiro, permitindo que você aproveite toda a história sem precisar ler legendas."
          },
          {
            question: "O dorama Devolva Meu Carro está disponível em HD?",
            answer: "Sim, todos os episódios de Devolva Meu Carro estão disponíveis em qualidade HD 1080p no Doramas Super, garantindo a melhor experiência visual possível."
          },
          {
            question: "É seguro assistir doramas no Doramas Super?",
            answer: "Absolutamente! O Doramas Super é uma plataforma segura, sem pop-ups invasivos, sem vírus e sem redirecionamentos suspeitos. Você pode assistir tranquilamente no celular, tablet, PC ou smart TV."
          },
          {
            question: "O acesso ao Doramas Super funciona em celular e TV?",
            answer: "Sim, o Doramas Super é totalmente responsivo e funciona perfeitamente em smartphones, tablets, computadores e smart TVs. Basta acessar pelo navegador e começar a assistir."
          },
          {
            question: "Quantos episódios tem Devolva Meu Carro?",
            answer: "Devolva Meu Carro possui todos os episódios completos disponíveis para você maratonar no Doramas Super, do primeiro ao último, sem precisar esperar."
          }
        ]
      },
      comoAssistir: {
        h1: "Como Assistir Devolva Meu Carro Dublado Online",
        metaTitle: "Como Assistir Devolva Meu Carro Dublado Online | Doramas Super",
        metaDescription: "Aprenda como assistir Devolva Meu Carro dublado online. Guia completo para assistir em HD no Doramas Super. Acesso fácil e rápido!",
        content: `Acesso fácil no Doramas Super. Comédia de ação em português com qualidade HD.`,
        introduction: `Quer saber como assistir Devolva Meu Carro dublado online? É muito simples! No Doramas Super, você acessa o dorama diretamente pelo navegador, sem precisar baixar aplicativos ou fazer cadastros complicados.

Basta acessar o Doramas Super, encontrar Devolva Meu Carro no catálogo e clicar em assistir. Em poucos segundos você já estará curtindo todos os episódios deste dorama hilário, com dublagem profissional em português e qualidade HD.

O processo é rápido e funciona em qualquer dispositivo: celular, tablet, computador ou smart TV. Não precisa de conhecimento técnico, não precisa de VPN, não precisa de nada especial. Só acessar e assistir!`,
        synopsis: `A história de Devolva Meu Carro começa quando o protagonista tem seu veículo roubado de forma inesperada. O que parecia ser um simples roubo rapidamente se transforma em uma aventura caótica e hilária, repleta de perseguições, encontros inusitados e situações que vão do dramático ao absurdo.

Misturando comédia física com momentos de tensão, o dorama conquista o público com diálogos afiados e cenas que alternam entre suspense e humor. Os personagens secundários adicionam camadas de complexidade à trama, cada um com suas próprias motivações e segredos.

Devolva Meu Carro é perfeito para quem busca entretenimento leve mas cheio de adrenalina. A produção de qualidade e as atuações convincentes elevam a experiência, tornando cada cena memorável.`,
        technicalInfo: {
          genres: ["Comédia", "Ação", "Aventura"],
          type: "Dorama / Série",
          language: "Dublado em Português",
          quality: "HD 1080p",
          audience: "Jovens e Adultos",
          access: "Streaming Imediato",
          platform: "Doramas Super"
        },
        faq: [
          {
            question: "Como faço para assistir Devolva Meu Carro dublado?",
            answer: "É muito simples! Acesse o Doramas Super pelo navegador, encontre Devolva Meu Carro e clique em assistir. Em segundos você já estará curtindo o dorama em HD."
          },
          {
            question: "Preciso baixar algum aplicativo para assistir?",
            answer: "Não! O Doramas Super funciona direto pelo navegador. Não precisa baixar nada, basta acessar o site e começar a assistir Devolva Meu Carro imediatamente."
          },
          {
            question: "Devolva Meu Carro está disponível com dublagem brasileira?",
            answer: "Sim! No Doramas Super, Devolva Meu Carro está disponível com dublagem profissional em português brasileiro de alta qualidade."
          },
          {
            question: "Posso assistir Devolva Meu Carro no celular?",
            answer: "Sim! O Doramas Super é totalmente responsivo e funciona perfeitamente em smartphones, tablets, computadores e smart TVs."
          },
          {
            question: "O streaming de Devolva Meu Carro é em HD?",
            answer: "Sim, todos os episódios estão disponíveis em qualidade HD 1080p, garantindo a melhor experiência visual em qualquer dispositivo."
          }
        ]
      },
      completo: {
        h1: "Devolva Meu Carro Completo e Dublado em HD",
        metaTitle: "Devolva Meu Carro Completo e Dublado em HD | Doramas Super",
        metaDescription: "Assista Devolva Meu Carro completo e dublado em HD. Todos os episódios disponíveis no Doramas Super. Streaming sem anúncios!",
        content: `Todos os episódios da comédia de ação disponíveis no Doramas Super. Assista Devolva Meu Carro completo e dublado em HD.`,
        introduction: `Procurando Devolva Meu Carro completo e dublado? No Doramas Super você encontra todos os episódios disponíveis para maratonar! Assista do primeiro ao último episódio sem precisar esperar, com qualidade HD e dublagem profissional em português.

Devolva Meu Carro é um dos doramas mais divertidos do catálogo, misturando comédia com ação de forma brilhante. Se você quer uma história envolvente com personagens carismáticos e situações hilárias, este é o dorama perfeito.

No Doramas Super, você assiste Devolva Meu Carro completo sem anúncios irritantes, sem pop-ups e com servidores rápidos. A experiência de streaming é profissional e você pode assistir em qualquer dispositivo.`,
        synopsis: `A história de Devolva Meu Carro começa quando o protagonista tem seu veículo roubado de forma completamente inesperada. O que parecia ser um simples roubo rapidamente se transforma em uma aventura caótica e hilária, repleta de perseguições, encontros inusitados e situações absurdas.

Misturando comédia física com momentos de tensão genuína, o dorama conquista o público com diálogos afiados e cenas que alternam entre suspense e humor. Os personagens secundários adicionam camadas de complexidade à trama, cada um com motivações próprias.

Devolva Meu Carro é perfeito para quem busca entretenimento leve mas cheio de adrenalina. Se você gosta de histórias que combinam risadas com reviravoltas inesperadas, este dorama vai te prender do primeiro ao último episódio.`,
        technicalInfo: {
          genres: ["Comédia", "Ação", "Aventura"],
          type: "Dorama / Série",
          language: "Dublado em Português",
          quality: "HD 1080p",
          audience: "Jovens e Adultos",
          access: "Streaming Imediato",
          platform: "Doramas Super"
        },
        faq: [
          {
            question: "Todos os episódios de Devolva Meu Carro estão disponíveis?",
            answer: "Sim! No Doramas Super você encontra Devolva Meu Carro completo, do primeiro ao último episódio, pronto para maratonar."
          },
          {
            question: "Devolva Meu Carro está dublado em português?",
            answer: "Sim! O dorama está disponível com dublagem profissional em português brasileiro, permitindo que você aproveite sem precisar ler legendas."
          },
          {
            question: "Qual a qualidade do streaming de Devolva Meu Carro?",
            answer: "Todos os episódios estão disponíveis em qualidade HD 1080p no Doramas Super, garantindo a melhor experiência visual."
          },
          {
            question: "Posso assistir Devolva Meu Carro na smart TV?",
            answer: "Sim! O Doramas Super funciona em smartphones, tablets, computadores e smart TVs. Basta acessar pelo navegador."
          },
          {
            question: "O Doramas Super tem anúncios durante o vídeo?",
            answer: "Não! No Doramas Super você assiste Devolva Meu Carro sem anúncios irritantes, sem pop-ups e sem interrupções."
          }
        ]
      }
    }
  },
  {
    name: "O Encanto da Virgem",
    slug: "o-encanto-da-virgem",
    genre: "Romance, Drama, Fantasia",
    synopsis: "Uma história de romance e mistério envolvendo uma virgem com poderes especiais.",
    pages: {
      assistirDublado: {
        h1: "Assistir O Encanto da Virgem Dublado",
        metaTitle: "Assistir O Encanto da Virgem Dublado | Doramas Super",
        metaDescription: "Assista O Encanto da Virgem dublado. Romance e fantasia. Streaming HD.",
        content: `Romance místico envolvente. Assista dublado no Doramas Super.`
      },
      ondeAssistir: {
        h1: "Onde Assistir O Encanto da Virgem",
        metaTitle: "Onde Assistir O Encanto da Virgem | Doramas Super",
        metaDescription: "Descubra onde assistir O Encanto da Virgem completo no Doramas Super.",
        content: `Disponível completo no Doramas Super. Romance místico em alta qualidade.`
      },
      comoAssistir: {
        h1: "Como Assistir O Encanto da Virgem Dublado",
        metaTitle: "Como Assistir O Encanto da Virgem | Doramas Super",
        metaDescription: "Guia para assistir O Encanto da Virgem dublado online.",
        content: `Acesso simples no Doramas Super. Romance místico em português.`
      },
      completo: {
        h1: "O Encanto da Virgem Completo e Dublado",
        metaTitle: "O Encanto da Virgem Completo | Doramas Super",
        metaDescription: "Assista O Encanto da Virgem completo e dublado no Doramas Super.",
        content: `Todos os episódios do romance místico disponíveis no Doramas Super.`
      }
    }
  }
];

// Helper function to find drama by slug
export const findDramaBySlug = (slug: string): DramaSEOContent | undefined => {
  return seoContent.find(drama => drama.slug === slug || drama.slug.replace(/[éáíóú]/g, (match) => {
    const accents: Record<string, string> = { 'é': 'e', 'á': 'a', 'í': 'i', 'ó': 'o', 'ú': 'u' };
    return accents[match] || match;
  }) === slug);
};

// Helper function to get drama index
export const getDramaIndex = (slug: string): number => {
  return seoContent.findIndex(drama => drama.slug === slug || drama.slug.replace(/[éáíóú]/g, (match) => {
    const accents: Record<string, string> = { 'é': 'e', 'á': 'a', 'í': 'i', 'ó': 'o', 'ú': 'u' };
    return accents[match] || match;
  }) === slug);
};
