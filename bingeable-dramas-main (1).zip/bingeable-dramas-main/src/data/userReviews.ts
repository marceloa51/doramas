export interface UserReview {
  name: string;
  rating: number;
  date: string;
  review: string;
  location: string;
}

export const userReviews: UserReview[] = [
  {
    name: "Maria Clara S.",
    rating: 5,
    date: "28 de Novembro de 2024",
    location: "São Paulo, SP",
    review: "Eu estava procurando há semanas um lugar confiável para assistir doramas dublados e finalmente encontrei o Doramas Super! A qualidade do vídeo é impressionante, sem travamentos, e a dublagem em português é muito bem feita. Já maratonei três doramas completos e recomendo para todas as minhas amigas. O player funciona super bem no meu celular e o melhor de tudo: sem propaganda irritante no meio do episódio! A experiência de assistir aqui é incomparável, nunca mais vou usar outro site."
  },
  {
    name: "João Pedro M.",
    rating: 5,
    date: "25 de Novembro de 2024",
    location: "Rio de Janeiro, RJ",
    review: "Sou muito exigente com qualidade de streaming e o Doramas Super superou todas as minhas expectativas. A imagem em HD é nítida, o carregamento é extremamente rápido e a interface do site é muito bonita e fácil de usar. Assisti esse dorama todo em um final de semana e já estou começando outro. A dublagem é profissional e natural, completamente diferente de outros sites por aí que usam dublagens amadoras. O investimento vale muito a pena, recomendo demais!"
  },
  {
    name: "Fernanda L.",
    rating: 5,
    date: "22 de Novembro de 2024",
    location: "Belo Horizonte, MG",
    review: "Descobri o Doramas Super por indicação de uma amiga do trabalho e não me arrependo nem um pouco! A experiência de assistir doramas dublados aqui é incomparável com qualquer outro serviço que já usei. O site é completamente seguro, não tem aqueles pop-ups suspeitos que aparecem em outros lugares, e os episódios carregam instantaneamente sem buffer. Já virei fã e assisto praticamente todos os dias depois do trabalho. A história desse dorama é emocionante demais, chorei em vários episódios!"
  },
  {
    name: "Lucas R.",
    rating: 5,
    date: "20 de Novembro de 2024",
    location: "Curitiba, PR",
    review: "O player do Doramas Super funciona perfeitamente na minha Smart TV, o que foi uma surpresa muito positiva. Outros sites de streaming sempre davam problema quando tentava espelhar a tela, mas aqui funciona liso demais. A qualidade de imagem é cinema, parece que estou assistindo na Netflix. Minha esposa também se viciou e agora assistimos juntos toda noite. A variedade de doramas disponíveis é excelente e a dublagem brasileira é muito bem produzida."
  },
  {
    name: "Amanda C.",
    rating: 5,
    date: "18 de Novembro de 2024",
    location: "Salvador, BA",
    review: "Chorei demais assistindo esse dorama no Doramas Super! A história é muito emocionante e a qualidade da dublagem faz você se conectar ainda mais com os personagens. Nunca tinha encontrado um site tão bom para assistir doramas em português. O carregamento dos episódios é instantâneo, nunca trava, e a interface é super intuitiva. Já indiquei para várias amigas e todas amaram também. Com certeza vou continuar assistindo todos os lançamentos por aqui!"
  },
  {
    name: "Rafael S.",
    rating: 5,
    date: "15 de Novembro de 2024",
    location: "Porto Alegre, RS",
    review: "Melhor site de doramas dublados que já usei na minha vida, e olha que já testei vários! A diferença de qualidade é gritante. Aqui no Doramas Super tudo funciona perfeitamente: o player não trava, a imagem é cristalina em HD, a dublagem é profissional com vozes que combinam com os personagens, e o site é bonito e organizado. Não tem comparação com aqueles sites cheios de propaganda e vírus. Vale cada centavo investido!"
  },
  {
    name: "Camila N.",
    rating: 5,
    date: "12 de Novembro de 2024",
    location: "Brasília, DF",
    review: "Assisto doramas no Doramas Super durante meu horário de almoço no trabalho e é perfeito porque carrega super rápido mesmo no 4G do celular. A interface mobile é muito bem feita e responsiva, diferente de outros sites que ficam bugados no celular. Já maratonei vários doramas aqui e a qualidade sempre é impecável. A dublagem em português facilita muito quando estou fazendo outras coisas ao mesmo tempo. Super recomendo para quem ama doramas!"
  },
  {
    name: "Gustavo T.",
    rating: 5,
    date: "10 de Novembro de 2024",
    location: "Recife, PE",
    review: "A dublagem do Doramas Super é muito natural e profissional, parece que foi feita por uma grande produtora. As vozes combinam perfeitamente com os personagens e as emoções são muito bem transmitidas. Minha mãe não consegue acompanhar legendas por causa da visão e agora ela pode assistir doramas comigo graças à dublagem de qualidade daqui. O site é fácil de navegar e encontrar o que procuramos. Experiência nota 10 em todos os aspectos!"
  },
  {
    name: "Patrícia M.",
    rating: 5,
    date: "8 de Novembro de 2024",
    location: "Fortaleza, CE",
    review: "Finalmente encontrei um lugar seguro e de qualidade para assistir meus doramas favoritos! O Doramas Super é simplesmente o melhor. Não preciso me preocupar com vírus ou propagandas invasivas, e a qualidade do streaming é excelente. Os episódios carregam em segundos e a imagem é linda. A dublagem brasileira é muito bem feita, com atores de voz talentosos. Já assisti vários doramas aqui e todos foram experiências incríveis. Recomendo de olhos fechados!"
  },
  {
    name: "Bruno H.",
    rating: 5,
    date: "5 de Novembro de 2024",
    location: "Goiânia, GO",
    review: "Comecei a assistir doramas por curiosidade e me viciei completamente graças ao Doramas Super! A plataforma é muito fácil de usar e a qualidade é impressionante. O que mais me surpreendeu foi a dublagem em português que é muito natural - não parece aquelas dublagens forçadas de outros lugares. O player funciona perfeitamente em qualquer dispositivo e nunca trava. Minha namorada também se apaixonou e agora assistimos juntos todo final de semana. Melhor descoberta do ano!"
  }
];
