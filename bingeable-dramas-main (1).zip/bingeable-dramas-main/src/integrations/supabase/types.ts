export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          ip_address: string | null
          new_data: Json | null
          old_data: Json | null
          record_id: string | null
          table_name: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          ip_address?: string | null
          new_data?: Json | null
          old_data?: Json | null
          record_id?: string | null
          table_name: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          ip_address?: string | null
          new_data?: Json | null
          old_data?: Json | null
          record_id?: string | null
          table_name?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      checkout_sessions: {
        Row: {
          abandoned_notified: boolean | null
          amount: number
          checkout_url: string | null
          created_at: string | null
          currency: string | null
          customer_name: string | null
          expired_at: string | null
          id: string
          items: Json
          paid_at: string | null
          payment_method: string | null
          pix_code: string | null
          reference_id: string
          status: string | null
          visitor_id: string | null
        }
        Insert: {
          abandoned_notified?: boolean | null
          amount: number
          checkout_url?: string | null
          created_at?: string | null
          currency?: string | null
          customer_name?: string | null
          expired_at?: string | null
          id?: string
          items: Json
          paid_at?: string | null
          payment_method?: string | null
          pix_code?: string | null
          reference_id: string
          status?: string | null
          visitor_id?: string | null
        }
        Update: {
          abandoned_notified?: boolean | null
          amount?: number
          checkout_url?: string | null
          created_at?: string | null
          currency?: string | null
          customer_name?: string | null
          expired_at?: string | null
          id?: string
          items?: Json
          paid_at?: string | null
          payment_method?: string | null
          pix_code?: string | null
          reference_id?: string
          status?: string | null
          visitor_id?: string | null
        }
        Relationships: []
      }
      dramas: {
        Row: {
          cover_url: string | null
          created_at: string | null
          duration_seconds: number | null
          file_url: string | null
          genres: string[] | null
          id: string
          is_premium: boolean | null
          price: number
          slug: string
          start_position_seconds: number | null
          status: string | null
          storage_path: string | null
          synopsis: string | null
          tags: string[] | null
          thumbnail_url: string | null
          title: string
          total_episodes: number | null
          updated_at: string | null
          video_url: string | null
          youtube_id: string | null
        }
        Insert: {
          cover_url?: string | null
          created_at?: string | null
          duration_seconds?: number | null
          file_url?: string | null
          genres?: string[] | null
          id?: string
          is_premium?: boolean | null
          price?: number
          slug: string
          start_position_seconds?: number | null
          status?: string | null
          storage_path?: string | null
          synopsis?: string | null
          tags?: string[] | null
          thumbnail_url?: string | null
          title: string
          total_episodes?: number | null
          updated_at?: string | null
          video_url?: string | null
          youtube_id?: string | null
        }
        Update: {
          cover_url?: string | null
          created_at?: string | null
          duration_seconds?: number | null
          file_url?: string | null
          genres?: string[] | null
          id?: string
          is_premium?: boolean | null
          price?: number
          slug?: string
          start_position_seconds?: number | null
          status?: string | null
          storage_path?: string | null
          synopsis?: string | null
          tags?: string[] | null
          thumbnail_url?: string | null
          title?: string
          total_episodes?: number | null
          updated_at?: string | null
          video_url?: string | null
          youtube_id?: string | null
        }
        Relationships: []
      }
      episodes: {
        Row: {
          created_at: string | null
          description: string | null
          drama_id: string
          duration: number | null
          episode_number: number
          id: string
          is_free: boolean | null
          thumbnail_url: string | null
          title: string
          updated_at: string | null
          video_url: string
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          drama_id: string
          duration?: number | null
          episode_number: number
          id?: string
          is_free?: boolean | null
          thumbnail_url?: string | null
          title: string
          updated_at?: string | null
          video_url: string
        }
        Update: {
          created_at?: string | null
          description?: string | null
          drama_id?: string
          duration?: number | null
          episode_number?: number
          id?: string
          is_free?: boolean | null
          thumbnail_url?: string | null
          title?: string
          updated_at?: string | null
          video_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "episodes_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
        ]
      }
      featured_dramas: {
        Row: {
          created_at: string | null
          drama_id: string
          id: string
          position: number
          section: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          drama_id: string
          id?: string
          position?: number
          section: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          drama_id?: string
          id?: string
          position?: number
          section?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "featured_dramas_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          created_at: string
          drama_id: string | null
          drama_title: string | null
          id: string
          ip_address: string | null
          phone: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          drama_id?: string | null
          drama_title?: string | null
          id?: string
          ip_address?: string | null
          phone: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          drama_id?: string | null
          drama_title?: string | null
          id?: string
          ip_address?: string | null
          phone?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "leads_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
        ]
      }
      movie_views: {
        Row: {
          created_at: string | null
          drama_id: string
          id: string
          is_preview_finished: boolean | null
          last_position_seconds: number | null
          preview_started_at: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          drama_id: string
          id?: string
          is_preview_finished?: boolean | null
          last_position_seconds?: number | null
          preview_started_at?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          drama_id?: string
          id?: string
          is_preview_finished?: boolean | null
          last_position_seconds?: number | null
          preview_started_at?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "movie_views_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
        ]
      }
      page_visits: {
        Row: {
          created_at: string
          id: string
          ip_hash: string | null
          page_path: string
          user_agent: string | null
          visitor_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          ip_hash?: string | null
          page_path?: string
          user_agent?: string | null
          visitor_id: string
        }
        Update: {
          created_at?: string
          id?: string
          ip_hash?: string | null
          page_path?: string
          user_agent?: string | null
          visitor_id?: string
        }
        Relationships: []
      }
      password_reset_requests: {
        Row: {
          attempts: number | null
          created_at: string | null
          expires_at: string
          id: string
          ip_address: string | null
          max_attempts: number | null
          otp_hash: string
          phone: string
          used: boolean | null
          verified: boolean | null
        }
        Insert: {
          attempts?: number | null
          created_at?: string | null
          expires_at: string
          id?: string
          ip_address?: string | null
          max_attempts?: number | null
          otp_hash: string
          phone: string
          used?: boolean | null
          verified?: boolean | null
        }
        Update: {
          attempts?: number | null
          created_at?: string | null
          expires_at?: string
          id?: string
          ip_address?: string | null
          max_attempts?: number | null
          otp_hash?: string
          phone?: string
          used?: boolean | null
          verified?: boolean | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          current_session_id: string | null
          email: string
          episodes_watched: number | null
          first_payment_processed: boolean
          free_months: number | null
          free_months_granted: number
          full_name: string | null
          id: string
          invites_confirmed: number | null
          is_active: boolean | null
          last_device: Json | null
          last_ip: string | null
          plan_renews_at: string | null
          plan_status: Database["public"]["Enums"]["plan_status"] | null
          ref_code: string | null
          referral_count: number | null
          referral_coupon_used: boolean
          referred_by: string | null
          total_watch_time: number | null
          updated_at: string | null
          username: string | null
          username_changed_at: string | null
          username_locked: boolean | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          current_session_id?: string | null
          email: string
          episodes_watched?: number | null
          first_payment_processed?: boolean
          free_months?: number | null
          free_months_granted?: number
          full_name?: string | null
          id: string
          invites_confirmed?: number | null
          is_active?: boolean | null
          last_device?: Json | null
          last_ip?: string | null
          plan_renews_at?: string | null
          plan_status?: Database["public"]["Enums"]["plan_status"] | null
          ref_code?: string | null
          referral_count?: number | null
          referral_coupon_used?: boolean
          referred_by?: string | null
          total_watch_time?: number | null
          updated_at?: string | null
          username?: string | null
          username_changed_at?: string | null
          username_locked?: boolean | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          current_session_id?: string | null
          email?: string
          episodes_watched?: number | null
          first_payment_processed?: boolean
          free_months?: number | null
          free_months_granted?: number
          full_name?: string | null
          id?: string
          invites_confirmed?: number | null
          is_active?: boolean | null
          last_device?: Json | null
          last_ip?: string | null
          plan_renews_at?: string | null
          plan_status?: Database["public"]["Enums"]["plan_status"] | null
          ref_code?: string | null
          referral_count?: number | null
          referral_coupon_used?: boolean
          referred_by?: string | null
          total_watch_time?: number | null
          updated_at?: string | null
          username?: string | null
          username_changed_at?: string | null
          username_locked?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_referred_by_fkey"
            columns: ["referred_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      search_queries: {
        Row: {
          clicked_drama_id: string | null
          created_at: string | null
          id: string
          query: string
          results_count: number | null
          user_id: string | null
        }
        Insert: {
          clicked_drama_id?: string | null
          created_at?: string | null
          id?: string
          query: string
          results_count?: number | null
          user_id?: string | null
        }
        Update: {
          clicked_drama_id?: string | null
          created_at?: string | null
          id?: string
          query?: string
          results_count?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "search_queries_clicked_drama_id_fkey"
            columns: ["clicked_drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "search_queries_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      transactions: {
        Row: {
          amount: number
          checkout_session_id: string | null
          created_at: string | null
          currency: string | null
          external_id: string | null
          id: string
          metadata: Json | null
          payment_method: Database["public"]["Enums"]["payment_method"]
          status: Database["public"]["Enums"]["transaction_status"] | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          amount: number
          checkout_session_id?: string | null
          created_at?: string | null
          currency?: string | null
          external_id?: string | null
          id?: string
          metadata?: Json | null
          payment_method: Database["public"]["Enums"]["payment_method"]
          status?: Database["public"]["Enums"]["transaction_status"] | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          amount?: number
          checkout_session_id?: string | null
          created_at?: string | null
          currency?: string | null
          external_id?: string | null
          id?: string
          metadata?: Json | null
          payment_method?: Database["public"]["Enums"]["payment_method"]
          status?: Database["public"]["Enums"]["transaction_status"] | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "transactions_checkout_session_id_fkey"
            columns: ["checkout_session_id"]
            isOneToOne: false
            referencedRelation: "checkout_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      upsell_purchases: {
        Row: {
          amount: number
          drama_ids: string[]
          id: string
          original_purchase_id: string | null
          purchased_at: string | null
          transaction_id: string | null
          user_id: string
        }
        Insert: {
          amount?: number
          drama_ids: string[]
          id?: string
          original_purchase_id?: string | null
          purchased_at?: string | null
          transaction_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          drama_ids?: string[]
          id?: string
          original_purchase_id?: string | null
          purchased_at?: string | null
          transaction_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "upsell_purchases_original_purchase_id_fkey"
            columns: ["original_purchase_id"]
            isOneToOne: false
            referencedRelation: "user_purchases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "upsell_purchases_transaction_id_fkey"
            columns: ["transaction_id"]
            isOneToOne: false
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_dramas: {
        Row: {
          created_at: string
          drama_id: string
          id: string
          last_watched_at: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          drama_id: string
          id?: string
          last_watched_at?: string
          status: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          drama_id?: string
          id?: string
          last_watched_at?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_dramas_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_dramas_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_purchases: {
        Row: {
          amount: number
          drama_id: string
          id: string
          purchased_at: string | null
          transaction_id: string | null
          user_id: string
        }
        Insert: {
          amount?: number
          drama_id: string
          id?: string
          purchased_at?: string | null
          transaction_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          drama_id?: string
          id?: string
          purchased_at?: string | null
          transaction_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_purchases_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_purchases_transaction_id_fkey"
            columns: ["transaction_id"]
            isOneToOne: false
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_sessions: {
        Row: {
          created_at: string | null
          fingerprint: string | null
          id: string
          ip_hash: string | null
          is_active: boolean | null
          last_activity_at: string | null
          session_token: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          fingerprint?: string | null
          id?: string
          ip_hash?: string | null
          is_active?: boolean | null
          last_activity_at?: string | null
          session_token: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          fingerprint?: string | null
          id?: string
          ip_hash?: string | null
          is_active?: boolean | null
          last_activity_at?: string | null
          session_token?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      video_views: {
        Row: {
          created_at: string | null
          device: string | null
          drama_id: string
          id: string
          user_id: string | null
          watch_duration: number | null
          watched_at: string | null
        }
        Insert: {
          created_at?: string | null
          device?: string | null
          drama_id: string
          id?: string
          user_id?: string | null
          watch_duration?: number | null
          watched_at?: string | null
        }
        Update: {
          created_at?: string | null
          device?: string | null
          drama_id?: string
          id?: string
          user_id?: string | null
          watch_duration?: number | null
          watched_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "video_views_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "video_views_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      wallet_transactions: {
        Row: {
          amount: number
          created_at: string
          description: string
          id: string
          type: Database["public"]["Enums"]["wallet_transaction_type"]
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          description: string
          id?: string
          type: Database["public"]["Enums"]["wallet_transaction_type"]
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string
          id?: string
          type?: Database["public"]["Enums"]["wallet_transaction_type"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallet_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      wallets: {
        Row: {
          available_balance: number
          created_at: string
          id: string
          total_earned: number
          total_withdrawn: number
          updated_at: string
          user_id: string
        }
        Insert: {
          available_balance?: number
          created_at?: string
          id?: string
          total_earned?: number
          total_withdrawn?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          available_balance?: number
          created_at?: string
          id?: string
          total_earned?: number
          total_withdrawn?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallets_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      watch_history: {
        Row: {
          completed: boolean | null
          created_at: string | null
          drama_id: string
          episode_id: string
          id: string
          last_watched_at: string | null
          progress: number | null
          user_id: string
        }
        Insert: {
          completed?: boolean | null
          created_at?: string | null
          drama_id: string
          episode_id: string
          id?: string
          last_watched_at?: string | null
          progress?: number | null
          user_id: string
        }
        Update: {
          completed?: boolean | null
          created_at?: string | null
          drama_id?: string
          episode_id?: string
          id?: string
          last_watched_at?: string | null
          progress?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "watch_history_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "watch_history_episode_id_fkey"
            columns: ["episode_id"]
            isOneToOne: false
            referencedRelation: "episodes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "watch_history_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      watch_progress: {
        Row: {
          created_at: string | null
          drama_id: string
          duration_seconds: number
          id: string
          position_seconds: number
          progress_percent: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          drama_id: string
          duration_seconds?: number
          id?: string
          position_seconds?: number
          progress_percent?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          drama_id?: string
          duration_seconds?: number
          id?: string
          position_seconds?: number
          progress_percent?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "watch_progress_drama_id_fkey"
            columns: ["drama_id"]
            isOneToOne: false
            referencedRelation: "dramas"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_events: {
        Row: {
          created_at: string | null
          event_type: string
          external_id: string
          id: string
          payload: Json
          processed_at: string | null
          provider: string | null
          status_processed: string | null
        }
        Insert: {
          created_at?: string | null
          event_type: string
          external_id: string
          id?: string
          payload: Json
          processed_at?: string | null
          provider?: string | null
          status_processed?: string | null
        }
        Update: {
          created_at?: string | null
          event_type?: string
          external_id?: string
          id?: string
          payload?: Json
          processed_at?: string | null
          provider?: string | null
          status_processed?: string | null
        }
        Relationships: []
      }
      whatsapp_events: {
        Row: {
          created_at: string | null
          error_message: string | null
          event_type: string
          id: string
          message_id: string | null
          phone: string
          reference_id: string | null
          sent_at: string | null
          status: string | null
        }
        Insert: {
          created_at?: string | null
          error_message?: string | null
          event_type: string
          id?: string
          message_id?: string | null
          phone: string
          reference_id?: string | null
          sent_at?: string | null
          status?: string | null
        }
        Update: {
          created_at?: string | null
          error_message?: string | null
          event_type?: string
          id?: string
          message_id?: string | null
          phone?: string
          reference_id?: string | null
          sent_at?: string | null
          status?: string | null
        }
        Relationships: []
      }
      withdrawal_requests: {
        Row: {
          admin_id: string | null
          admin_note: string | null
          amount: number
          created_at: string
          full_name: string
          id: string
          phone: string
          pix_key: string
          processed_at: string | null
          status: Database["public"]["Enums"]["withdrawal_status"]
          user_id: string
        }
        Insert: {
          admin_id?: string | null
          admin_note?: string | null
          amount: number
          created_at?: string
          full_name: string
          id?: string
          phone: string
          pix_key: string
          processed_at?: string | null
          status?: Database["public"]["Enums"]["withdrawal_status"]
          user_id: string
        }
        Update: {
          admin_id?: string | null
          admin_note?: string | null
          amount?: number
          created_at?: string
          full_name?: string
          id?: string
          phone?: string
          pix_key?: string
          processed_at?: string | null
          status?: Database["public"]["Enums"]["withdrawal_status"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "withdrawal_requests_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "withdrawal_requests_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_watch_episode: {
        Args: { episode_id: string; user_id: string }
        Returns: boolean
      }
      cleanup_inactive_sessions: { Args: never; Returns: undefined }
      cleanup_old_data: { Args: never; Returns: undefined }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      log_security_event: {
        Args: {
          p_action: string
          p_new_data?: Json
          p_old_data?: Json
          p_record_id?: string
          p_table_name: string
        }
        Returns: string
      }
    }
    Enums: {
      app_role: "user" | "admin"
      payment_method: "pix" | "card"
      plan_status: "none" | "pending" | "active" | "canceled"
      transaction_status: "pending" | "paid" | "failed" | "canceled"
      wallet_transaction_type:
        | "REFERRAL_BONUS"
        | "WITHDRAWAL_REQUEST"
        | "WITHDRAWAL_APPROVED"
        | "WITHDRAWAL_REJECTED"
        | "FREE_MONTH_BONUS"
        | "ADMIN_ADJUSTMENT"
      withdrawal_status: "PENDING" | "APPROVED" | "REJECTED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["user", "admin"],
      payment_method: ["pix", "card"],
      plan_status: ["none", "pending", "active", "canceled"],
      transaction_status: ["pending", "paid", "failed", "canceled"],
      wallet_transaction_type: [
        "REFERRAL_BONUS",
        "WITHDRAWAL_REQUEST",
        "WITHDRAWAL_APPROVED",
        "WITHDRAWAL_REJECTED",
        "FREE_MONTH_BONUS",
        "ADMIN_ADJUSTMENT",
      ],
      withdrawal_status: ["PENDING", "APPROVED", "REJECTED"],
    },
  },
} as const
