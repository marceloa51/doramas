import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export const usePurchases = () => {
  const [purchases, setPurchases] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPurchases();
  }, []);

  const loadPurchases = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setPurchases([]);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("user_purchases")
        .select("drama_id")
        .eq("user_id", session.user.id);

      if (error) throw error;

      const dramaIds = data?.map((p) => p.drama_id) || [];
      setPurchases(dramaIds);
    } catch (error) {
      console.error("Error loading purchases:", error);
    } finally {
      setLoading(false);
    }
  };

  const hasPurchased = (dramaId: string) => purchases.includes(dramaId);

  const refreshPurchases = () => {
    loadPurchases();
  };

  return { purchases, hasPurchased, loading, refreshPurchases };
};
