import { useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { AffiliatePopup } from "@/components/AffiliatePopup";
import { trackPageVisit } from "@/utils/trackVisit";
import Home from "./pages/Home";
import Explore from "./pages/Explore";
import Auth from "./pages/Auth";
import ForgotPassword from "./pages/auth/ForgotPassword";
import ResetPassword from "./pages/auth/ResetPassword";
import Movie from "./pages/Movie";
import Paywall from "./pages/Paywall";
import DramaCheckout from "./pages/DramaCheckout";
import UpsellOffer from "./pages/UpsellOffer";
import ReceberCompra from "./pages/ReceberCompra";
import MeusDoramas from "./pages/MeusDoramas";
import Profile from "./pages/Profile";
import ReferralRedirect from "./pages/ReferralRedirect";
import NotFound from "./pages/NotFound";
import PaymentSuccess from "./pages/PaymentSuccess";
import PaymentCanceled from "./pages/PaymentCanceled";
import PaymentConfirmed from "./pages/PaymentConfirmed";
import Dashboard from "./pages/admin/Dashboard";
import ManageDramas from "./pages/admin/ManageDramas";
import ManageUsers from "./pages/admin/ManageUsers";
import ManagePayments from "./pages/admin/ManagePayments";
import Reports from "./pages/admin/Reports";
import ManageEpisodes from "./pages/admin/ManageEpisodes";
import ManageFeatured from "./pages/admin/ManageFeatured";
import Withdrawals from "./pages/admin/Withdrawals";
import Leads from "./pages/admin/Leads";
import Notifications from "./pages/admin/Notifications";
import PlanManagement from "./pages/admin/PlanManagement";
import Wallet from "./pages/Wallet";
import InitializeAdmins from "./pages/InitializeAdmins";
import VIP from "./pages/VIP";

// SEO Pages - Esplendor de um Pai
import AssistirEsplendorPaiDublado from "./pages/seo/esplendor-pai/AssistirDublado";
import OndeAssistirEsplendorPai from "./pages/seo/esplendor-pai/OndeAssistir";
import ComoAssistirEsplendorPai from "./pages/seo/esplendor-pai/ComoAssistir";
import EsplendorPaiCompleto from "./pages/seo/esplendor-pai/Completo";

// SEO Pages - Fortuna e Poder em Minutos
import AssistirFortunaPoderDublado from "./pages/seo/fortuna-poder/AssistirDublado";
import OndeAssistirFortunaPoder from "./pages/seo/fortuna-poder/OndeAssistir";
import ComoAssistirFortunaPoder from "./pages/seo/fortuna-poder/ComoAssistir";
import FortunaPoderCompleto from "./pages/seo/fortuna-poder/Completo";

// SEO Pages - O Novato Mais Forte do Mundo
import AssistirNovatoMaisForteDublado from "./pages/seo/novato-mais-forte/AssistirDublado";
import OndeAssistirNovatoMaisForte from "./pages/seo/novato-mais-forte/OndeAssistir";
import ComoAssistirNovatoMaisForte from "./pages/seo/novato-mais-forte/ComoAssistir";
import NovatoMaisForteCompleto from "./pages/seo/novato-mais-forte/Completo";

// SEO Pages - Meu Companheiro é um Licano de Rua
import AssistirLicanoRuaDublado from "./pages/seo/licano-rua/AssistirDublado";
import OndeAssistirLicanoRua from "./pages/seo/licano-rua/OndeAssistir";
import ComoAssistirLicanoRua from "./pages/seo/licano-rua/ComoAssistir";
import LicanoRuaCompleto from "./pages/seo/licano-rua/Completo";

// SEO Pages - A Imperatriz Esquecida
import AssistirAImperatrizEsquecidaDublado from "./pages/seo/a-imperatriz-esquecida/AssistirDublado";
import OndeAssistirAImperatrizEsquecida from "./pages/seo/a-imperatriz-esquecida/OndeAssistir";
import ComoAssistirAImperatrizEsquecida from "./pages/seo/a-imperatriz-esquecida/ComoAssistir";
import AImperatrizEsquecidaCompleto from "./pages/seo/a-imperatriz-esquecida/Completo";

// SEO Pages - Casamento Blindado: Um Contrato de Natal
import AssistirCasamentoBlindadoDublado from "./pages/seo/casamento-blindado/AssistirDublado";
import OndeAssistirCasamentoBlindado from "./pages/seo/casamento-blindado/OndeAssistir";
import ComoAssistirCasamentoBlindado from "./pages/seo/casamento-blindado/ComoAssistir";
import CasamentoBlindadoCompleto from "./pages/seo/casamento-blindado/Completo";

// SEO Pages - Criando o Filho Bastardo do Meu Marido
import AssistirCriandoFilhoBastardoDublado from "./pages/seo/criando-filho-bastardo/AssistirDublado";
import OndeAssistirCriandoFilhoBastardo from "./pages/seo/criando-filho-bastardo/OndeAssistir";
import ComoAssistirCriandoFilhoBastardo from "./pages/seo/criando-filho-bastardo/ComoAssistir";
import CriandoFilhoBastardoCompleto from "./pages/seo/criando-filho-bastardo/Completo";

// SEO Pages - Devolva Meu Carro
import AssistirDevolvaMeuCarroDublado from "./pages/seo/devolva-meu-carro/AssistirDublado";
import OndeAssistirDevolvaMeuCarro from "./pages/seo/devolva-meu-carro/OndeAssistir";
import ComoAssistirDevolvaMeuCarro from "./pages/seo/devolva-meu-carro/ComoAssistir";
import DevolvaMeuCarroCompleto from "./pages/seo/devolva-meu-carro/Completo";

// SEO Pages - O Encanto da Virgem
import AssistirOEncantoDaVirgemDublado from "./pages/seo/o-encanto-da-virgem/AssistirDublado";
import OndeAssistirOEncantoDaVirgem from "./pages/seo/o-encanto-da-virgem/OndeAssistir";
import ComoAssistirOEncantoDaVirgem from "./pages/seo/o-encanto-da-virgem/ComoAssistir";
import OEncantoDaVirgemCompleto from "./pages/seo/o-encanto-da-virgem/Completo";


const queryClient = new QueryClient();

const App = () => {
  useEffect(() => {
    trackPageVisit();
  }, []);

  return (
  <QueryClientProvider client={queryClient}>
    <HelmetProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          {/* <AffiliatePopup /> */}
        <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/explorar" element={<Explore />} />
              <Route path="/ref/:username" element={<ReferralRedirect />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/auth/forgot-password" element={<ForgotPassword />} />
              <Route path="/auth/reset-password" element={<ResetPassword />} />
          <Route path="/movie/:slug" element={<Movie />} />
          <Route path="/paywall" element={<Paywall />} />
          <Route path="/vip" element={<VIP />} />
          <Route path="/checkout/:slug" element={<DramaCheckout />} />
          <Route path="/upsell" element={<UpsellOffer />} />
          <Route path="/receber-compra" element={<ReceberCompra />} />
          <Route path="/meus-doramas" element={<MeusDoramas />} />
          <Route path="/pagamento-confirmado" element={<PaymentConfirmed />} />
          <Route path="/pagamento-sucesso" element={<PaymentSuccess />} />
          <Route path="/pagamento-cancelado" element={<PaymentCanceled />} />
          <Route path="/perfil" element={<Profile />} />
          <Route path="/wallet" element={<Wallet />} />
          <Route path="/admin" element={<Dashboard />} />
          <Route path="/admin/dramas" element={<ManageDramas />} />
          <Route path="/admin/users" element={<ManageUsers />} />
          <Route path="/admin/payments" element={<ManagePayments />} />
          <Route path="/admin/reports" element={<Reports />} />
          <Route path="/admin/featured" element={<ManageFeatured />} />
          <Route path="/admin/withdrawals" element={<Withdrawals />} />
          <Route path="/admin/leads" element={<Leads />} />
          <Route path="/admin/notifications" element={<Notifications />} />
          <Route path="/admin/episodes/:dramaId" element={<ManageEpisodes />} />
          <Route path="/admin/plans" element={<PlanManagement />} />
          <Route path="/initialize-admins" element={<InitializeAdmins />} />

          {/* SEO ROUTES - Esplendor de um Pai */}
          <Route path="/assistir-esplendor-de-um-pai-dublado" element={<AssistirEsplendorPaiDublado />} />
          <Route path="/onde-assistir-esplendor-de-um-pai-dublado-e-completo" element={<OndeAssistirEsplendorPai />} />
          <Route path="/como-assistir-esplendor-de-um-pai-dublado" element={<ComoAssistirEsplendorPai />} />
          <Route path="/esplendor-de-um-pai-completo-e-dublado" element={<EsplendorPaiCompleto />} />

          {/* SEO ROUTES - Fortuna e Poder em Minutos */}
          <Route path="/assistir-fortuna-e-poder-em-minutos-dublado" element={<AssistirFortunaPoderDublado />} />
          <Route path="/onde-assistir-fortuna-e-poder-em-minutos-dublado-e-completo" element={<OndeAssistirFortunaPoder />} />
          <Route path="/como-assistir-fortuna-e-poder-em-minutos-dublado" element={<ComoAssistirFortunaPoder />} />
          <Route path="/fortuna-e-poder-em-minutos-completo-e-dublado" element={<FortunaPoderCompleto />} />

          {/* SEO ROUTES - O Novato Mais Forte do Mundo */}
          <Route path="/assistir-o-novato-mais-forte-do-mundo-dublado" element={<AssistirNovatoMaisForteDublado />} />
          <Route path="/onde-assistir-o-novato-mais-forte-do-mundo-dublado-e-completo" element={<OndeAssistirNovatoMaisForte />} />
          <Route path="/como-assistir-o-novato-mais-forte-do-mundo-dublado" element={<ComoAssistirNovatoMaisForte />} />
          <Route path="/o-novato-mais-forte-do-mundo-completo-e-dublado" element={<NovatoMaisForteCompleto />} />

          {/* SEO ROUTES - Meu Companheiro é um Licano de Rua */}
          <Route path="/assistir-meu-companheiro-e-um-licano-de-rua-dublado" element={<AssistirLicanoRuaDublado />} />
          <Route path="/onde-assistir-meu-companheiro-e-um-licano-de-rua-dublado-e-completo" element={<OndeAssistirLicanoRua />} />
          <Route path="/como-assistir-meu-companheiro-e-um-licano-de-rua-dublado" element={<ComoAssistirLicanoRua />} />
          <Route path="/meu-companheiro-e-um-licano-de-rua-completo-e-dublado" element={<LicanoRuaCompleto />} />

          {/* SEO ROUTES - A Imperatriz Esquecida */}
          <Route path="/assistir-a-imperatriz-esquecida-dublado" element={<AssistirAImperatrizEsquecidaDublado />} />
          <Route path="/onde-assistir-a-imperatriz-esquecida-dublado-e-completo" element={<OndeAssistirAImperatrizEsquecida />} />
          <Route path="/como-assistir-a-imperatriz-esquecida-dublado" element={<ComoAssistirAImperatrizEsquecida />} />
          <Route path="/a-imperatriz-esquecida-completo-e-dublado" element={<AImperatrizEsquecidaCompleto />} />

          {/* SEO ROUTES - Casamento Blindado: Um Contrato de Natal */}
          <Route path="/assistir-casamento-blindado-um-contrato-de-natal-dublado" element={<AssistirCasamentoBlindadoDublado />} />
          <Route path="/onde-assistir-casamento-blindado-um-contrato-de-natal-dublado-e-completo" element={<OndeAssistirCasamentoBlindado />} />
          <Route path="/como-assistir-casamento-blindado-um-contrato-de-natal-dublado" element={<ComoAssistirCasamentoBlindado />} />
          <Route path="/casamento-blindado-um-contrato-de-natal-completo-e-dublado" element={<CasamentoBlindadoCompleto />} />

          {/* SEO ROUTES - Criando o Filho Bastardo do Meu Marido */}
          <Route path="/assistir-criando-o-filho-bastardo-do-meu-marido-dublado" element={<AssistirCriandoFilhoBastardoDublado />} />
          <Route path="/onde-assistir-criando-o-filho-bastardo-do-meu-marido-dublado-e-completo" element={<OndeAssistirCriandoFilhoBastardo />} />
          <Route path="/como-assistir-criando-o-filho-bastardo-do-meu-marido-dublado" element={<ComoAssistirCriandoFilhoBastardo />} />
          <Route path="/criando-o-filho-bastardo-do-meu-marido-completo-e-dublado" element={<CriandoFilhoBastardoCompleto />} />

          {/* SEO ROUTES - Devolva Meu Carro */}
          <Route path="/assistir-devolva-meu-carro-dublado" element={<AssistirDevolvaMeuCarroDublado />} />
          <Route path="/onde-assistir-devolva-meu-carro-dublado-e-completo" element={<OndeAssistirDevolvaMeuCarro />} />
          <Route path="/como-assistir-devolva-meu-carro-dublado" element={<ComoAssistirDevolvaMeuCarro />} />
          <Route path="/devolva-meu-carro-completo-e-dublado" element={<DevolvaMeuCarroCompleto />} />

          {/* SEO ROUTES - O Encanto da Virgem */}
          <Route path="/assistir-o-encanto-da-virgem-dublado" element={<AssistirOEncantoDaVirgemDublado />} />
          <Route path="/onde-assistir-o-encanto-da-virgem-dublado-e-completo" element={<OndeAssistirOEncantoDaVirgem />} />
          <Route path="/como-assistir-o-encanto-da-virgem-dublado" element={<ComoAssistirOEncantoDaVirgem />} />
          <Route path="/o-encanto-da-virgem-completo-e-dublado" element={<OEncantoDaVirgemCompleto />} />


          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
      </TooltipProvider>
    </HelmetProvider>
  </QueryClientProvider>
  );
};

export default App;
